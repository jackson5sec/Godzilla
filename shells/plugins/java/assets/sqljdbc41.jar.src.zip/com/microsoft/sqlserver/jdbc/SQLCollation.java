/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.EnumSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLCollation
/*     */   implements Serializable
/*     */ {
/*     */   private final int info;
/*     */   private final int sortId;
/*     */   private final Encoding encoding;
/*     */   
/*     */   private final int langID() {
/*  31 */     return this.info & 0xFFFF;
/*     */   }
/*     */ 
/*     */   
/*     */   final String getCharset() {
/*  36 */     return this.encoding.charsetName(); }
/*  37 */   final boolean supportsAsciiConversion() { return this.encoding.supportsAsciiConversion(); } final boolean hasAsciiCompatibleSBCS() {
/*  38 */     return this.encoding.hasAsciiCompatibleSBCS();
/*     */   } static final int tdsLength() {
/*  40 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLCollation(TDSReader paramTDSReader) throws UnsupportedEncodingException, SQLServerException {
/*  54 */     this.info = paramTDSReader.readInt();
/*  55 */     this.sortId = paramTDSReader.readUnsignedByte();
/*     */     
/*  57 */     this.encoding = (0 == this.sortId) ? encodingFromLCID() : encodingFromSortId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeCollation(TDSWriter paramTDSWriter) throws SQLServerException {
/*  66 */     paramTDSWriter.writeInt(this.info);
/*  67 */     paramTDSWriter.writeByte((byte)(this.sortId & 0xFF));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum WindowsLocale
/*     */   {
/*  87 */     ar_SA(1025, Encoding.CP1256),
/*  88 */     bg_BG(1026, Encoding.CP1251),
/*  89 */     ca_ES(1027, Encoding.CP1252),
/*  90 */     zh_TW(1028, Encoding.CP950),
/*  91 */     cs_CZ(1029, Encoding.CP1250),
/*  92 */     da_DK(1030, Encoding.CP1252),
/*  93 */     de_DE(1031, Encoding.CP1252),
/*  94 */     el_GR(1032, Encoding.CP1253),
/*  95 */     en_US(1033, Encoding.CP1252),
/*  96 */     es_ES_tradnl(1034, Encoding.CP1252),
/*  97 */     fi_FI(1035, Encoding.CP1252),
/*  98 */     fr_FR(1036, Encoding.CP1252),
/*  99 */     he_IL(1037, Encoding.CP1255),
/* 100 */     hu_HU(1038, Encoding.CP1250),
/* 101 */     is_IS(1039, Encoding.CP1252),
/* 102 */     it_IT(1040, Encoding.CP1252),
/* 103 */     ja_JP(1041, Encoding.CP932),
/* 104 */     ko_KR(1042, Encoding.CP949),
/* 105 */     nl_NL(1043, Encoding.CP1252),
/* 106 */     nb_NO(1044, Encoding.CP1252),
/* 107 */     pl_PL(1045, Encoding.CP1250),
/* 108 */     pt_BR(1046, Encoding.CP1252),
/* 109 */     rm_CH(1047, Encoding.CP1252),
/* 110 */     ro_RO(1048, Encoding.CP1250),
/* 111 */     ru_RU(1049, Encoding.CP1251),
/* 112 */     hr_HR(1050, Encoding.CP1250),
/* 113 */     sk_SK(1051, Encoding.CP1250),
/* 114 */     sq_AL(1052, Encoding.CP1250),
/* 115 */     sv_SE(1053, Encoding.CP1252),
/* 116 */     th_TH(1054, Encoding.CP874),
/* 117 */     tr_TR(1055, Encoding.CP1254),
/* 118 */     ur_PK(1056, Encoding.CP1256),
/* 119 */     id_ID(1057, Encoding.CP1252),
/* 120 */     uk_UA(1058, Encoding.CP1251),
/* 121 */     be_BY(1059, Encoding.CP1251),
/* 122 */     sl_SI(1060, Encoding.CP1250),
/* 123 */     et_EE(1061, Encoding.CP1257),
/* 124 */     lv_LV(1062, Encoding.CP1257),
/* 125 */     lt_LT(1063, Encoding.CP1257),
/* 126 */     tg_Cyrl_TJ(1064, Encoding.CP1251),
/* 127 */     fa_IR(1065, Encoding.CP1256),
/* 128 */     vi_VN(1066, Encoding.CP1258),
/* 129 */     hy_AM(1067, Encoding.CP1252),
/* 130 */     az_Latn_AZ(1068, Encoding.CP1254),
/* 131 */     eu_ES(1069, Encoding.CP1252),
/* 132 */     wen_DE(1070, Encoding.CP1252),
/* 133 */     mk_MK(1071, Encoding.CP1251),
/* 134 */     tn_ZA(1074, Encoding.CP1252),
/* 135 */     xh_ZA(1076, Encoding.CP1252),
/* 136 */     zu_ZA(1077, Encoding.CP1252),
/* 137 */     Af_ZA(1078, Encoding.CP1252),
/* 138 */     ka_GE(1079, Encoding.CP1252),
/* 139 */     fo_FO(1080, Encoding.CP1252),
/* 140 */     hi_IN(1081, Encoding.UNICODE),
/* 141 */     mt_MT(1082, Encoding.UNICODE),
/* 142 */     se_NO(1083, Encoding.CP1252),
/* 143 */     ms_MY(1086, Encoding.CP1252),
/* 144 */     kk_KZ(1087, Encoding.CP1251),
/* 145 */     ky_KG(1088, Encoding.CP1251),
/* 146 */     sw_KE(1089, Encoding.CP1252),
/* 147 */     tk_TM(1090, Encoding.CP1250),
/* 148 */     uz_Latn_UZ(1091, Encoding.CP1254),
/* 149 */     tt_RU(1092, Encoding.CP1251),
/* 150 */     bn_IN(1093, Encoding.UNICODE),
/* 151 */     pa_IN(1094, Encoding.UNICODE),
/* 152 */     gu_IN(1095, Encoding.UNICODE),
/* 153 */     or_IN(1096, Encoding.UNICODE),
/* 154 */     ta_IN(1097, Encoding.UNICODE),
/* 155 */     te_IN(1098, Encoding.UNICODE),
/* 156 */     kn_IN(1099, Encoding.UNICODE),
/* 157 */     ml_IN(1100, Encoding.UNICODE),
/* 158 */     as_IN(1101, Encoding.UNICODE),
/* 159 */     mr_IN(1102, Encoding.UNICODE),
/* 160 */     sa_IN(1103, Encoding.UNICODE),
/* 161 */     mn_MN(1104, Encoding.CP1251),
/* 162 */     bo_CN(1105, Encoding.UNICODE),
/* 163 */     cy_GB(1106, Encoding.CP1252),
/* 164 */     km_KH(1107, Encoding.UNICODE),
/* 165 */     lo_LA(1108, Encoding.UNICODE),
/* 166 */     gl_ES(1110, Encoding.CP1252),
/* 167 */     kok_IN(1111, Encoding.UNICODE),
/* 168 */     syr_SY(1114, Encoding.UNICODE),
/* 169 */     si_LK(1115, Encoding.UNICODE),
/* 170 */     iu_Cans_CA(1117, Encoding.CP1252),
/* 171 */     am_ET(1118, Encoding.CP1252),
/* 172 */     ne_NP(1121, Encoding.UNICODE),
/* 173 */     fy_NL(1122, Encoding.CP1252),
/* 174 */     ps_AF(1123, Encoding.UNICODE),
/* 175 */     fil_PH(1124, Encoding.CP1252),
/* 176 */     dv_MV(1125, Encoding.UNICODE),
/* 177 */     ha_Latn_NG(1128, Encoding.CP1252),
/* 178 */     yo_NG(1130, Encoding.CP1252),
/* 179 */     quz_BO(1131, Encoding.CP1252),
/* 180 */     nso_ZA(1132, Encoding.CP1252),
/* 181 */     ba_RU(1133, Encoding.CP1251),
/* 182 */     lb_LU(1134, Encoding.CP1252),
/* 183 */     kl_GL(1135, Encoding.CP1252),
/* 184 */     ig_NG(1136, Encoding.CP1252),
/* 185 */     ii_CN(1144, Encoding.CP1252),
/* 186 */     arn_CL(1146, Encoding.CP1252),
/* 187 */     moh_CA(1148, Encoding.CP1252),
/* 188 */     br_FR(1150, Encoding.CP1252),
/* 189 */     ug_CN(1152, Encoding.CP1256),
/* 190 */     mi_NZ(1153, Encoding.UNICODE),
/* 191 */     oc_FR(1154, Encoding.CP1252),
/* 192 */     co_FR(1155, Encoding.CP1252),
/* 193 */     gsw_FR(1156, Encoding.CP1252),
/* 194 */     sah_RU(1157, Encoding.CP1251),
/* 195 */     qut_GT(1158, Encoding.CP1252),
/* 196 */     rw_RW(1159, Encoding.CP1252),
/* 197 */     wo_SN(1160, Encoding.CP1252),
/* 198 */     prs_AF(1164, Encoding.CP1256),
/* 199 */     ar_IQ(2049, Encoding.CP1256),
/* 200 */     zh_CN(2052, Encoding.CP936),
/* 201 */     de_CH(2055, Encoding.CP1252),
/* 202 */     en_GB(2057, Encoding.CP1252),
/* 203 */     es_MX(2058, Encoding.CP1252),
/* 204 */     fr_BE(2060, Encoding.CP1252),
/* 205 */     it_CH(2064, Encoding.CP1252),
/* 206 */     nl_BE(2067, Encoding.CP1252),
/* 207 */     nn_NO(2068, Encoding.CP1252),
/* 208 */     pt_PT(2070, Encoding.CP1252),
/* 209 */     sr_Latn_CS(2074, Encoding.CP1250),
/* 210 */     sv_FI(2077, Encoding.CP1252),
/* 211 */     Lithuanian_Classic(2087, Encoding.CP1257),
/* 212 */     az_Cyrl_AZ(2092, Encoding.CP1251),
/* 213 */     dsb_DE(2094, Encoding.CP1252),
/* 214 */     se_SE(2107, Encoding.CP1252),
/* 215 */     ga_IE(2108, Encoding.CP1252),
/* 216 */     ms_BN(2110, Encoding.CP1252),
/* 217 */     uz_Cyrl_UZ(2115, Encoding.CP1251),
/* 218 */     bn_BD(2117, Encoding.UNICODE),
/* 219 */     mn_Mong_CN(2128, Encoding.CP1251),
/* 220 */     iu_Latn_CA(2141, Encoding.CP1252),
/* 221 */     tzm_Latn_DZ(2143, Encoding.CP1252),
/* 222 */     quz_EC(2155, Encoding.CP1252),
/* 223 */     ar_EG(3073, Encoding.CP1256),
/* 224 */     zh_HK(3076, Encoding.CP950),
/* 225 */     de_AT(3079, Encoding.CP1252),
/* 226 */     en_AU(3081, Encoding.CP1252),
/* 227 */     es_ES(3082, Encoding.CP1252),
/* 228 */     fr_CA(3084, Encoding.CP1252),
/* 229 */     sr_Cyrl_CS(3098, Encoding.CP1251),
/* 230 */     se_FI(3131, Encoding.CP1252),
/* 231 */     quz_PE(3179, Encoding.CP1252),
/* 232 */     ar_LY(4097, Encoding.CP1256),
/* 233 */     zh_SG(4100, Encoding.CP936),
/* 234 */     de_LU(4103, Encoding.CP1252),
/* 235 */     en_CA(4105, Encoding.CP1252),
/* 236 */     es_GT(4106, Encoding.CP1252),
/* 237 */     fr_CH(4108, Encoding.CP1252),
/* 238 */     hr_BA(4122, Encoding.CP1250),
/* 239 */     smj_NO(4155, Encoding.CP1252),
/* 240 */     ar_DZ(5121, Encoding.CP1256),
/* 241 */     zh_MO(5124, Encoding.CP950),
/* 242 */     de_LI(5127, Encoding.CP1252),
/* 243 */     en_NZ(5129, Encoding.CP1252),
/* 244 */     es_CR(5130, Encoding.CP1252),
/* 245 */     fr_LU(5132, Encoding.CP1252),
/* 246 */     bs_Latn_BA(5146, Encoding.CP1250),
/* 247 */     smj_SE(5179, Encoding.CP1252),
/* 248 */     ar_MA(6145, Encoding.CP1256),
/* 249 */     en_IE(6153, Encoding.CP1252),
/* 250 */     es_PA(6154, Encoding.CP1252),
/* 251 */     fr_MC(6156, Encoding.CP1252),
/* 252 */     sr_Latn_BA(6170, Encoding.CP1250),
/* 253 */     sma_NO(6203, Encoding.CP1252),
/* 254 */     ar_TN(7169, Encoding.CP1256),
/* 255 */     en_ZA(7177, Encoding.CP1252),
/* 256 */     es_DO(7178, Encoding.CP1252),
/* 257 */     sr_Cyrl_BA(7194, Encoding.CP1251),
/* 258 */     sma_SB(7227, Encoding.CP1252),
/* 259 */     ar_OM(8193, Encoding.CP1256),
/* 260 */     en_JM(8201, Encoding.CP1252),
/* 261 */     es_VE(8202, Encoding.CP1252),
/* 262 */     bs_Cyrl_BA(8218, Encoding.CP1251),
/* 263 */     sms_FI(8251, Encoding.CP1252),
/* 264 */     ar_YE(9217, Encoding.CP1256),
/* 265 */     en_CB(9225, Encoding.CP1252),
/* 266 */     es_CO(9226, Encoding.CP1252),
/* 267 */     smn_FI(9275, Encoding.CP1252),
/* 268 */     ar_SY(10241, Encoding.CP1256),
/* 269 */     en_BZ(10249, Encoding.CP1252),
/* 270 */     es_PE(10250, Encoding.CP1252),
/* 271 */     ar_JO(11265, Encoding.CP1256),
/* 272 */     en_TT(11273, Encoding.CP1252),
/* 273 */     es_AR(11274, Encoding.CP1252),
/* 274 */     ar_LB(12289, Encoding.CP1256),
/* 275 */     en_ZW(12297, Encoding.CP1252),
/* 276 */     es_EC(12298, Encoding.CP1252),
/* 277 */     ar_KW(13313, Encoding.CP1256),
/* 278 */     en_PH(13321, Encoding.CP1252),
/* 279 */     es_CL(13322, Encoding.CP1252),
/* 280 */     ar_AE(14337, Encoding.CP1256),
/* 281 */     es_UY(14346, Encoding.CP1252),
/* 282 */     ar_BH(15361, Encoding.CP1256),
/* 283 */     es_PY(15370, Encoding.CP1252),
/* 284 */     ar_QA(16385, Encoding.CP1256),
/* 285 */     en_IN(16393, Encoding.CP1252),
/* 286 */     es_BO(16394, Encoding.CP1252),
/* 287 */     en_MY(17417, Encoding.CP1252),
/* 288 */     es_SV(17418, Encoding.CP1252),
/* 289 */     en_SG(18441, Encoding.CP1252),
/* 290 */     es_HN(18442, Encoding.CP1252),
/* 291 */     es_NI(19466, Encoding.CP1252),
/* 292 */     es_PR(20490, Encoding.CP1252),
/* 293 */     es_US(21514, Encoding.CP1252);
/*     */     
/*     */     private final int langID;
/*     */     
/*     */     private final Encoding encoding;
/*     */     
/*     */     WindowsLocale(int param1Int1, Encoding param1Encoding) {
/* 300 */       this.langID = param1Int1;
/* 301 */       this.encoding = param1Encoding;
/*     */     }
/*     */ 
/*     */     
/*     */     final Encoding getEncoding() throws UnsupportedEncodingException {
/* 306 */       return this.encoding.checkSupported();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Encoding encodingFromLCID() throws UnsupportedEncodingException {
/* 316 */     WindowsLocale windowsLocale = localeIndex.get(Integer.valueOf(langID()));
/*     */     
/* 318 */     if (null == windowsLocale) {
/*     */       
/* 320 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownLCID"));
/* 321 */       Object[] arrayOfObject = { Integer.toHexString(langID()).toUpperCase() };
/* 322 */       throw new UnsupportedEncodingException(messageFormat.format(arrayOfObject));
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 327 */       return windowsLocale.getEncoding();
/*     */     }
/* 329 */     catch (UnsupportedEncodingException unsupportedEncodingException1) {
/*     */       
/* 331 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownLCID"));
/* 332 */       Object[] arrayOfObject = { windowsLocale };
/* 333 */       UnsupportedEncodingException unsupportedEncodingException2 = new UnsupportedEncodingException(messageFormat.format(arrayOfObject));
/* 334 */       unsupportedEncodingException2.initCause(unsupportedEncodingException1);
/* 335 */       throw unsupportedEncodingException2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   enum SortOrder
/*     */   {
/* 347 */     BIN_CP437(30, "SQL_Latin1_General_CP437_BIN", Encoding.CP437),
/* 348 */     DICTIONARY_437(31, "SQL_Latin1_General_CP437_CS_AS", Encoding.CP437),
/* 349 */     NOCASE_437(32, "SQL_Latin1_General_CP437_CI_AS", Encoding.CP437),
/* 350 */     NOCASEPREF_437(33, "SQL_Latin1_General_Pref_CP437_CI_AS", Encoding.CP437),
/* 351 */     NOACCENTS_437(34, "SQL_Latin1_General_CP437_CI_AI", Encoding.CP437),
/* 352 */     BIN2_CP437(35, "SQL_Latin1_General_CP437_BIN2", Encoding.CP437),
/*     */     
/* 354 */     BIN_CP850(40, "SQL_Latin1_General_CP850_BIN", Encoding.CP850),
/* 355 */     DICTIONARY_850(41, "SQL_Latin1_General_CP850_CS_AS", Encoding.CP850),
/* 356 */     NOCASE_850(42, "SQL_Latin1_General_CP850_CI_AS", Encoding.CP850),
/* 357 */     NOCASEPREF_850(43, "SQL_Latin1_General_Pref_CP850_CI_AS", Encoding.CP850),
/* 358 */     NOACCENTS_850(44, "SQL_Latin1_General_CP850_CI_AI", Encoding.CP850),
/* 359 */     BIN2_CP850(45, "SQL_Latin1_General_CP850_BIN2", Encoding.CP850),
/*     */     
/* 361 */     CASELESS_34(49, "SQL_1xCompat_CP850_CI_AS", Encoding.CP850),
/* 362 */     BIN_ISO_1(50, "bin_iso_1", Encoding.CP1252),
/* 363 */     DICTIONARY_ISO(51, "SQL_Latin1_General_CP1_CS_AS", Encoding.CP1252),
/* 364 */     NOCASE_ISO(52, "SQL_Latin1_General_CP1_CI_AS", Encoding.CP1252),
/* 365 */     NOCASEPREF_ISO(53, "SQL_Latin1_General_Pref_CP1_CI_AS", Encoding.CP1252),
/* 366 */     NOACCENTS_ISO(54, "SQL_Latin1_General_CP1_CI_AI", Encoding.CP1252),
/* 367 */     ALT_DICTIONARY(55, "SQL_AltDiction_CP850_CS_AS", Encoding.CP850),
/* 368 */     ALT_NOCASEPREF(56, "SQL_AltDiction_Pref_CP850_CI_AS", Encoding.CP850),
/* 369 */     ALT_NOACCENTS(57, "SQL_AltDiction_CP850_CI_AI", Encoding.CP850),
/* 370 */     SCAND_NOCASEPREF(58, "SQL_Scandinavian_Pref_CP850_CI_AS", Encoding.CP850),
/* 371 */     SCAND_DICTIONARY(59, "SQL_Scandinavian_CP850_CS_AS", Encoding.CP850),
/* 372 */     SCAND_NOCASE(60, "SQL_Scandinavian_CP850_CI_AS", Encoding.CP850),
/* 373 */     ALT_NOCASE(61, "SQL_AltDiction_CP850_CI_AS", Encoding.CP850),
/*     */     
/* 375 */     DICTIONARY_1252(71, "dictionary_1252", Encoding.CP1252),
/* 376 */     NOCASE_1252(72, "nocase_1252", Encoding.CP1252),
/* 377 */     DNK_NOR_DICTIONARY(73, "dnk_nor_dictionary", Encoding.CP1252),
/* 378 */     FIN_SWE_DICTIONARY(74, "fin_swe_dictionary", Encoding.CP1252),
/* 379 */     ISL_DICTIONARY(75, "isl_dictionary", Encoding.CP1252),
/*     */     
/* 381 */     BIN_CP1250(80, "bin_cp1250", Encoding.CP1250),
/* 382 */     DICTIONARY_1250(81, "SQL_Latin1_General_CP1250_CS_AS", Encoding.CP1250),
/* 383 */     NOCASE_1250(82, "SQL_Latin1_General_CP1250_CI_AS", Encoding.CP1250),
/* 384 */     CSYDIC(83, "SQL_Czech_CP1250_CS_AS", Encoding.CP1250),
/* 385 */     CSYNC(84, "SQL_Czech_CP1250_CI_AS", Encoding.CP1250),
/* 386 */     HUNDIC(85, "SQL_Hungarian_CP1250_CS_AS", Encoding.CP1250),
/* 387 */     HUNNC(86, "SQL_Hungarian_CP1250_CI_AS", Encoding.CP1250),
/* 388 */     PLKDIC(87, "SQL_Polish_CP1250_CS_AS", Encoding.CP1250),
/* 389 */     PLKNC(88, "SQL_Polish_CP1250_CI_AS", Encoding.CP1250),
/* 390 */     ROMDIC(89, "SQL_Romanian_CP1250_CS_AS", Encoding.CP1250),
/* 391 */     ROMNC(90, "SQL_Romanian_CP1250_CI_AS", Encoding.CP1250),
/* 392 */     SHLDIC(91, "SQL_Croatian_CP1250_CS_AS", Encoding.CP1250),
/* 393 */     SHLNC(92, "SQL_Croatian_CP1250_CI_AS", Encoding.CP1250),
/* 394 */     SKYDIC(93, "SQL_Slovak_CP1250_CS_AS", Encoding.CP1250),
/* 395 */     SKYNC(94, "SQL_Slovak_CP1250_CI_AS", Encoding.CP1250),
/* 396 */     SLVDIC(95, "SQL_Slovenian_CP1250_CS_AS", Encoding.CP1250),
/* 397 */     SLVNC(96, "SQL_Slovenian_CP1250_CI_AS", Encoding.CP1250),
/* 398 */     POLISH_CS(97, "polish_cs", Encoding.CP1250),
/* 399 */     POLISH_CI(98, "polish_ci", Encoding.CP1250),
/*     */     
/* 401 */     BIN_CP1251(104, "bin_cp1251", Encoding.CP1251),
/* 402 */     DICTIONARY_1251(105, "SQL_Latin1_General_CP1251_CS_AS", Encoding.CP1251),
/* 403 */     NOCASE_1251(106, "SQL_Latin1_General_CP1251_CI_AS", Encoding.CP1251),
/* 404 */     UKRDIC(107, "SQL_Ukrainian_CP1251_CS_AS", Encoding.CP1251),
/* 405 */     UKRNC(108, "SQL_Ukrainian_CP1251_CI_AS", Encoding.CP1251),
/*     */     
/* 407 */     BIN_CP1253(112, "bin_cp1253", Encoding.CP1253),
/* 408 */     DICTIONARY_1253(113, "SQL_Latin1_General_CP1253_CS_AS", Encoding.CP1253),
/* 409 */     NOCASE_1253(114, "SQL_Latin1_General_CP1253_CI_AS", Encoding.CP1253),
/*     */     
/* 411 */     GREEK_MIXEDDICTIONARY(120, "SQL_MixDiction_CP1253_CS_AS", Encoding.CP1253),
/* 412 */     GREEK_ALTDICTIONARY(121, "SQL_AltDiction_CP1253_CS_AS", Encoding.CP1253),
/* 413 */     GREEK_ALTDICTIONARY2(122, "SQL_AltDiction2_CP1253_CS_AS", Encoding.CP1253),
/* 414 */     GREEK_NOCASEDICT(124, "SQL_Latin1_General_CP1253_CI_AI", Encoding.CP1253),
/* 415 */     BIN_CP1254(128, "bin_cp1254", Encoding.CP1254),
/* 416 */     DICTIONARY_1254(129, "SQL_Latin1_General_CP1254_CS_AS", Encoding.CP1254),
/* 417 */     NOCASE_1254(130, "SQL_Latin1_General_CP1254_CI_AS", Encoding.CP1254),
/*     */     
/* 419 */     BIN_CP1255(136, "bin_cp1255", Encoding.CP1255),
/* 420 */     DICTIONARY_1255(137, "SQL_Latin1_General_CP1255_CS_AS", Encoding.CP1255),
/* 421 */     NOCASE_1255(138, "SQL_Latin1_General_CP1255_CI_AS", Encoding.CP1255),
/*     */     
/* 423 */     BIN_CP1256(144, "bin_cp1256", Encoding.CP1256),
/* 424 */     DICTIONARY_1256(145, "SQL_Latin1_General_CP1256_CS_AS", Encoding.CP1256),
/* 425 */     NOCASE_1256(146, "SQL_Latin1_General_CP1256_CI_AS", Encoding.CP1256),
/*     */     
/* 427 */     BIN_CP1257(152, "bin_cp1257", Encoding.CP1257),
/* 428 */     DICTIONARY_1257(153, "SQL_Latin1_General_CP1257_CS_AS", Encoding.CP1257),
/* 429 */     NOCASE_1257(154, "SQL_Latin1_General_CP1257_CI_AS", Encoding.CP1257),
/* 430 */     ETIDIC(155, "SQL_Estonian_CP1257_CS_AS", Encoding.CP1257),
/* 431 */     ETINC(156, "SQL_Estonian_CP1257_CI_AS", Encoding.CP1257),
/* 432 */     LVIDIC(157, "SQL_Latvian_CP1257_CS_AS", Encoding.CP1257),
/* 433 */     LVINC(158, "SQL_Latvian_CP1257_CI_AS", Encoding.CP1257),
/* 434 */     LTHDIC(159, "SQL_Lithuanian_CP1257_CS_AS", Encoding.CP1257),
/* 435 */     LTHNC(160, "SQL_Lithuanian_CP1257_CI_AS", Encoding.CP1257),
/*     */     
/* 437 */     DANNO_NOCASEPREF(183, "SQL_Danish_Pref_CP1_CI_AS", Encoding.CP1252),
/* 438 */     SVFI1_NOCASEPREF(184, "SQL_SwedishPhone_Pref_CP1_CI_AS", Encoding.CP1252),
/* 439 */     SVFI2_NOCASEPREF(185, "SQL_SwedishStd_Pref_CP1_CI_AS", Encoding.CP1252),
/* 440 */     ISLAN_NOCASEPREF(186, "SQL_Icelandic_Pref_CP1_CI_AS", Encoding.CP1252),
/*     */     
/* 442 */     BIN_CP932(192, "bin_cp932", Encoding.CP932),
/* 443 */     NLS_CP932(193, "nls_cp932", Encoding.CP932),
/* 444 */     BIN_CP949(194, "bin_cp949", Encoding.CP949),
/* 445 */     NLS_CP949(195, "nls_cp949", Encoding.CP949),
/* 446 */     BIN_CP950(196, "bin_cp950", Encoding.CP950),
/* 447 */     NLS_CP950(197, "nls_cp950", Encoding.CP950),
/* 448 */     BIN_CP936(198, "bin_cp936", Encoding.CP936),
/* 449 */     NLS_CP936(199, "nls_cp936", Encoding.CP936),
/* 450 */     NLS_CP932_CS(200, "nls_cp932_cs", Encoding.CP932),
/* 451 */     NLS_CP949_CS(201, "nls_cp949_cs", Encoding.CP949),
/* 452 */     NLS_CP950_CS(202, "nls_cp950_cs", Encoding.CP950),
/* 453 */     NLS_CP936_CS(203, "nls_cp936_cs", Encoding.CP936),
/* 454 */     BIN_CP874(204, "bin_cp874", Encoding.CP874),
/* 455 */     NLS_CP874(205, "nls_cp874", Encoding.CP874),
/* 456 */     NLS_CP874_CS(206, "nls_cp874_cs", Encoding.CP874),
/*     */     
/* 458 */     EBCDIC_037(210, "SQL_EBCDIC037_CP1_CS_AS", Encoding.CP1252),
/* 459 */     EBCDIC_273(211, "SQL_EBCDIC273_CP1_CS_AS", Encoding.CP1252),
/* 460 */     EBCDIC_277(212, "SQL_EBCDIC277_CP1_CS_AS", Encoding.CP1252),
/* 461 */     EBCDIC_278(213, "SQL_EBCDIC278_CP1_CS_AS", Encoding.CP1252),
/* 462 */     EBCDIC_280(214, "SQL_EBCDIC280_CP1_CS_AS", Encoding.CP1252),
/* 463 */     EBCDIC_284(215, "SQL_EBCDIC284_CP1_CS_AS", Encoding.CP1252),
/* 464 */     EBCDIC_285(216, "SQL_EBCDIC285_CP1_CS_AS", Encoding.CP1252),
/* 465 */     EBCDIC_297(217, "SQL_EBCDIC297_CP1_CS_AS", Encoding.CP1252);
/*     */     
/*     */     private final int sortId;
/*     */     private final String name;
/*     */     private final Encoding encoding;
/*     */     
/*     */     final Encoding getEncoding() throws UnsupportedEncodingException {
/* 472 */       return this.encoding.checkSupported();
/*     */     }
/*     */ 
/*     */     
/*     */     SortOrder(int param1Int1, String param1String1, Encoding param1Encoding) {
/* 477 */       this.sortId = param1Int1;
/* 478 */       this.name = param1String1;
/* 479 */       this.encoding = param1Encoding;
/*     */     }
/*     */     public final String toString() {
/* 482 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Encoding encodingFromSortId() throws UnsupportedEncodingException {
/* 489 */     SortOrder sortOrder = sortOrderIndex.get(Integer.valueOf(this.sortId));
/*     */     
/* 491 */     if (null == sortOrder) {
/*     */       
/* 493 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownSortId"));
/* 494 */       Object[] arrayOfObject = { Integer.valueOf(this.sortId) };
/* 495 */       throw new UnsupportedEncodingException(messageFormat.format(arrayOfObject));
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 500 */       return sortOrder.getEncoding();
/*     */     }
/* 502 */     catch (UnsupportedEncodingException unsupportedEncodingException1) {
/*     */       
/* 504 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownSortId"));
/* 505 */       Object[] arrayOfObject = { sortOrder };
/* 506 */       UnsupportedEncodingException unsupportedEncodingException2 = new UnsupportedEncodingException(messageFormat.format(arrayOfObject));
/* 507 */       unsupportedEncodingException2.initCause(unsupportedEncodingException1);
/* 508 */       throw unsupportedEncodingException2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 516 */   private static final Map<Integer, WindowsLocale> localeIndex = new HashMap<>(); static {
/* 517 */     for (WindowsLocale windowsLocale : EnumSet.<WindowsLocale>allOf(WindowsLocale.class))
/* 518 */       localeIndex.put(Integer.valueOf(windowsLocale.langID), windowsLocale); 
/*     */   }
/* 520 */   private static final HashMap<Integer, SortOrder> sortOrderIndex = new HashMap<>(); static {
/* 521 */     for (SortOrder sortOrder : EnumSet.<SortOrder>allOf(SortOrder.class))
/* 522 */       sortOrderIndex.put(Integer.valueOf(sortOrder.sortId), sortOrder); 
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLCollation.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */