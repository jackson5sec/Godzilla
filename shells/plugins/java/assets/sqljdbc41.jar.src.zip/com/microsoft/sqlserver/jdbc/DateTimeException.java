package com.microsoft.sqlserver.jdbc;

final class DateTimeException extends Exception {}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\DateTimeException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */