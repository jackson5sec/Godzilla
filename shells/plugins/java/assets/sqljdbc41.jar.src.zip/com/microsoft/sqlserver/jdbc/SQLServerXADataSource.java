/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.Reference;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXADataSource
/*     */   extends SQLServerConnectionPoolDataSource
/*     */   implements XADataSource
/*     */ {
/*  44 */   static Logger xaLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.XA");
/*     */ 
/*     */   
/*     */   public XAConnection getXAConnection(String paramString1, String paramString2) throws SQLException {
/*  48 */     if (loggerExternal.isLoggable(Level.FINER))
/*  49 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection", new Object[] { paramString1, "Password not traced" }); 
/*  50 */     SQLServerXAConnection sQLServerXAConnection = new SQLServerXAConnection(this, paramString1, paramString2);
/*     */     
/*  52 */     if (xaLogger.isLoggable(Level.FINER)) {
/*  53 */       xaLogger.finer(toString() + " user:" + paramString1 + sQLServerXAConnection.toString());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     if (xaLogger.isLoggable(Level.FINER))
/*  61 */       xaLogger.finer(toString() + " Start get physical connection."); 
/*  62 */     SQLServerConnection sQLServerConnection = sQLServerXAConnection.getPhysicalConnection();
/*  63 */     if (xaLogger.isLoggable(Level.FINE))
/*  64 */       xaLogger.fine(toString() + " End get physical connection, " + sQLServerConnection.toString()); 
/*  65 */     if (loggerExternal.isLoggable(Level.FINER))
/*  66 */       loggerExternal.exiting(getClassNameLogging(), "getXAConnection", sQLServerXAConnection); 
/*  67 */     return sQLServerXAConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public XAConnection getXAConnection() throws SQLException {
/*  81 */     if (loggerExternal.isLoggable(Level.FINER))
/*  82 */       loggerExternal.entering(getClassNameLogging(), "getXAConnection"); 
/*  83 */     return getXAConnection(getUser(), getPassword());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() {
/*  90 */     if (loggerExternal.isLoggable(Level.FINER))
/*  91 */       loggerExternal.entering(getClassNameLogging(), "getReference"); 
/*  92 */     Reference reference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerXADataSource");
/*  93 */     if (loggerExternal.isLoggable(Level.FINER))
/*  94 */       loggerExternal.exiting(getClassNameLogging(), "getReference", reference); 
/*  95 */     return reference;
/*     */   }
/*     */   
/*     */   private Object writeReplace() throws ObjectStreamException {
/*  99 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
/* 109 */     throw new InvalidObjectException("");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final Reference ref;
/*     */     
/*     */     private static final long serialVersionUID = 454661379842314126L;
/*     */ 
/*     */     
/*     */     SerializationProxy(SQLServerXADataSource param1SQLServerXADataSource) {
/* 123 */       this.ref = param1SQLServerXADataSource.getReferenceInternal(null);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 127 */       SQLServerXADataSource sQLServerXADataSource = new SQLServerXADataSource();
/* 128 */       sQLServerXADataSource.initializeFromReference(this.ref);
/* 129 */       return sQLServerXADataSource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerXADataSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */