/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerParameterMetaData
/*     */   implements ParameterMetaData
/*     */ {
/*     */   private static final int SQL_SERVER_2012_VERSION = 11;
/*     */   private final SQLServerStatement stmtParent;
/*     */   private SQLServerConnection con;
/*     */   private Statement stmtCall;
/*     */   private SQLServerResultSet rsProcedureMeta;
/*  37 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerParameterMetaData");
/*     */ 
/*     */   
/*  40 */   private static int baseID = 0;
/*  41 */   private final String traceID = " SQLServerParameterMetaData:" + nextInstanceID();
/*     */ 
/*     */   
/*     */   private static synchronized int nextInstanceID() {
/*  45 */     baseID++;
/*  46 */     return baseID;
/*     */   }
/*     */   
/*     */   public final String toString() {
/*  50 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseColumns(String paramString1, String paramString2) {
/*  60 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString1, " =?<>!", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     byte b = 0;
/*  67 */     String str = null;
/*  68 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/*  70 */     while (stringTokenizer.hasMoreTokens()) {
/*     */ 
/*     */       
/*  73 */       String str1 = stringTokenizer.nextToken();
/*  74 */       if (str1.equalsIgnoreCase(paramString2)) {
/*     */         
/*  76 */         b = 1;
/*     */         continue;
/*     */       } 
/*  79 */       if (!b)
/*     */         continue; 
/*  81 */       if (str1.charAt(0) == '=' || str1.equalsIgnoreCase("is") || str1.charAt(0) == '<' || str1.charAt(0) == '>' || str1.equalsIgnoreCase("like") || str1.equalsIgnoreCase("not") || str1.equalsIgnoreCase("in") || str1.charAt(0) == '!') {
/*     */ 
/*     */ 
/*     */         
/*  85 */         b = 2;
/*     */         continue;
/*     */       } 
/*  88 */       if (str1.charAt(0) == '?' && str != null) {
/*     */         
/*  90 */         if (stringBuilder.length() != 0)
/*     */         {
/*  92 */           stringBuilder.append(", ");
/*     */         }
/*  94 */         stringBuilder.append(str);
/*  95 */         b = 1;
/*  96 */         str = null;
/*     */         continue;
/*     */       } 
/*  99 */       if (b == 1) {
/*     */ 
/*     */         
/* 102 */         if (str1.equals(" "))
/*     */           continue; 
/* 104 */         String str2 = escapeParse(stringTokenizer, str1);
/* 105 */         if (str2.length() > 0)
/*     */         {
/* 107 */           str = str2;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 112 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseInsertColumns(String paramString1, String paramString2) {
/* 121 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString1, " (),", true);
/* 122 */     byte b = 0;
/* 123 */     String str = null;
/* 124 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/* 126 */     while (stringTokenizer.hasMoreTokens()) {
/* 127 */       String str1 = stringTokenizer.nextToken();
/* 128 */       if (str1.equalsIgnoreCase(paramString2)) {
/* 129 */         b = 1;
/*     */         continue;
/*     */       } 
/* 132 */       if (!b)
/*     */         continue; 
/* 134 */       if (str1.charAt(0) == '=') {
/* 135 */         b = 2;
/*     */         continue;
/*     */       } 
/* 138 */       if ((str1.charAt(0) == ',' || str1.charAt(0) == ')' || str1.charAt(0) == ' ') && str != null) {
/*     */ 
/*     */         
/* 141 */         if (stringBuilder.length() != 0)
/* 142 */           stringBuilder.append(", "); 
/* 143 */         stringBuilder.append(str);
/* 144 */         b = 1;
/* 145 */         str = null;
/*     */       } 
/* 147 */       if (str1.charAt(0) == ')') {
/* 148 */         b = 0;
/*     */         break;
/*     */       } 
/* 151 */       if (b == 1 && 
/* 152 */         str1.trim().length() > 0 && 
/* 153 */         str1.charAt(0) != ',') {
/* 154 */         str = escapeParse(stringTokenizer, str1);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 159 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   class QueryMeta
/*     */   {
/* 165 */     String parameterClassName = null;
/* 166 */     int parameterType = 0;
/* 167 */     String parameterTypeName = null;
/* 168 */     int precision = 0;
/* 169 */     int scale = 0;
/* 170 */     int isNullable = 2;
/*     */     boolean isSigned = false;
/*     */   }
/* 173 */   Map<Integer, QueryMeta> queryMetaMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseQueryMeta(ResultSet paramResultSet) throws SQLServerException {
/* 180 */     Pattern pattern = Pattern.compile("(.*)\\((.*)(\\)|,(.*)\\))");
/*     */     try {
/* 182 */       while (paramResultSet.next())
/*     */       {
/* 184 */         QueryMeta queryMeta = new QueryMeta();
/* 185 */         SSType sSType = null;
/*     */         
/* 187 */         int i = paramResultSet.getInt("parameter_ordinal");
/* 188 */         String str = paramResultSet.getString("suggested_system_type_name");
/*     */         
/* 190 */         if (null == str) {
/* 191 */           str = paramResultSet.getString("suggested_user_type_name");
/* 192 */           SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)this.con.prepareCall("select max_length, precision, scale, is_nullable from sys.assembly_types where name = ?");
/* 193 */           sQLServerPreparedStatement.setNString(1, str);
/* 194 */           ResultSet resultSet = sQLServerPreparedStatement.executeQuery();
/* 195 */           if (resultSet.next()) {
/* 196 */             queryMeta.parameterTypeName = str;
/* 197 */             queryMeta.precision = resultSet.getInt("max_length");
/* 198 */             queryMeta.scale = resultSet.getInt("scale");
/* 199 */             sSType = SSType.UDT;
/*     */           } 
/*     */         } else {
/*     */           
/* 203 */           queryMeta.precision = paramResultSet.getInt("suggested_precision");
/* 204 */           queryMeta.scale = paramResultSet.getInt("suggested_scale");
/*     */ 
/*     */           
/* 207 */           Matcher matcher = pattern.matcher(str);
/* 208 */           if (matcher.matches()) {
/*     */ 
/*     */             
/* 211 */             sSType = SSType.of(matcher.group(1));
/* 212 */             if (str.equalsIgnoreCase("varchar(max)") || str.equalsIgnoreCase("varbinary(max)")) {
/*     */ 
/*     */               
/* 215 */               queryMeta.precision = Integer.MAX_VALUE;
/*     */             }
/* 217 */             else if (str.equalsIgnoreCase("nvarchar(max)")) {
/*     */               
/* 219 */               queryMeta.precision = 1073741823;
/*     */             }
/* 221 */             else if (SSType.Category.CHARACTER == sSType.category || SSType.Category.BINARY == sSType.category || SSType.Category.NCHARACTER == sSType.category) {
/*     */               
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/*     */                 
/* 228 */                 queryMeta.precision = Integer.parseInt(matcher.group(2));
/*     */               }
/* 230 */               catch (NumberFormatException numberFormatException)
/*     */               {
/* 232 */                 MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
/* 233 */                 Object[] arrayOfObject = { new Integer(i) };
/* 234 */                 SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject) + " " + numberFormatException.toString(), null, false);
/*     */               }
/*     */             
/*     */             } 
/*     */           } else {
/*     */             
/* 240 */             sSType = SSType.of(str);
/*     */           } 
/*     */           
/* 243 */           if (SSType.FLOAT == sSType) {
/*     */ 
/*     */ 
/*     */             
/* 247 */             queryMeta.precision = 15;
/*     */           }
/* 249 */           else if (SSType.REAL == sSType) {
/*     */             
/* 251 */             queryMeta.precision = 7;
/*     */           }
/* 253 */           else if (SSType.TEXT == sSType) {
/*     */             
/* 255 */             queryMeta.precision = Integer.MAX_VALUE;
/*     */           }
/* 257 */           else if (SSType.NTEXT == sSType) {
/*     */             
/* 259 */             queryMeta.precision = 1073741823;
/*     */           }
/* 261 */           else if (SSType.IMAGE == sSType) {
/*     */             
/* 263 */             queryMeta.precision = Integer.MAX_VALUE;
/*     */           }
/* 265 */           else if (SSType.GUID == sSType) {
/*     */             
/* 267 */             queryMeta.precision = 36;
/*     */           }
/* 269 */           else if (SSType.TIMESTAMP == sSType) {
/*     */             
/* 271 */             queryMeta.precision = 8;
/*     */           }
/* 273 */           else if (SSType.XML == sSType) {
/*     */             
/* 275 */             queryMeta.precision = 1073741823;
/*     */           } 
/*     */           
/* 278 */           queryMeta.parameterTypeName = sSType.toString();
/*     */         } 
/*     */ 
/*     */         
/* 282 */         if (null == sSType)
/*     */         {
/* 284 */           throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null);
/*     */         }
/*     */         
/* 287 */         JDBCType jDBCType = sSType.getJDBCType();
/* 288 */         queryMeta.parameterClassName = jDBCType.className();
/* 289 */         queryMeta.parameterType = jDBCType.getIntValue();
/*     */         
/* 291 */         queryMeta.isSigned = (SSType.Category.NUMERIC == sSType.category && SSType.BIT != sSType && SSType.TINYINT != sSType);
/* 292 */         this.queryMetaMap.put(Integer.valueOf(i), queryMeta);
/*     */       }
/*     */     
/* 295 */     } catch (SQLException sQLException) {
/*     */       
/* 297 */       throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), sQLException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseQueryMetaFor2008(ResultSet paramResultSet) throws SQLServerException {
/*     */     try {
/* 306 */       ResultSetMetaData resultSetMetaData = paramResultSet.getMetaData();
/*     */       
/* 308 */       for (byte b = 1; b <= resultSetMetaData.getColumnCount(); b++) {
/* 309 */         QueryMeta queryMeta = new QueryMeta();
/*     */         
/* 311 */         queryMeta.parameterClassName = resultSetMetaData.getColumnClassName(b);
/* 312 */         queryMeta.parameterType = resultSetMetaData.getColumnType(b);
/* 313 */         queryMeta.parameterTypeName = resultSetMetaData.getColumnTypeName(b);
/* 314 */         queryMeta.precision = resultSetMetaData.getPrecision(b);
/* 315 */         queryMeta.scale = resultSetMetaData.getScale(b);
/* 316 */         queryMeta.isNullable = resultSetMetaData.isNullable(b);
/* 317 */         queryMeta.isSigned = resultSetMetaData.isSigned(b);
/*     */         
/* 319 */         this.queryMetaMap.put(Integer.valueOf(b), queryMeta);
/*     */       }
/*     */     
/* 322 */     } catch (SQLException sQLException) {
/* 323 */       throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), sQLException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String escapeParse(StringTokenizer paramStringTokenizer, String paramString) {
/* 337 */     String str1 = paramString;
/*     */     
/* 339 */     while (str1.equals(" ") && paramStringTokenizer.hasMoreTokens())
/*     */     {
/* 341 */       str1 = paramStringTokenizer.nextToken();
/*     */     }
/* 343 */     String str2 = str1;
/* 344 */     if (str1.charAt(0) == '[' && str1.charAt(str1.length() - 1) != ']')
/*     */     {
/* 346 */       while (paramStringTokenizer.hasMoreTokens()) {
/*     */         
/* 348 */         str1 = paramStringTokenizer.nextToken();
/* 349 */         str2 = str2.concat(str1);
/* 350 */         if (str1.charAt(str1.length() - 1) == ']') {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 357 */     str2 = str2.trim();
/* 358 */     return str2;
/*     */   }
/*     */ 
/*     */   
/*     */   private class MetaInfo
/*     */   {
/*     */     String table;
/*     */     String fields;
/*     */     
/*     */     MetaInfo(String param1String1, String param1String2) {
/* 368 */       this.table = param1String1;
/* 369 */       this.fields = param1String2;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MetaInfo parseStatement(String paramString1, String paramString2) {
/* 380 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString1, " ,", true);
/*     */ 
/*     */ 
/*     */     
/* 384 */     String str1 = null;
/* 385 */     String str2 = "";
/* 386 */     while (stringTokenizer.hasMoreTokens()) {
/*     */       
/* 388 */       String str = stringTokenizer.nextToken().trim();
/*     */       
/* 390 */       if (str.equalsIgnoreCase(paramString2))
/*     */       {
/* 392 */         if (stringTokenizer.hasMoreTokens()) {
/*     */           
/* 394 */           str1 = escapeParse(stringTokenizer, stringTokenizer.nextToken());
/*     */           
/*     */           break;
/*     */         } 
/*     */       }
/*     */     } 
/* 400 */     if (null != str1) {
/*     */       
/* 402 */       if (paramString2.equalsIgnoreCase("UPDATE")) {
/* 403 */         str2 = parseColumns(paramString1, "SET");
/* 404 */       } else if (paramString2.equalsIgnoreCase("INTO")) {
/* 405 */         str2 = parseInsertColumns(paramString1, "(");
/*     */       } else {
/* 407 */         str2 = parseColumns(paramString1, "WHERE");
/*     */       } 
/* 409 */       return new MetaInfo(str1, str2);
/*     */     } 
/*     */     
/* 412 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MetaInfo parseStatement(String paramString) throws SQLServerException {
/* 422 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, " ");
/* 423 */     if (stringTokenizer.hasMoreTokens()) {
/*     */       
/* 425 */       String str = stringTokenizer.nextToken().trim();
/*     */       
/* 427 */       if (str.equalsIgnoreCase("INSERT")) {
/* 428 */         return parseStatement(paramString, "INTO");
/*     */       }
/* 430 */       if (str.equalsIgnoreCase("UPDATE")) {
/* 431 */         return parseStatement(paramString, "UPDATE");
/*     */       }
/* 433 */       if (str.equalsIgnoreCase("SELECT")) {
/* 434 */         return parseStatement(paramString, "FROM");
/*     */       }
/* 436 */       if (str.equalsIgnoreCase("DELETE")) {
/* 437 */         return parseStatement(paramString, "FROM");
/*     */       }
/*     */     } 
/* 440 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   String parseThreePartNames(String paramString) throws SQLServerException {
/* 445 */     byte b = 0;
/* 446 */     String str1 = null;
/* 447 */     String str2 = null;
/* 448 */     String str3 = null;
/* 449 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ".", true);
/*     */ 
/*     */ 
/*     */     
/* 453 */     while (stringTokenizer.hasMoreTokens()) {
/*     */       
/* 455 */       String str4 = stringTokenizer.nextToken();
/* 456 */       String str5 = escapeParse(stringTokenizer, str4);
/* 457 */       if (!str5.equals(".")) {
/*     */         
/* 459 */         switch (b) {
/*     */           
/*     */           case true:
/* 462 */             str3 = str2;
/* 463 */             str2 = str1;
/* 464 */             str1 = str5;
/* 465 */             b++;
/*     */             continue;
/*     */           case true:
/* 468 */             str2 = str1;
/* 469 */             str1 = str5;
/* 470 */             b++;
/*     */             continue;
/*     */           case false:
/* 473 */             str1 = str5;
/* 474 */             b++;
/*     */             continue;
/*     */         } 
/* 477 */         b++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 482 */     StringBuilder stringBuilder = new StringBuilder(100);
/*     */     
/* 484 */     if (b > 3 && 1 < b) {
/* 485 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
/*     */     }
/* 487 */     switch (b) {
/*     */       
/*     */       case 3:
/* 490 */         stringBuilder.append("@procedure_qualifier =");
/* 491 */         stringBuilder.append(str3);
/* 492 */         stringBuilder.append(", ");
/* 493 */         stringBuilder.append("@procedure_owner =");
/* 494 */         stringBuilder.append(str2);
/* 495 */         stringBuilder.append(", ");
/* 496 */         stringBuilder.append("@procedure_name =");
/* 497 */         stringBuilder.append(str1);
/* 498 */         stringBuilder.append(", ");
/*     */         break;
/*     */       
/*     */       case 2:
/* 502 */         stringBuilder.append("@procedure_owner =");
/* 503 */         stringBuilder.append(str2);
/* 504 */         stringBuilder.append(", ");
/* 505 */         stringBuilder.append("@procedure_name =");
/* 506 */         stringBuilder.append(str1);
/* 507 */         stringBuilder.append(", ");
/*     */         break;
/*     */       case 1:
/* 510 */         stringBuilder.append("@procedure_name =");
/* 511 */         stringBuilder.append(str1);
/* 512 */         stringBuilder.append(", ");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 517 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 523 */     this.stmtParent.checkClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerParameterMetaData(SQLServerStatement paramSQLServerStatement, String paramString) throws SQLServerException {
/* 535 */     assert null != paramSQLServerStatement;
/* 536 */     this.stmtParent = paramSQLServerStatement;
/* 537 */     this.con = paramSQLServerStatement.connection;
/* 538 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/* 540 */       logger.fine(toString() + " created by (" + paramSQLServerStatement.toString() + ")");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 547 */       if (null != paramSQLServerStatement.procedureName) {
/*     */         
/* 549 */         SQLServerStatement sQLServerStatement = (SQLServerStatement)this.con.createStatement(1004, 1007);
/* 550 */         String str = parseThreePartNames(paramSQLServerStatement.procedureName);
/* 551 */         if (this.con.isKatmaiOrLater()) {
/* 552 */           this.rsProcedureMeta = sQLServerStatement.executeQueryInternal("exec sp_sproc_columns_100 " + str + " @ODBCVer=3");
/*     */         } else {
/* 554 */           this.rsProcedureMeta = sQLServerStatement.executeQueryInternal("exec sp_sproc_columns " + str + " @ODBCVer=3");
/*     */         } 
/* 556 */         this.rsProcedureMeta.getColumn(6).setFilter(new DataTypeFilter());
/* 557 */         if (this.con.isKatmaiOrLater())
/*     */         {
/* 559 */           this.rsProcedureMeta.getColumn(8).setFilter(new ZeroFixupFilter());
/* 560 */           this.rsProcedureMeta.getColumn(9).setFilter(new ZeroFixupFilter());
/* 561 */           this.rsProcedureMeta.getColumn(17).setFilter(new ZeroFixupFilter());
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 571 */         this.queryMetaMap = new HashMap<>();
/*     */         
/* 573 */         if (this.con.getServerMajorVersion() >= 11)
/*     */         {
/* 575 */           String str = this.con.replaceParameterMarkers(((SQLServerPreparedStatement)this.stmtParent).userSQL, ((SQLServerPreparedStatement)this.stmtParent).inOutParam, ((SQLServerPreparedStatement)this.stmtParent).bReturnValueSyntax);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 580 */           SQLServerCallableStatement sQLServerCallableStatement = (SQLServerCallableStatement)this.con.prepareCall("exec sp_describe_undeclared_parameters ?");
/* 581 */           sQLServerCallableStatement.setNString(1, str);
/* 582 */           parseQueryMeta(sQLServerCallableStatement.executeQueryInternal());
/* 583 */           sQLServerCallableStatement.close();
/*     */         }
/*     */         else
/*     */         {
/* 587 */           MetaInfo metaInfo = parseStatement(paramString);
/* 588 */           if (null == metaInfo) {
/*     */             
/* 590 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cantIdentifyTableMetadata"));
/* 591 */             Object[] arrayOfObject = { new String(paramString) };
/* 592 */             SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject), null, false);
/*     */           } 
/*     */           
/* 595 */           if (metaInfo.fields.length() <= 0) {
/*     */             return;
/*     */           }
/* 598 */           Statement statement = this.con.createStatement();
/* 599 */           String str = "sp_executesql N'SET FMTONLY ON SELECT " + metaInfo.fields + " FROM " + metaInfo.table + " WHERE 1 = 2'";
/* 600 */           ResultSet resultSet = statement.executeQuery(str);
/* 601 */           parseQueryMetaFor2008(resultSet);
/* 602 */           statement.close();
/* 603 */           resultSet.close();
/*     */         }
/*     */       
/*     */       } 
/* 607 */     } catch (SQLException sQLException) {
/*     */       
/* 609 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 615 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 617 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/* 622 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 623 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   
/*     */   private void verifyParameterPosition(int paramInt) throws SQLServerException {
/* 628 */     boolean bool = false;
/*     */     try {
/* 630 */       bool = this.rsProcedureMeta.absolute(paramInt + 1);
/*     */     }
/* 632 */     catch (SQLException sQLException) {
/* 633 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_metaDataErrorForParameter"));
/* 634 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 635 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject) + " " + sQLException.toString(), null, false);
/*     */     } 
/*     */     
/* 638 */     if (!bool) {
/* 639 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidParameterNumber"));
/* 640 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 641 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, messageFormat.format(arrayOfObject), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void checkParam(int paramInt) throws SQLServerException {
/* 647 */     if (!this.queryMetaMap.containsKey(Integer.valueOf(paramInt)))
/*     */     {
/* 649 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, SQLServerException.getErrString("R_noMetadata"), null, false);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getParameterClassName(int paramInt) throws SQLServerException {
/* 654 */     checkClosed();
/*     */     try {
/* 656 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 658 */         checkParam(paramInt);
/* 659 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterClassName;
/*     */       } 
/*     */       
/* 662 */       verifyParameterPosition(paramInt);
/* 663 */       JDBCType jDBCType = JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE"));
/* 664 */       return jDBCType.className();
/*     */     
/*     */     }
/* 667 */     catch (SQLException sQLException) {
/* 668 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 669 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getParameterCount() throws SQLServerException {
/* 674 */     checkClosed();
/*     */     try {
/* 676 */       if (this.rsProcedureMeta == null)
/*     */       {
/* 678 */         return this.queryMetaMap.size();
/*     */       }
/*     */       
/* 681 */       this.rsProcedureMeta.last();
/* 682 */       int i = this.rsProcedureMeta.getRow() - 1;
/* 683 */       if (i < 0)
/* 684 */         i = 0; 
/* 685 */       return i;
/*     */     
/*     */     }
/* 688 */     catch (SQLException sQLException) {
/* 689 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 690 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getParameterMode(int paramInt) throws SQLServerException {
/* 695 */     checkClosed();
/*     */     try {
/* 697 */       if (this.rsProcedureMeta == null) {
/* 698 */         checkParam(paramInt);
/*     */         
/* 700 */         return 1;
/*     */       } 
/*     */       
/* 703 */       verifyParameterPosition(paramInt);
/* 704 */       int i = this.rsProcedureMeta.getInt("COLUMN_TYPE");
/* 705 */       switch (i) {
/*     */         case 1:
/* 707 */           return 1;
/*     */         case 2:
/* 709 */           return 4;
/*     */       } 
/* 711 */       return 0;
/*     */ 
/*     */     
/*     */     }
/* 715 */     catch (SQLException sQLException) {
/* 716 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 717 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getParameterType(int paramInt) throws SQLServerException {
/* 722 */     checkClosed();
/*     */     
/*     */     try {
/*     */       int i;
/* 726 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 728 */         checkParam(paramInt);
/* 729 */         i = ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterType;
/*     */       } else {
/*     */         
/* 732 */         verifyParameterPosition(paramInt);
/* 733 */         i = this.rsProcedureMeta.getShort("DATA_TYPE");
/*     */       } 
/*     */       
/* 736 */       switch (i) {
/*     */         
/*     */         case -151:
/*     */         case -150:
/* 740 */           i = SSType.DATETIME2.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case -148:
/*     */         case -146:
/* 744 */           i = SSType.DECIMAL.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case -145:
/* 747 */           i = SSType.CHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */       } 
/*     */       
/* 751 */       return i;
/*     */     }
/* 753 */     catch (SQLException sQLException) {
/* 754 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 755 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getParameterTypeName(int paramInt) throws SQLServerException {
/* 760 */     checkClosed();
/*     */     try {
/* 762 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 764 */         checkParam(paramInt);
/* 765 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).parameterTypeName;
/*     */       } 
/*     */       
/* 768 */       verifyParameterPosition(paramInt);
/* 769 */       return this.rsProcedureMeta.getString("TYPE_NAME");
/*     */     
/*     */     }
/* 772 */     catch (SQLException sQLException) {
/* 773 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 774 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getPrecision(int paramInt) throws SQLServerException {
/* 779 */     checkClosed();
/*     */     try {
/* 781 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 783 */         checkParam(paramInt);
/* 784 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).precision;
/*     */       } 
/*     */       
/* 787 */       verifyParameterPosition(paramInt);
/* 788 */       return this.rsProcedureMeta.getInt("PRECISION");
/*     */ 
/*     */     
/*     */     }
/* 792 */     catch (SQLException sQLException) {
/* 793 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 794 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int getScale(int paramInt) throws SQLServerException {
/* 799 */     checkClosed();
/*     */     try {
/* 801 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 803 */         checkParam(paramInt);
/* 804 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).scale;
/*     */       } 
/*     */       
/* 807 */       verifyParameterPosition(paramInt);
/* 808 */       return this.rsProcedureMeta.getInt("SCALE");
/*     */ 
/*     */     
/*     */     }
/* 812 */     catch (SQLException sQLException) {
/* 813 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 814 */       return 0;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLServerException {
/* 819 */     checkClosed();
/*     */     try {
/* 821 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 823 */         checkParam(paramInt);
/* 824 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).isNullable;
/*     */       } 
/*     */       
/* 827 */       verifyParameterPosition(paramInt);
/* 828 */       int i = this.rsProcedureMeta.getInt("NULLABLE");
/* 829 */       if (i == 1)
/* 830 */         return 1; 
/* 831 */       if (i == 0)
/* 832 */         return 0; 
/* 833 */       return 2;
/*     */     
/*     */     }
/* 836 */     catch (SQLException sQLException) {
/* 837 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 838 */       return 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSigned(int paramInt) throws SQLServerException {
/* 849 */     checkClosed();
/*     */     try {
/* 851 */       if (this.rsProcedureMeta == null) {
/*     */         
/* 853 */         checkParam(paramInt);
/* 854 */         return ((QueryMeta)this.queryMetaMap.get(Integer.valueOf(paramInt))).isSigned;
/*     */       } 
/*     */       
/* 857 */       verifyParameterPosition(paramInt);
/* 858 */       return JDBCType.of(this.rsProcedureMeta.getShort("DATA_TYPE")).isSigned();
/*     */     
/*     */     }
/* 861 */     catch (SQLException sQLException) {
/* 862 */       SQLServerException.makeFromDriverError(this.con, this.stmtParent, sQLException.toString(), null, false);
/* 863 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerParameterMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */