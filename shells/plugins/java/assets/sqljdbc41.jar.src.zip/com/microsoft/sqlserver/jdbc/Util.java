/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ final class Util
/*     */ {
/*  21 */   static final String SYSTEM_SPEC_VERSION = System.getProperty("java.specification.version");
/*  22 */   static final char[] hexChars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */   
/*     */   static final String WSIDNotAvailable = "";
/*     */   
/*     */   static final String ActivityIdTraceProperty = "com.microsoft.sqlserver.jdbc.traceactivity";
/*     */   
/*  29 */   static final String SYSTEM_JRE = System.getProperty("java.vendor") + " " + System.getProperty("java.version");
/*     */ 
/*     */   
/*     */   static boolean isIBM() {
/*  33 */     return SYSTEM_JRE.startsWith("IBM");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final Boolean isCharType(int paramInt) {
/*  39 */     switch (paramInt) {
/*     */       
/*     */       case -16:
/*     */       case -15:
/*     */       case -9:
/*     */       case -1:
/*     */       case 1:
/*     */       case 12:
/*  47 */         return Boolean.valueOf(true);
/*     */     } 
/*  49 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final Boolean isCharType(SSType paramSSType) {
/*  55 */     switch (paramSSType) {
/*     */       
/*     */       case OBJECT:
/*     */       case STRING:
/*     */       case BYTEARRAY:
/*     */       case BIGDECIMAL:
/*     */       case TIMESTAMP:
/*     */       case TIME:
/*  63 */         return Boolean.valueOf(true);
/*     */     } 
/*  65 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final Boolean isBinaryType(SSType paramSSType) {
/*  71 */     switch (paramSSType) {
/*     */       
/*     */       case DATETIMEOFFSET:
/*     */       case READER:
/*     */       case CLOB:
/*     */       case NCLOB:
/*  77 */         return Boolean.valueOf(true);
/*     */     } 
/*  79 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static final Boolean isBinaryType(int paramInt) {
/*  85 */     switch (paramInt) {
/*     */       
/*     */       case -4:
/*     */       case -3:
/*     */       case -2:
/*  90 */         return Boolean.valueOf(true);
/*     */     } 
/*  92 */     return Boolean.valueOf(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static short readShort(byte[] paramArrayOfbyte, int paramInt) {
/* 103 */     return (short)(paramArrayOfbyte[paramInt] & 0xFF | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int readUnsignedShort(byte[] paramArrayOfbyte, int paramInt) {
/* 113 */     return paramArrayOfbyte[paramInt] & 0xFF | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8;
/*     */   }
/*     */ 
/*     */   
/*     */   static int readUnsignedShortBigEndian(byte[] paramArrayOfbyte, int paramInt) {
/* 118 */     return (paramArrayOfbyte[paramInt] & 0xFF) << 8 | paramArrayOfbyte[paramInt + 1] & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   static void writeShort(short paramShort, byte[] paramArrayOfbyte, int paramInt) {
/* 123 */     paramArrayOfbyte[paramInt + 0] = (byte)(paramShort >> 0 & 0xFF);
/* 124 */     paramArrayOfbyte[paramInt + 1] = (byte)(paramShort >> 8 & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   static void writeShortBigEndian(short paramShort, byte[] paramArrayOfbyte, int paramInt) {
/* 129 */     paramArrayOfbyte[paramInt + 0] = (byte)(paramShort >> 8 & 0xFF);
/* 130 */     paramArrayOfbyte[paramInt + 1] = (byte)(paramShort >> 0 & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int readInt(byte[] paramArrayOfbyte, int paramInt) {
/* 139 */     int i = paramArrayOfbyte[paramInt + 0] & 0xFF;
/* 140 */     int j = (paramArrayOfbyte[paramInt + 1] & 0xFF) << 8;
/* 141 */     int k = (paramArrayOfbyte[paramInt + 2] & 0xFF) << 16;
/* 142 */     int m = (paramArrayOfbyte[paramInt + 3] & 0xFF) << 24;
/* 143 */     return m | k | j | i;
/*     */   }
/*     */ 
/*     */   
/*     */   static int readIntBigEndian(byte[] paramArrayOfbyte, int paramInt) {
/* 148 */     return (paramArrayOfbyte[paramInt + 3] & 0xFF) << 0 | (paramArrayOfbyte[paramInt + 2] & 0xFF) << 8 | (paramArrayOfbyte[paramInt + 1] & 0xFF) << 16 | (paramArrayOfbyte[paramInt + 0] & 0xFF) << 24;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void writeInt(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 157 */     paramArrayOfbyte[paramInt2 + 0] = (byte)(paramInt1 >> 0 & 0xFF);
/* 158 */     paramArrayOfbyte[paramInt2 + 1] = (byte)(paramInt1 >> 8 & 0xFF);
/* 159 */     paramArrayOfbyte[paramInt2 + 2] = (byte)(paramInt1 >> 16 & 0xFF);
/* 160 */     paramArrayOfbyte[paramInt2 + 3] = (byte)(paramInt1 >> 24 & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   static void writeIntBigEndian(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 165 */     paramArrayOfbyte[paramInt2 + 0] = (byte)(paramInt1 >> 24 & 0xFF);
/* 166 */     paramArrayOfbyte[paramInt2 + 1] = (byte)(paramInt1 >> 16 & 0xFF);
/* 167 */     paramArrayOfbyte[paramInt2 + 2] = (byte)(paramInt1 >> 8 & 0xFF);
/* 168 */     paramArrayOfbyte[paramInt2 + 3] = (byte)(paramInt1 >> 0 & 0xFF);
/*     */   }
/*     */ 
/*     */   
/*     */   static void writeLongBigEndian(long paramLong, byte[] paramArrayOfbyte, int paramInt) {
/* 173 */     paramArrayOfbyte[paramInt + 0] = (byte)(int)(paramLong >> 56L & 0xFFL);
/* 174 */     paramArrayOfbyte[paramInt + 1] = (byte)(int)(paramLong >> 48L & 0xFFL);
/* 175 */     paramArrayOfbyte[paramInt + 2] = (byte)(int)(paramLong >> 40L & 0xFFL);
/* 176 */     paramArrayOfbyte[paramInt + 3] = (byte)(int)(paramLong >> 32L & 0xFFL);
/* 177 */     paramArrayOfbyte[paramInt + 4] = (byte)(int)(paramLong >> 24L & 0xFFL);
/* 178 */     paramArrayOfbyte[paramInt + 5] = (byte)(int)(paramLong >> 16L & 0xFFL);
/* 179 */     paramArrayOfbyte[paramInt + 6] = (byte)(int)(paramLong >> 8L & 0xFFL);
/* 180 */     paramArrayOfbyte[paramInt + 7] = (byte)(int)(paramLong >> 0L & 0xFFL);
/*     */   }
/*     */ 
/*     */   
/*     */   static BigDecimal readBigDecimal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 185 */     boolean bool = (0 == paramArrayOfbyte[0]) ? true : true;
/* 186 */     byte[] arrayOfByte = new byte[paramInt1 - 1];
/* 187 */     for (byte b = 1; b <= arrayOfByte.length; b++)
/* 188 */       arrayOfByte[arrayOfByte.length - b] = paramArrayOfbyte[b]; 
/* 189 */     return new BigDecimal(new BigInteger(bool, arrayOfByte), paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long readLong(byte[] paramArrayOfbyte, int paramInt) {
/* 200 */     long l = 0L;
/* 201 */     for (byte b = 7; b > 0; b--) {
/*     */       
/* 203 */       l += (paramArrayOfbyte[paramInt + b] & 0xFF);
/* 204 */       l <<= 8L;
/*     */     } 
/* 206 */     return l + (paramArrayOfbyte[paramInt] & 0xFF);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Properties parseUrl(String paramString, Logger paramLogger) throws SQLServerException {
/* 216 */     Properties properties = new Properties();
/* 217 */     String str1 = paramString;
/* 218 */     String str2 = "jdbc:sqlserver://";
/* 219 */     String str3 = "";
/* 220 */     String str4 = "";
/* 221 */     String str5 = "";
/*     */     
/* 223 */     if (!str1.startsWith(str2)) {
/* 224 */       return null;
/*     */     }
/* 226 */     str1 = str1.substring(str2.length());
/* 227 */     byte b1 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 240 */     byte b2 = 0;
/*     */     
/* 242 */     b1 = 0;
/* 243 */     while (b1 < str1.length()) {
/*     */       
/* 245 */       char c = str1.charAt(b1);
/* 246 */       switch (b2) {
/*     */ 
/*     */         
/*     */         case false:
/* 250 */           if (c == ';') {
/*     */ 
/*     */             
/* 253 */             b2 = 7;
/*     */             
/*     */             break;
/*     */           } 
/* 257 */           str3 = str3 + c;
/* 258 */           b2 = 1;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 265 */           if (c == ';' || c == ':' || c == '\\') {
/*     */ 
/*     */             
/* 268 */             str3 = str3.trim();
/* 269 */             if (str3.length() > 0) {
/*     */               
/* 271 */               properties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
/* 272 */               if (paramLogger.isLoggable(Level.FINE))
/*     */               {
/* 274 */                 paramLogger.fine("Property:serverName Value:" + str3);
/*     */               }
/*     */             } 
/* 277 */             str3 = "";
/*     */             
/* 279 */             if (c == ';') {
/* 280 */               b2 = 7; break;
/*     */             } 
/* 282 */             if (c == ':') {
/* 283 */               b2 = 2; break;
/*     */             } 
/* 285 */             b2 = 3;
/*     */             
/*     */             break;
/*     */           } 
/* 289 */           str3 = str3 + c;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 297 */           if (c == ';') {
/*     */             
/* 299 */             str3 = str3.trim();
/* 300 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 302 */               paramLogger.fine("Property:portNumber Value:" + str3);
/*     */             }
/* 304 */             properties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
/* 305 */             str3 = "";
/* 306 */             b2 = 7;
/*     */             
/*     */             break;
/*     */           } 
/* 310 */           str3 = str3 + c;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 317 */           if (c == ';' || c == ':') {
/*     */ 
/*     */             
/* 320 */             str3 = str3.trim();
/* 321 */             if (paramLogger.isLoggable(Level.FINE))
/*     */             {
/* 323 */               paramLogger.fine("Property:instanceName Value:" + str3);
/*     */             }
/* 325 */             properties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3.toLowerCase(Locale.US));
/* 326 */             str3 = "";
/*     */             
/* 328 */             if (c == ';') {
/* 329 */               b2 = 7; break;
/*     */             } 
/* 331 */             b2 = 2;
/*     */             
/*     */             break;
/*     */           } 
/* 335 */           str3 = str3 + c;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 342 */           if (c == '=') {
/*     */ 
/*     */             
/* 345 */             str4 = str4.trim();
/* 346 */             if (str4.length() <= 0)
/*     */             {
/* 348 */               SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */             }
/*     */             
/* 351 */             b2 = 6;
/*     */             break;
/*     */           } 
/* 354 */           if (c == ';') {
/*     */             
/* 356 */             str4 = str4.trim();
/* 357 */             if (str4.length() > 0)
/*     */             {
/* 359 */               SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */             }
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 366 */           str4 = str4 + c;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 373 */           if (c == ';') {
/*     */ 
/*     */             
/* 376 */             str5 = str5.trim();
/* 377 */             str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 378 */             if (null != str4) {
/*     */               
/* 380 */               if (paramLogger.isLoggable(Level.FINE))
/*     */               {
/* 382 */                 if (false == str4.equals(SQLServerDriverStringProperty.USER.toString()) && false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString()))
/* 383 */                   paramLogger.fine("Property:" + str4 + " Value:" + str5); 
/*     */               }
/* 385 */               properties.put(str4, str5);
/*     */             } 
/* 387 */             str4 = "";
/* 388 */             str5 = "";
/* 389 */             b2 = 7;
/*     */             
/*     */             break;
/*     */           } 
/* 393 */           if (c == '{') {
/*     */             
/* 395 */             b2 = 4;
/* 396 */             str5 = str5.trim();
/* 397 */             if (str5.length() > 0)
/*     */             {
/* 399 */               SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */             }
/*     */             
/*     */             break;
/*     */           } 
/* 404 */           str5 = str5 + c;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 411 */           if (c == '}') {
/*     */ 
/*     */             
/* 414 */             str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 415 */             if (null != str4) {
/*     */               
/* 417 */               if (paramLogger.isLoggable(Level.FINE))
/*     */               {
/* 419 */                 if (false == str4.equals(SQLServerDriverStringProperty.USER.toString()) && false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString()))
/* 420 */                   paramLogger.fine("Property:" + str4 + " Value:" + str5); 
/*     */               }
/* 422 */               properties.put(str4, str5);
/*     */             } 
/*     */             
/* 425 */             str4 = "";
/* 426 */             str5 = "";
/*     */ 
/*     */             
/* 429 */             b2 = 5;
/*     */             
/*     */             break;
/*     */           } 
/* 433 */           str5 = str5 + c;
/*     */           break;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 440 */           if (c == ';') {
/*     */             
/* 442 */             b2 = 7; break;
/*     */           } 
/* 444 */           if (c != ' ')
/*     */           {
/*     */             
/* 447 */             SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */           }
/*     */           break;
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 454 */           assert false : "parseURL: Invalid state " + b2; break;
/*     */       } 
/* 456 */       b1++;
/*     */     } 
/*     */ 
/*     */     
/* 460 */     switch (b2) {
/*     */       
/*     */       case 1:
/* 463 */         str3 = str3.trim();
/* 464 */         if (str3.length() > 0) {
/*     */           
/* 466 */           if (paramLogger.isLoggable(Level.FINE))
/*     */           {
/* 468 */             paramLogger.fine("Property:serverName Value:" + str3);
/*     */           }
/* 470 */           properties.put(SQLServerDriverStringProperty.SERVER_NAME.toString(), str3);
/*     */         } 
/*     */       
/*     */       case 2:
/* 474 */         str3 = str3.trim();
/* 475 */         if (paramLogger.isLoggable(Level.FINE))
/*     */         {
/* 477 */           paramLogger.fine("Property:portNumber Value:" + str3);
/*     */         }
/* 479 */         properties.put(SQLServerDriverIntProperty.PORT_NUMBER.toString(), str3);
/*     */       
/*     */       case 3:
/* 482 */         str3 = str3.trim();
/* 483 */         if (paramLogger.isLoggable(Level.FINE))
/*     */         {
/* 485 */           paramLogger.fine("Property:instanceName Value:" + str3);
/*     */         }
/* 487 */         properties.put(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), str3);
/*     */ 
/*     */       
/*     */       case 6:
/* 491 */         str5 = str5.trim();
/* 492 */         str4 = SQLServerDriver.getNormalizedPropertyName(str4, paramLogger);
/* 493 */         if (null != str4) {
/*     */           
/* 495 */           if (paramLogger.isLoggable(Level.FINE))
/*     */           {
/* 497 */             if (false == str4.equals(SQLServerDriverStringProperty.USER.toString()) && false == str4.equals(SQLServerDriverStringProperty.PASSWORD.toString()))
/* 498 */               paramLogger.fine("Property:" + str4 + " Value:" + str5); 
/*     */           }
/* 500 */           properties.put(str4, str5);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/*     */       case 5:
/* 523 */         return properties;
/*     */       case 7:
/*     */         str4 = str4.trim();
/*     */         if (str4.length() > 0) {
/*     */           SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */         }
/*     */     } 
/*     */     SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String escapeSQLId(String paramString) {
/* 545 */     StringBuilder stringBuilder = new StringBuilder(paramString.length() + 2);
/*     */     
/* 547 */     stringBuilder.append('[');
/* 548 */     for (byte b = 0; b < paramString.length(); b++) {
/*     */       
/* 550 */       char c = paramString.charAt(b);
/* 551 */       if (']' == c) {
/* 552 */         stringBuilder.append("]]");
/*     */       } else {
/* 554 */         stringBuilder.append(c);
/*     */       } 
/* 556 */     }  stringBuilder.append(']');
/* 557 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static void checkDuplicateColumnName(String paramString, Map<Integer, ?> paramMap) throws SQLServerException {
/* 562 */     if (paramMap.get(Integer.valueOf(0)) instanceof SQLServerMetaData) {
/*     */       
/* 564 */       for (Map.Entry<Integer, ?> entry : paramMap.entrySet()) {
/*     */         
/* 566 */         SQLServerMetaData sQLServerMetaData = (SQLServerMetaData)entry.getValue();
/* 567 */         if (sQLServerMetaData.columnName.equals(paramString))
/*     */         {
/* 569 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
/* 570 */           Object[] arrayOfObject = { paramString };
/* 571 */           throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */         }
/*     */       
/*     */       } 
/* 575 */     } else if (paramMap.get(Integer.valueOf(0)) instanceof SQLServerDataColumn) {
/*     */       
/* 577 */       for (Map.Entry<Integer, ?> entry : paramMap.entrySet()) {
/*     */         
/* 579 */         SQLServerDataColumn sQLServerDataColumn = (SQLServerDataColumn)entry.getValue();
/* 580 */         if (sQLServerDataColumn.columnName.equals(paramString)) {
/*     */           
/* 582 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateColumnName"));
/* 583 */           Object[] arrayOfObject = { paramString };
/* 584 */           throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String readUnicodeString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*     */     try {
/* 602 */       return new String(paramArrayOfbyte, paramInt1, paramInt2, Encoding.UNICODE.charsetName());
/*     */     }
/* 604 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 606 */       String str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
/* 607 */       MessageFormat messageFormat = new MessageFormat(str);
/* 608 */       Object[] arrayOfObject = { new Integer(paramInt1) };
/*     */       
/* 610 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
/*     */     }
/* 612 */     catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*     */       
/* 614 */       String str = SQLServerException.checkAndAppendClientConnId(SQLServerException.getErrString("R_stringReadError"), paramSQLServerConnection);
/* 615 */       MessageFormat messageFormat = new MessageFormat(str);
/* 616 */       Object[] arrayOfObject = { new Integer(paramInt1) };
/*     */       
/* 618 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String byteToHexDisplayString(byte[] paramArrayOfbyte) {
/* 631 */     if (null == paramArrayOfbyte) return "(null)";
/*     */     
/* 633 */     StringBuilder stringBuilder = new StringBuilder(paramArrayOfbyte.length * 2 + 2);
/* 634 */     stringBuilder.append("0x");
/* 635 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*     */       
/* 637 */       int i = paramArrayOfbyte[b] & 0xFF;
/* 638 */       stringBuilder.append(hexChars[(i & 0xF0) >> 4]);
/* 639 */       stringBuilder.append(hexChars[i & 0xF]);
/*     */     } 
/* 641 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String bytesToHexString(byte[] paramArrayOfbyte, int paramInt) {
/* 652 */     StringBuilder stringBuilder = new StringBuilder(paramInt * 2);
/* 653 */     for (byte b = 0; b < paramInt; b++) {
/*     */       
/* 655 */       int i = paramArrayOfbyte[b] & 0xFF;
/* 656 */       stringBuilder.append(hexChars[(i & 0xF0) >> 4]);
/* 657 */       stringBuilder.append(hexChars[i & 0xF]);
/*     */     } 
/* 659 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String lookupHostName() {
/*     */     try {
/* 673 */       InetAddress inetAddress = InetAddress.getLocalHost();
/* 674 */       if (null != inetAddress) {
/*     */         
/* 676 */         String str = inetAddress.getHostName();
/* 677 */         if (null != str && str.length() > 0) return str;
/*     */         
/* 679 */         str = inetAddress.getHostAddress();
/* 680 */         if (null != str && str.length() > 0) return str;
/*     */       
/*     */       } 
/* 683 */     } catch (UnknownHostException unknownHostException) {
/*     */       
/* 685 */       return "";
/*     */     } 
/*     */     
/* 688 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   static final byte[] asGuidByteArray(UUID paramUUID) {
/* 693 */     long l1 = paramUUID.getMostSignificantBits();
/* 694 */     long l2 = paramUUID.getLeastSignificantBits();
/* 695 */     byte[] arrayOfByte = new byte[16];
/* 696 */     writeLongBigEndian(l1, arrayOfByte, 0);
/* 697 */     writeLongBigEndian(l2, arrayOfByte, 8);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 706 */     byte b = arrayOfByte[0];
/* 707 */     arrayOfByte[0] = arrayOfByte[3];
/* 708 */     arrayOfByte[3] = b;
/* 709 */     b = arrayOfByte[1];
/* 710 */     arrayOfByte[1] = arrayOfByte[2];
/* 711 */     arrayOfByte[2] = b;
/*     */ 
/*     */     
/* 714 */     b = arrayOfByte[4];
/* 715 */     arrayOfByte[4] = arrayOfByte[5];
/* 716 */     arrayOfByte[5] = b;
/*     */ 
/*     */     
/* 719 */     b = arrayOfByte[6];
/* 720 */     arrayOfByte[6] = arrayOfByte[7];
/* 721 */     arrayOfByte[7] = b;
/*     */     
/* 723 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   static final String readGUID(byte[] paramArrayOfbyte) throws SQLServerException {
/* 728 */     String str = "NNNNNNNN-NNNN-NNNN-NNNN-NNNNNNNNNNNN";
/* 729 */     byte[] arrayOfByte = paramArrayOfbyte;
/*     */     
/* 731 */     StringBuilder stringBuilder = new StringBuilder(str.length()); byte b;
/* 732 */     for (b = 0; b < 4; b++) {
/*     */       
/* 734 */       stringBuilder.append(hexChars[(arrayOfByte[3 - b] & 0xF0) >> 4]);
/* 735 */       stringBuilder.append(hexChars[arrayOfByte[3 - b] & 0xF]);
/*     */     } 
/* 737 */     stringBuilder.append('-');
/* 738 */     for (b = 0; b < 2; b++) {
/*     */       
/* 740 */       stringBuilder.append(hexChars[(arrayOfByte[5 - b] & 0xF0) >> 4]);
/* 741 */       stringBuilder.append(hexChars[arrayOfByte[5 - b] & 0xF]);
/*     */     } 
/* 743 */     stringBuilder.append('-');
/* 744 */     for (b = 0; b < 2; b++) {
/*     */       
/* 746 */       stringBuilder.append(hexChars[(arrayOfByte[7 - b] & 0xF0) >> 4]);
/* 747 */       stringBuilder.append(hexChars[arrayOfByte[7 - b] & 0xF]);
/*     */     } 
/* 749 */     stringBuilder.append('-');
/* 750 */     for (b = 0; b < 2; b++) {
/*     */       
/* 752 */       stringBuilder.append(hexChars[(arrayOfByte[8 + b] & 0xF0) >> 4]);
/* 753 */       stringBuilder.append(hexChars[arrayOfByte[8 + b] & 0xF]);
/*     */     } 
/* 755 */     stringBuilder.append('-');
/* 756 */     for (b = 0; b < 6; b++) {
/*     */       
/* 758 */       stringBuilder.append(hexChars[(arrayOfByte[10 + b] & 0xF0) >> 4]);
/* 759 */       stringBuilder.append(hexChars[arrayOfByte[10 + b] & 0xF]);
/*     */     } 
/*     */     
/* 762 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean IsActivityTraceOn() {
/* 767 */     LogManager logManager = LogManager.getLogManager();
/* 768 */     String str = logManager.getProperty("com.microsoft.sqlserver.jdbc.traceactivity");
/* 769 */     if (null != str && str.equalsIgnoreCase("on")) {
/* 770 */       return true;
/*     */     }
/* 772 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean shouldHonorAEForRead(SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, SQLServerConnection paramSQLServerConnection) {
/* 781 */     switch (paramSQLServerStatementColumnEncryptionSetting) {
/*     */       case OBJECT:
/* 783 */         return false;
/*     */       case STRING:
/* 785 */         return true;
/*     */       case BYTEARRAY:
/* 787 */         return true;
/*     */     } 
/*     */ 
/*     */     
/* 791 */     assert SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == paramSQLServerStatementColumnEncryptionSetting : "Unexpected value for command level override";
/* 792 */     return (paramSQLServerConnection != null && paramSQLServerConnection.isColumnEncryptionSettingEnabled());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean shouldHonorAEForParameters(SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, SQLServerConnection paramSQLServerConnection) {
/* 802 */     switch (paramSQLServerStatementColumnEncryptionSetting) {
/*     */       case OBJECT:
/* 804 */         return false;
/*     */       case STRING:
/* 806 */         return true;
/*     */       case BYTEARRAY:
/* 808 */         return false;
/*     */     } 
/*     */ 
/*     */     
/* 812 */     assert SQLServerStatementColumnEncryptionSetting.UseConnectionSetting == paramSQLServerStatementColumnEncryptionSetting : "Unexpected value for command level override";
/* 813 */     return (paramSQLServerConnection != null && paramSQLServerConnection.isColumnEncryptionSettingEnabled());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void validateMoneyRange(BigDecimal paramBigDecimal, JDBCType paramJDBCType) throws SQLServerException {
/* 819 */     if (null == paramBigDecimal) {
/*     */       return;
/*     */     }
/* 822 */     switch (paramJDBCType) {
/*     */       
/*     */       case OBJECT:
/* 825 */         if (1 != paramBigDecimal.compareTo(SSType.MAX_VALUE_MONEY) && -1 != paramBigDecimal.compareTo(SSType.MIN_VALUE_MONEY)) {
/*     */           return;
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       case STRING:
/* 832 */         if (1 != paramBigDecimal.compareTo(SSType.MAX_VALUE_SMALLMONEY) && -1 != paramBigDecimal.compareTo(SSType.MIN_VALUE_SMALLMONEY)) {
/*     */           return;
/*     */         }
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 839 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 840 */     Object[] arrayOfObject = { paramJDBCType };
/* 841 */     throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getValueLengthBaseOnJavaType(Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, JDBCType paramJDBCType) {
/*     */     int i;
/* 849 */     switch (paramJavaType) {
/*     */ 
/*     */ 
/*     */       
/*     */       case OBJECT:
/* 854 */         switch (paramJDBCType) {
/*     */           case BYTEARRAY:
/*     */           case BIGDECIMAL:
/* 857 */             paramJavaType = JavaType.BIGDECIMAL;
/*     */             break;
/*     */           case TIMESTAMP:
/* 860 */             paramJavaType = JavaType.TIME;
/*     */             break;
/*     */           case TIME:
/* 863 */             paramJavaType = JavaType.TIMESTAMP;
/*     */             break;
/*     */           case DATETIMEOFFSET:
/* 866 */             paramJavaType = JavaType.DATETIMEOFFSET;
/*     */             break;
/*     */         } 
/*     */ 
/*     */         
/*     */         break;
/*     */     } 
/*     */     
/* 874 */     switch (paramJavaType) {
/*     */       
/*     */       case STRING:
/* 877 */         if (JDBCType.GUID == paramJDBCType) {
/* 878 */           String str = "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX";
/* 879 */           return (null == paramObject) ? 0 : str.length();
/*     */         } 
/* 881 */         if (JDBCType.TIMESTAMP == paramJDBCType || JDBCType.TIME == paramJDBCType || JDBCType.DATETIMEOFFSET == paramJDBCType)
/*     */         {
/*     */           
/* 884 */           return (null == paramInteger2) ? 7 : paramInteger2.intValue();
/*     */         }
/*     */         
/* 887 */         return (null == paramObject) ? 0 : ((String)paramObject).length();
/*     */ 
/*     */       
/*     */       case BYTEARRAY:
/* 891 */         return (null == paramObject) ? 0 : ((byte[])paramObject).length;
/*     */       
/*     */       case BIGDECIMAL:
/* 894 */         i = -1;
/*     */         
/* 896 */         if (null == paramInteger1) {
/* 897 */           if (null == paramObject) {
/* 898 */             i = 0;
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 903 */           else if (0 == ((BigDecimal)paramObject).intValue()) {
/* 904 */             String str = "" + (BigDecimal)paramObject;
/* 905 */             str = str.replaceAll("\\.", "");
/* 906 */             str = str.replaceAll("\\-", "");
/* 907 */             i = str.length();
/*     */           
/*     */           }
/* 910 */           else if (("" + (BigDecimal)paramObject).contains("E")) {
/* 911 */             DecimalFormat decimalFormat = new DecimalFormat("###.#####");
/* 912 */             String str = decimalFormat.format(paramObject);
/* 913 */             str = str.replaceAll("\\.", "");
/* 914 */             str = str.replaceAll("\\-", "");
/* 915 */             i = str.length();
/*     */           } else {
/*     */             
/* 918 */             i = ((BigDecimal)paramObject).precision();
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 923 */           i = paramInteger1.intValue();
/*     */         } 
/*     */         
/* 926 */         return i;
/*     */       
/*     */       case TIMESTAMP:
/*     */       case TIME:
/*     */       case DATETIMEOFFSET:
/* 931 */         return (null == paramInteger2) ? 7 : paramInteger2.intValue();
/*     */       case READER:
/* 933 */         return (null == paramObject) ? 0 : 1073741823;
/*     */       
/*     */       case CLOB:
/* 936 */         return (null == paramObject) ? 0 : 2147483646;
/*     */       
/*     */       case NCLOB:
/* 939 */         return (null == paramObject) ? 0 : 1073741823;
/*     */     } 
/* 941 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static synchronized boolean checkIfNeedNewAccessToken(SQLServerConnection paramSQLServerConnection) {
/* 948 */     Date date1 = paramSQLServerConnection.getAuthenticationResult().getExpiresOnDate();
/* 949 */     Date date2 = new Date();
/*     */ 
/*     */ 
/*     */     
/* 953 */     if (date1.getTime() - date2.getTime() < 2700000L) {
/*     */ 
/*     */       
/* 956 */       if (date1.getTime() - date2.getTime() < 600000L) {
/* 957 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 961 */       if (paramSQLServerConnection.attemptRefreshTokenLocked) {
/* 962 */         return false;
/*     */       }
/*     */       
/* 965 */       paramSQLServerConnection.attemptRefreshTokenLocked = true;
/* 966 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 971 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\Util.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */