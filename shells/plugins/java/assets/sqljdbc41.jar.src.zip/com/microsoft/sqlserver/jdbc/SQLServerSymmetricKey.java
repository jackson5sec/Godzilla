/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SQLServerSymmetricKey
/*    */ {
/*    */   private byte[] rootKey;
/*    */   
/*    */   SQLServerSymmetricKey(byte[] paramArrayOfbyte) throws SQLServerException {
/* 13 */     if (null == paramArrayOfbyte)
/*    */     {
/* 15 */       throw new SQLServerException(this, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
/*    */     }
/* 17 */     if (0 == paramArrayOfbyte.length)
/*    */     {
/* 19 */       throw new SQLServerException(this, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
/*    */     }
/* 21 */     this.rootKey = paramArrayOfbyte;
/*    */   }
/*    */   
/*    */   byte[] getRootKey() {
/* 25 */     return this.rootKey;
/*    */   }
/*    */   
/*    */   int length() {
/* 29 */     return this.rootKey.length;
/*    */   }
/*    */ 
/*    */   
/*    */   void zeroOutKey() {
/* 34 */     for (byte b = 0; b < this.rootKey.length; b++)
/*    */     {
/* 36 */       this.rootKey[b] = 0;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerSymmetricKey.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */