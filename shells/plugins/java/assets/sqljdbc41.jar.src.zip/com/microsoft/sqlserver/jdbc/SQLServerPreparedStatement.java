/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Vector;
/*      */ import java.util.logging.Level;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ public class SQLServerPreparedStatement
/*      */   extends SQLServerStatement implements ISQLServerPreparedStatement {
/*      */   boolean isInternalEncryptionQuery = false;
/*      */   private static final int BATCH_STATEMENT_DELIMITER_TDS_71 = 128;
/*      */   private static final int BATCH_STATEMENT_DELIMITER_TDS_72 = 255;
/*   36 */   final int nBatchStatementDelimiter = 255;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String sqlCommand;
/*      */ 
/*      */ 
/*      */   
/*      */   private String preparedTypeDefinitions;
/*      */ 
/*      */ 
/*      */   
/*      */   final String userSQL;
/*      */ 
/*      */ 
/*      */   
/*      */   private String preparedSQL;
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<String> parameterNames;
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean bReturnValueSyntax;
/*      */ 
/*      */ 
/*      */   
/*      */   int outParamIndexAdjustment;
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList<Parameter[]> batchParamValues;
/*      */ 
/*      */ 
/*      */   
/*   73 */   private int prepStmtHandle = 0;
/*      */ 
/*      */   
/*      */   private boolean expectPrepStmtHandle = false;
/*      */ 
/*      */ 
/*      */   
/*      */   String getClassNameInternal() {
/*   81 */     return "SQLServerPreparedStatement";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerPreparedStatement(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/*   96 */     super(paramSQLServerConnection, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*   97 */     this.stmtPoolable = true;
/*   98 */     this.sqlCommand = paramString;
/*      */     
/*  100 */     JDBCSyntaxTranslator jDBCSyntaxTranslator = new JDBCSyntaxTranslator();
/*  101 */     paramString = jDBCSyntaxTranslator.translate(paramString);
/*  102 */     this.procedureName = jDBCSyntaxTranslator.getProcedureName();
/*  103 */     this.bReturnValueSyntax = jDBCSyntaxTranslator.hasReturnValueSyntax();
/*      */     
/*  105 */     this.userSQL = paramString;
/*  106 */     initParams(this.userSQL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closePreparedHandle() {
/*  114 */     if (0 == this.prepStmtHandle) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  120 */     if (this.connection.isSessionUnAvailable()) {
/*      */       
/*  122 */       if (getStatementLogger().isLoggable(Level.FINER)) {
/*  123 */         getStatementLogger().finer(this + ": Not closing PreparedHandle:" + this.prepStmtHandle + "; connection is already closed.");
/*      */       }
/*      */     } else {
/*      */       
/*  127 */       if (getStatementLogger().isLoggable(Level.FINER)) {
/*  128 */         getStatementLogger().finer(this + ": Closing PreparedHandle:" + this.prepStmtHandle);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  154 */         executeCommand(new PreparedHandleClose());
/*      */       }
/*  156 */       catch (SQLServerException sQLServerException) {
/*      */         
/*  158 */         if (getStatementLogger().isLoggable(Level.FINER)) {
/*  159 */           getStatementLogger().log(Level.FINER, this + ": Error (ignored) closing PreparedHandle:" + this.prepStmtHandle, sQLServerException);
/*      */         }
/*      */       } 
/*  162 */       if (getStatementLogger().isLoggable(Level.FINER)) {
/*  163 */         getStatementLogger().finer(this + ": Closed PreparedHandle:" + this.prepStmtHandle);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void closeInternal() {
/*  178 */     super.closeInternal();
/*      */ 
/*      */     
/*  181 */     closePreparedHandle();
/*      */ 
/*      */     
/*  184 */     this.batchParamValues = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initParams(String paramString) {
/*  193 */     byte b1 = 0;
/*      */ 
/*      */ 
/*      */     
/*  197 */     int i = -1;
/*  198 */     while ((i = ParameterUtils.scanSQLForChar('?', paramString, ++i)) < paramString.length()) {
/*  199 */       b1++;
/*      */     }
/*  201 */     this.inOutParam = new Parameter[b1];
/*  202 */     for (byte b2 = 0; b2 < b1; b2++) {
/*  203 */       this.inOutParam[b2] = new Parameter(Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearParameters() throws SQLServerException {
/*  209 */     loggerExternal.entering(getClassNameLogging(), "clearParameters");
/*  210 */     checkClosed();
/*      */     
/*  212 */     if (this.inOutParam == null)
/*  213 */       return;  for (byte b = 0; b < this.inOutParam.length; b++)
/*      */     {
/*  215 */       this.inOutParam[b].clearInputValue();
/*      */     }
/*  217 */     loggerExternal.exiting(getClassNameLogging(), "clearParameters");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean buildPreparedStrings(Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
/*  227 */     String str = buildParamTypeDefinitions(paramArrayOfParameter, paramBoolean);
/*  228 */     if (null != this.preparedTypeDefinitions && str.equals(this.preparedTypeDefinitions)) {
/*  229 */       return false;
/*      */     }
/*  231 */     this.preparedTypeDefinitions = str;
/*      */ 
/*      */     
/*  234 */     this.preparedSQL = this.connection.replaceParameterMarkers(this.userSQL, paramArrayOfParameter, this.bReturnValueSyntax);
/*  235 */     if (this.bRequestedGeneratedKeys) {
/*  236 */       this.preparedSQL += " select SCOPE_IDENTITY() AS GENERATED_KEYS";
/*      */     }
/*  238 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String buildParamTypeDefinitions(Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
/*  250 */     StringBuilder stringBuilder = new StringBuilder();
/*  251 */     int i = paramArrayOfParameter.length;
/*  252 */     char[] arrayOfChar = new char[10];
/*  253 */     this.parameterNames = new ArrayList<>();
/*      */     
/*  255 */     for (byte b = 0; b < i; b++) {
/*  256 */       if (b > 0) {
/*  257 */         stringBuilder.append(',');
/*      */       }
/*  259 */       int j = SQLServerConnection.makeParamName(b, arrayOfChar, 0);
/*  260 */       for (byte b1 = 0; b1 < j; b1++)
/*  261 */         stringBuilder.append(arrayOfChar[b1]); 
/*  262 */       stringBuilder.append(' ');
/*      */       
/*  264 */       this.parameterNames.add(b, (new String(arrayOfChar)).trim());
/*      */       
/*  266 */       (paramArrayOfParameter[b]).renewDefinition = paramBoolean;
/*  267 */       String str = paramArrayOfParameter[b].getTypeDefinition(this.connection, resultsReader());
/*  268 */       if (null == str) {
/*      */         
/*  270 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
/*  271 */         Object[] arrayOfObject = { new Integer(b + 1) };
/*  272 */         SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */       } 
/*      */       
/*  275 */       stringBuilder.append(str);
/*      */       
/*  277 */       if (paramArrayOfParameter[b].isOutput())
/*  278 */         stringBuilder.append(" OUTPUT"); 
/*      */     } 
/*  280 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLServerException {
/*  291 */     loggerExternal.entering(getClassNameLogging(), "executeQuery");
/*  292 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  294 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  296 */     checkClosed();
/*  297 */     executeStatement(new PrepStmtExecCmd(this, 1));
/*  298 */     loggerExternal.exiting(getClassNameLogging(), "executeQuery");
/*  299 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ResultSet executeQueryInternal() throws SQLServerException {
/*  309 */     checkClosed();
/*  310 */     executeStatement(new PrepStmtExecCmd(this, 5));
/*  311 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLServerException {
/*  320 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate");
/*  321 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  323 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/*  326 */     checkClosed();
/*      */     
/*  328 */     executeStatement(new PrepStmtExecCmd(this, 2));
/*      */ 
/*      */     
/*  331 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/*  332 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/*  334 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Long(this.updateCount));
/*      */     
/*  336 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public long executeLargeUpdate() throws SQLServerException {
/*  341 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/*  343 */     loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate");
/*  344 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  346 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  348 */     checkClosed();
/*  349 */     executeStatement(new PrepStmtExecCmd(this, 2));
/*  350 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(this.updateCount));
/*  351 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLServerException {
/*  361 */     loggerExternal.entering(getClassNameLogging(), "execute");
/*  362 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  364 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  366 */     checkClosed();
/*  367 */     executeStatement(new PrepStmtExecCmd(this, 3));
/*  368 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
/*  369 */     return (null != this.resultSet);
/*      */   }
/*      */   
/*      */   private final class PrepStmtExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     private final SQLServerPreparedStatement stmt;
/*      */     
/*      */     PrepStmtExecCmd(SQLServerPreparedStatement param1SQLServerPreparedStatement1, int param1Int) {
/*  378 */       super(param1SQLServerPreparedStatement1.toString() + " executeXXX", SQLServerPreparedStatement.this.queryTimeout);
/*  379 */       this.stmt = param1SQLServerPreparedStatement1;
/*  380 */       param1SQLServerPreparedStatement1.executeMethod = param1Int;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/*  385 */       this.stmt.doExecutePreparedStatement(this);
/*  386 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
/*  391 */       SQLServerPreparedStatement.this.ensureExecuteResultsReader(param1TDSReader);
/*  392 */       SQLServerPreparedStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final void doExecutePreparedStatement(PrepStmtExecCmd paramPrepStmtExecCmd) throws SQLServerException {
/*  398 */     resetForReexecute();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  410 */     setMaxRowsAndMaxFieldSize();
/*      */     
/*  412 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  414 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/*  417 */     boolean bool = buildPreparedStrings(this.inOutParam, false);
/*  418 */     if (Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection) && 0 < this.inOutParam.length && !this.isInternalEncryptionQuery) {
/*      */ 
/*      */ 
/*      */       
/*  422 */       getParameterEncryptionMetadata(this.inOutParam);
/*      */ 
/*      */ 
/*      */       
/*  426 */       setMaxRowsAndMaxFieldSize();
/*      */ 
/*      */       
/*  429 */       buildPreparedStrings(this.inOutParam, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  434 */     TDSWriter tDSWriter = paramPrepStmtExecCmd.startRequest((byte)3);
/*      */     
/*  436 */     doPrepExec(tDSWriter, this.inOutParam, bool);
/*      */     
/*  438 */     ensureExecuteResultsReader(paramPrepStmtExecCmd.startResponse(getIsResponseBufferingAdaptive()));
/*  439 */     startResults();
/*  440 */     getNextResult();
/*      */     
/*  442 */     if (1 == this.executeMethod && null == this.resultSet) {
/*      */       
/*  444 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_noResultset"), (String)null, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  451 */     else if (2 == this.executeMethod && null != this.resultSet) {
/*      */       
/*  453 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean consumeExecOutParam(TDSReader paramTDSReader) throws SQLServerException {
/*      */     final class PrepStmtExecOutParamHandler
/*      */       extends SQLServerStatement.StmtExecOutParamHandler
/*      */     {
/*      */       boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
/*  477 */         if (!SQLServerPreparedStatement.this.expectPrepStmtHandle) {
/*  478 */           return super.onRetValue(param1TDSReader);
/*      */         }
/*      */ 
/*      */         
/*  482 */         SQLServerPreparedStatement.this.expectPrepStmtHandle = false;
/*  483 */         Parameter parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerPreparedStatement.this.stmtColumnEncriptionSetting, SQLServerPreparedStatement.this.connection));
/*  484 */         parameter.skipRetValStatus(param1TDSReader);
/*  485 */         SQLServerPreparedStatement.this.prepStmtHandle = parameter.getInt(param1TDSReader);
/*  486 */         parameter.skipValue(param1TDSReader, true);
/*  487 */         if (SQLServerPreparedStatement.this.getStatementLogger().isLoggable(Level.FINER)) {
/*  488 */           SQLServerPreparedStatement.this.getStatementLogger().finer(toString() + ": Setting PreparedHandle:" + SQLServerPreparedStatement.this.prepStmtHandle);
/*      */         }
/*  490 */         return true;
/*      */       }
/*      */     };
/*      */     
/*  494 */     if (this.expectPrepStmtHandle || this.expectCursorOutParams) {
/*      */       
/*  496 */       TDSParser.parse(paramTDSReader, new PrepStmtExecOutParamHandler());
/*  497 */       return true;
/*      */     } 
/*      */     
/*  500 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sendParamsByRPC(TDSWriter paramTDSWriter, Parameter[] paramArrayOfParameter) throws SQLServerException {
/*  509 */     for (byte b = 0; b < paramArrayOfParameter.length; b++) {
/*      */       
/*  511 */       if (JDBCType.TVP == paramArrayOfParameter[b].getJdbcType()) {
/*      */         
/*  513 */         char[] arrayOfChar = new char[10];
/*  514 */         int i = SQLServerConnection.makeParamName(b, arrayOfChar, 0);
/*  515 */         paramTDSWriter.writeByte((byte)i);
/*  516 */         paramTDSWriter.writeString(new String(arrayOfChar, 0, i));
/*      */       } 
/*  518 */       paramArrayOfParameter[b].sendByRPC(paramTDSWriter, this.connection);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final void buildServerCursorPrepExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
/*  524 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  525 */       getStatementLogger().fine(toString() + ": calling sp_cursorprepexec: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
/*      */     }
/*  527 */     this.expectPrepStmtHandle = true;
/*  528 */     this.executedSqlDirectly = false;
/*  529 */     this.expectCursorOutParams = true;
/*  530 */     this.outParamIndexAdjustment = 7;
/*      */     
/*  532 */     paramTDSWriter.writeShort((short)-1);
/*  533 */     paramTDSWriter.writeShort((short)5);
/*  534 */     paramTDSWriter.writeByte((byte)0);
/*  535 */     paramTDSWriter.writeByte((byte)0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  540 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), true);
/*  541 */     this.prepStmtHandle = 0;
/*      */ 
/*      */     
/*  544 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */ 
/*      */     
/*  547 */     paramTDSWriter.writeRPCStringUnicode((this.preparedTypeDefinitions.length() > 0) ? this.preparedTypeDefinitions : null);
/*      */ 
/*      */     
/*  550 */     paramTDSWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  555 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt() & (((0 == this.preparedTypeDefinitions.length()) ? 4096 : 0) ^ 0xFFFFFFFF)), false);
/*      */ 
/*      */     
/*  558 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);
/*      */ 
/*      */     
/*  561 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void buildPrepExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
/*  566 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  567 */       getStatementLogger().fine(toString() + ": calling sp_prepexec: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
/*      */     }
/*  569 */     this.expectPrepStmtHandle = true;
/*  570 */     this.executedSqlDirectly = true;
/*  571 */     this.expectCursorOutParams = false;
/*  572 */     this.outParamIndexAdjustment = 3;
/*      */     
/*  574 */     paramTDSWriter.writeShort((short)-1);
/*  575 */     paramTDSWriter.writeShort((short)13);
/*  576 */     paramTDSWriter.writeByte((byte)0);
/*  577 */     paramTDSWriter.writeByte((byte)0);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  582 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), true);
/*  583 */     this.prepStmtHandle = 0;
/*      */ 
/*      */     
/*  586 */     paramTDSWriter.writeRPCStringUnicode((this.preparedTypeDefinitions.length() > 0) ? this.preparedTypeDefinitions : null);
/*      */ 
/*      */     
/*  589 */     paramTDSWriter.writeRPCStringUnicode(this.preparedSQL);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void buildServerCursorExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
/*  594 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  595 */       getStatementLogger().fine(toString() + ": calling sp_cursorexecute: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
/*      */     }
/*  597 */     this.expectPrepStmtHandle = false;
/*  598 */     this.executedSqlDirectly = false;
/*  599 */     this.expectCursorOutParams = true;
/*  600 */     this.outParamIndexAdjustment = 5;
/*      */     
/*  602 */     paramTDSWriter.writeShort((short)-1);
/*  603 */     paramTDSWriter.writeShort((short)4);
/*  604 */     paramTDSWriter.writeByte((byte)0);
/*  605 */     paramTDSWriter.writeByte((byte)0);
/*      */ 
/*      */     
/*  608 */     assert 0 != this.prepStmtHandle;
/*  609 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), false);
/*      */ 
/*      */     
/*  612 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */ 
/*      */     
/*  615 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt() & 0xFFFFEFFF), false);
/*      */ 
/*      */     
/*  618 */     paramTDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);
/*      */ 
/*      */     
/*  621 */     paramTDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void buildExecParams(TDSWriter paramTDSWriter) throws SQLServerException {
/*  626 */     if (getStatementLogger().isLoggable(Level.FINE)) {
/*  627 */       getStatementLogger().fine(toString() + ": calling sp_execute: PreparedHandle:" + this.prepStmtHandle + ", SQL:" + this.preparedSQL);
/*      */     }
/*  629 */     this.expectPrepStmtHandle = false;
/*  630 */     this.executedSqlDirectly = true;
/*  631 */     this.expectCursorOutParams = false;
/*  632 */     this.outParamIndexAdjustment = 1;
/*      */     
/*  634 */     paramTDSWriter.writeShort((short)-1);
/*  635 */     paramTDSWriter.writeShort((short)12);
/*  636 */     paramTDSWriter.writeByte((byte)0);
/*  637 */     paramTDSWriter.writeByte((byte)0);
/*      */ 
/*      */     
/*  640 */     assert 0 != this.prepStmtHandle;
/*  641 */     paramTDSWriter.writeRPCInt(null, new Integer(this.prepStmtHandle), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getParameterEncryptionMetadata(Parameter[] paramArrayOfParameter) throws SQLServerException {
/*  652 */     SQLServerResultSet sQLServerResultSet = null;
/*  653 */     SQLServerCallableStatement sQLServerCallableStatement = null;
/*      */     
/*  655 */     assert this.connection != null : "Connection should not be null";
/*      */     
/*      */     try {
/*  658 */       if (getStatementLogger().isLoggable(Level.FINE)) {
/*  659 */         getStatementLogger().fine("Calling stored procedure sp_describe_parameter_encryption to get parameter encryption information.");
/*      */       }
/*      */       
/*  662 */       sQLServerCallableStatement = (SQLServerCallableStatement)this.connection.prepareCall("exec sp_describe_parameter_encryption ?,?");
/*  663 */       sQLServerCallableStatement.isInternalEncryptionQuery = true;
/*  664 */       sQLServerCallableStatement.setNString(1, this.preparedSQL);
/*  665 */       sQLServerCallableStatement.setNString(2, this.preparedTypeDefinitions);
/*  666 */       sQLServerResultSet = (SQLServerResultSet)sQLServerCallableStatement.executeQueryInternal();
/*      */     }
/*  668 */     catch (SQLException sQLException) {
/*      */       
/*  670 */       if (sQLException instanceof SQLServerException)
/*      */       {
/*  672 */         throw (SQLServerException)sQLException;
/*      */       }
/*      */ 
/*      */       
/*  676 */       throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, sQLException);
/*      */     } 
/*      */ 
/*      */     
/*  680 */     if (null == sQLServerResultSet) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  687 */     HashMap<Object, Object> hashMap = new HashMap<>();
/*  688 */     CekTableEntry cekTableEntry = null;
/*      */     
/*      */     try {
/*  691 */       while (sQLServerResultSet.next()) {
/*      */         
/*  693 */         int i = sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.KeyOrdinal.value());
/*  694 */         if (!hashMap.containsKey(Integer.valueOf(i))) {
/*      */           
/*  696 */           cekTableEntry = new CekTableEntry(i);
/*  697 */           hashMap.put(Integer.valueOf(cekTableEntry.ordinal), cekTableEntry);
/*      */         }
/*      */         else {
/*      */           
/*  701 */           cekTableEntry = (CekTableEntry)hashMap.get(Integer.valueOf(i));
/*      */         } 
/*  703 */         cekTableEntry.add(sQLServerResultSet.getBytes(DescribeParameterEncryptionResultSet1.EncryptedKey.value()), sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.DbId.value()), sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.KeyId.value()), sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet1.KeyVersion.value()), sQLServerResultSet.getBytes(DescribeParameterEncryptionResultSet1.KeyMdVersion.value()), sQLServerResultSet.getString(DescribeParameterEncryptionResultSet1.KeyPath.value()), sQLServerResultSet.getString(DescribeParameterEncryptionResultSet1.ProviderName.value()), sQLServerResultSet.getString(DescribeParameterEncryptionResultSet1.KeyEncryptionAlgorithm.value()));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  714 */       if (getStatementLogger().isLoggable(Level.FINE)) {
/*  715 */         getStatementLogger().fine("Matadata of CEKs is retrieved.");
/*      */       }
/*      */     }
/*  718 */     catch (SQLException sQLException) {
/*      */       
/*  720 */       if (sQLException instanceof SQLServerException)
/*      */       {
/*  722 */         throw (SQLServerException)sQLException;
/*      */       }
/*      */ 
/*      */       
/*  726 */       throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, sQLException);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  731 */     if (!sQLServerCallableStatement.getMoreResults())
/*      */     {
/*  733 */       throw new SQLServerException(this, SQLServerException.getErrString("R_UnexpectedDescribeParamFormat"), null, 0, false);
/*      */     }
/*      */ 
/*      */     
/*  737 */     byte b = 0;
/*      */     
/*      */     try {
/*  740 */       sQLServerResultSet = (SQLServerResultSet)sQLServerCallableStatement.getResultSet();
/*  741 */       while (sQLServerResultSet.next()) {
/*      */         
/*  743 */         b++;
/*  744 */         String str = sQLServerResultSet.getString(DescribeParameterEncryptionResultSet2.ParameterName.value());
/*  745 */         int i = this.parameterNames.indexOf(str);
/*  746 */         int j = sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionKeyOrdinal.value());
/*  747 */         cekTableEntry = (CekTableEntry)hashMap.get(Integer.valueOf(j));
/*      */ 
/*      */         
/*  750 */         if (null != cekTableEntry && hashMap.size() < j) {
/*      */           
/*  752 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionKeyOridnal"));
/*  753 */           Object[] arrayOfObject = { Integer.valueOf(j), Integer.valueOf(cekTableEntry.getSize()) };
/*  754 */           throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */         } 
/*  756 */         SQLServerEncryptionType sQLServerEncryptionType = SQLServerEncryptionType.of((byte)sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.ColumnEncrytionType.value()));
/*      */         
/*  758 */         if (SQLServerEncryptionType.PlainText != sQLServerEncryptionType) {
/*      */           
/*  760 */           (paramArrayOfParameter[i]).cryptoMeta = new CryptoMetadata(cekTableEntry, (short)j, (byte)sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.ColumnEncryptionAlgorithm.value()), null, sQLServerEncryptionType.value, (byte)sQLServerResultSet.getInt(DescribeParameterEncryptionResultSet2.NormalizationRuleVersion.value()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  769 */           SQLServerSecurityUtility.decryptSymmetricKey((paramArrayOfParameter[i]).cryptoMeta, this.connection);
/*      */           continue;
/*      */         } 
/*  772 */         if (true == paramArrayOfParameter[i].getForceEncryption()) {
/*      */           
/*  774 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumn"));
/*  775 */           Object[] arrayOfObject = { this.userSQL, Integer.valueOf(i + 1) };
/*  776 */           SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
/*      */         } 
/*      */       } 
/*      */       
/*  780 */       if (getStatementLogger().isLoggable(Level.FINE)) {
/*  781 */         getStatementLogger().fine("Parameter encryption metadata is set.");
/*      */       }
/*      */     }
/*  784 */     catch (SQLException sQLException) {
/*      */       
/*  786 */       if (sQLException instanceof SQLServerException)
/*      */       {
/*  788 */         throw (SQLServerException)sQLException;
/*      */       }
/*      */ 
/*      */       
/*  792 */       throw new SQLServerException(SQLServerException.getErrString("R_UnableRetrieveParameterMetadata"), null, 0, sQLException);
/*      */     } 
/*      */ 
/*      */     
/*  796 */     if (b != paramArrayOfParameter.length) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  801 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_MissingParamEncryptionMetadata"));
/*  802 */       Object[] arrayOfObject = { this.userSQL };
/*  803 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */ 
/*      */     
/*  807 */     sQLServerResultSet.close();
/*      */     
/*  809 */     if (null != sQLServerCallableStatement)
/*      */     {
/*  811 */       sQLServerCallableStatement.close();
/*      */     }
/*  813 */     this.connection.resetCurrentCommand();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean doPrepExec(TDSWriter paramTDSWriter, Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
/*  830 */     boolean bool = (paramBoolean || 0 == this.prepStmtHandle) ? true : false;
/*      */     
/*  832 */     if (bool) {
/*      */       
/*  834 */       if (isCursorable(this.executeMethod)) {
/*  835 */         buildServerCursorPrepExecParams(paramTDSWriter);
/*      */       } else {
/*  837 */         buildPrepExecParams(paramTDSWriter);
/*      */       }
/*      */     
/*      */     }
/*  841 */     else if (isCursorable(this.executeMethod)) {
/*  842 */       buildServerCursorExecParams(paramTDSWriter);
/*      */     } else {
/*  844 */       buildExecParams(paramTDSWriter);
/*      */     } 
/*      */     
/*  847 */     sendParamsByRPC(paramTDSWriter, paramArrayOfParameter);
/*  848 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSetMetaData getMetaData() throws SQLServerException {
/*  853 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/*  854 */     checkClosed();
/*  855 */     boolean bool = false;
/*  856 */     ResultSetMetaData resultSetMetaData = null;
/*      */ 
/*      */     
/*      */     try {
/*  860 */       if (this.resultSet != null) {
/*  861 */         this.resultSet.checkClosed();
/*      */       }
/*  863 */     } catch (SQLServerException sQLServerException) {
/*      */       
/*  865 */       bool = true;
/*      */     } 
/*  867 */     if (this.resultSet == null || bool) {
/*      */       
/*  869 */       SQLServerResultSet sQLServerResultSet = (SQLServerResultSet)buildExecuteMetaData();
/*  870 */       if (null != sQLServerResultSet) {
/*  871 */         resultSetMetaData = sQLServerResultSet.getMetaData();
/*      */       }
/*      */     }
/*  874 */     else if (this.resultSet != null) {
/*      */       
/*  876 */       resultSetMetaData = this.resultSet.getMetaData();
/*      */     } 
/*  878 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", resultSetMetaData);
/*  879 */     return resultSetMetaData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSet buildExecuteMetaData() throws SQLServerException {
/*  891 */     String str = this.sqlCommand;
/*  892 */     if (str.indexOf('{') >= 0)
/*      */     {
/*  894 */       str = (new JDBCSyntaxTranslator()).translate(str);
/*      */     }
/*      */     
/*  897 */     SQLServerResultSet sQLServerResultSet = null;
/*      */     try {
/*  899 */       str = replaceMarkerWithNull(str);
/*  900 */       SQLServerStatement sQLServerStatement = (SQLServerStatement)this.connection.createStatement();
/*  901 */       sQLServerResultSet = sQLServerStatement.executeQueryInternal("set fmtonly on " + str + "\nset fmtonly off");
/*      */     }
/*  903 */     catch (SQLException sQLException) {
/*      */       
/*  905 */       if (false == sQLException.getMessage().equals(SQLServerException.getErrString("R_noResultset"))) {
/*      */ 
/*      */         
/*  908 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_processingError"));
/*  909 */         Object[] arrayOfObject = { new String(sQLException.getMessage()) };
/*      */         
/*  911 */         SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
/*      */       } 
/*      */     } 
/*      */     
/*  915 */     return sQLServerResultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Parameter setterGetParam(int paramInt) throws SQLServerException {
/*  930 */     if (paramInt < 1 || paramInt > this.inOutParam.length) {
/*  931 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  932 */       Object[] arrayOfObject = { new Integer(paramInt) };
/*  933 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
/*      */     } 
/*      */ 
/*      */     
/*  937 */     return this.inOutParam[paramInt - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, String paramString) throws SQLServerException {
/*  943 */     setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, paramString);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, boolean paramBoolean) throws SQLServerException {
/*  948 */     setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, null, null, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
/*  953 */     setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, null, paramInteger1, paramInteger2, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/*  958 */     setterGetParam(paramInt).setValue(paramJDBCType, paramObject, paramJavaType, null, paramCalendar, null, null, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setStream(int paramInt, StreamType paramStreamType, Object paramObject, JavaType paramJavaType, long paramLong) throws SQLServerException {
/*  963 */     setterGetParam(paramInt).setValue(paramStreamType.getJDBCType(), paramObject, paramJavaType, new StreamSetterArgs(paramStreamType, paramLong), null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLServerException {
/*  980 */     setterGetParam(paramInt).setValue(JDBCType.SQLXML, paramSQLXML, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, null, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/*  997 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  998 */     if (loggerExternal.isLoggable(Level.FINER))
/*  999 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream }); 
/* 1000 */     checkClosed();
/* 1001 */     setStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1002 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException {
/* 1007 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1008 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) }); 
/* 1009 */     checkClosed();
/* 1010 */     setStream(paramInt1, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/* 1011 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1016 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1017 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1018 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) }); 
/* 1019 */     checkClosed();
/* 1020 */     setStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1021 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   private final Parameter getParam(int paramInt) throws SQLServerException {
/* 1026 */     paramInt--;
/* 1027 */     if (paramInt < 0 || paramInt >= this.inOutParam.length) {
/*      */       
/* 1029 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/* 1030 */       Object[] arrayOfObject = { new Integer(paramInt + 1) };
/* 1031 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
/*      */     } 
/*      */     
/* 1034 */     return this.inOutParam[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
/* 1040 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1041 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
/* 1042 */     checkClosed();
/* 1043 */     setValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);
/* 1044 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBigDecimal(int paramInt1, BigDecimal paramBigDecimal, int paramInt2, int paramInt3) throws SQLServerException {
/* 1049 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1050 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt1), paramBigDecimal, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }); 
/* 1051 */     checkClosed();
/* 1052 */     setValue(paramInt1, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), false);
/* 1053 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBigDecimal(int paramInt1, BigDecimal paramBigDecimal, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException {
/* 1058 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1059 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { Integer.valueOf(paramInt1), paramBigDecimal, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Boolean.valueOf(paramBoolean) }); 
/* 1060 */     checkClosed();
/* 1061 */     setValue(paramInt1, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), paramBoolean);
/* 1062 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
/* 1067 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1068 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
/* 1069 */     checkClosed();
/* 1070 */     setValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/* 1071 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 1076 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1077 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 1078 */     checkClosed();
/* 1079 */     setValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/* 1080 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
/* 1085 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1086 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
/* 1087 */     checkClosed();
/* 1088 */     setValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/* 1089 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 1094 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1095 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 1096 */     checkClosed();
/* 1097 */     setValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/* 1098 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 1103 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1104 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1105 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStreaml", new Object[] { Integer.valueOf(paramInt), paramInputStream }); 
/* 1106 */     checkClosed();
/* 1107 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1108 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException {
/* 1113 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1114 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) }); 
/* 1115 */     checkClosed();
/* 1116 */     setStream(paramInt1, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/* 1117 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1122 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1123 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1124 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) }); 
/* 1125 */     checkClosed();
/* 1126 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1127 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBoolean(int paramInt, boolean paramBoolean) throws SQLServerException {
/* 1132 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1133 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) }); 
/* 1134 */     checkClosed();
/* 1135 */     setValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);
/* 1136 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBoolean(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
/* 1141 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1142 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) }); 
/* 1143 */     checkClosed();
/* 1144 */     setValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);
/* 1145 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setByte(int paramInt, byte paramByte) throws SQLServerException {
/* 1150 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1151 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte) }); 
/* 1152 */     checkClosed();
/* 1153 */     setValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, false);
/* 1154 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setByte(int paramInt, byte paramByte, boolean paramBoolean) throws SQLServerException {
/* 1159 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1160 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) }); 
/* 1161 */     checkClosed();
/* 1162 */     setValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);
/* 1163 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLServerException {
/* 1168 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1169 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte }); 
/* 1170 */     checkClosed();
/* 1171 */     setValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);
/* 1172 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
/* 1177 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1178 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte, Boolean.valueOf(paramBoolean) }); 
/* 1179 */     checkClosed();
/* 1180 */     setValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);
/* 1181 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setUniqueIdentifier(int paramInt, String paramString) throws SQLServerException {
/* 1186 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1187 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString }); 
/* 1188 */     checkClosed();
/* 1189 */     setValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, false);
/* 1190 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setUniqueIdentifier(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
/* 1195 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1196 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) }); 
/* 1197 */     checkClosed();
/* 1198 */     setValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, paramBoolean);
/* 1199 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDouble(int paramInt, double paramDouble) throws SQLServerException {
/* 1204 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1205 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble) }); 
/* 1206 */     checkClosed();
/* 1207 */     setValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);
/* 1208 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDouble(int paramInt, double paramDouble, boolean paramBoolean) throws SQLServerException {
/* 1213 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1214 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) }); 
/* 1215 */     checkClosed();
/* 1216 */     setValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);
/* 1217 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setFloat(int paramInt, float paramFloat) throws SQLServerException {
/* 1222 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1223 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat) }); 
/* 1224 */     checkClosed();
/* 1225 */     setValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);
/* 1226 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setFloat(int paramInt, float paramFloat, boolean paramBoolean) throws SQLServerException {
/* 1231 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1232 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) }); 
/* 1233 */     checkClosed();
/* 1234 */     setValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);
/* 1235 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setInt(int paramInt1, int paramInt2) throws SQLServerException {
/* 1240 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1241 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
/* 1242 */     checkClosed();
/* 1243 */     setValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, false);
/* 1244 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setInt(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 1249 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1250 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
/* 1251 */     checkClosed();
/* 1252 */     setValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, paramBoolean);
/* 1253 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setLong(int paramInt, long paramLong) throws SQLServerException {
/* 1258 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1259 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) }); 
/* 1260 */     checkClosed();
/* 1261 */     setValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);
/* 1262 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setLong(int paramInt, long paramLong, boolean paramBoolean) throws SQLServerException {
/* 1267 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1268 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) }); 
/* 1269 */     checkClosed();
/* 1270 */     setValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);
/* 1271 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setNull(int paramInt1, int paramInt2) throws SQLServerException {
/* 1277 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1278 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
/* 1279 */     checkClosed();
/* 1280 */     setObject(setterGetParam(paramInt1), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, (String)null);
/* 1281 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setObjectNoType(int paramInt, Object paramObject, boolean paramBoolean) throws SQLServerException {
/* 1288 */     Parameter parameter = setterGetParam(paramInt);
/* 1289 */     JDBCType jDBCType = parameter.getJdbcType();
/* 1290 */     String str = null;
/*      */     
/* 1292 */     if (null == paramObject) {
/*      */ 
/*      */ 
/*      */       
/* 1296 */       if (JDBCType.UNKNOWN == jDBCType) {
/* 1297 */         jDBCType = JDBCType.CHAR;
/*      */       }
/* 1299 */       setObject(parameter, (Object)null, JavaType.OBJECT, jDBCType, (Integer)null, (Integer)null, paramBoolean, paramInt, (String)null);
/*      */     }
/*      */     else {
/*      */       
/* 1303 */       JavaType javaType = JavaType.of(paramObject);
/* 1304 */       if (JavaType.TVP == javaType)
/* 1305 */         str = getTVPNameIfNull(paramInt, (String)null); 
/* 1306 */       jDBCType = javaType.getJDBCType(SSType.UNKNOWN, jDBCType);
/*      */       
/* 1308 */       if (JDBCType.UNKNOWN == jDBCType && 
/* 1309 */         paramObject instanceof java.util.UUID) {
/* 1310 */         javaType = JavaType.STRING;
/* 1311 */         jDBCType = JDBCType.GUID;
/*      */       } 
/*      */ 
/*      */       
/* 1315 */       setObject(parameter, paramObject, javaType, jDBCType, (Integer)null, (Integer)null, paramBoolean, paramInt, str);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt, Object paramObject) throws SQLServerException {
/* 1321 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1322 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject }); 
/* 1323 */     checkClosed();
/* 1324 */     setObjectNoType(paramInt, paramObject, false);
/* 1325 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLServerException {
/* 1330 */     String str = null;
/* 1331 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1332 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2) }); 
/* 1333 */     checkClosed();
/* 1334 */     if (-153 == paramInt2)
/* 1335 */       str = getTVPNameIfNull(paramInt1, (String)null); 
/* 1336 */     setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, str);
/* 1337 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt, Object paramObject, SQLType paramSQLType) throws SQLServerException {
/* 1342 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1344 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1345 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType });
/*      */     }
/*      */     
/* 1348 */     setObject(paramInt, paramObject, paramSQLType.getVendorTypeNumber().intValue());
/*      */     
/* 1350 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLServerException {
/* 1355 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1356 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) }); 
/* 1357 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1364 */     setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2 || 3 == paramInt2 || 93 == paramInt2 || 92 == paramInt2 || -155 == paramInt2 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null, (Integer)null, false, paramInt1, (String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1383 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt1, Object paramObject, int paramInt2, Integer paramInteger, int paramInt3) throws SQLServerException {
/* 1388 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1389 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), paramInteger, Integer.valueOf(paramInt3) }); 
/* 1390 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1397 */     setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2 || 3 == paramInt2 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null, paramInteger, false, paramInt1, (String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1413 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt1, Object paramObject, int paramInt2, Integer paramInteger, int paramInt3, boolean paramBoolean) throws SQLServerException {
/* 1418 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1419 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2), paramInteger, Integer.valueOf(paramInt3), Boolean.valueOf(paramBoolean) }); 
/* 1420 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1427 */     setObject(setterGetParam(paramInt1), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt2), (2 == paramInt2 || 3 == paramInt2 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt3) : null, paramInteger, paramBoolean, paramInt1, (String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1443 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2) throws SQLServerException {
/* 1448 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1450 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1451 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt1), paramObject, paramSQLType, Integer.valueOf(paramInt2) });
/*      */     }
/*      */     
/* 1454 */     setObject(paramInt1, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInt2);
/*      */     
/* 1456 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt, Object paramObject, SQLType paramSQLType, Integer paramInteger1, Integer paramInteger2) throws SQLServerException {
/* 1461 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1463 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1464 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType, paramInteger1, paramInteger2 });
/*      */     }
/*      */     
/* 1467 */     setObject(paramInt, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInteger1, paramInteger2.intValue(), false);
/*      */     
/* 1469 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(int paramInt, Object paramObject, SQLType paramSQLType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
/* 1474 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1476 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1477 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType, paramInteger1, paramInteger2, Boolean.valueOf(paramBoolean) });
/*      */     }
/*      */     
/* 1480 */     setObject(paramInt, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInteger1, paramInteger2.intValue(), paramBoolean);
/*      */     
/* 1482 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setObject(Parameter paramParameter, Object paramObject, JavaType paramJavaType, JDBCType paramJDBCType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean, int paramInt, String paramString) throws SQLServerException {
/* 1496 */     assert JDBCType.UNKNOWN != paramJDBCType;
/*      */ 
/*      */ 
/*      */     
/* 1500 */     if (null != paramObject || JavaType.TVP == paramJavaType) {
/*      */ 
/*      */       
/* 1503 */       JDBCType jDBCType = paramJavaType.getJDBCType(SSType.UNKNOWN, paramJDBCType);
/*      */ 
/*      */       
/* 1506 */       if (!jDBCType.convertsTo(paramJDBCType)) {
/* 1507 */         DataTypes.throwConversionError(jDBCType.toString(), paramJDBCType.toString());
/*      */       }
/* 1509 */       StreamSetterArgs streamSetterArgs = null;
/*      */       
/* 1511 */       switch (paramJavaType) {
/*      */         
/*      */         case READER:
/* 1514 */           streamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case INPUTSTREAM:
/* 1520 */           streamSetterArgs = new StreamSetterArgs(paramJDBCType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case SQLXML:
/* 1528 */           streamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1538 */       paramParameter.setValue(paramJDBCType, paramObject, paramJavaType, streamSetterArgs, null, paramInteger2, paramInteger1, this.connection, paramBoolean, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, paramString);
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1545 */       assert JavaType.OBJECT == paramJavaType;
/*      */       
/* 1547 */       if (paramJDBCType.isUnsupported()) {
/* 1548 */         paramJDBCType = JDBCType.BINARY;
/*      */       }
/*      */       
/* 1551 */       paramParameter.setValue(paramJDBCType, null, JavaType.OBJECT, null, null, paramInteger2, paramInteger1, this.connection, false, this.stmtColumnEncriptionSetting, paramInt, this.userSQL, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setShort(int paramInt, short paramShort) throws SQLServerException {
/* 1557 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1558 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort) }); 
/* 1559 */     checkClosed();
/* 1560 */     setValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);
/* 1561 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setShort(int paramInt, short paramShort, boolean paramBoolean) throws SQLServerException {
/* 1566 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1567 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) }); 
/* 1568 */     checkClosed();
/* 1569 */     setValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);
/* 1570 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setString(int paramInt, String paramString) throws SQLServerException {
/* 1575 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1576 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(paramInt), paramString }); 
/* 1577 */     checkClosed();
/* 1578 */     setValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, false);
/* 1579 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
/* 1584 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1585 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) }); 
/* 1586 */     checkClosed();
/* 1587 */     setValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, paramBoolean);
/* 1588 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(int paramInt, String paramString) throws SQLException {
/* 1593 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1594 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1595 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { Integer.valueOf(paramInt), paramString }); 
/* 1596 */     checkClosed();
/* 1597 */     setValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, false);
/* 1598 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(int paramInt, String paramString, boolean paramBoolean) throws SQLException {
/* 1603 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1604 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1605 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) }); 
/* 1606 */     checkClosed();
/* 1607 */     setValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, paramBoolean);
/* 1608 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int paramInt, Time paramTime) throws SQLServerException {
/* 1613 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1614 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime }); 
/* 1615 */     checkClosed();
/* 1616 */     setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, false);
/* 1617 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int paramInt1, Time paramTime, int paramInt2) throws SQLServerException {
/* 1622 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1623 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt1), paramTime, Integer.valueOf(paramInt2) }); 
/* 1624 */     checkClosed();
/* 1625 */     setValue(paramInt1, JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt2), false);
/* 1626 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int paramInt1, Time paramTime, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 1631 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1632 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt1), paramTime, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
/* 1633 */     checkClosed();
/* 1634 */     setValue(paramInt1, JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt2), paramBoolean);
/* 1635 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
/* 1640 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1641 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp }); 
/* 1642 */     checkClosed();
/* 1643 */     setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);
/* 1644 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2) throws SQLServerException {
/* 1649 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1650 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2) }); 
/* 1651 */     checkClosed();
/* 1652 */     setValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt2), false);
/* 1653 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 1658 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1659 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
/* 1660 */     checkClosed();
/* 1661 */     setValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt2), paramBoolean);
/* 1662 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException {
/* 1667 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1668 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset }); 
/* 1669 */     checkClosed();
/* 1670 */     setValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);
/* 1671 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTimeOffset(int paramInt1, DateTimeOffset paramDateTimeOffset, int paramInt2) throws SQLException {
/* 1676 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1677 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt1), paramDateTimeOffset, Integer.valueOf(paramInt2) }); 
/* 1678 */     checkClosed();
/* 1679 */     setValue(paramInt1, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt2), false);
/* 1680 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTimeOffset(int paramInt1, DateTimeOffset paramDateTimeOffset, int paramInt2, boolean paramBoolean) throws SQLException {
/* 1685 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1686 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { Integer.valueOf(paramInt1), paramDateTimeOffset, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
/* 1687 */     checkClosed();
/* 1688 */     setValue(paramInt1, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt2), paramBoolean);
/* 1689 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDate(int paramInt, Date paramDate) throws SQLServerException {
/* 1694 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1695 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate }); 
/* 1696 */     checkClosed();
/* 1697 */     setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, false);
/* 1698 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
/* 1703 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1704 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp }); 
/* 1705 */     checkClosed();
/* 1706 */     setValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/* 1707 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDateTime(int paramInt, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
/* 1712 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1713 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, Boolean.valueOf(paramBoolean) }); 
/* 1714 */     checkClosed();
/* 1715 */     setValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
/* 1716 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
/* 1721 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1722 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp }); 
/* 1723 */     checkClosed();
/* 1724 */     setValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/* 1725 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSmallDateTime(int paramInt, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
/* 1730 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1731 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, Boolean.valueOf(paramBoolean) }); 
/* 1732 */     checkClosed();
/* 1733 */     setValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
/* 1734 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(int paramInt, String paramString, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException {
/* 1739 */     paramString = getTVPNameIfNull(paramInt, paramString);
/* 1740 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1741 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(paramInt), paramString, paramSQLServerDataTable }); 
/* 1742 */     checkClosed();
/* 1743 */     setValue(paramInt, JDBCType.TVP, paramSQLServerDataTable, JavaType.TVP, paramString);
/* 1744 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(int paramInt, String paramString, ResultSet paramResultSet) throws SQLServerException {
/* 1749 */     paramString = getTVPNameIfNull(paramInt, paramString);
/* 1750 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1751 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(paramInt), paramString, paramResultSet }); 
/* 1752 */     checkClosed();
/* 1753 */     setValue(paramInt, JDBCType.TVP, paramResultSet, JavaType.TVP, paramString);
/* 1754 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(int paramInt, String paramString, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException {
/* 1759 */     paramString = getTVPNameIfNull(paramInt, paramString);
/* 1760 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1761 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { Integer.valueOf(paramInt), paramString, paramISQLServerDataRecord }); 
/* 1762 */     checkClosed();
/* 1763 */     setValue(paramInt, JDBCType.TVP, paramISQLServerDataRecord, JavaType.TVP, paramString);
/* 1764 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   String getTVPNameIfNull(int paramInt, String paramString) throws SQLServerException {
/* 1769 */     if (null == paramString || 0 == paramString.length())
/*      */     {
/* 1771 */       if (this instanceof SQLServerCallableStatement) {
/*      */         
/* 1773 */         ParameterMetaData parameterMetaData = getParameterMetaData();
/*      */         try {
/* 1775 */           paramString = parameterMetaData.getParameterTypeName(paramInt);
/* 1776 */         } catch (SQLException sQLException) {
/* 1777 */           throw new SQLServerException(SQLServerException.getErrString("R_metaDataErrorForParameter"), null, 0, sQLException);
/*      */         } 
/*      */       } 
/*      */     }
/* 1781 */     return paramString;
/*      */   }
/*      */   @Deprecated
/*      */   public final void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 1785 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addBatch() throws SQLServerException {
/* 1790 */     loggerExternal.entering(getClassNameLogging(), "addBatch");
/* 1791 */     checkClosed();
/*      */ 
/*      */     
/* 1794 */     if (this.batchParamValues == null) {
/* 1795 */       this.batchParamValues = (ArrayList)new ArrayList<>();
/*      */     }
/* 1797 */     int i = this.inOutParam.length;
/* 1798 */     Parameter[] arrayOfParameter = new Parameter[i];
/* 1799 */     for (byte b = 0; b < i; b++)
/* 1800 */       arrayOfParameter[b] = this.inOutParam[b].cloneForBatch(); 
/* 1801 */     this.batchParamValues.add(arrayOfParameter);
/* 1802 */     loggerExternal.exiting(getClassNameLogging(), "addBatch");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearBatch() throws SQLServerException {
/* 1807 */     loggerExternal.entering(getClassNameLogging(), "clearBatch");
/* 1808 */     checkClosed();
/* 1809 */     this.batchParamValues = null;
/* 1810 */     loggerExternal.exiting(getClassNameLogging(), "clearBatch");
/*      */   }
/*      */   
/*      */   public int[] executeBatch() throws SQLServerException, BatchUpdateException {
/*      */     int[] arrayOfInt;
/* 1815 */     loggerExternal.entering(getClassNameLogging(), "executeBatch");
/* 1816 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1818 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1820 */     checkClosed();
/* 1821 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */     
/* 1825 */     if (this.batchParamValues == null) {
/* 1826 */       arrayOfInt = new int[0];
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1840 */         for (byte b1 = 0; b1 < this.batchParamValues.size(); b1++) {
/*      */           
/* 1842 */           Parameter[] arrayOfParameter = this.batchParamValues.get(b1);
/* 1843 */           for (byte b = 0; b < arrayOfParameter.length; b++) {
/*      */             
/* 1845 */             if (arrayOfParameter[b].isOutput())
/*      */             {
/* 1847 */               throw new BatchUpdateException(SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1856 */         PrepStmtBatchExecCmd prepStmtBatchExecCmd = new PrepStmtBatchExecCmd(this);
/*      */         
/* 1858 */         executeStatement(prepStmtBatchExecCmd);
/*      */         
/* 1860 */         arrayOfInt = new int[prepStmtBatchExecCmd.updateCounts.length];
/* 1861 */         for (byte b2 = 0; b2 < prepStmtBatchExecCmd.updateCounts.length; b2++) {
/* 1862 */           arrayOfInt[b2] = (int)prepStmtBatchExecCmd.updateCounts[b2];
/*      */         }
/*      */         
/* 1865 */         if (null != prepStmtBatchExecCmd.batchException)
/*      */         {
/* 1867 */           throw new BatchUpdateException(prepStmtBatchExecCmd.batchException.getMessage(), prepStmtBatchExecCmd.batchException.getSQLState(), prepStmtBatchExecCmd.batchException.getErrorCode(), arrayOfInt);
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */         
/* 1877 */         this.batchParamValues = null;
/*      */       } 
/*      */     } 
/* 1880 */     loggerExternal.exiting(getClassNameLogging(), "executeBatch", arrayOfInt);
/* 1881 */     return arrayOfInt;
/*      */   }
/*      */   
/*      */   public long[] executeLargeBatch() throws SQLServerException, BatchUpdateException {
/*      */     long[] arrayOfLong;
/* 1886 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1888 */     loggerExternal.entering(getClassNameLogging(), "executeLargeBatch");
/* 1889 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1891 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1893 */     checkClosed();
/* 1894 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */     
/* 1898 */     if (this.batchParamValues == null) {
/* 1899 */       arrayOfLong = new long[0];
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1913 */         for (byte b1 = 0; b1 < this.batchParamValues.size(); b1++) {
/*      */           
/* 1915 */           Parameter[] arrayOfParameter = this.batchParamValues.get(b1);
/* 1916 */           for (byte b = 0; b < arrayOfParameter.length; b++) {
/*      */             
/* 1918 */             if (arrayOfParameter[b].isOutput())
/*      */             {
/* 1920 */               throw new BatchUpdateException(SQLServerException.getErrString("R_outParamsNotPermittedinBatch"), null, 0, null);
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1929 */         PrepStmtBatchExecCmd prepStmtBatchExecCmd = new PrepStmtBatchExecCmd(this);
/*      */         
/* 1931 */         executeStatement(prepStmtBatchExecCmd);
/*      */         
/* 1933 */         arrayOfLong = new long[prepStmtBatchExecCmd.updateCounts.length];
/*      */         
/* 1935 */         for (byte b2 = 0; b2 < prepStmtBatchExecCmd.updateCounts.length; b2++) {
/* 1936 */           arrayOfLong[b2] = prepStmtBatchExecCmd.updateCounts[b2];
/*      */         }
/*      */         
/* 1939 */         if (null != prepStmtBatchExecCmd.batchException)
/*      */         {
/* 1941 */           DriverJDBCVersion.throwBatchUpdateException(prepStmtBatchExecCmd.batchException, arrayOfLong);
/*      */         
/*      */         }
/*      */       }
/*      */       finally {
/*      */         
/* 1947 */         this.batchParamValues = null;
/*      */       } 
/* 1949 */     }  loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", arrayOfLong);
/* 1950 */     return arrayOfLong;
/*      */   }
/*      */   
/*      */   private final class PrepStmtBatchExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     private final SQLServerPreparedStatement stmt;
/*      */     SQLServerException batchException;
/*      */     long[] updateCounts;
/*      */     
/*      */     PrepStmtBatchExecCmd(SQLServerPreparedStatement param1SQLServerPreparedStatement1) {
/* 1961 */       super(param1SQLServerPreparedStatement1.toString() + " executeBatch", SQLServerPreparedStatement.this.queryTimeout);
/* 1962 */       this.stmt = param1SQLServerPreparedStatement1;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/* 1967 */       this.stmt.doExecutePreparedStatementBatch(this);
/* 1968 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
/* 1973 */       SQLServerPreparedStatement.this.ensureExecuteResultsReader(param1TDSReader);
/* 1974 */       SQLServerPreparedStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final void doExecutePreparedStatementBatch(PrepStmtBatchExecCmd paramPrepStmtBatchExecCmd) throws SQLServerException {
/* 1980 */     this.executeMethod = 4;
/*      */     
/* 1982 */     paramPrepStmtBatchExecCmd.batchException = null;
/* 1983 */     int i = this.batchParamValues.size();
/* 1984 */     paramPrepStmtBatchExecCmd.updateCounts = new long[i]; byte b1;
/* 1985 */     for (b1 = 0; b1 < i; b1++) {
/* 1986 */       paramPrepStmtBatchExecCmd.updateCounts[b1] = -3L;
/*      */     }
/* 1988 */     b1 = 0;
/* 1989 */     byte b2 = 0;
/* 1990 */     Vector<CryptoMetadata> vector = new Vector();
/*      */     
/* 1992 */     if (isSelect(this.userSQL))
/*      */     {
/* 1994 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_selectNotPermittedinBatch"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2003 */     this.connection.setMaxRows(0);
/*      */     
/* 2005 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 2007 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/* 2010 */     Parameter[] arrayOfParameter = new Parameter[this.inOutParam.length];
/*      */     
/* 2012 */     TDSWriter tDSWriter = null;
/* 2013 */     while (b2 < i) {
/*      */ 
/*      */       
/* 2016 */       Parameter[] arrayOfParameter1 = this.batchParamValues.get(b1);
/* 2017 */       assert arrayOfParameter1.length == arrayOfParameter.length;
/* 2018 */       for (byte b = 0; b < arrayOfParameter1.length; b++) {
/* 2019 */         arrayOfParameter[b] = arrayOfParameter1[b];
/*      */       }
/* 2021 */       boolean bool = buildPreparedStrings(arrayOfParameter, false);
/*      */       
/* 2023 */       if (0 == b2 && Util.shouldHonorAEForParameters(this.stmtColumnEncriptionSetting, this.connection) && 0 < arrayOfParameter.length && !this.isInternalEncryptionQuery) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2028 */         getParameterEncryptionMetadata(arrayOfParameter);
/*      */ 
/*      */         
/* 2031 */         buildPreparedStrings(arrayOfParameter, true);
/*      */ 
/*      */         
/* 2034 */         for (byte b3 = 0; b3 < arrayOfParameter.length; b3++)
/*      */         {
/* 2036 */           vector.add((arrayOfParameter[b3]).cryptoMeta);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 2041 */       if (0 < b2)
/*      */       {
/*      */         
/* 2044 */         for (byte b3 = 0; b3 < vector.size(); b3++)
/*      */         {
/* 2046 */           (arrayOfParameter[b3]).cryptoMeta = vector.get(b3);
/*      */         }
/*      */       }
/*      */       
/* 2050 */       if (b2 < b1) {
/*      */ 
/*      */         
/* 2053 */         tDSWriter.writeByte((byte)-1);
/*      */       }
/*      */       else {
/*      */         
/* 2057 */         resetForReexecute();
/* 2058 */         tDSWriter = paramPrepStmtBatchExecCmd.startRequest((byte)3);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2069 */       b1++;
/* 2070 */       if (doPrepExec(tDSWriter, arrayOfParameter, bool) || b1 == i) {
/*      */         
/* 2072 */         ensureExecuteResultsReader(paramPrepStmtBatchExecCmd.startResponse(getIsResponseBufferingAdaptive()));
/*      */         
/* 2074 */         while (b2 < b1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2080 */           startResults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 2087 */             if (!getNextResult()) {
/*      */               return;
/*      */             }
/*      */ 
/*      */ 
/*      */             
/* 2093 */             if (null != this.resultSet)
/*      */             {
/* 2095 */               SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/* 2103 */           catch (SQLServerException sQLServerException) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2108 */             if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
/* 2109 */               throw sQLServerException;
/*      */             }
/*      */ 
/*      */             
/* 2113 */             this.updateCount = -3L;
/* 2114 */             if (null == paramPrepStmtBatchExecCmd.batchException) {
/* 2115 */               paramPrepStmtBatchExecCmd.batchException = sQLServerException;
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 2120 */           paramPrepStmtBatchExecCmd.updateCounts[b2++] = (-1L == this.updateCount) ? -2L : this.updateCount;
/*      */ 
/*      */           
/* 2123 */           processBatch();
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2128 */         assert b2 == b1;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 2135 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2136 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2137 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader }); 
/* 2138 */     checkClosed();
/* 2139 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 2140 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLServerException {
/* 2145 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2146 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt1), paramReader, Integer.valueOf(paramInt2) }); 
/* 2147 */     checkClosed();
/* 2148 */     setStream(paramInt1, StreamType.CHARACTER, paramReader, JavaType.READER, paramInt2);
/* 2149 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2154 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2155 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2156 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
/* 2157 */     checkClosed();
/* 2158 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 2159 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 2164 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2165 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2166 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader }); 
/* 2167 */     checkClosed();
/* 2168 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 2169 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2174 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2175 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2176 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
/* 2177 */     checkClosed();
/* 2178 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 2179 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */   
/*      */   public final void setRef(int paramInt, Ref paramRef) throws SQLServerException {
/* 2183 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 2188 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2189 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramBlob }); 
/* 2190 */     checkClosed();
/* 2191 */     setValue(paramInt, JDBCType.BLOB, paramBlob, JavaType.BLOB, false);
/* 2192 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 2197 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2198 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2199 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream }); 
/* 2200 */     checkClosed();
/* 2201 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 2202 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 2207 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2208 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2209 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) }); 
/* 2210 */     checkClosed();
/* 2211 */     setStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 2212 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(int paramInt, Clob paramClob) throws SQLException {
/* 2217 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2218 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramClob }); 
/* 2219 */     checkClosed();
/* 2220 */     setValue(paramInt, JDBCType.CLOB, paramClob, JavaType.CLOB, false);
/* 2221 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(int paramInt, Reader paramReader) throws SQLException {
/* 2226 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2227 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2228 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramReader }); 
/* 2229 */     checkClosed();
/* 2230 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 2231 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2236 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2237 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2238 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
/* 2239 */     checkClosed();
/* 2240 */     setStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 2241 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 2246 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2247 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2248 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramNClob }); 
/* 2249 */     checkClosed();
/* 2250 */     setValue(paramInt, JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);
/* 2251 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(int paramInt, Reader paramReader) throws SQLException {
/* 2256 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2257 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2258 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramReader }); 
/* 2259 */     checkClosed();
/* 2260 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 2261 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 2266 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2267 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2268 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) }); 
/* 2269 */     checkClosed();
/* 2270 */     setStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 2271 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */   
/*      */   public final void setArray(int paramInt, Array paramArray) throws SQLServerException {
/* 2275 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLServerException {
/* 2280 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2281 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate, paramCalendar }); 
/* 2282 */     checkClosed();
/* 2283 */     setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, false);
/* 2284 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDate(int paramInt, Date paramDate, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 2289 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2290 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { Integer.valueOf(paramInt), paramDate, paramCalendar, Boolean.valueOf(paramBoolean) }); 
/* 2291 */     checkClosed();
/* 2292 */     setValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, paramBoolean);
/* 2293 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLServerException {
/* 2298 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2299 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramCalendar }); 
/* 2300 */     checkClosed();
/* 2301 */     setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, false);
/* 2302 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTime(int paramInt, Time paramTime, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 2307 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2308 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramCalendar, Boolean.valueOf(paramBoolean) }); 
/* 2309 */     checkClosed();
/* 2310 */     setValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, paramBoolean);
/* 2311 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLServerException {
/* 2316 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2317 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramCalendar }); 
/* 2318 */     checkClosed();
/* 2319 */     setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, false);
/* 2320 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 2325 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2326 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramCalendar, Boolean.valueOf(paramBoolean) }); 
/* 2327 */     checkClosed();
/* 2328 */     setValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, paramBoolean);
/* 2329 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNull(int paramInt1, int paramInt2, String paramString) throws SQLServerException {
/* 2334 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2335 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramString }); 
/* 2336 */     checkClosed();
/* 2337 */     if (-153 == paramInt2) {
/*      */       
/* 2339 */       setObject(setterGetParam(paramInt1), (Object)null, JavaType.TVP, JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, paramString);
/*      */     }
/*      */     else {
/*      */       
/* 2343 */       setObject(setterGetParam(paramInt1), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt2), (Integer)null, (Integer)null, false, paramInt1, paramString);
/*      */     } 
/* 2345 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ParameterMetaData getParameterMetaData() throws SQLServerException {
/* 2352 */     loggerExternal.entering(getClassNameLogging(), "getParameterMetaData");
/* 2353 */     checkClosed();
/* 2354 */     SQLServerParameterMetaData sQLServerParameterMetaData = new SQLServerParameterMetaData(this, this.userSQL);
/* 2355 */     loggerExternal.exiting(getClassNameLogging(), "getParameterMetaData", sQLServerParameterMetaData);
/* 2356 */     return sQLServerParameterMetaData;
/*      */   }
/*      */   
/*      */   public final void setURL(int paramInt, URL paramURL) throws SQLServerException {
/* 2360 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 2365 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 2368 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 2373 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2374 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2375 */       loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { Integer.valueOf(paramInt), paramSQLXML }); 
/* 2376 */     checkClosed();
/* 2377 */     setSQLXMLInternal(paramInt, paramSQLXML);
/* 2378 */     loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String paramString) throws SQLServerException {
/* 2385 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate", paramString);
/* 2386 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 2387 */     Object[] arrayOfObject = { new String("executeUpdate()") };
/* 2388 */     throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */   public final boolean execute(String paramString) throws SQLServerException {
/* 2391 */     loggerExternal.entering(getClassNameLogging(), "execute", paramString);
/* 2392 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 2393 */     Object[] arrayOfObject = { new String("execute()") };
/* 2394 */     throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */   public final ResultSet executeQuery(String paramString) throws SQLServerException {
/* 2397 */     loggerExternal.entering(getClassNameLogging(), "executeQuery", paramString);
/* 2398 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 2399 */     Object[] arrayOfObject = { new String("executeQuery()") };
/* 2400 */     throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */   public void addBatch(String paramString) throws SQLServerException {
/* 2403 */     loggerExternal.entering(getClassNameLogging(), "addBatch", paramString);
/* 2404 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_cannotTakeArgumentsPreparedOrCallable"));
/* 2405 */     Object[] arrayOfObject = { new String("addBatch()") };
/* 2406 */     throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerPreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */