/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamTabName
/*    */   extends StreamPacket
/*    */ {
/*    */   private TDSReader tdsReader;
/*    */   private TDSReaderMark tableNamesMark;
/*    */   
/*    */   StreamTabName() {
/* 17 */     super(164);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 22 */     if (164 != paramTDSReader.readUnsignedByte() && 
/* 23 */       !$assertionsDisabled) throw new AssertionError("Not a TABNAME token");
/*    */     
/* 25 */     this.tdsReader = paramTDSReader;
/* 26 */     int i = paramTDSReader.readUnsignedShort();
/* 27 */     this.tableNamesMark = paramTDSReader.mark();
/* 28 */     paramTDSReader.skip(i);
/*    */   }
/*    */ 
/*    */   
/*    */   void applyTo(Column[] paramArrayOfColumn, int paramInt) throws SQLServerException {
/* 33 */     TDSReaderMark tDSReaderMark = this.tdsReader.mark();
/* 34 */     this.tdsReader.reset(this.tableNamesMark);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 39 */     SQLIdentifier[] arrayOfSQLIdentifier = new SQLIdentifier[paramInt]; byte b;
/* 40 */     for (b = 0; b < paramInt; b++) {
/* 41 */       arrayOfSQLIdentifier[b] = this.tdsReader.readSQLIdentifier();
/*    */     }
/*    */     
/* 44 */     for (b = 0; b < paramArrayOfColumn.length; b++) {
/*    */       
/* 46 */       Column column = paramArrayOfColumn[b];
/*    */       
/* 48 */       if (column.getTableNum() > 0) {
/* 49 */         column.setTableName(arrayOfSQLIdentifier[column.getTableNum() - 1]);
/*    */       }
/*    */     } 
/* 52 */     this.tdsReader.reset(tDSReaderMark);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamTabName.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */