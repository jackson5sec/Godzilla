/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.logging.Level;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ public final class SQLServerCallableStatement extends SQLServerPreparedStatement implements ISQLServerCallableStatement {
/*      */   private ArrayList<String> paramNames;
/*   32 */   int nOutParams = 0;
/*      */ 
/*      */   
/*   35 */   int nOutParamsAssigned = 0;
/*      */   
/*   37 */   private int outParamIndex = -1;
/*      */ 
/*      */   
/*      */   private Parameter lastParamAccessed;
/*      */ 
/*      */   
/*      */   private Closeable activeStream;
/*      */ 
/*      */ 
/*      */   
/*      */   String getClassNameInternal() {
/*   48 */     return "SQLServerCallableStatement";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerCallableStatement(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/*   63 */     super(paramSQLServerConnection, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLServerException {
/*   68 */     if (loggerExternal.isLoggable(Level.FINER))
/*   69 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2) }); 
/*   70 */     checkClosed();
/*   71 */     if (paramInt1 < 1 || paramInt1 > this.inOutParam.length) {
/*      */       
/*   73 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*   74 */       Object[] arrayOfObject = { new Integer(paramInt1) };
/*   75 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "7009", false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   81 */     if (2012 == paramInt2) {
/*      */       
/*   83 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_featureNotSupported"));
/*   84 */       Object[] arrayOfObject = { new String("REF_CURSOR") };
/*   85 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), null, false);
/*      */     } 
/*      */     
/*   88 */     JDBCType jDBCType = JDBCType.of(paramInt2);
/*      */ 
/*      */ 
/*      */     
/*   92 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */     
/*   96 */     if (jDBCType.isUnsupported()) {
/*   97 */       jDBCType = JDBCType.BINARY;
/*      */     }
/*   99 */     Parameter parameter = this.inOutParam[paramInt1 - 1];
/*  100 */     assert null != parameter;
/*      */ 
/*      */ 
/*      */     
/*  104 */     if (!parameter.isOutput()) {
/*  105 */       this.nOutParams++;
/*      */     }
/*      */ 
/*      */     
/*  109 */     parameter.registerForOutput(jDBCType, this.connection);
/*  110 */     switch (paramInt2) {
/*      */       
/*      */       case -151:
/*  113 */         parameter.setOutScale(3);
/*      */         break;
/*      */       case -155:
/*      */       case 92:
/*      */       case 93:
/*  118 */         parameter.setOutScale(7);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  124 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt, SQLType paramSQLType) throws SQLServerException {
/*  129 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/*  131 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  132 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt), paramSQLType });
/*      */     }
/*      */     
/*  135 */     registerOutParameter(paramInt, paramSQLType.getVendorTypeNumber().intValue());
/*  136 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Parameter getOutParameter(int paramInt) throws SQLServerException {
/*  148 */     processResults();
/*      */ 
/*      */     
/*  151 */     if (this.inOutParam[paramInt - 1] == this.lastParamAccessed || this.inOutParam[paramInt - 1].isValueGotten()) {
/*  152 */       return this.inOutParam[paramInt - 1];
/*      */     }
/*      */ 
/*      */     
/*  156 */     while (this.outParamIndex != paramInt - 1) {
/*  157 */       skipOutParameters(1, false);
/*      */     }
/*  159 */     return this.inOutParam[paramInt - 1];
/*      */   }
/*      */ 
/*      */   
/*      */   void startResults() {
/*  164 */     super.startResults();
/*  165 */     this.outParamIndex = -1;
/*  166 */     this.nOutParamsAssigned = 0;
/*  167 */     this.lastParamAccessed = null;
/*  168 */     assert null == this.activeStream;
/*      */   }
/*      */ 
/*      */   
/*      */   void processBatch() throws SQLServerException {
/*  173 */     processResults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  179 */     assert this.nOutParams >= 0;
/*  180 */     if (this.nOutParams > 0) {
/*      */       
/*  182 */       processOutParameters();
/*  183 */       processBatchRemainder();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void processOutParameters() throws SQLServerException {
/*  189 */     assert this.nOutParams > 0;
/*  190 */     assert null != this.inOutParam;
/*      */ 
/*      */     
/*  193 */     closeActiveStream();
/*      */ 
/*      */ 
/*      */     
/*  197 */     if (this.outParamIndex >= 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  203 */       for (byte b = 0; b < this.inOutParam.length; b++) {
/*      */         
/*  205 */         if (b != this.outParamIndex && this.inOutParam[b].isValueGotten()) {
/*      */           
/*  207 */           assert this.inOutParam[b].isOutput();
/*  208 */           this.inOutParam[b].resetOutputValue();
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  214 */     assert this.nOutParamsAssigned <= this.nOutParams;
/*  215 */     if (this.nOutParamsAssigned < this.nOutParams) {
/*  216 */       skipOutParameters(this.nOutParams - this.nOutParamsAssigned, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  222 */     if (this.outParamIndex >= 0) {
/*      */       
/*  224 */       this.inOutParam[this.outParamIndex].skipValue(resultsReader(), true);
/*  225 */       this.inOutParam[this.outParamIndex].resetOutputValue();
/*  226 */       this.outParamIndex = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processBatchRemainder() throws SQLServerException {
/*      */     final class ExecDoneHandler
/*      */       extends TDSTokenHandler
/*      */     {
/*      */       ExecDoneHandler() {
/*  240 */         super("ExecDoneHandler");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
/*  246 */         StreamDone streamDone = new StreamDone();
/*  247 */         streamDone.setFromTDS(param1TDSReader);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  252 */         if (streamDone.wasRPCInBatch()) {
/*      */           
/*  254 */           SQLServerCallableStatement.this.startResults();
/*  255 */           return false;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  260 */         return true;
/*      */       }
/*      */     };
/*      */     
/*  264 */     ExecDoneHandler execDoneHandler = new ExecDoneHandler();
/*  265 */     TDSParser.parse(resultsReader(), execDoneHandler);
/*      */   }
/*      */ 
/*      */   
/*      */   private void skipOutParameters(int paramInt, boolean paramBoolean) throws SQLServerException {
/*      */     final class OutParamHandler
/*      */       extends TDSTokenHandler
/*      */     {
/*  273 */       final StreamRetValue srv = new StreamRetValue(); private boolean foundParam;
/*      */       
/*      */       final boolean foundParam() {
/*  276 */         return this.foundParam;
/*      */       }
/*      */       
/*      */       OutParamHandler() {
/*  280 */         super("OutParamHandler");
/*      */       }
/*      */ 
/*      */       
/*      */       final void reset() {
/*  285 */         this.foundParam = false;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
/*  290 */         this.srv.setFromTDS(param1TDSReader);
/*  291 */         this.foundParam = true;
/*  292 */         return false;
/*      */       }
/*      */     };
/*      */     
/*  296 */     OutParamHandler outParamHandler = new OutParamHandler();
/*      */ 
/*      */     
/*  299 */     assert paramInt <= this.nOutParams - this.nOutParamsAssigned;
/*  300 */     for (byte b = 0; b < paramInt; b++) {
/*      */ 
/*      */ 
/*      */       
/*  304 */       if (-1 != this.outParamIndex) {
/*      */         
/*  306 */         this.inOutParam[this.outParamIndex].skipValue(resultsReader(), paramBoolean);
/*  307 */         if (paramBoolean) {
/*  308 */           this.inOutParam[this.outParamIndex].resetOutputValue();
/*      */         }
/*      */       } 
/*      */       
/*  312 */       outParamHandler.reset();
/*  313 */       TDSParser.parse(resultsReader(), outParamHandler);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  318 */       if (!outParamHandler.foundParam()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  325 */         if (paramBoolean) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  332 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueNotSetForParameter"));
/*  333 */         Object[] arrayOfObject = { new Integer(this.outParamIndex + 1) };
/*  334 */         SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), null, false);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  344 */       this.outParamIndex = outParamHandler.srv.getOrdinalOrLength();
/*      */ 
/*      */ 
/*      */       
/*  348 */       this.outParamIndex -= this.outParamIndexAdjustment;
/*  349 */       if (this.outParamIndex < 0 || this.outParamIndex >= this.inOutParam.length || !this.inOutParam[this.outParamIndex].isOutput()) {
/*      */         
/*  351 */         getStatementLogger().info(toString() + " Unexpected outParamIndex: " + this.outParamIndex + "; adjustment: " + this.outParamIndexAdjustment);
/*  352 */         this.connection.throwInvalidTDS();
/*      */       } 
/*      */ 
/*      */       
/*  356 */       this.nOutParamsAssigned++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLServerException {
/*  362 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  363 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), paramString });
/*      */     }
/*  365 */     checkClosed();
/*      */     
/*  367 */     registerOutParameter(paramInt1, paramInt2);
/*      */     
/*  369 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt, SQLType paramSQLType, String paramString) throws SQLServerException {
/*  374 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/*  376 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  377 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt), paramSQLType, paramString });
/*      */     }
/*      */     
/*  380 */     registerOutParameter(paramInt, paramSQLType.getVendorTypeNumber().intValue(), paramString);
/*      */     
/*  382 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
/*  387 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  388 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt3) });
/*      */     }
/*  390 */     checkClosed();
/*      */     
/*  392 */     registerOutParameter(paramInt1, paramInt2);
/*  393 */     this.inOutParam[paramInt1 - 1].setOutScale(paramInt3);
/*      */     
/*  395 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, SQLType paramSQLType, int paramInt2) throws SQLServerException {
/*  400 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/*  402 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  403 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), paramSQLType, new Integer(paramInt2) });
/*      */     }
/*      */     
/*  406 */     registerOutParameter(paramInt1, paramSQLType.getVendorTypeNumber().intValue(), paramInt2);
/*      */     
/*  408 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, SQLType paramSQLType, int paramInt2, int paramInt3) throws SQLServerException {
/*  413 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/*  415 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  416 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), paramSQLType, new Integer(paramInt3) });
/*      */     }
/*      */     
/*  419 */     registerOutParameter(paramInt1, paramSQLType.getVendorTypeNumber().intValue(), paramInt2, paramInt3);
/*      */     
/*  421 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLServerException {
/*  426 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  427 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { new Integer(paramInt1), new Integer(paramInt2), new Integer(paramInt4), new Integer(paramInt3) });
/*      */     }
/*  429 */     checkClosed();
/*      */     
/*  431 */     registerOutParameter(paramInt1, paramInt2);
/*  432 */     this.inOutParam[paramInt1 - 1].setValueLength(paramInt3);
/*  433 */     this.inOutParam[paramInt1 - 1].setOutScale(paramInt4);
/*      */     
/*  435 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Parameter getterGetParam(int paramInt) throws SQLServerException {
/*  442 */     checkClosed();
/*      */ 
/*      */     
/*  445 */     if (paramInt < 1 || paramInt > this.inOutParam.length) {
/*      */       
/*  447 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidOutputParameter"));
/*  448 */       Object[] arrayOfObject = { new Integer(paramInt) };
/*  449 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
/*      */     } 
/*      */ 
/*      */     
/*  453 */     if (!this.inOutParam[paramInt - 1].isOutput()) {
/*      */       
/*  455 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_outputParameterNotRegisteredForOutput"));
/*  456 */       Object[] arrayOfObject = { new Integer(paramInt) };
/*  457 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", true);
/*      */     } 
/*      */ 
/*      */     
/*  461 */     if (!wasExecuted()) {
/*  462 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementMustBeExecuted"), "07009", false);
/*      */     }
/*  464 */     resultsReader().getCommand().checkForInterrupt();
/*      */     
/*  466 */     closeActiveStream();
/*  467 */     if (getStatementLogger().isLoggable(Level.FINER)) {
/*  468 */       getStatementLogger().finer(toString() + " Getting Param:" + paramInt);
/*      */     }
/*      */     
/*  471 */     this.lastParamAccessed = getOutParameter(paramInt);
/*  472 */     return this.lastParamAccessed;
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getValue(int paramInt, JDBCType paramJDBCType) throws SQLServerException {
/*  477 */     return getterGetParam(paramInt).getValue(paramJDBCType, null, null, resultsReader());
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getValue(int paramInt, JDBCType paramJDBCType, Calendar paramCalendar) throws SQLServerException {
/*  482 */     return getterGetParam(paramInt).getValue(paramJDBCType, null, paramCalendar, resultsReader());
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getStream(int paramInt, StreamType paramStreamType) throws SQLServerException {
/*  487 */     Object object = getterGetParam(paramInt).getValue(paramStreamType.getJDBCType(), new InputStreamGetterArgs(paramStreamType, getIsResponseBufferingAdaptive(), getIsResponseBufferingAdaptive(), toString()), null, resultsReader());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  497 */     this.activeStream = (Closeable)object;
/*  498 */     return object;
/*      */   }
/*      */   
/*      */   private Object getSQLXMLInternal(int paramInt) throws SQLServerException {
/*  502 */     SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getterGetParam(paramInt).getValue(JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, getIsResponseBufferingAdaptive(), getIsResponseBufferingAdaptive(), toString()), null, resultsReader());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  512 */     if (null != sQLServerSQLXML)
/*  513 */       this.activeStream = sQLServerSQLXML.getStream(); 
/*  514 */     return sQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLServerException {
/*  519 */     loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(paramInt));
/*  520 */     checkClosed();
/*  521 */     Integer integer = (Integer)getValue(paramInt, JDBCType.INTEGER);
/*  522 */     loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
/*  523 */     return (null != integer) ? integer.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLServerException {
/*  528 */     loggerExternal.entering(getClassNameLogging(), "getInt", paramString);
/*  529 */     checkClosed();
/*  530 */     Integer integer = (Integer)getValue(findColumn(paramString), JDBCType.INTEGER);
/*  531 */     loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
/*  532 */     return (null != integer) ? integer.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLServerException {
/*  537 */     loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(paramInt));
/*  538 */     checkClosed();
/*  539 */     String str = (String)getValue(paramInt, JDBCType.CHAR);
/*  540 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/*  541 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLServerException {
/*  546 */     loggerExternal.entering(getClassNameLogging(), "getString", paramString);
/*  547 */     checkClosed();
/*  548 */     String str = (String)getValue(findColumn(paramString), JDBCType.CHAR);
/*  549 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/*  550 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNString(int paramInt) throws SQLException {
/*  555 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*  557 */     loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(paramInt));
/*  558 */     checkClosed();
/*  559 */     String str = (String)getValue(paramInt, JDBCType.NCHAR);
/*  560 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/*  561 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getNString(String paramString) throws SQLException {
/*  566 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*  568 */     loggerExternal.entering(getClassNameLogging(), "getNString", paramString);
/*  569 */     checkClosed();
/*  570 */     String str = (String)getValue(findColumn(paramString), JDBCType.NCHAR);
/*  571 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/*  572 */     return str;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  577 */     if (loggerExternal.isLoggable(Level.FINER))
/*  578 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
/*  579 */     checkClosed();
/*  580 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt1, JDBCType.DECIMAL);
/*  581 */     if (null != bigDecimal)
/*  582 */       bigDecimal = bigDecimal.setScale(paramInt2, 1); 
/*  583 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/*  584 */     return bigDecimal;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/*  589 */     if (loggerExternal.isLoggable(Level.FINER))
/*  590 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { paramString, Integer.valueOf(paramInt) }); 
/*  591 */     checkClosed();
/*  592 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/*  593 */     if (null != bigDecimal)
/*  594 */       bigDecimal = bigDecimal.setScale(paramInt, 1); 
/*  595 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/*  596 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLServerException {
/*  601 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(paramInt));
/*  602 */     checkClosed();
/*  603 */     Boolean bool = (Boolean)getValue(paramInt, JDBCType.BIT);
/*  604 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
/*  605 */     return (null != bool) ? bool.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLServerException {
/*  610 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", paramString);
/*  611 */     checkClosed();
/*  612 */     Boolean bool = (Boolean)getValue(findColumn(paramString), JDBCType.BIT);
/*  613 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
/*  614 */     return (null != bool) ? bool.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLServerException {
/*  619 */     loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(paramInt));
/*  620 */     checkClosed();
/*  621 */     Short short_ = (Short)getValue(paramInt, JDBCType.TINYINT);
/*  622 */     boolean bool = (null != short_) ? short_.byteValue() : false;
/*  623 */     loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(bool));
/*  624 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLServerException {
/*  629 */     loggerExternal.entering(getClassNameLogging(), "getByte", paramString);
/*  630 */     checkClosed();
/*  631 */     Short short_ = (Short)getValue(findColumn(paramString), JDBCType.TINYINT);
/*  632 */     boolean bool = (null != short_) ? short_.byteValue() : false;
/*  633 */     loggerExternal.exiting(getClassNameLogging(), "getByte", Byte.valueOf(bool));
/*  634 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLServerException {
/*  639 */     loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(paramInt));
/*  640 */     checkClosed();
/*  641 */     byte[] arrayOfByte = (byte[])getValue(paramInt, JDBCType.BINARY);
/*  642 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/*  643 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLServerException {
/*  648 */     loggerExternal.entering(getClassNameLogging(), "getBytes", paramString);
/*  649 */     checkClosed();
/*  650 */     byte[] arrayOfByte = (byte[])getValue(findColumn(paramString), JDBCType.BINARY);
/*  651 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/*  652 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLServerException {
/*  657 */     loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(paramInt));
/*  658 */     checkClosed();
/*  659 */     Date date = (Date)getValue(paramInt, JDBCType.DATE);
/*  660 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/*  661 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLServerException {
/*  666 */     loggerExternal.entering(getClassNameLogging(), "getDate", paramString);
/*  667 */     checkClosed();
/*  668 */     Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE);
/*  669 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/*  670 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLServerException {
/*  675 */     if (loggerExternal.isLoggable(Level.FINER))
/*  676 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/*  677 */     checkClosed();
/*  678 */     Date date = (Date)getValue(paramInt, JDBCType.DATE, paramCalendar);
/*  679 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/*  680 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLServerException {
/*  685 */     if (loggerExternal.isLoggable(Level.FINER))
/*  686 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { paramString, paramCalendar }); 
/*  687 */     checkClosed();
/*  688 */     Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE, paramCalendar);
/*  689 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/*  690 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLServerException {
/*  695 */     loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(paramInt));
/*  696 */     checkClosed();
/*  697 */     Double double_ = (Double)getValue(paramInt, JDBCType.DOUBLE);
/*  698 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
/*  699 */     return (null != double_) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLServerException {
/*  704 */     loggerExternal.entering(getClassNameLogging(), "getDouble", paramString);
/*  705 */     checkClosed();
/*  706 */     Double double_ = (Double)getValue(findColumn(paramString), JDBCType.DOUBLE);
/*  707 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
/*  708 */     return (null != double_) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLServerException {
/*  713 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(paramInt));
/*  714 */     checkClosed();
/*  715 */     Float float_ = (Float)getValue(paramInt, JDBCType.REAL);
/*  716 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
/*  717 */     return (null != float_) ? float_.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLServerException {
/*  723 */     loggerExternal.entering(getClassNameLogging(), "getFloat", paramString);
/*  724 */     checkClosed();
/*  725 */     Float float_ = (Float)getValue(findColumn(paramString), JDBCType.REAL);
/*  726 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
/*  727 */     return (null != float_) ? float_.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLServerException {
/*  733 */     loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(paramInt));
/*  734 */     checkClosed();
/*  735 */     Long long_ = (Long)getValue(paramInt, JDBCType.BIGINT);
/*  736 */     loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
/*  737 */     return (null != long_) ? long_.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLServerException {
/*  742 */     loggerExternal.entering(getClassNameLogging(), "getLong", paramString);
/*  743 */     checkClosed();
/*  744 */     Long long_ = (Long)getValue(findColumn(paramString), JDBCType.BIGINT);
/*  745 */     loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
/*  746 */     return (null != long_) ? long_.longValue() : 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLServerException {
/*  752 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(paramInt));
/*  753 */     checkClosed();
/*  754 */     Object object = getValue(paramInt, (getterGetParam(paramInt).getJdbcTypeSetByUser() != null) ? getterGetParam(paramInt).getJdbcTypeSetByUser() : getterGetParam(paramInt).getJdbcType());
/*      */ 
/*      */ 
/*      */     
/*  758 */     loggerExternal.exiting(getClassNameLogging(), "getObject", object);
/*  759 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/*  764 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/*  767 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLServerException {
/*  772 */     loggerExternal.entering(getClassNameLogging(), "getObject", paramString);
/*  773 */     checkClosed();
/*  774 */     int i = findColumn(paramString);
/*  775 */     Object object = getValue(i, (getterGetParam(i).getJdbcTypeSetByUser() != null) ? getterGetParam(i).getJdbcTypeSetByUser() : getterGetParam(i).getJdbcType());
/*      */ 
/*      */ 
/*      */     
/*  779 */     loggerExternal.exiting(getClassNameLogging(), "getObject", object);
/*  780 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
/*  785 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/*  788 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLServerException {
/*  794 */     loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(paramInt));
/*  795 */     checkClosed();
/*  796 */     Short short_ = (Short)getValue(paramInt, JDBCType.SMALLINT);
/*  797 */     loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
/*  798 */     return (null != short_) ? short_.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLServerException {
/*  803 */     loggerExternal.entering(getClassNameLogging(), "getShort", paramString);
/*  804 */     checkClosed();
/*  805 */     Short short_ = (Short)getValue(findColumn(paramString), JDBCType.SMALLINT);
/*  806 */     loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
/*  807 */     return (null != short_) ? short_.shortValue() : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLServerException {
/*  813 */     loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(paramInt));
/*  814 */     checkClosed();
/*  815 */     Time time = (Time)getValue(paramInt, JDBCType.TIME);
/*  816 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/*  817 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLServerException {
/*  822 */     loggerExternal.entering(getClassNameLogging(), "getTime", paramString);
/*  823 */     checkClosed();
/*  824 */     Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME);
/*  825 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/*  826 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
/*  831 */     if (loggerExternal.isLoggable(Level.FINER))
/*  832 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/*  833 */     checkClosed();
/*  834 */     Time time = (Time)getValue(paramInt, JDBCType.TIME, paramCalendar);
/*  835 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/*  836 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLServerException {
/*  841 */     if (loggerExternal.isLoggable(Level.FINER))
/*  842 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { paramString, paramCalendar }); 
/*  843 */     checkClosed();
/*  844 */     Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME, paramCalendar);
/*  845 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/*  846 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLServerException {
/*  851 */     if (loggerExternal.isLoggable(Level.FINER))
/*  852 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(paramInt)); 
/*  853 */     checkClosed();
/*  854 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
/*  855 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/*  856 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLServerException {
/*  861 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", paramString);
/*  862 */     checkClosed();
/*  863 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
/*  864 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/*  865 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLServerException {
/*  870 */     if (loggerExternal.isLoggable(Level.FINER))
/*  871 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/*  872 */     checkClosed();
/*  873 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
/*  874 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/*  875 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLServerException {
/*  880 */     if (loggerExternal.isLoggable(Level.FINER))
/*  881 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { paramString, paramCalendar }); 
/*  882 */     checkClosed();
/*  883 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
/*  884 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/*  885 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int paramInt) throws SQLServerException {
/*  890 */     if (loggerExternal.isLoggable(Level.FINER))
/*  891 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", Integer.valueOf(paramInt)); 
/*  892 */     checkClosed();
/*  893 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.DATETIME);
/*  894 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/*  895 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String paramString) throws SQLServerException {
/*  900 */     loggerExternal.entering(getClassNameLogging(), "getDateTime", paramString);
/*  901 */     checkClosed();
/*  902 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.DATETIME);
/*  903 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/*  904 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
/*  909 */     if (loggerExternal.isLoggable(Level.FINER))
/*  910 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/*  911 */     checkClosed();
/*  912 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.DATETIME, paramCalendar);
/*  913 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/*  914 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
/*  919 */     if (loggerExternal.isLoggable(Level.FINER))
/*  920 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { paramString, paramCalendar }); 
/*  921 */     checkClosed();
/*  922 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.DATETIME, paramCalendar);
/*  923 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/*  924 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int paramInt) throws SQLServerException {
/*  929 */     if (loggerExternal.isLoggable(Level.FINER))
/*  930 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", Integer.valueOf(paramInt)); 
/*  931 */     checkClosed();
/*  932 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.SMALLDATETIME);
/*  933 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/*  934 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String paramString) throws SQLServerException {
/*  939 */     loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", paramString);
/*  940 */     checkClosed();
/*  941 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.SMALLDATETIME);
/*  942 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/*  943 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
/*  948 */     if (loggerExternal.isLoggable(Level.FINER))
/*  949 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/*  950 */     checkClosed();
/*  951 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.SMALLDATETIME, paramCalendar);
/*  952 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/*  953 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
/*  958 */     if (loggerExternal.isLoggable(Level.FINER))
/*  959 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { paramString, paramCalendar }); 
/*  960 */     checkClosed();
/*  961 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramCalendar);
/*  962 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/*  963 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(int paramInt) throws SQLException {
/*  968 */     if (loggerExternal.isLoggable(Level.FINER))
/*  969 */       loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(paramInt)); 
/*  970 */     checkClosed();
/*      */ 
/*      */     
/*  973 */     if (!this.connection.isKatmaiOrLater()) {
/*  974 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  980 */     DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(paramInt, JDBCType.DATETIMEOFFSET);
/*  981 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
/*  982 */     return dateTimeOffset;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(String paramString) throws SQLException {
/*  987 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", paramString);
/*  988 */     checkClosed();
/*      */ 
/*      */     
/*  991 */     if (!this.connection.isKatmaiOrLater()) {
/*  992 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  998 */     DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(findColumn(paramString), JDBCType.DATETIMEOFFSET);
/*  999 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
/* 1000 */     return dateTimeOffset;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLServerException {
/* 1005 */     loggerExternal.entering(getClassNameLogging(), "wasNull");
/* 1006 */     checkClosed();
/* 1007 */     boolean bool = false;
/* 1008 */     if (null != this.lastParamAccessed)
/*      */     {
/* 1010 */       bool = this.lastParamAccessed.isNull();
/*      */     }
/* 1012 */     loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(bool));
/* 1013 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getAsciiStream(int paramInt) throws SQLServerException {
/* 1018 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(paramInt));
/* 1019 */     checkClosed();
/* 1020 */     InputStream inputStream = (InputStream)getStream(paramInt, StreamType.ASCII);
/* 1021 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
/* 1022 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getAsciiStream(String paramString) throws SQLServerException {
/* 1027 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", paramString);
/* 1028 */     checkClosed();
/* 1029 */     InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.ASCII);
/* 1030 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
/* 1031 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLServerException {
/* 1036 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(paramInt));
/* 1037 */     checkClosed();
/* 1038 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
/* 1039 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/* 1040 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLServerException {
/* 1045 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", paramString);
/* 1046 */     checkClosed();
/* 1047 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 1048 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/* 1049 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(int paramInt) throws SQLServerException {
/* 1054 */     loggerExternal.entering(getClassNameLogging(), "getMoney", Integer.valueOf(paramInt));
/* 1055 */     checkClosed();
/* 1056 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.MONEY);
/* 1057 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
/* 1058 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(String paramString) throws SQLServerException {
/* 1063 */     loggerExternal.entering(getClassNameLogging(), "getMoney", paramString);
/* 1064 */     checkClosed();
/* 1065 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.MONEY);
/* 1066 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
/* 1067 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(int paramInt) throws SQLServerException {
/* 1072 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", Integer.valueOf(paramInt));
/* 1073 */     checkClosed();
/* 1074 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.SMALLMONEY);
/* 1075 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
/* 1076 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(String paramString) throws SQLServerException {
/* 1081 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", paramString);
/* 1082 */     checkClosed();
/* 1083 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.SMALLMONEY);
/* 1084 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
/* 1085 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getBinaryStream(int paramInt) throws SQLServerException {
/* 1090 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(paramInt));
/* 1091 */     checkClosed();
/* 1092 */     InputStream inputStream = (InputStream)getStream(paramInt, StreamType.BINARY);
/* 1093 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
/* 1094 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public final InputStream getBinaryStream(String paramString) throws SQLServerException {
/* 1099 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", paramString);
/* 1100 */     checkClosed();
/* 1101 */     InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.BINARY);
/* 1102 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
/* 1103 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLServerException {
/* 1108 */     loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(paramInt));
/* 1109 */     checkClosed();
/* 1110 */     Blob blob = (Blob)getValue(paramInt, JDBCType.BLOB);
/* 1111 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
/* 1112 */     return blob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLServerException {
/* 1117 */     loggerExternal.entering(getClassNameLogging(), "getBlob", paramString);
/* 1118 */     checkClosed();
/* 1119 */     Blob blob = (Blob)getValue(findColumn(paramString), JDBCType.BLOB);
/* 1120 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
/* 1121 */     return blob;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getCharacterStream(int paramInt) throws SQLServerException {
/* 1126 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(paramInt));
/* 1127 */     checkClosed();
/* 1128 */     Reader reader = (Reader)getStream(paramInt, StreamType.CHARACTER);
/* 1129 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
/* 1130 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getCharacterStream(String paramString) throws SQLException {
/* 1135 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/* 1137 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", paramString);
/* 1138 */     checkClosed();
/* 1139 */     Reader reader = (Reader)getStream(findColumn(paramString), StreamType.CHARACTER);
/* 1140 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterSream", reader);
/* 1141 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getNCharacterStream(int paramInt) throws SQLException {
/* 1146 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1147 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(paramInt));
/* 1148 */     checkClosed();
/* 1149 */     Reader reader = (Reader)getStream(paramInt, StreamType.NCHARACTER);
/* 1150 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
/* 1151 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public final Reader getNCharacterStream(String paramString) throws SQLException {
/* 1156 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/* 1158 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", paramString);
/* 1159 */     checkClosed();
/* 1160 */     Reader reader = (Reader)getStream(findColumn(paramString), StreamType.NCHARACTER);
/* 1161 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
/* 1162 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   void closeActiveStream() throws SQLServerException {
/* 1167 */     if (null != this.activeStream) {
/*      */       
/*      */       try {
/*      */         
/* 1171 */         this.activeStream.close();
/*      */       }
/* 1173 */       catch (IOException iOException) {
/*      */         
/* 1175 */         SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
/*      */       }
/*      */       finally {
/*      */         
/* 1179 */         this.activeStream = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLServerException {
/* 1187 */     loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(paramInt));
/* 1188 */     checkClosed();
/* 1189 */     Clob clob = (Clob)getValue(paramInt, JDBCType.CLOB);
/* 1190 */     loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
/* 1191 */     return clob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLServerException {
/* 1196 */     loggerExternal.entering(getClassNameLogging(), "getClob", paramString);
/* 1197 */     checkClosed();
/* 1198 */     Clob clob = (Clob)getValue(findColumn(paramString), JDBCType.CLOB);
/* 1199 */     loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
/* 1200 */     return clob;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 1205 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1206 */     loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(paramInt));
/* 1207 */     checkClosed();
/* 1208 */     NClob nClob = (NClob)getValue(paramInt, JDBCType.NCLOB);
/* 1209 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
/* 1210 */     return nClob;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(String paramString) throws SQLException {
/* 1215 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1216 */     loggerExternal.entering(getClassNameLogging(), "getNClob", paramString);
/* 1217 */     checkClosed();
/* 1218 */     NClob nClob = (NClob)getValue(findColumn(paramString), JDBCType.NCLOB);
/* 1219 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
/* 1220 */     return nClob;
/*      */   }
/*      */   
/*      */   public Object getObject(int paramInt, Map<String, Class<?>> paramMap) throws SQLServerException {
/* 1224 */     NotImplemented();
/* 1225 */     return null;
/*      */   }
/*      */   
/*      */   public Object getObject(String paramString, Map<String, Class<?>> paramMap) throws SQLServerException {
/* 1229 */     checkClosed();
/* 1230 */     return getObject(findColumn(paramString), paramMap);
/*      */   }
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLServerException {
/* 1234 */     NotImplemented();
/* 1235 */     return null;
/*      */   }
/*      */   public Ref getRef(String paramString) throws SQLServerException {
/* 1238 */     checkClosed();
/* 1239 */     return getRef(findColumn(paramString));
/*      */   }
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLServerException {
/* 1243 */     NotImplemented();
/* 1244 */     return null;
/*      */   }
/*      */   public Array getArray(String paramString) throws SQLServerException {
/* 1247 */     checkClosed();
/* 1248 */     return getArray(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int findColumn(String paramString) throws SQLServerException {
/*      */     final class ThreePartNamesParser
/*      */     {
/* 1265 */       private String procedurePart = null;
/* 1266 */       private String ownerPart = null;
/* 1267 */       private String databasePart = null;
/*      */       
/* 1269 */       String getProcedurePart() { return this.procedurePart; }
/* 1270 */       String getOwnerPart() { return this.ownerPart; } String getDatabasePart() {
/* 1271 */         return this.databasePart;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1282 */       private final Pattern threePartName = Pattern.compile(JDBCSyntaxTranslator.getSQLIdentifierWithGroups());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       final void parseProcedureNameIntoParts(String param1String) {
/* 1288 */         if (null != param1String) {
/*      */           
/* 1290 */           Matcher matcher = this.threePartName.matcher(param1String);
/* 1291 */           if (matcher.matches()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1297 */             if (matcher.group(2) != null)
/*      */             {
/* 1299 */               this.databasePart = matcher.group(1);
/*      */ 
/*      */               
/* 1302 */               matcher = this.threePartName.matcher(matcher.group(2));
/* 1303 */               if (matcher.matches())
/*      */               {
/* 1305 */                 if (null != matcher.group(2))
/*      */                 {
/* 1307 */                   this.ownerPart = matcher.group(1);
/* 1308 */                   this.procedurePart = matcher.group(2);
/*      */                 }
/*      */                 else
/*      */                 {
/* 1312 */                   this.ownerPart = this.databasePart;
/* 1313 */                   this.databasePart = null;
/* 1314 */                   this.procedurePart = matcher.group(1);
/*      */                 
/*      */                 }
/*      */ 
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */             else
/*      */             {
/* 1324 */               this.procedurePart = matcher.group(1);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 1329 */             this.procedurePart = param1String;
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1338 */     if (this.paramNames == null) {
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1345 */         SQLServerStatement sQLServerStatement = (SQLServerStatement)this.connection.createStatement();
/* 1346 */         ThreePartNamesParser threePartNamesParser = new ThreePartNamesParser();
/* 1347 */         threePartNamesParser.parseProcedureNameIntoParts(this.procedureName);
/* 1348 */         StringBuilder stringBuilder = new StringBuilder("exec sp_sproc_columns ");
/* 1349 */         if (null != threePartNamesParser.getDatabasePart()) {
/*      */           
/* 1351 */           stringBuilder.append("@procedure_qualifier=");
/* 1352 */           stringBuilder.append(threePartNamesParser.getDatabasePart());
/* 1353 */           stringBuilder.append(", ");
/*      */         } 
/* 1355 */         if (null != threePartNamesParser.getOwnerPart()) {
/*      */           
/* 1357 */           stringBuilder.append("@procedure_owner=");
/* 1358 */           stringBuilder.append(threePartNamesParser.getOwnerPart());
/* 1359 */           stringBuilder.append(", ");
/*      */         } 
/* 1361 */         if (null != threePartNamesParser.getProcedurePart()) {
/*      */ 
/*      */           
/* 1364 */           stringBuilder.append("@procedure_name=");
/* 1365 */           stringBuilder.append(threePartNamesParser.getProcedurePart());
/* 1366 */           stringBuilder.append(" , @ODBCVer=3");
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1372 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
/* 1373 */           Object[] arrayOfObject = { paramString, "" };
/* 1374 */           SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
/*      */         } 
/*      */         
/* 1377 */         SQLServerResultSet sQLServerResultSet = sQLServerStatement.executeQueryInternal(stringBuilder.toString());
/* 1378 */         this.paramNames = new ArrayList<>();
/* 1379 */         while (sQLServerResultSet.next())
/*      */         {
/* 1381 */           String str = sQLServerResultSet.getString(4);
/* 1382 */           this.paramNames.add(str.trim());
/*      */         }
/*      */       
/* 1385 */       } catch (SQLException sQLException) {
/*      */         
/* 1387 */         SQLServerException.makeFromDriverError(this.connection, this, sQLException.toString(), null, false);
/*      */       } 
/*      */     }
/*      */     
/* 1391 */     int i = 0;
/* 1392 */     if (this.paramNames != null) {
/* 1393 */       i = this.paramNames.size();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1402 */     byte b = 0;
/* 1403 */     byte b1 = -1;
/*      */ 
/*      */     
/* 1406 */     for (b = 0; b < i; b++) {
/*      */       
/* 1408 */       String str = this.paramNames.get(b);
/* 1409 */       str = str.substring(1, str.length());
/* 1410 */       if (str.equals(paramString)) {
/*      */         
/* 1412 */         b1 = b;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/* 1417 */     if (-1 == b1)
/*      */     {
/*      */ 
/*      */       
/* 1421 */       for (b = 0; b < i; b++) {
/*      */         
/* 1423 */         String str = this.paramNames.get(b);
/* 1424 */         str = str.substring(1, str.length());
/* 1425 */         if (str.equalsIgnoreCase(paramString)) {
/*      */           
/* 1427 */           b1 = b;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     }
/* 1433 */     if (-1 == b1) {
/*      */       
/* 1435 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_parameterNotDefinedForProcedure"));
/* 1436 */       Object[] arrayOfObject = { paramString, this.procedureName };
/* 1437 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), "07009", false);
/*      */     } 
/*      */ 
/*      */     
/* 1441 */     if (this.bReturnValueSyntax) {
/* 1442 */       return b1 + 1;
/*      */     }
/* 1444 */     return b1;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLServerException {
/* 1449 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1450 */       loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { paramString, paramTimestamp, paramCalendar }); 
/* 1451 */     checkClosed();
/* 1452 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, false);
/* 1453 */     loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 1458 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1459 */       loggerExternal.entering(getClassNameLogging(), "setTimeStamp", new Object[] { paramString, paramTimestamp, paramCalendar, Boolean.valueOf(paramBoolean) }); 
/* 1460 */     checkClosed();
/* 1461 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, paramCalendar, paramBoolean);
/* 1462 */     loggerExternal.exiting(getClassNameLogging(), "setTimeStamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLServerException {
/* 1467 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1468 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, paramCalendar }); 
/* 1469 */     checkClosed();
/* 1470 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, false);
/* 1471 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 1476 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1477 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, paramCalendar, Boolean.valueOf(paramBoolean) }); 
/* 1478 */     checkClosed();
/* 1479 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, paramCalendar, paramBoolean);
/* 1480 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLServerException {
/* 1485 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1486 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate, paramCalendar }); 
/* 1487 */     checkClosed();
/* 1488 */     setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, false);
/* 1489 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 1494 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1495 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate, paramCalendar, Boolean.valueOf(paramBoolean) }); 
/* 1496 */     checkClosed();
/* 1497 */     setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramCalendar, paramBoolean);
/* 1498 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 1503 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1504 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1505 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader }); 
/* 1506 */     checkClosed();
/* 1507 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 1508 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 1513 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1514 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader, Integer.valueOf(paramInt) }); 
/* 1515 */     checkClosed();
/* 1516 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramInt);
/* 1517 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1523 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1524 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1525 */       loggerExternal.entering(getClassNameLogging(), "setCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
/* 1526 */     checkClosed();
/* 1527 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 1528 */     loggerExternal.exiting(getClassNameLogging(), "setCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 1533 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1534 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1535 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { paramString, paramReader }); 
/* 1536 */     checkClosed();
/* 1537 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 1538 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1543 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1544 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1545 */       loggerExternal.entering(getClassNameLogging(), "setNCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
/* 1546 */     checkClosed();
/* 1547 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 1548 */     loggerExternal.exiting(getClassNameLogging(), "setNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(String paramString, Clob paramClob) throws SQLException {
/* 1553 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1554 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1555 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramClob }); 
/* 1556 */     checkClosed();
/* 1557 */     setValue(findColumn(paramString), JDBCType.CLOB, paramClob, JavaType.CLOB, false);
/* 1558 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(String paramString, Reader paramReader) throws SQLException {
/* 1563 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1564 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1565 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramReader }); 
/* 1566 */     checkClosed();
/* 1567 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/* 1568 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1573 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1574 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1575 */       loggerExternal.entering(getClassNameLogging(), "setClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
/* 1576 */     checkClosed();
/* 1577 */     setStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/* 1578 */     loggerExternal.exiting(getClassNameLogging(), "setClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(String paramString, NClob paramNClob) throws SQLException {
/* 1583 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1584 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1585 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramNClob }); 
/* 1586 */     checkClosed();
/* 1587 */     setValue(findColumn(paramString), JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);
/* 1588 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(String paramString, Reader paramReader) throws SQLException {
/* 1593 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1594 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1595 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramReader }); 
/* 1596 */     checkClosed();
/* 1597 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/* 1598 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 1603 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1604 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1605 */       loggerExternal.entering(getClassNameLogging(), "setNClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) }); 
/* 1606 */     checkClosed();
/* 1607 */     setStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/* 1608 */     loggerExternal.exiting(getClassNameLogging(), "setNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(String paramString1, String paramString2) throws SQLException {
/* 1613 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1614 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1615 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { paramString1, paramString2 }); 
/* 1616 */     checkClosed();
/* 1617 */     setValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, false);
/* 1618 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNString(String paramString1, String paramString2, boolean paramBoolean) throws SQLException {
/* 1623 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1624 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1625 */       loggerExternal.entering(getClassNameLogging(), "setNString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) }); 
/* 1626 */     checkClosed();
/* 1627 */     setValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, paramBoolean);
/* 1628 */     loggerExternal.exiting(getClassNameLogging(), "setNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLServerException {
/* 1633 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1634 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject }); 
/* 1635 */     checkClosed();
/* 1636 */     setObjectNoType(findColumn(paramString), paramObject, false);
/* 1637 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLServerException {
/* 1642 */     String str = null;
/* 1643 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1644 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt) }); 
/* 1645 */     checkClosed();
/* 1646 */     if (-153 == paramInt) {
/*      */       
/* 1648 */       str = getTVPNameIfNull(findColumn(paramString), (String)null);
/* 1649 */       setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.TVP, JDBCType.TVP, (Integer)null, (Integer)null, false, findColumn(paramString), str);
/*      */     } else {
/*      */       
/* 1652 */       setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt), (Integer)null, (Integer)null, false, findColumn(paramString), str);
/* 1653 */     }  loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, SQLType paramSQLType) throws SQLServerException {
/* 1658 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1660 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1661 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, paramSQLType });
/*      */     }
/*      */     
/* 1664 */     setObject(paramString, paramObject, paramSQLType.getVendorTypeNumber().intValue());
/*      */     
/* 1666 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
/* 1671 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1672 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
/* 1673 */     checkClosed();
/*      */     
/* 1675 */     setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), Integer.valueOf(paramInt2), (Integer)null, false, findColumn(paramString), (String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1687 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 1692 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1693 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
/* 1694 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1700 */     setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), (2 == paramInt1 || 3 == paramInt1) ? Integer.valueOf(paramInt2) : null, (Integer)null, paramBoolean, findColumn(paramString), (String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1713 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt) throws SQLServerException {
/* 1718 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1720 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1721 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt) });
/*      */     }
/*      */     
/* 1724 */     setObject(paramString, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInt);
/*      */     
/* 1726 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 1731 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1733 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1734 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/*      */     
/* 1737 */     setObject(paramString, paramObject, paramSQLType.getVendorTypeNumber().intValue(), paramInt, paramBoolean);
/*      */     
/* 1739 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setObject(String paramString, Object paramObject, int paramInt1, Integer paramInteger, int paramInt2) throws SQLServerException {
/* 1744 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1745 */       loggerExternal.entering(getClassNameLogging(), "setObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), paramInteger, Integer.valueOf(paramInt2) }); 
/* 1746 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1753 */     setObject(setterGetParam(findColumn(paramString)), paramObject, JavaType.of(paramObject), JDBCType.of(paramInt1), (2 == paramInt1 || 3 == paramInt1 || InputStream.class.isInstance(paramObject) || Reader.class.isInstance(paramObject)) ? Integer.valueOf(paramInt2) : null, paramInteger, false, findColumn(paramString), (String)null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1769 */     loggerExternal.exiting(getClassNameLogging(), "setObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 1774 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1775 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream }); 
/* 1776 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1777 */     checkClosed();
/* 1778 */     setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1779 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1784 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1785 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) }); 
/* 1786 */     checkClosed();
/* 1787 */     setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/* 1788 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1793 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1794 */       loggerExternal.entering(getClassNameLogging(), "setAsciiStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) }); 
/* 1795 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1796 */     checkClosed();
/* 1797 */     setStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1798 */     loggerExternal.exiting(getClassNameLogging(), "setAsciiStream");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 1804 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1805 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1806 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream }); 
/* 1807 */     checkClosed();
/* 1808 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1809 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1814 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1815 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) }); 
/* 1816 */     checkClosed();
/* 1817 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/* 1818 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1823 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1824 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1825 */       loggerExternal.entering(getClassNameLogging(), "setBinaryStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) }); 
/* 1826 */     checkClosed();
/* 1827 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1828 */     loggerExternal.exiting(getClassNameLogging(), "setBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(String paramString, Blob paramBlob) throws SQLException {
/* 1833 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1834 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1835 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramBlob }); 
/* 1836 */     checkClosed();
/* 1837 */     setValue(findColumn(paramString), JDBCType.BLOB, paramBlob, JavaType.BLOB, false);
/* 1838 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(String paramString, InputStream paramInputStream) throws SQLException {
/* 1843 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/* 1845 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1846 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramInputStream }); 
/* 1847 */     checkClosed();
/* 1848 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/* 1849 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 1854 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 1855 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1856 */       loggerExternal.entering(getClassNameLogging(), "setBlob", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) }); 
/* 1857 */     checkClosed();
/* 1858 */     setStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/* 1859 */     loggerExternal.exiting(getClassNameLogging(), "setBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLServerException {
/* 1864 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1865 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp }); 
/* 1866 */     checkClosed();
/* 1867 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);
/* 1868 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
/* 1873 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1874 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp }); 
/* 1875 */     checkClosed();
/* 1876 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt), false);
/* 1877 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 1882 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1883 */       loggerExternal.entering(getClassNameLogging(), "setTimestamp", new Object[] { paramString, paramTimestamp, Boolean.valueOf(paramBoolean) }); 
/* 1884 */     checkClosed();
/* 1885 */     setValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, (Integer)null, Integer.valueOf(paramInt), paramBoolean);
/* 1886 */     loggerExternal.exiting(getClassNameLogging(), "setTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLException {
/* 1891 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1892 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset }); 
/* 1893 */     checkClosed();
/* 1894 */     setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);
/* 1895 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt) throws SQLException {
/* 1900 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1901 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset }); 
/* 1902 */     checkClosed();
/* 1903 */     setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt), false);
/* 1904 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt, boolean paramBoolean) throws SQLException {
/* 1909 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1910 */       loggerExternal.entering(getClassNameLogging(), "setDateTimeOffset", new Object[] { paramString, paramDateTimeOffset, Boolean.valueOf(paramBoolean) }); 
/* 1911 */     checkClosed();
/* 1912 */     setValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, (Integer)null, Integer.valueOf(paramInt), paramBoolean);
/* 1913 */     loggerExternal.exiting(getClassNameLogging(), "setDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLServerException {
/* 1918 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1919 */       loggerExternal.entering(getClassNameLogging(), "setDate", new Object[] { paramString, paramDate }); 
/* 1920 */     checkClosed();
/* 1921 */     setValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, false);
/* 1922 */     loggerExternal.exiting(getClassNameLogging(), "setDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLServerException {
/* 1927 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1928 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime }); 
/* 1929 */     checkClosed();
/* 1930 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, false);
/* 1931 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, int paramInt) throws SQLServerException {
/* 1936 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1937 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime }); 
/* 1938 */     checkClosed();
/* 1939 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt), false);
/* 1940 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 1945 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1946 */       loggerExternal.entering(getClassNameLogging(), "setTime", new Object[] { paramString, paramTime, Boolean.valueOf(paramBoolean) }); 
/* 1947 */     checkClosed();
/* 1948 */     setValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, (Integer)null, Integer.valueOf(paramInt), paramBoolean);
/* 1949 */     loggerExternal.exiting(getClassNameLogging(), "setTime");
/*      */   }
/*      */   
/*      */   public void setDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
/* 1953 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1954 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { paramString, paramTimestamp }); 
/* 1955 */     checkClosed();
/* 1956 */     setValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/* 1957 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDateTime(String paramString, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
/* 1962 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1963 */       loggerExternal.entering(getClassNameLogging(), "setDateTime", new Object[] { paramString, paramTimestamp, Boolean.valueOf(paramBoolean) }); 
/* 1964 */     checkClosed();
/* 1965 */     setValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
/* 1966 */     loggerExternal.exiting(getClassNameLogging(), "setDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
/* 1971 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1972 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { paramString, paramTimestamp }); 
/* 1973 */     checkClosed();
/* 1974 */     setValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/* 1975 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallDateTime(String paramString, Timestamp paramTimestamp, boolean paramBoolean) throws SQLServerException {
/* 1980 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1981 */       loggerExternal.entering(getClassNameLogging(), "setSmallDateTime", new Object[] { paramString, paramTimestamp, Boolean.valueOf(paramBoolean) }); 
/* 1982 */     checkClosed();
/* 1983 */     setValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, paramBoolean);
/* 1984 */     loggerExternal.exiting(getClassNameLogging(), "setSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUniqueIdentifier(String paramString1, String paramString2) throws SQLServerException {
/* 1989 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1990 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { paramString1, paramString2 }); 
/* 1991 */     checkClosed();
/* 1992 */     setValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, false);
/* 1993 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setUniqueIdentifier(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
/* 1998 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1999 */       loggerExternal.entering(getClassNameLogging(), "setUniqueIdentifier", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) }); 
/* 2000 */     checkClosed();
/* 2001 */     setValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, paramBoolean);
/* 2002 */     loggerExternal.exiting(getClassNameLogging(), "setUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLServerException {
/* 2007 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2008 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { paramString, paramArrayOfbyte }); 
/* 2009 */     checkClosed();
/* 2010 */     setValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);
/* 2011 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
/* 2016 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2017 */       loggerExternal.entering(getClassNameLogging(), "setBytes", new Object[] { paramString, paramArrayOfbyte, Boolean.valueOf(paramBoolean) }); 
/* 2018 */     checkClosed();
/* 2019 */     setValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);
/* 2020 */     loggerExternal.exiting(getClassNameLogging(), "setBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLServerException {
/* 2025 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2026 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { paramString, Byte.valueOf(paramByte) }); 
/* 2027 */     checkClosed();
/* 2028 */     setValue(findColumn(paramString), JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, false);
/* 2029 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte, boolean paramBoolean) throws SQLServerException {
/* 2034 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2035 */       loggerExternal.entering(getClassNameLogging(), "setByte", new Object[] { paramString, Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) }); 
/* 2036 */     checkClosed();
/* 2037 */     setValue(findColumn(paramString), JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);
/* 2038 */     loggerExternal.exiting(getClassNameLogging(), "setByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLServerException {
/* 2043 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2044 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { paramString1, paramString2 }); 
/* 2045 */     checkClosed();
/* 2046 */     setValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, false);
/* 2047 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
/* 2052 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2053 */       loggerExternal.entering(getClassNameLogging(), "setString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) }); 
/* 2054 */     checkClosed();
/* 2055 */     setValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, paramBoolean);
/* 2056 */     loggerExternal.exiting(getClassNameLogging(), "setString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
/* 2061 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2062 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { paramString, paramBigDecimal }); 
/* 2063 */     checkClosed();
/* 2064 */     setValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/* 2065 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 2070 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2071 */       loggerExternal.entering(getClassNameLogging(), "setMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 2072 */     checkClosed();
/* 2073 */     setValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/* 2074 */     loggerExternal.exiting(getClassNameLogging(), "setMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
/* 2079 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2080 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { paramString, paramBigDecimal }); 
/* 2081 */     checkClosed();
/* 2082 */     setValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/* 2083 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSmallMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 2088 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2089 */       loggerExternal.entering(getClassNameLogging(), "setSmallMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 2090 */     checkClosed();
/* 2091 */     setValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/* 2092 */     loggerExternal.exiting(getClassNameLogging(), "setSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
/* 2097 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2098 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal }); 
/* 2099 */     checkClosed();
/* 2100 */     setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);
/* 2101 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt1, int paramInt2) throws SQLServerException {
/* 2106 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2107 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
/* 2108 */     checkClosed();
/* 2109 */     setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), false);
/* 2110 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 2115 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2116 */       loggerExternal.entering(getClassNameLogging(), "setBigDecimal", new Object[] { paramString, paramBigDecimal, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) }); 
/* 2117 */     checkClosed();
/* 2118 */     setValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), paramBoolean);
/* 2119 */     loggerExternal.exiting(getClassNameLogging(), "setBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLServerException {
/* 2124 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2125 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { paramString, Double.valueOf(paramDouble) }); 
/* 2126 */     checkClosed();
/* 2127 */     setValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);
/* 2128 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble, boolean paramBoolean) throws SQLServerException {
/* 2133 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2134 */       loggerExternal.entering(getClassNameLogging(), "setDouble", new Object[] { paramString, Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) }); 
/* 2135 */     checkClosed();
/* 2136 */     setValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);
/* 2137 */     loggerExternal.exiting(getClassNameLogging(), "setDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLServerException {
/* 2142 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2143 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { paramString, Float.valueOf(paramFloat) }); 
/* 2144 */     checkClosed();
/* 2145 */     setValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);
/* 2146 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat, boolean paramBoolean) throws SQLServerException {
/* 2151 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2152 */       loggerExternal.entering(getClassNameLogging(), "setFloat", new Object[] { paramString, Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) }); 
/* 2153 */     checkClosed();
/* 2154 */     setValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);
/* 2155 */     loggerExternal.exiting(getClassNameLogging(), "setFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLServerException {
/* 2160 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2161 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { paramString, Integer.valueOf(paramInt) }); 
/* 2162 */     checkClosed();
/* 2163 */     setValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, false);
/* 2164 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 2169 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2170 */       loggerExternal.entering(getClassNameLogging(), "setInt", new Object[] { paramString, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) }); 
/* 2171 */     checkClosed();
/* 2172 */     setValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, paramBoolean);
/* 2173 */     loggerExternal.exiting(getClassNameLogging(), "setInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLServerException {
/* 2178 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2179 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { paramString, Long.valueOf(paramLong) }); 
/* 2180 */     checkClosed();
/* 2181 */     setValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);
/* 2182 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong, boolean paramBoolean) throws SQLServerException {
/* 2187 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2188 */       loggerExternal.entering(getClassNameLogging(), "setLong", new Object[] { paramString, Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) }); 
/* 2189 */     checkClosed();
/* 2190 */     setValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);
/* 2191 */     loggerExternal.exiting(getClassNameLogging(), "setLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLServerException {
/* 2196 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2197 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { paramString, Short.valueOf(paramShort) }); 
/* 2198 */     checkClosed();
/* 2199 */     setValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);
/* 2200 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort, boolean paramBoolean) throws SQLServerException {
/* 2205 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2206 */       loggerExternal.entering(getClassNameLogging(), "setShort", new Object[] { paramString, Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) }); 
/* 2207 */     checkClosed();
/* 2208 */     setValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);
/* 2209 */     loggerExternal.exiting(getClassNameLogging(), "setShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLServerException {
/* 2214 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2215 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean) }); 
/* 2216 */     checkClosed();
/* 2217 */     setValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);
/* 2218 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
/* 2223 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2224 */       loggerExternal.entering(getClassNameLogging(), "setBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) }); 
/* 2225 */     checkClosed();
/* 2226 */     setValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);
/* 2227 */     loggerExternal.exiting(getClassNameLogging(), "setBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLServerException {
/* 2232 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2233 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { paramString, Integer.valueOf(paramInt) }); 
/* 2234 */     checkClosed();
/* 2235 */     setObject(setterGetParam(findColumn(paramString)), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt), (Integer)null, (Integer)null, false, findColumn(paramString), (String)null);
/* 2236 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLServerException {
/* 2241 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2242 */       loggerExternal.entering(getClassNameLogging(), "setNull", new Object[] { paramString1, Integer.valueOf(paramInt), paramString2 }); 
/* 2243 */     checkClosed();
/* 2244 */     setObject(setterGetParam(findColumn(paramString1)), (Object)null, JavaType.OBJECT, JDBCType.of(paramInt), (Integer)null, (Integer)null, false, findColumn(paramString1), paramString2);
/* 2245 */     loggerExternal.exiting(getClassNameLogging(), "setNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLServerException {
/* 2250 */     loggerExternal.entering(getClassNameLogging(), "setURL", paramString);
/* 2251 */     checkClosed();
/* 2252 */     setURL(findColumn(paramString), paramURL);
/* 2253 */     loggerExternal.exiting(getClassNameLogging(), "setURL");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(String paramString1, String paramString2, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException {
/* 2258 */     paramString2 = getTVPNameIfNull(findColumn(paramString1), paramString2);
/* 2259 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2260 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { paramString1, paramString2, paramSQLServerDataTable }); 
/* 2261 */     checkClosed();
/* 2262 */     setValue(findColumn(paramString1), JDBCType.TVP, paramSQLServerDataTable, JavaType.TVP, paramString2);
/* 2263 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(String paramString1, String paramString2, ResultSet paramResultSet) throws SQLServerException {
/* 2268 */     paramString2 = getTVPNameIfNull(findColumn(paramString1), paramString2);
/* 2269 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2270 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { paramString1, paramString2, paramResultSet }); 
/* 2271 */     checkClosed();
/* 2272 */     setValue(findColumn(paramString1), JDBCType.TVP, paramResultSet, JavaType.TVP, paramString2);
/* 2273 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setStructured(String paramString1, String paramString2, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException {
/* 2278 */     paramString2 = getTVPNameIfNull(findColumn(paramString1), paramString2);
/* 2279 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2280 */       loggerExternal.entering(getClassNameLogging(), "setStructured", new Object[] { paramString1, paramString2, paramISQLServerDataRecord }); 
/* 2281 */     checkClosed();
/* 2282 */     setValue(findColumn(paramString1), JDBCType.TVP, paramISQLServerDataRecord, JavaType.TVP, paramString2);
/* 2283 */     loggerExternal.exiting(getClassNameLogging(), "setStructured");
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLServerException {
/* 2288 */     NotImplemented();
/* 2289 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLServerException {
/* 2294 */     NotImplemented();
/* 2295 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 2300 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2301 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2302 */       loggerExternal.entering(getClassNameLogging(), "setSQLXML", new Object[] { paramString, paramSQLXML }); 
/* 2303 */     checkClosed();
/* 2304 */     setSQLXMLInternal(findColumn(paramString), paramSQLXML);
/* 2305 */     loggerExternal.exiting(getClassNameLogging(), "setSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public final SQLXML getSQLXML(int paramInt) throws SQLException {
/* 2310 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2311 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(paramInt));
/* 2312 */     checkClosed();
/* 2313 */     SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getSQLXMLInternal(paramInt);
/* 2314 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLServerSQLXML);
/* 2315 */     return sQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   
/*      */   public final SQLXML getSQLXML(String paramString) throws SQLException {
/* 2320 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2321 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", paramString);
/* 2322 */     checkClosed();
/* 2323 */     SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getSQLXMLInternal(findColumn(paramString));
/* 2324 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLServerSQLXML);
/* 2325 */     return sQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setRowId(String paramString, RowId paramRowId) throws SQLException {
/* 2330 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 2333 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final RowId getRowId(int paramInt) throws SQLException {
/* 2338 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 2341 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public final RowId getRowId(String paramString) throws SQLException {
/* 2346 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 2349 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLServerException {
/* 2354 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2355 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString1, new Integer(paramInt), paramString2 }); 
/* 2356 */     checkClosed();
/* 2357 */     registerOutParameter(findColumn(paramString1), paramInt, paramString2);
/* 2358 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, SQLType paramSQLType, String paramString2) throws SQLServerException {
/* 2363 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2365 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2366 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString1, paramSQLType, paramString2 });
/*      */     }
/*      */     
/* 2369 */     registerOutParameter(paramString1, paramSQLType.getVendorTypeNumber().intValue(), paramString2);
/*      */     
/* 2371 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLServerException {
/* 2376 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2377 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) });
/*      */     }
/* 2379 */     checkClosed();
/* 2380 */     registerOutParameter(findColumn(paramString), paramInt1, paramInt2);
/* 2381 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
/* 2386 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2387 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt3) });
/*      */     }
/* 2389 */     checkClosed();
/* 2390 */     registerOutParameter(findColumn(paramString), paramInt1, paramInt2, paramInt3);
/* 2391 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, SQLType paramSQLType, int paramInt) throws SQLServerException {
/* 2396 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2398 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2399 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, paramSQLType, new Integer(paramInt) });
/*      */     }
/*      */ 
/*      */     
/* 2403 */     registerOutParameter(paramString, paramSQLType.getVendorTypeNumber().intValue(), paramInt);
/*      */     
/* 2405 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, SQLType paramSQLType, int paramInt1, int paramInt2) throws SQLServerException {
/* 2410 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2412 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2413 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, paramSQLType, new Integer(paramInt2) });
/*      */     }
/*      */ 
/*      */     
/* 2417 */     registerOutParameter(paramString, paramSQLType.getVendorTypeNumber().intValue(), paramInt1, paramInt2);
/*      */     
/* 2419 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLServerException {
/* 2424 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2425 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, new Integer(paramInt) }); 
/* 2426 */     checkClosed();
/* 2427 */     registerOutParameter(findColumn(paramString), paramInt);
/* 2428 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, SQLType paramSQLType) throws SQLServerException {
/* 2433 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2435 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 2436 */       loggerExternal.entering(getClassNameLogging(), "registerOutParameter", new Object[] { paramString, paramSQLType });
/*      */     }
/*      */     
/* 2439 */     registerOutParameter(paramString, paramSQLType.getVendorTypeNumber().intValue());
/*      */     
/* 2441 */     loggerExternal.exiting(getClassNameLogging(), "registerOutParameter");
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerCallableStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */