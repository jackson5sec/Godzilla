/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ final class StreamInfo
/*    */   extends StreamPacket {
/*  5 */   final StreamError msg = new StreamError();
/*    */ 
/*    */   
/*    */   StreamInfo() {
/*  9 */     super(171);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 14 */     if (171 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 15 */     this.msg.setContentsFromTDS(paramTDSReader);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */