/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.MathContext;
/*      */ import java.math.RoundingMode;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.charset.Charset;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.TimeZone;
/*      */ import java.util.UUID;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DTV
/*      */ {
/*   85 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.DTV");
/*      */ 
/*      */   
/*      */   private DTVImpl impl;
/*      */ 
/*      */   
/*   91 */   CryptoMetadata cryptoMeta = null;
/*   92 */   JDBCType jdbcTypeSetByUser = null;
/*   93 */   int valueLength = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException {
/*  112 */     if (null == this.impl) {
/*  113 */       this.impl = new AppDTVImpl();
/*      */     }
/*  115 */     this.impl.setValue(this, paramSQLCollation, paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger, paramSQLServerConnection, paramBoolean);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setValue(Object paramObject, JavaType paramJavaType) {
/*  120 */     this.impl.setValue(paramObject, paramJavaType);
/*      */   }
/*      */   final void clear() {
/*  123 */     this.impl = null;
/*      */   }
/*      */   
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
/*  127 */     if (null == this.impl) {
/*  128 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  130 */     this.impl.skipValue(paramTypeInfo, paramTDSReader, paramBoolean);
/*      */   }
/*      */ 
/*      */   
/*      */   final void initFromCompressedNull() {
/*  135 */     if (null == this.impl) {
/*  136 */       this.impl = new ServerDTVImpl();
/*      */     }
/*  138 */     this.impl.initFromCompressedNull();
/*      */   }
/*      */ 
/*      */   
/*      */   final void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs) {
/*  143 */     this.impl.setStreamSetterArgs(paramStreamSetterArgs);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setCalendar(Calendar paramCalendar) {
/*  148 */     this.impl.setCalendar(paramCalendar);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setScale(Integer paramInteger) {
/*  153 */     this.impl.setScale(paramInteger);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setForceEncrypt(boolean paramBoolean) {
/*  158 */     this.impl.setForceEncrypt(paramBoolean);
/*      */   }
/*      */   
/*  161 */   StreamSetterArgs getStreamSetterArgs() { return this.impl.getStreamSetterArgs(); }
/*  162 */   Calendar getCalendar() { return this.impl.getCalendar(); } Integer getScale() {
/*  163 */     return this.impl.getScale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isNull() {
/*  170 */     return (null == this.impl || this.impl.isNull());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isInitialized() {
/*  179 */     return (null != this.impl);
/*      */   }
/*      */ 
/*      */   
/*      */   final void setJdbcType(JDBCType paramJDBCType) {
/*  184 */     if (null == this.impl) {
/*  185 */       this.impl = new AppDTVImpl();
/*      */     }
/*  187 */     this.impl.setJdbcType(paramJDBCType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final JDBCType getJdbcType() {
/*  195 */     assert null != this.impl;
/*  196 */     return this.impl.getJdbcType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final JavaType getJavaType() {
/*  204 */     assert null != this.impl;
/*  205 */     return this.impl.getJavaType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getValue(JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader) throws SQLServerException {
/*  224 */     if (null == this.impl)
/*  225 */       this.impl = new ServerDTVImpl(); 
/*  226 */     return this.impl.getValue(this, paramJDBCType, paramInt, paramInputStreamGetterArgs, paramCalendar, paramTypeInfo, paramCryptoMetadata, paramTDSReader);
/*      */   }
/*      */ 
/*      */   
/*      */   Object getSetterValue() {
/*  231 */     return this.impl.getSetterValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setImpl(DTVImpl paramDTVImpl) {
/*  240 */     this.impl = paramDTVImpl;
/*      */   }
/*      */ 
/*      */   
/*      */   final class SendByRPCOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private final String name;
/*      */     
/*      */     private final TypeInfo typeInfo;
/*      */     
/*      */     private final SQLCollation collation;
/*      */     
/*      */     private final int precision;
/*      */     
/*      */     private final int outScale;
/*      */     
/*      */     private final boolean isOutParam;
/*      */     
/*      */     private final TDSWriter tdsWriter;
/*      */     
/*      */     private final SQLServerConnection conn;
/*      */     
/*      */     SendByRPCOp(String param1String, TypeInfo param1TypeInfo, SQLCollation param1SQLCollation, int param1Int1, int param1Int2, boolean param1Boolean, TDSWriter param1TDSWriter, SQLServerConnection param1SQLServerConnection) {
/*  264 */       this.name = param1String;
/*  265 */       this.typeInfo = param1TypeInfo;
/*  266 */       this.collation = param1SQLCollation;
/*  267 */       this.precision = param1Int1;
/*  268 */       this.outScale = param1Int2;
/*  269 */       this.isOutParam = param1Boolean;
/*  270 */       this.tdsWriter = param1TDSWriter;
/*  271 */       this.conn = param1SQLServerConnection;
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, String param1String) throws SQLServerException {
/*  276 */       this.tdsWriter.writeRPCStringUnicode(this.name, param1String, this.isOutParam, this.collation);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Clob param1Clob) throws SQLServerException {
/*  282 */       assert null != param1Clob;
/*      */       
/*  284 */       long l = 0L;
/*  285 */       Reader reader = null;
/*      */ 
/*      */       
/*      */       try {
/*  289 */         l = DataTypes.getCheckedLength(this.conn, param1DTV.getJdbcType(), param1Clob.length(), false);
/*  290 */         reader = param1Clob.getCharacterStream();
/*      */       }
/*  292 */       catch (SQLException sQLException) {
/*      */         
/*  294 */         SQLServerException.makeFromDriverError(this.conn, null, sQLException.getMessage(), null, false);
/*      */       } 
/*      */ 
/*      */       
/*  298 */       JDBCType jDBCType = param1DTV.getJdbcType();
/*  299 */       if (null != this.collation && (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.LONGVARCHAR == jDBCType || JDBCType.CLOB == jDBCType)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  305 */         if (null == reader)
/*      */         {
/*  307 */           this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, jDBCType, this.collation);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */           
/*  316 */           ReaderInputStream readerInputStream = null;
/*      */ 
/*      */           
/*      */           try {
/*  320 */             readerInputStream = new ReaderInputStream(reader, this.collation.getCharset(), l);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*  325 */           catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */             
/*  327 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/*  328 */             Object[] arrayOfObject = { new String(unsupportedEncodingException.getMessage()) };
/*  329 */             SQLServerException.makeFromDriverError(this.conn, null, messageFormat.format(arrayOfObject), null, true);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  337 */           this.tdsWriter.writeRPCInputStream(this.name, readerInputStream, -1L, this.isOutParam, jDBCType, this.collation);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  348 */       else if (null == reader) {
/*      */         
/*  350 */         this.tdsWriter.writeRPCStringUnicode(this.name, null, this.isOutParam, this.collation);
/*      */       }
/*      */       else {
/*      */         
/*  354 */         this.tdsWriter.writeRPCReaderUnicode(this.name, reader, l, this.isOutParam, this.collation);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Byte param1Byte) throws SQLServerException {
/*  366 */       this.tdsWriter.writeRPCByte(this.name, param1Byte, this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Integer param1Integer) throws SQLServerException {
/*  371 */       this.tdsWriter.writeRPCInt(this.name, param1Integer, this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Time param1Time) throws SQLServerException {
/*  376 */       sendTemporal(param1DTV, JavaType.TIME, param1Time);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
/*  384 */       sendTemporal(param1DTV, JavaType.DATE, param1Date);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Timestamp param1Timestamp) throws SQLServerException {
/*  392 */       sendTemporal(param1DTV, JavaType.TIMESTAMP, param1Timestamp);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
/*  400 */       sendTemporal(param1DTV, JavaType.UTILDATE, param1Date);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Calendar param1Calendar) throws SQLServerException {
/*  408 */       sendTemporal(param1DTV, JavaType.CALENDAR, param1Calendar);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalDate param1LocalDate) throws SQLServerException {
/*  416 */       sendTemporal(param1DTV, JavaType.LOCALDATE, param1LocalDate);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalTime param1LocalTime) throws SQLServerException {
/*  424 */       sendTemporal(param1DTV, JavaType.LOCALTIME, param1LocalTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalDateTime param1LocalDateTime) throws SQLServerException {
/*  432 */       sendTemporal(param1DTV, JavaType.LOCALDATETIME, param1LocalDateTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, OffsetTime param1OffsetTime) throws SQLServerException {
/*  440 */       sendTemporal(param1DTV, JavaType.OFFSETTIME, param1OffsetTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, OffsetDateTime param1OffsetDateTime) throws SQLServerException {
/*  448 */       sendTemporal(param1DTV, JavaType.OFFSETDATETIME, param1OffsetDateTime);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, DateTimeOffset param1DateTimeOffset) throws SQLServerException {
/*  456 */       sendTemporal(param1DTV, JavaType.DATETIMEOFFSET, param1DateTimeOffset);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, TVP param1TVP) throws SQLServerException {
/*  465 */       this.tdsWriter.writeTVP(param1TVP);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void clearSetCalendar(Calendar param1Calendar, boolean param1Boolean, Integer param1Integer1, Integer param1Integer2, Integer param1Integer3, Integer param1Integer4, Integer param1Integer5, Integer param1Integer6) {
/*  476 */       param1Calendar.clear();
/*  477 */       param1Calendar.setLenient(param1Boolean);
/*  478 */       if (null != param1Integer1)
/*      */       {
/*  480 */         param1Calendar.set(1, param1Integer1.intValue());
/*      */       }
/*  482 */       if (null != param1Integer2)
/*      */       {
/*  484 */         param1Calendar.set(2, param1Integer2.intValue());
/*      */       }
/*  486 */       if (null != param1Integer3)
/*      */       {
/*  488 */         param1Calendar.set(5, param1Integer3.intValue());
/*      */       }
/*  490 */       if (null != param1Integer4)
/*      */       {
/*  492 */         param1Calendar.set(11, param1Integer4.intValue());
/*      */       }
/*  494 */       if (null != param1Integer5)
/*      */       {
/*  496 */         param1Calendar.set(12, param1Integer5.intValue());
/*      */       }
/*  498 */       if (null != param1Integer6)
/*      */       {
/*  500 */         param1Calendar.set(13, param1Integer6.intValue());
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void sendTemporal(DTV param1DTV, JavaType param1JavaType, Object param1Object) throws SQLServerException {
/*  522 */       JDBCType jDBCType = param1DTV.getJdbcType();
/*  523 */       GregorianCalendar gregorianCalendar = null;
/*  524 */       int i = 0;
/*  525 */       int j = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  551 */       if (null != param1Object) {
/*      */         Timestamp timestamp; LocalTime localTime; LocalDateTime localDateTime; OffsetTime offsetTime; String str1; OffsetDateTime offsetDateTime; String str2; DateTimeOffset dateTimeOffset;
/*  553 */         TimeZone timeZone = TimeZone.getDefault();
/*  554 */         long l = 0L;
/*      */ 
/*      */         
/*  557 */         switch (param1JavaType) {
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME2:
/*  562 */             timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*      */             
/*  565 */             l = ((Time)param1Object).getTime();
/*  566 */             i = 1000000 * (int)(l % 1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  575 */             if (i < 0) {
/*  576 */               i += 1000000000;
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATE:
/*  584 */             timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*      */             
/*  587 */             l = ((Date)param1Object).getTime();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case TIME:
/*  594 */             timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*      */             
/*  597 */             timestamp = (Timestamp)param1Object;
/*  598 */             l = timestamp.getTime();
/*  599 */             i = timestamp.getNanos();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIMEOFFSET:
/*  608 */             timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*      */             
/*  611 */             l = ((Date)param1Object).getTime();
/*      */ 
/*      */ 
/*      */             
/*  615 */             i = 1000000 * (int)(l % 1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  624 */             if (i < 0) {
/*  625 */               i += 1000000000;
/*      */             }
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME:
/*  634 */             timeZone = (null != param1DTV.getCalendar()) ? param1DTV.getCalendar().getTimeZone() : TimeZone.getDefault();
/*      */ 
/*      */             
/*  637 */             l = ((Calendar)param1Object).getTimeInMillis();
/*      */ 
/*      */ 
/*      */             
/*  641 */             i = 1000000 * (int)(l % 1000L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  650 */             if (i < 0) {
/*  651 */               i += 1000000000;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case SMALLDATETIME:
/*  657 */             gregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */ 
/*      */             
/*  660 */             clearSetCalendar(gregorianCalendar, true, Integer.valueOf(((LocalDate)param1Object).getYear()), Integer.valueOf(((LocalDate)param1Object).getMonthValue() - 1), Integer.valueOf(((LocalDate)param1Object).getDayOfMonth()), null, null, null);
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case VARBINARY:
/*  669 */             gregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */ 
/*      */             
/*  672 */             localTime = (LocalTime)param1Object;
/*  673 */             clearSetCalendar(gregorianCalendar, true, Integer.valueOf(this.conn.baseYear()), Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(localTime.getHour()), Integer.valueOf(localTime.getMinute()), Integer.valueOf(localTime.getSecond()));
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  678 */             i = localTime.getNano();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case VARBINARYMAX:
/*  687 */             gregorianCalendar = new GregorianCalendar(UTC.timeZone, Locale.US);
/*      */             
/*  689 */             localDateTime = (LocalDateTime)param1Object;
/*  690 */             clearSetCalendar(gregorianCalendar, true, Integer.valueOf(localDateTime.getYear()), Integer.valueOf(localDateTime.getMonthValue() - 1), Integer.valueOf(localDateTime.getDayOfMonth()), Integer.valueOf(localDateTime.getHour()), Integer.valueOf(localDateTime.getMinute()), Integer.valueOf(localDateTime.getSecond()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  697 */             i = localDateTime.getNano();
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*  704 */             offsetTime = (OffsetTime)param1Object;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/*  710 */               j = offsetTime.getOffset().getTotalSeconds() / 60;
/*      */             }
/*  712 */             catch (Exception exception) {
/*      */               
/*  714 */               throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  720 */             i = offsetTime.getNano();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  727 */             timeZone = (JDBCType.TIME_WITH_TIMEZONE == jDBCType && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  735 */             str1 = this.conn.baseYear() + "-01-01" + ' ' + offsetTime.getHour() + ':' + offsetTime.getMinute() + ':' + offsetTime.getSecond();
/*      */ 
/*      */ 
/*      */             
/*  739 */             l = Timestamp.valueOf(str1).getTime();
/*      */             break;
/*      */           
/*      */           case null:
/*  743 */             offsetDateTime = (OffsetDateTime)param1Object;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/*  749 */               j = offsetDateTime.getOffset().getTotalSeconds() / 60;
/*      */             }
/*  751 */             catch (Exception exception) {
/*      */               
/*  753 */               throw new SQLServerException(SQLServerException.getErrString("R_zoneOffsetError"), null, 0, null);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  760 */             i = offsetDateTime.getNano();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  767 */             timeZone = ((JDBCType.TIMESTAMP_WITH_TIMEZONE == jDBCType || JDBCType.TIME_WITH_TIMEZONE == jDBCType) && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  775 */             str2 = String.format("%04d", new Object[] { Integer.valueOf(offsetDateTime.getYear()) }) + '-' + offsetDateTime.getMonthValue() + '-' + offsetDateTime.getDayOfMonth() + ' ' + offsetDateTime.getHour() + ':' + offsetDateTime.getMinute() + ':' + offsetDateTime.getSecond();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  781 */             l = Timestamp.valueOf(str2).getTime();
/*      */             break;
/*      */ 
/*      */           
/*      */           case null:
/*  786 */             dateTimeOffset = (DateTimeOffset)param1Object;
/*      */             
/*  788 */             l = dateTimeOffset.getTimestamp().getTime();
/*  789 */             i = dateTimeOffset.getTimestamp().getNanos();
/*  790 */             j = dateTimeOffset.getMinutesOffset();
/*      */ 
/*      */ 
/*      */             
/*  794 */             assert null == param1DTV.getCalendar();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  801 */             timeZone = (JDBCType.DATETIMEOFFSET == jDBCType && (null == this.typeInfo || SSType.DATETIMEOFFSET == this.typeInfo.getSSType() || SSType.VARBINARY == this.typeInfo.getSSType() || SSType.VARBINARYMAX == this.typeInfo.getSSType())) ? UTC.timeZone : new SimpleTimeZone(j * 60 * 1000, "");
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/*  812 */             throw new AssertionError("Unexpected JavaType: " + param1JavaType);
/*      */         } 
/*      */ 
/*      */         
/*  816 */         if (null == gregorianCalendar) {
/*      */ 
/*      */ 
/*      */           
/*  820 */           gregorianCalendar = new GregorianCalendar(timeZone, Locale.US);
/*      */ 
/*      */ 
/*      */           
/*  824 */           gregorianCalendar.setLenient(true);
/*      */ 
/*      */ 
/*      */           
/*  828 */           gregorianCalendar.clear();
/*      */ 
/*      */           
/*  831 */           gregorianCalendar.setTimeInMillis(l);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  839 */       if (null != this.typeInfo) {
/*      */         
/*  841 */         switch (this.typeInfo.getSSType()) {
/*      */ 
/*      */           
/*      */           case DATETIME2:
/*  845 */             this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.typeInfo.getScale(), this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATE:
/*  855 */             this.tdsWriter.writeRPCDate(this.name, gregorianCalendar, this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case TIME:
/*  864 */             this.tdsWriter.writeRPCTime(this.name, gregorianCalendar, i, this.typeInfo.getScale(), this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIMEOFFSET:
/*  877 */             if (JavaType.DATETIMEOFFSET != param1JavaType) {
/*      */               
/*  879 */               gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  885 */               j = 0;
/*      */             } 
/*      */             
/*  888 */             this.tdsWriter.writeRPCDateTimeOffset(this.name, gregorianCalendar, j, i, this.typeInfo.getScale(), this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME:
/*      */           case SMALLDATETIME:
/*  900 */             this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case VARBINARY:
/*      */           case VARBINARYMAX:
/*  909 */             switch (jDBCType) {
/*      */               
/*      */               case DATETIME2:
/*      */               case DATE:
/*  913 */                 this.tdsWriter.writeEncryptedRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.isOutParam, jDBCType);
/*      */                 return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case TIME:
/*  922 */                 assert null != DTV.this.cryptoMeta;
/*  923 */                 this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, DTV.this.valueLength, this.isOutParam);
/*      */                 return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case DATETIMEOFFSET:
/*  933 */                 assert null != DTV.this.cryptoMeta;
/*  934 */                 this.tdsWriter.writeEncryptedRPCTime(this.name, gregorianCalendar, i, DTV.this.valueLength, this.isOutParam);
/*      */                 return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case DATETIME:
/*  942 */                 assert null != DTV.this.cryptoMeta;
/*  943 */                 this.tdsWriter.writeEncryptedRPCDate(this.name, gregorianCalendar, this.isOutParam);
/*      */                 return;
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case SMALLDATETIME:
/*      */               case VARBINARY:
/*  951 */                 if (JavaType.DATETIMEOFFSET != param1JavaType && JavaType.OFFSETDATETIME != param1JavaType) {
/*      */ 
/*      */                   
/*  954 */                   gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/*  960 */                   j = 0;
/*      */                 } 
/*      */                 
/*  963 */                 assert null != DTV.this.cryptoMeta;
/*  964 */                 this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, gregorianCalendar, j, i, DTV.this.valueLength, this.isOutParam);
/*      */                 return;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  974 */             assert false : "Unexpected JDBCType: " + jDBCType;
/*      */             return;
/*      */         } 
/*      */ 
/*      */         
/*  979 */         assert false : "Unexpected SSType: " + this.typeInfo.getSSType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  993 */       else if (this.conn.isKatmaiOrLater()) {
/*      */         
/*  995 */         if (DTV.aeLogger.isLoggable(Level.FINE) && null != DTV.this.cryptoMeta)
/*      */         {
/*  997 */           DTV.aeLogger.fine("Encrypting temporal data type.");
/*      */         }
/*      */         
/* 1000 */         switch (jDBCType) {
/*      */           
/*      */           case DATETIME2:
/*      */           case DATE:
/*      */           case TIME:
/* 1005 */             if (null != DTV.this.cryptoMeta) {
/*      */               
/* 1007 */               if (JDBCType.DATETIME == jDBCType || JDBCType.SMALLDATETIME == jDBCType)
/*      */               {
/* 1009 */                 this.tdsWriter.writeEncryptedRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.isOutParam, jDBCType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               }
/* 1016 */               else if (0 == DTV.this.valueLength)
/*      */               {
/* 1018 */                 this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, this.outScale, this.isOutParam);
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*      */               else
/*      */               {
/*      */ 
/*      */                 
/* 1027 */                 this.tdsWriter.writeEncryptedRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, DTV.this.valueLength, this.isOutParam);
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 1036 */               this.tdsWriter.writeRPCDateTime2(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, this.conn.baseYear()), i, 7, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIMEOFFSET:
/* 1047 */             if (null != DTV.this.cryptoMeta) {
/*      */               
/* 1049 */               if (0 == DTV.this.valueLength) {
/* 1050 */                 this.tdsWriter.writeEncryptedRPCTime(this.name, gregorianCalendar, i, this.outScale, this.isOutParam);
/*      */ 
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */                 
/* 1057 */                 this.tdsWriter.writeEncryptedRPCTime(this.name, gregorianCalendar, i, DTV.this.valueLength, this.isOutParam);
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 1067 */             else if (this.conn.getSendTimeAsDatetime()) {
/*      */               
/* 1069 */               this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, JavaType.TIME, 1970), i, this.isOutParam);
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 1076 */               this.tdsWriter.writeRPCTime(this.name, gregorianCalendar, i, 7, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATETIME:
/* 1088 */             if (null != DTV.this.cryptoMeta) {
/* 1089 */               this.tdsWriter.writeEncryptedRPCDate(this.name, gregorianCalendar, this.isOutParam);
/*      */             } else {
/* 1091 */               this.tdsWriter.writeRPCDate(this.name, gregorianCalendar, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case VARBINARYMAX:
/* 1102 */             if (JavaType.OFFSETDATETIME != param1JavaType && JavaType.OFFSETTIME != param1JavaType) {
/*      */ 
/*      */               
/* 1105 */               gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1111 */               j = 0;
/*      */             } 
/*      */             
/* 1114 */             this.tdsWriter.writeRPCDateTimeOffset(this.name, gregorianCalendar, j, i, 7, this.isOutParam);
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case SMALLDATETIME:
/*      */           case VARBINARY:
/* 1129 */             if (JavaType.DATETIMEOFFSET != param1JavaType && JavaType.OFFSETDATETIME != param1JavaType) {
/*      */ 
/*      */               
/* 1132 */               gregorianCalendar = timestampNormalizedCalendar(localCalendarAsUTC(gregorianCalendar), param1JavaType, this.conn.baseYear());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1138 */               j = 0;
/*      */             } 
/*      */             
/* 1141 */             if (null != DTV.this.cryptoMeta) {
/*      */               
/* 1143 */               if (0 == DTV.this.valueLength) {
/* 1144 */                 this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, gregorianCalendar, j, i, this.outScale, this.isOutParam);
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */ 
/*      */                 
/* 1153 */                 this.tdsWriter.writeEncryptedRPCDateTimeOffset(this.name, gregorianCalendar, j, i, (0 == DTV.this.valueLength) ? 7 : DTV.this.valueLength, this.isOutParam);
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 1163 */               this.tdsWriter.writeRPCDateTimeOffset(this.name, gregorianCalendar, j, i, 7, this.isOutParam);
/*      */             } 
/*      */             return;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1174 */         assert false : "Unexpected JDBCType: " + jDBCType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1193 */         assert JDBCType.TIME == jDBCType || JDBCType.DATE == jDBCType || JDBCType.TIMESTAMP == jDBCType : "Unexpected JDBCType: " + jDBCType;
/*      */         
/* 1195 */         this.tdsWriter.writeRPCDateTime(this.name, timestampNormalizedCalendar(gregorianCalendar, param1JavaType, 1970), i, this.isOutParam);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private GregorianCalendar timestampNormalizedCalendar(GregorianCalendar param1GregorianCalendar, JavaType param1JavaType, int param1Int) {
/* 1222 */       if (null != param1GregorianCalendar)
/*      */       {
/* 1224 */         switch (param1JavaType) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case DATE:
/*      */           case SMALLDATETIME:
/* 1231 */             param1GregorianCalendar.set(11, 0);
/* 1232 */             param1GregorianCalendar.set(12, 0);
/* 1233 */             param1GregorianCalendar.set(13, 0);
/* 1234 */             param1GregorianCalendar.set(14, 0);
/*      */             break;
/*      */           
/*      */           case DATETIME2:
/*      */           case VARBINARY:
/*      */           case null:
/* 1240 */             assert 1970 == param1Int || 1900 == param1Int;
/* 1241 */             param1GregorianCalendar.set(param1Int, 0, 1);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1249 */       return param1GregorianCalendar;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private GregorianCalendar localCalendarAsUTC(GregorianCalendar param1GregorianCalendar) {
/* 1260 */       if (null == param1GregorianCalendar) {
/* 1261 */         return null;
/*      */       }
/*      */       
/* 1264 */       int i = param1GregorianCalendar.get(1);
/* 1265 */       int j = param1GregorianCalendar.get(2);
/* 1266 */       int k = param1GregorianCalendar.get(5);
/* 1267 */       int m = param1GregorianCalendar.get(11);
/* 1268 */       int n = param1GregorianCalendar.get(12);
/* 1269 */       int i1 = param1GregorianCalendar.get(13);
/* 1270 */       int i2 = param1GregorianCalendar.get(14);
/*      */       
/* 1272 */       param1GregorianCalendar.setTimeZone(UTC.timeZone);
/* 1273 */       param1GregorianCalendar.set(i, j, k, m, n, i1);
/* 1274 */       param1GregorianCalendar.set(14, i2);
/* 1275 */       return param1GregorianCalendar;
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Float param1Float) throws SQLServerException {
/* 1280 */       if (JDBCType.REAL == param1DTV.getJdbcType()) {
/*      */         
/* 1282 */         this.tdsWriter.writeRPCReal(this.name, param1Float, this.isOutParam);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1292 */         Double double_ = (null == param1Float) ? null : new Double(param1Float.floatValue());
/* 1293 */         this.tdsWriter.writeRPCDouble(this.name, double_, this.isOutParam);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Double param1Double) throws SQLServerException {
/* 1299 */       this.tdsWriter.writeRPCDouble(this.name, param1Double, this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, BigDecimal param1BigDecimal) throws SQLServerException {
/* 1304 */       if (DDC.exceedsMaxRPCDecimalPrecisionOrScale(param1BigDecimal)) {
/*      */         
/* 1306 */         String str = param1BigDecimal.toString();
/* 1307 */         this.tdsWriter.writeRPCStringUnicode(this.name, str, this.isOutParam, this.collation);
/*      */       }
/*      */       else {
/*      */         
/* 1311 */         this.tdsWriter.writeRPCBigDecimal(this.name, param1BigDecimal, this.outScale, this.isOutParam);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Long param1Long) throws SQLServerException {
/* 1321 */       this.tdsWriter.writeRPCLong(this.name, param1Long, this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, BigInteger param1BigInteger) throws SQLServerException {
/* 1326 */       this.tdsWriter.writeRPCLong(this.name, Long.valueOf(param1BigInteger.longValue()), this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Short param1Short) throws SQLServerException {
/* 1331 */       this.tdsWriter.writeRPCShort(this.name, param1Short, this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Boolean param1Boolean) throws SQLServerException {
/* 1336 */       this.tdsWriter.writeRPCBit(this.name, param1Boolean, this.isOutParam);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, byte[] param1ArrayOfbyte) throws SQLServerException {
/* 1341 */       if (null != DTV.this.cryptoMeta) {
/*      */         
/* 1343 */         this.tdsWriter.writeRPCNameValType(this.name, this.isOutParam, TDSType.BIGVARBINARY);
/* 1344 */         if (null != param1ArrayOfbyte)
/*      */         {
/* 1346 */           param1ArrayOfbyte = SQLServerSecurityUtility.encryptWithKey(param1ArrayOfbyte, DTV.this.cryptoMeta, this.conn);
/* 1347 */           this.tdsWriter.writeEncryptedRPCByteArray(param1ArrayOfbyte);
/* 1348 */           writeEncryptData(param1DTV, false);
/*      */         }
/*      */         else
/*      */         {
/* 1352 */           this.tdsWriter.writeEncryptedRPCByteArray(param1ArrayOfbyte);
/* 1353 */           writeEncryptData(param1DTV, true);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1358 */         this.tdsWriter.writeRPCByteArray(this.name, param1ArrayOfbyte, this.isOutParam, param1DTV.getJdbcType(), this.collation);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void writeEncryptData(DTV param1DTV, boolean param1Boolean) throws SQLServerException {
/*      */       MessageFormat messageFormat;
/* 1369 */       JDBCType jDBCType = (null == DTV.this.jdbcTypeSetByUser) ? param1DTV.getJdbcType() : DTV.this.jdbcTypeSetByUser;
/*      */       
/* 1371 */       switch (jDBCType.getIntValue()) {
/*      */         
/*      */         case 4:
/* 1374 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1375 */           this.tdsWriter.writeByte((byte)4);
/*      */           break;
/*      */         
/*      */         case -5:
/* 1379 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1380 */           this.tdsWriter.writeByte((byte)8);
/*      */           break;
/*      */         
/*      */         case -7:
/* 1384 */           this.tdsWriter.writeByte(TDSType.BITN.byteValue());
/* 1385 */           this.tdsWriter.writeByte((byte)1);
/*      */           break;
/*      */         
/*      */         case 5:
/* 1389 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1390 */           this.tdsWriter.writeByte((byte)2);
/*      */           break;
/*      */         
/*      */         case -6:
/* 1394 */           this.tdsWriter.writeByte(TDSType.INTN.byteValue());
/* 1395 */           this.tdsWriter.writeByte((byte)1);
/*      */           break;
/*      */         
/*      */         case 8:
/* 1399 */           this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1400 */           this.tdsWriter.writeByte((byte)8);
/*      */           break;
/*      */         
/*      */         case 7:
/* 1404 */           this.tdsWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1405 */           this.tdsWriter.writeByte((byte)4);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -148:
/*      */         case -146:
/*      */         case 2:
/*      */         case 3:
/* 1413 */           if (JDBCType.MONEY == jDBCType || JDBCType.SMALLMONEY == jDBCType) {
/*      */             
/* 1415 */             this.tdsWriter.writeByte(TDSType.MONEYN.byteValue());
/* 1416 */             this.tdsWriter.writeByte((byte)((JDBCType.MONEY == jDBCType) ? 8 : 4));
/*      */             
/*      */             break;
/*      */           } 
/* 1420 */           this.tdsWriter.writeByte(TDSType.NUMERICN.byteValue());
/* 1421 */           if (param1Boolean) {
/* 1422 */             this.tdsWriter.writeByte((byte)17);
/*      */             
/* 1424 */             if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
/* 1425 */               this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision()));
/*      */             } else {
/*      */               
/* 1428 */               this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 18));
/*      */             } 
/*      */             
/* 1431 */             this.tdsWriter.writeByte((byte)((0 != this.outScale) ? this.outScale : 0));
/*      */             
/*      */             break;
/*      */           } 
/* 1435 */           this.tdsWriter.writeByte((byte)17);
/*      */           
/* 1437 */           if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
/* 1438 */             this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getPrecision());
/*      */           } else {
/*      */             
/* 1441 */             this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 18));
/*      */           } 
/*      */           
/* 1444 */           if (null != DTV.this.cryptoMeta && null != DTV.this.cryptoMeta.getBaseTypeInfo()) {
/* 1445 */             this.tdsWriter.writeByte((byte)DTV.this.cryptoMeta.getBaseTypeInfo().getScale());
/*      */             break;
/*      */           } 
/* 1448 */           this.tdsWriter.writeByte((byte)((null != param1DTV.getScale()) ? param1DTV.getScale().intValue() : 0));
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -145:
/* 1455 */           this.tdsWriter.writeByte(TDSType.GUID.byteValue());
/* 1456 */           if (param1Boolean) {
/* 1457 */             this.tdsWriter.writeByte((byte)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1)); break;
/*      */           } 
/* 1459 */           this.tdsWriter.writeByte((byte)16);
/*      */           break;
/*      */ 
/*      */         
/*      */         case 1:
/* 1464 */           this.tdsWriter.writeByte(TDSType.BIGCHAR.byteValue());
/*      */           
/* 1466 */           if (param1Boolean) {
/* 1467 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
/*      */           } else {
/* 1469 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/* 1471 */           if (null != this.collation) {
/* 1472 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1474 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */         
/*      */         case -15:
/* 1478 */           this.tdsWriter.writeByte(TDSType.NCHAR.byteValue());
/* 1479 */           if (param1Boolean) {
/* 1480 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? (DTV.this.valueLength * 2) : 1));
/*      */           }
/* 1482 */           else if (this.isOutParam) {
/* 1483 */             this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
/*      */           } else {
/*      */             
/* 1486 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/*      */           
/* 1489 */           if (null != this.collation) {
/* 1490 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1492 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -1:
/*      */         case 12:
/* 1498 */           this.tdsWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1499 */           if (param1Boolean) {
/* 1500 */             if (param1DTV.jdbcTypeSetByUser.getIntValue() == -1) {
/* 1501 */               this.tdsWriter.writeShort((short)-1);
/*      */             } else {
/*      */               
/* 1504 */               this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
/*      */             
/*      */             }
/*      */           
/*      */           }
/* 1509 */           else if (param1DTV.getJdbcType().getIntValue() == -1 || param1DTV.getJdbcType().getIntValue() == -16) {
/*      */ 
/*      */ 
/*      */             
/* 1513 */             this.tdsWriter.writeShort((short)1);
/*      */           
/*      */           }
/* 1516 */           else if (param1DTV.jdbcTypeSetByUser.getIntValue() == -1) {
/* 1517 */             this.tdsWriter.writeShort((short)-1);
/*      */           } else {
/*      */             
/* 1520 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1525 */           if (null != this.collation) {
/* 1526 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1528 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */         
/*      */         case -16:
/*      */         case -9:
/* 1533 */           this.tdsWriter.writeByte(TDSType.NVARCHAR.byteValue());
/* 1534 */           if (param1Boolean) {
/* 1535 */             if (param1DTV.jdbcTypeSetByUser.getIntValue() == -16) {
/* 1536 */               this.tdsWriter.writeShort((short)-1);
/*      */             } else {
/*      */               
/* 1539 */               this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? (DTV.this.valueLength * 2) : 1));
/*      */             }
/*      */           
/*      */           }
/* 1543 */           else if (this.isOutParam) {
/*      */ 
/*      */ 
/*      */             
/* 1547 */             if (param1DTV.jdbcTypeSetByUser.getIntValue() == -16) {
/* 1548 */               this.tdsWriter.writeShort((short)-1);
/*      */             } else {
/*      */               
/* 1551 */               this.tdsWriter.writeShort((short)(DTV.this.valueLength * 2));
/*      */             } 
/*      */           } else {
/*      */             
/* 1555 */             this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           } 
/*      */ 
/*      */           
/* 1559 */           if (null != this.collation) {
/* 1560 */             this.collation.writeCollation(this.tdsWriter); break;
/*      */           } 
/* 1562 */           this.conn.getDatabaseCollation().writeCollation(this.tdsWriter);
/*      */           break;
/*      */         
/*      */         case -2:
/* 1566 */           this.tdsWriter.writeByte(TDSType.BIGBINARY.byteValue());
/* 1567 */           if (param1Boolean) {
/* 1568 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1)); break;
/*      */           } 
/* 1570 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           break;
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/* 1576 */           this.tdsWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
/* 1577 */           if (param1Boolean) {
/* 1578 */             if (param1DTV.jdbcTypeSetByUser.getIntValue() == -4) {
/* 1579 */               this.tdsWriter.writeShort((short)-1);
/*      */               break;
/*      */             } 
/* 1582 */             this.tdsWriter.writeShort((short)((0 != DTV.this.valueLength) ? DTV.this.valueLength : 1));
/*      */             
/*      */             break;
/*      */           } 
/* 1586 */           if (param1DTV.jdbcTypeSetByUser.getIntValue() == -4) {
/* 1587 */             this.tdsWriter.writeShort((short)-1);
/*      */             break;
/*      */           } 
/* 1590 */           this.tdsWriter.writeShort((short)DTV.this.valueLength);
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1595 */           messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 1596 */           throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
/*      */       } 
/*      */       
/* 1599 */       this.tdsWriter.writeCryptoMetaData();
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Blob param1Blob) throws SQLServerException {
/* 1604 */       assert null != param1Blob;
/*      */       
/* 1606 */       long l = 0L;
/* 1607 */       InputStream inputStream = null;
/*      */ 
/*      */       
/*      */       try {
/* 1611 */         l = DataTypes.getCheckedLength(this.conn, param1DTV.getJdbcType(), param1Blob.length(), false);
/* 1612 */         inputStream = param1Blob.getBinaryStream();
/*      */       }
/* 1614 */       catch (SQLException sQLException) {
/*      */         
/* 1616 */         SQLServerException.makeFromDriverError(this.conn, null, sQLException.getMessage(), null, false);
/*      */       } 
/*      */       
/* 1619 */       if (null == inputStream) {
/*      */         
/* 1621 */         this.tdsWriter.writeRPCByteArray(this.name, null, this.isOutParam, param1DTV.getJdbcType(), this.collation);
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 1630 */         this.tdsWriter.writeRPCInputStream(this.name, inputStream, l, this.isOutParam, param1DTV.getJdbcType(), this.collation);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, SQLServerSQLXML param1SQLServerSQLXML) throws SQLServerException {
/* 1642 */       InputStream inputStream = (null == param1SQLServerSQLXML) ? null : param1SQLServerSQLXML.getValue();
/* 1643 */       this.tdsWriter.writeRPCXML(this.name, inputStream, (null == inputStream) ? 0L : param1DTV.getStreamSetterArgs().getLength(), this.isOutParam);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, InputStream param1InputStream) throws SQLServerException {
/* 1651 */       this.tdsWriter.writeRPCInputStream(this.name, param1InputStream, (null == param1InputStream) ? 0L : param1DTV.getStreamSetterArgs().getLength(), this.isOutParam, param1DTV.getJdbcType(), this.collation);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Reader param1Reader) throws SQLServerException {
/* 1662 */       JDBCType jDBCType = param1DTV.getJdbcType();
/*      */ 
/*      */       
/* 1665 */       assert null != param1Reader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1672 */       assert JDBCType.NCHAR == jDBCType || JDBCType.NVARCHAR == jDBCType || JDBCType.LONGNVARCHAR == jDBCType || JDBCType.NCLOB == jDBCType : "SendByRPCOp(Reader): Unexpected JDBC type " + jDBCType;
/*      */ 
/*      */       
/* 1675 */       this.tdsWriter.writeRPCReaderUnicode(this.name, param1Reader, param1DTV.getStreamSetterArgs().getLength(), this.isOutParam, this.collation);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void executeOp(DTVExecuteOp paramDTVExecuteOp) throws SQLServerException {
/* 1691 */     JDBCType jDBCType = getJdbcType();
/* 1692 */     Object object = getSetterValue();
/* 1693 */     JavaType javaType = getJavaType();
/* 1694 */     boolean bool = false;
/* 1695 */     byte[] arrayOfByte = null;
/*      */     
/* 1697 */     if (null != this.cryptoMeta && !JavaType.SetterConversionAE.converts(javaType, jDBCType)) {
/*      */       
/* 1699 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
/* 1700 */       Object[] arrayOfObject = { javaType.toString().toLowerCase(Locale.ENGLISH), jDBCType.toString().toLowerCase(Locale.ENGLISH) };
/* 1701 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */     } 
/*      */     
/* 1704 */     if (null == object) {
/*      */ 
/*      */       
/* 1707 */       switch (jDBCType) {
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1713 */           if (null != this.cryptoMeta) {
/* 1714 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1716 */           paramDTVExecuteOp.execute(this, (String)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1720 */           if (null != this.cryptoMeta) {
/* 1721 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1723 */           paramDTVExecuteOp.execute(this, (Integer)null);
/*      */           break;
/*      */         
/*      */         case DATETIME:
/* 1727 */           paramDTVExecuteOp.execute(this, (Date)null);
/*      */           break;
/*      */         
/*      */         case DATETIMEOFFSET:
/* 1731 */           paramDTVExecuteOp.execute(this, (Time)null);
/*      */           break;
/*      */         
/*      */         case DATETIME2:
/*      */         case DATE:
/*      */         case TIME:
/* 1737 */           paramDTVExecuteOp.execute(this, (Timestamp)null);
/*      */           break;
/*      */         
/*      */         case SMALLDATETIME:
/*      */         case VARBINARY:
/*      */         case VARBINARYMAX:
/* 1743 */           paramDTVExecuteOp.execute(this, (DateTimeOffset)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/* 1748 */           if (null != this.cryptoMeta) {
/* 1749 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1751 */           paramDTVExecuteOp.execute(this, (Float)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1758 */           if (null != this.cryptoMeta) {
/* 1759 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1761 */           paramDTVExecuteOp.execute(this, (BigDecimal)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1773 */           if (null != this.cryptoMeta) {
/* 1774 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1776 */           paramDTVExecuteOp.execute(this, (byte[])null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1780 */           if (null != this.cryptoMeta) {
/* 1781 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1783 */           paramDTVExecuteOp.execute(this, (Byte)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1787 */           if (null != this.cryptoMeta) {
/* 1788 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1790 */           paramDTVExecuteOp.execute(this, (Long)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1794 */           if (null != this.cryptoMeta) {
/* 1795 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1797 */           paramDTVExecuteOp.execute(this, (Double)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1801 */           if (null != this.cryptoMeta) {
/* 1802 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1804 */           paramDTVExecuteOp.execute(this, (Short)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/* 1809 */           if (null != this.cryptoMeta) {
/* 1810 */             paramDTVExecuteOp.execute(this, (byte[])null); break;
/*      */           } 
/* 1812 */           paramDTVExecuteOp.execute(this, (Boolean)null);
/*      */           break;
/*      */         
/*      */         case null:
/* 1816 */           paramDTVExecuteOp.execute(this, (SQLServerSQLXML)null);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/* 1828 */           bool = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         default:
/* 1833 */           assert false : "Unexpected JDBCType: " + jDBCType;
/* 1834 */           bool = true;
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     } else {
/* 1840 */       if (aeLogger.isLoggable(Level.FINE) && null != this.cryptoMeta)
/*      */       {
/* 1842 */         aeLogger.fine("Encrypting java data type: " + javaType);
/*      */       }
/*      */       
/* 1845 */       switch (javaType) {
/*      */         
/*      */         case null:
/* 1848 */           if (JDBCType.GUID == jDBCType) {
/*      */             
/* 1850 */             if (object instanceof String)
/* 1851 */               object = UUID.fromString((String)object); 
/* 1852 */             byte[] arrayOfByte1 = Util.asGuidByteArray((UUID)object);
/* 1853 */             paramDTVExecuteOp.execute(this, arrayOfByte1);
/*      */             break;
/*      */           } 
/* 1856 */           if (null != this.cryptoMeta) {
/*      */ 
/*      */ 
/*      */             
/* 1860 */             if (jDBCType == JDBCType.LONGNVARCHAR && JDBCType.VARCHAR == this.jdbcTypeSetByUser && Integer.MAX_VALUE < this.valueLength) {
/*      */ 
/*      */ 
/*      */               
/* 1864 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1865 */               Object[] arrayOfObject = { Integer.valueOf(2147483647), JDBCType.LONGVARCHAR };
/* 1866 */               throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */             } 
/* 1868 */             if (JDBCType.NVARCHAR == this.jdbcTypeSetByUser && 1073741823 < this.valueLength) {
/*      */ 
/*      */               
/* 1871 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 1872 */               Object[] arrayOfObject = { Integer.valueOf(1073741823), JDBCType.LONGNVARCHAR };
/* 1873 */               throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */             } 
/*      */             
/* 1876 */             if (JDBCType.NVARCHAR == this.jdbcTypeSetByUser || JDBCType.NCHAR == this.jdbcTypeSetByUser || JDBCType.LONGNVARCHAR == this.jdbcTypeSetByUser) {
/*      */               
/* 1878 */               arrayOfByte = ((String)object).getBytes(Charset.forName("UTF-16LE"));
/*      */             
/*      */             }
/* 1881 */             else if (JDBCType.VARCHAR == this.jdbcTypeSetByUser || JDBCType.CHAR == this.jdbcTypeSetByUser || JDBCType.LONGVARCHAR == this.jdbcTypeSetByUser) {
/*      */               
/* 1883 */               arrayOfByte = ((String)object).getBytes();
/*      */             } 
/*      */             
/* 1886 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 1889 */           paramDTVExecuteOp.execute(this, (String)object);
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/* 1894 */           if (null != this.cryptoMeta) {
/*      */             
/* 1896 */             arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Integer)object).longValue()).array();
/* 1897 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 1900 */           paramDTVExecuteOp.execute(this, (Integer)object);
/*      */           break;
/*      */         
/*      */         case DATE:
/* 1904 */           paramDTVExecuteOp.execute(this, (Date)object);
/*      */           break;
/*      */         
/*      */         case DATETIME2:
/* 1908 */           paramDTVExecuteOp.execute(this, (Time)object);
/*      */           break;
/*      */         
/*      */         case TIME:
/* 1912 */           if (JDBCType.SMALLDATETIME == jDBCType) {
/*      */             
/* 1914 */             Timestamp timestamp = (Timestamp)object;
/* 1915 */             if (timestamp.after(TDS.MAX_TIMESTAMP) || timestamp.before(TDS.MIN_TIMESTAMP)) {
/*      */               
/* 1917 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1918 */               throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
/*      */             } 
/*      */           } 
/* 1921 */           paramDTVExecuteOp.execute(this, (Timestamp)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 1925 */           paramDTVExecuteOp.execute(this, (TVP)object);
/*      */           break;
/*      */         
/*      */         case DATETIMEOFFSET:
/* 1929 */           paramDTVExecuteOp.execute(this, (Date)object);
/*      */           break;
/*      */         
/*      */         case DATETIME:
/* 1933 */           paramDTVExecuteOp.execute(this, (Calendar)object);
/*      */           break;
/*      */         
/*      */         case SMALLDATETIME:
/* 1937 */           paramDTVExecuteOp.execute(this, (LocalDate)object);
/*      */           break;
/*      */         
/*      */         case VARBINARY:
/* 1941 */           paramDTVExecuteOp.execute(this, (LocalTime)object);
/*      */           break;
/*      */         
/*      */         case VARBINARYMAX:
/* 1945 */           paramDTVExecuteOp.execute(this, (LocalDateTime)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 1949 */           paramDTVExecuteOp.execute(this, (OffsetTime)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 1953 */           paramDTVExecuteOp.execute(this, (OffsetDateTime)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 1957 */           paramDTVExecuteOp.execute(this, (DateTimeOffset)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 1961 */           if (null != this.cryptoMeta) {
/*      */             
/* 1963 */             if (Float.isInfinite(((Float)object).floatValue())) {
/*      */               
/* 1965 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 1966 */               throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
/*      */             } 
/*      */             
/* 1969 */             arrayOfByte = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(((Float)object).floatValue()).array();
/* 1970 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 1973 */           paramDTVExecuteOp.execute(this, (Float)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 1977 */           if (null != this.cryptoMeta) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1983 */             if (JDBCType.MONEY == jDBCType || JDBCType.SMALLMONEY == jDBCType) {
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1988 */               BigDecimal bigDecimal1 = (BigDecimal)object;
/*      */               
/* 1990 */               Util.validateMoneyRange(bigDecimal1, jDBCType);
/*      */ 
/*      */ 
/*      */               
/* 1994 */               int i = Math.max(bigDecimal1.precision() - bigDecimal1.scale(), 0) + 4;
/*      */               
/* 1996 */               long l = ((BigDecimal)object).multiply(new BigDecimal(10000), new MathContext(i, RoundingMode.HALF_UP)).longValue();
/* 1997 */               ByteBuffer byteBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/* 1998 */               byteBuffer.putInt((int)(l >> 32L)).array();
/* 1999 */               byteBuffer.putInt((int)l).array();
/* 2000 */               paramDTVExecuteOp.execute(this, byteBuffer.array());
/*      */               
/*      */               break;
/*      */             } 
/* 2004 */             BigDecimal bigDecimal = (BigDecimal)object;
/* 2005 */             byte[] arrayOfByte1 = DDC.convertBigDecimalToBytes(bigDecimal, bigDecimal.scale());
/* 2006 */             arrayOfByte = new byte[16];
/*      */             
/* 2008 */             System.arraycopy(arrayOfByte1, 2, arrayOfByte, 0, arrayOfByte1.length - 2);
/* 2009 */             setScale(Integer.valueOf(bigDecimal.scale()));
/* 2010 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             
/*      */             break;
/*      */           } 
/* 2014 */           paramDTVExecuteOp.execute(this, (BigDecimal)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2018 */           if (null != this.cryptoMeta && Integer.MAX_VALUE < this.valueLength) {
/*      */             
/* 2020 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_StreamingDataTypeAE"));
/* 2021 */             Object[] arrayOfObject = { Integer.valueOf(2147483647), JDBCType.BINARY };
/* 2022 */             throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */           } 
/*      */           
/* 2025 */           paramDTVExecuteOp.execute(this, (byte[])object);
/*      */           break;
/*      */ 
/*      */         
/*      */         case null:
/* 2030 */           if (null != this.cryptoMeta) {
/*      */             
/* 2032 */             arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong((((Byte)object).byteValue() & 0xFF)).array();
/* 2033 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 2036 */           paramDTVExecuteOp.execute(this, (Byte)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2040 */           if (null != this.cryptoMeta) {
/*      */             
/* 2042 */             arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Long)object).longValue()).array();
/* 2043 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 2046 */           paramDTVExecuteOp.execute(this, (Long)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2050 */           paramDTVExecuteOp.execute(this, (BigInteger)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2054 */           if (null != this.cryptoMeta) {
/*      */             
/* 2056 */             if (Double.isInfinite(((Double)object).doubleValue())) {
/*      */               
/* 2058 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_valueOutOfRange"));
/* 2059 */               throw new SQLServerException(messageFormat.format(new Object[] { jDBCType }, ), null, 0, null);
/*      */             } 
/* 2061 */             arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(((Double)object).doubleValue()).array();
/* 2062 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 2065 */           paramDTVExecuteOp.execute(this, (Double)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2069 */           if (null != this.cryptoMeta) {
/*      */             
/* 2071 */             arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Short)object).shortValue()).array();
/* 2072 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 2075 */           paramDTVExecuteOp.execute(this, (Short)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2079 */           if (null != this.cryptoMeta) {
/*      */             
/* 2081 */             arrayOfByte = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(((Boolean)object).booleanValue() ? 1L : 0L).array();
/* 2082 */             paramDTVExecuteOp.execute(this, arrayOfByte);
/*      */             break;
/*      */           } 
/* 2085 */           paramDTVExecuteOp.execute(this, (Boolean)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2089 */           paramDTVExecuteOp.execute(this, (Blob)object);
/*      */           break;
/*      */         
/*      */         case null:
/*      */         case null:
/* 2094 */           paramDTVExecuteOp.execute(this, (Clob)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2098 */           paramDTVExecuteOp.execute(this, (InputStream)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2102 */           paramDTVExecuteOp.execute(this, (Reader)object);
/*      */           break;
/*      */         
/*      */         case null:
/* 2106 */           paramDTVExecuteOp.execute(this, (SQLServerSQLXML)object);
/*      */           break;
/*      */         
/*      */         default:
/* 2110 */           assert false : "Unexpected JavaType: " + javaType;
/* 2111 */           bool = true;
/*      */           break;
/*      */       } 
/*      */     
/*      */     } 
/* 2116 */     if (bool) {
/*      */       
/* 2118 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/* 2119 */       Object[] arrayOfObject = { javaType, jDBCType };
/* 2120 */       throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sendCryptoMetaData(CryptoMetadata paramCryptoMetadata, TDSWriter paramTDSWriter) {
/* 2130 */     this.cryptoMeta = paramCryptoMetadata;
/* 2131 */     paramTDSWriter.setCryptoMetaData(paramCryptoMetadata);
/*      */   }
/*      */ 
/*      */   
/*      */   void jdbcTypeSetByUser(JDBCType paramJDBCType, int paramInt) {
/* 2136 */     this.jdbcTypeSetByUser = paramJDBCType;
/* 2137 */     this.valueLength = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sendByRPC(String paramString, TypeInfo paramTypeInfo, SQLCollation paramSQLCollation, int paramInt1, int paramInt2, boolean paramBoolean, TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/* 2154 */     executeOp(new SendByRPCOp(paramString, paramTypeInfo, paramSQLCollation, paramInt1, paramInt2, paramBoolean, paramTDSWriter, paramSQLServerConnection));
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\DTV.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */