/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ public class SQLServerMetaData
/*     */ {
/*   7 */   String columnName = null;
/*     */   int javaSqlType;
/*   9 */   int precision = 0;
/*  10 */   int scale = 0;
/*     */   boolean useServerDefault = false;
/*     */   boolean isUniqueKey = false;
/*  13 */   SQLServerSortOrder sortOrder = SQLServerSortOrder.Unspecified;
/*     */ 
/*     */   
/*     */   int sortOrdinal;
/*     */   
/*     */   static final int defaultSortOrdinal = -1;
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String paramString, int paramInt) {
/*  22 */     this.columnName = paramString;
/*  23 */     this.javaSqlType = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String paramString, int paramInt1, int paramInt2, int paramInt3) {
/*  32 */     this.columnName = paramString;
/*  33 */     this.javaSqlType = paramInt1;
/*  34 */     this.precision = paramInt2;
/*  35 */     this.scale = paramInt3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(String paramString, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, SQLServerSortOrder paramSQLServerSortOrder, int paramInt4) throws SQLServerException {
/*  48 */     this.columnName = paramString;
/*  49 */     this.javaSqlType = paramInt1;
/*  50 */     this.precision = paramInt2;
/*  51 */     this.scale = paramInt3;
/*  52 */     this.useServerDefault = paramBoolean1;
/*  53 */     this.isUniqueKey = paramBoolean2;
/*  54 */     this.sortOrder = paramSQLServerSortOrder;
/*  55 */     this.sortOrdinal = paramInt4;
/*  56 */     validateSortOrder();
/*     */   }
/*     */ 
/*     */   
/*     */   public SQLServerMetaData(SQLServerMetaData paramSQLServerMetaData) {
/*  61 */     this.columnName = paramSQLServerMetaData.columnName;
/*  62 */     this.javaSqlType = paramSQLServerMetaData.javaSqlType;
/*  63 */     this.precision = paramSQLServerMetaData.precision;
/*  64 */     this.scale = paramSQLServerMetaData.scale;
/*  65 */     this.useServerDefault = paramSQLServerMetaData.useServerDefault;
/*  66 */     this.isUniqueKey = paramSQLServerMetaData.isUniqueKey;
/*  67 */     this.sortOrder = paramSQLServerMetaData.sortOrder;
/*  68 */     this.sortOrdinal = paramSQLServerMetaData.sortOrdinal;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumName() {
/*  73 */     return this.columnName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSqlType() {
/*  78 */     return this.javaSqlType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrecision() {
/*  83 */     return this.precision;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScale() {
/*  88 */     return this.scale;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean useServerDefault() {
/*  93 */     return this.useServerDefault;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isUniqueKey() {
/*  98 */     return this.isUniqueKey;
/*     */   }
/*     */ 
/*     */   
/*     */   public SQLServerSortOrder getSortOrder() {
/* 103 */     return this.sortOrder;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSortOrdinal() {
/* 108 */     return this.sortOrdinal;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void validateSortOrder() throws SQLServerException {
/* 114 */     if (((SQLServerSortOrder.Unspecified == this.sortOrder) ? true : false) != ((-1 == this.sortOrdinal) ? true : false)) {
/*     */       
/* 116 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrderOrOrdinal"));
/* 117 */       throw new SQLServerException(messageFormat.format(new Object[] { this.sortOrder, Integer.valueOf(this.sortOrdinal) }, ), null, 0, null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */