package com.microsoft.sqlserver.jdbc;

final class XAReturnValue {
  int nStatus;
  
  byte[] bData;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\XAReturnValue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */