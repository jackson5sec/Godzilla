/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamLoginAck
/*    */   extends StreamPacket
/*    */ {
/*    */   String sSQLServerVersion;
/*    */   int tdsVersion;
/*    */   
/*    */   StreamLoginAck() {
/* 18 */     super(173);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 23 */     if (173 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 24 */     paramTDSReader.readUnsignedShort();
/* 25 */     paramTDSReader.readUnsignedByte();
/* 26 */     this.tdsVersion = paramTDSReader.readIntBigEndian();
/* 27 */     paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 28 */     int i = paramTDSReader.readUnsignedByte();
/* 29 */     int j = paramTDSReader.readUnsignedByte();
/* 30 */     int k = paramTDSReader.readUnsignedByte() << 8 | paramTDSReader.readUnsignedByte();
/*    */     
/* 32 */     this.sSQLServerVersion = i + "." + ((j <= 9) ? "0" : "") + j + "." + k;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamLoginAck.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */