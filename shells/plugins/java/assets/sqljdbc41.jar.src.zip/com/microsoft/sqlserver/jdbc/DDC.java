/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.RoundingMode;
/*      */ import java.sql.Date;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class DDC
/*      */ {
/*      */   static final Object convertIntegerToObject(int paramInt1, int paramInt2, JDBCType paramJDBCType, StreamType paramStreamType) {
/*   33 */     switch (paramJDBCType) {
/*      */       
/*      */       case BINARY:
/*   36 */         return new Integer(paramInt1);
/*      */       case DATE:
/*      */       case TIME:
/*   39 */         return new Short((short)paramInt1);
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*   42 */         return new Boolean((0 != paramInt1));
/*      */       case CHARACTER:
/*   44 */         return new Long(paramInt1);
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*   49 */         return new BigDecimal(Integer.toString(paramInt1));
/*      */       case null:
/*      */       case null:
/*   52 */         return new Double(paramInt1);
/*      */       case null:
/*   54 */         return new Float(paramInt1);
/*      */       case null:
/*   56 */         return convertIntToBytes(paramInt1, paramInt2);
/*      */     } 
/*   58 */     return Integer.toString(paramInt1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertLongToObject(long paramLong, JDBCType paramJDBCType, SSType paramSSType, StreamType paramStreamType) {
/*      */     byte[] arrayOfByte1;
/*      */     byte b;
/*      */     byte[] arrayOfByte2;
/*   70 */     switch (paramJDBCType) {
/*      */       
/*      */       case CHARACTER:
/*   73 */         return new Long(paramLong);
/*      */       case BINARY:
/*   75 */         return new Integer((int)paramLong);
/*      */       case DATE:
/*      */       case TIME:
/*   78 */         return new Short((short)(int)paramLong);
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*   81 */         return new Boolean((0L != paramLong));
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*   86 */         return new BigDecimal(Long.toString(paramLong));
/*      */       case null:
/*      */       case null:
/*   89 */         return new Double(paramLong);
/*      */       case null:
/*   91 */         return new Float((float)paramLong);
/*      */       case null:
/*   93 */         arrayOfByte1 = convertLongToBytes(paramLong);
/*   94 */         b = 0;
/*      */ 
/*      */         
/*   97 */         switch (paramSSType) {
/*      */           case BINARY:
/*      */           case DATE:
/*  100 */             b = 1;
/*  101 */             arrayOfByte2 = new byte[b];
/*  102 */             System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
/*  103 */             return arrayOfByte2;
/*      */           case TIME:
/*  105 */             b = 2;
/*  106 */             arrayOfByte2 = new byte[b];
/*  107 */             System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
/*  108 */             return arrayOfByte2;
/*      */           case TIMESTAMP:
/*  110 */             b = 4;
/*  111 */             arrayOfByte2 = new byte[b];
/*  112 */             System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
/*  113 */             return arrayOfByte2;
/*      */           case DATETIMEOFFSET:
/*  115 */             b = 8;
/*  116 */             arrayOfByte2 = new byte[b];
/*  117 */             System.arraycopy(arrayOfByte1, arrayOfByte1.length - b, arrayOfByte2, 0, b);
/*  118 */             return arrayOfByte2;
/*      */         } 
/*  120 */         return arrayOfByte1;
/*      */ 
/*      */       
/*      */       case null:
/*  124 */         switch (paramSSType) {
/*      */           
/*      */           case DATETIMEOFFSET:
/*  127 */             return new Long(paramLong);
/*      */           case TIMESTAMP:
/*  129 */             return new Integer((int)paramLong);
/*      */           case DATE:
/*      */           case TIME:
/*  132 */             return new Short((short)(int)paramLong);
/*      */           case BINARY:
/*  134 */             return new Boolean((0L != paramLong));
/*      */           case CHARACTER:
/*      */           case null:
/*      */           case null:
/*      */           case null:
/*  139 */             return new BigDecimal(Long.toString(paramLong));
/*      */           case null:
/*  141 */             return new Double(paramLong);
/*      */           case null:
/*  143 */             return new Float((float)paramLong);
/*      */           case null:
/*  145 */             return convertLongToBytes(paramLong);
/*      */         } 
/*  147 */         return Long.toString(paramLong);
/*      */     } 
/*      */     
/*  150 */     return Long.toString(paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] convertIntToBytes(int paramInt1, int paramInt2) {
/*  162 */     byte[] arrayOfByte = new byte[paramInt2];
/*  163 */     for (int i = paramInt2; i-- > 0; ) {
/*      */       
/*  165 */       arrayOfByte[i] = (byte)(paramInt1 & 0xFF);
/*  166 */       paramInt1 >>= 8;
/*      */     } 
/*  168 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertFloatToObject(float paramFloat, JDBCType paramJDBCType, StreamType paramStreamType) {
/*  179 */     switch (paramJDBCType) {
/*      */       
/*      */       case null:
/*  182 */         return new Float(paramFloat);
/*      */       case BINARY:
/*  184 */         return new Integer((int)paramFloat);
/*      */       case DATE:
/*      */       case TIME:
/*  187 */         return new Short((short)(int)paramFloat);
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*  190 */         return new Boolean((0 != Float.compare(0.0F, paramFloat)));
/*      */       case CHARACTER:
/*  192 */         return new Long((long)paramFloat);
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  197 */         return new BigDecimal(Float.toString(paramFloat));
/*      */       case null:
/*      */       case null:
/*  200 */         return new Double((new Float(paramFloat)).doubleValue());
/*      */       case null:
/*  202 */         return convertIntToBytes(Float.floatToRawIntBits(paramFloat), 4);
/*      */     } 
/*  204 */     return Float.toString(paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] convertLongToBytes(long paramLong) {
/*  215 */     byte[] arrayOfByte = new byte[8];
/*  216 */     for (byte b = 8; b-- > 0; ) {
/*      */       
/*  218 */       arrayOfByte[b] = (byte)(int)(paramLong & 0xFFL);
/*  219 */       paramLong >>= 8L;
/*      */     } 
/*  221 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertDoubleToObject(double paramDouble, JDBCType paramJDBCType, StreamType paramStreamType) {
/*  232 */     switch (paramJDBCType) {
/*      */       
/*      */       case null:
/*      */       case null:
/*  236 */         return new Double(paramDouble);
/*      */       case null:
/*  238 */         return new Float((new Double(paramDouble)).floatValue());
/*      */       case BINARY:
/*  240 */         return new Integer((int)paramDouble);
/*      */       case DATE:
/*      */       case TIME:
/*  243 */         return new Short((short)(int)paramDouble);
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*  246 */         return new Boolean((0 != Double.compare(0.0D, paramDouble)));
/*      */       case CHARACTER:
/*  248 */         return new Long((long)paramDouble);
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  253 */         return new BigDecimal(Double.toString(paramDouble));
/*      */       case null:
/*  255 */         return convertLongToBytes(Double.doubleToRawLongBits(paramDouble));
/*      */     } 
/*  257 */     return Double.toString(paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] convertBigDecimalToBytes(BigDecimal paramBigDecimal, int paramInt) {
/*      */     byte[] arrayOfByte;
/*  265 */     if (paramBigDecimal == null) {
/*      */       
/*  267 */       arrayOfByte = new byte[2];
/*  268 */       arrayOfByte[0] = (byte)paramInt;
/*  269 */       arrayOfByte[1] = 0;
/*      */     }
/*      */     else {
/*      */       
/*  273 */       boolean bool = (paramBigDecimal.signum() < 0) ? true : false;
/*      */ 
/*      */       
/*  276 */       if (paramBigDecimal.scale() < 0) {
/*  277 */         paramBigDecimal = paramBigDecimal.setScale(0);
/*      */       }
/*  279 */       BigInteger bigInteger = paramBigDecimal.unscaledValue();
/*      */       
/*  281 */       if (bool) {
/*  282 */         bigInteger = bigInteger.negate();
/*      */       }
/*  284 */       byte[] arrayOfByte1 = bigInteger.toByteArray();
/*      */       
/*  286 */       arrayOfByte = new byte[arrayOfByte1.length + 3];
/*  287 */       byte b = 0;
/*  288 */       arrayOfByte[b++] = (byte)paramBigDecimal.scale();
/*  289 */       arrayOfByte[b++] = (byte)(arrayOfByte1.length + 1);
/*  290 */       arrayOfByte[b++] = (byte)(bool ? 0 : 1);
/*  291 */       for (int i = arrayOfByte1.length - 1; i >= 0; i--) {
/*  292 */         arrayOfByte[b++] = arrayOfByte1[i];
/*      */       }
/*      */     } 
/*  295 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertBigDecimalToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType) {
/*  306 */     switch (paramJDBCType) {
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  312 */         return paramBigDecimal;
/*      */       case null:
/*      */       case null:
/*  315 */         return new Double(paramBigDecimal.doubleValue());
/*      */       case null:
/*  317 */         return new Float(paramBigDecimal.floatValue());
/*      */       case BINARY:
/*  319 */         return new Integer(paramBigDecimal.intValue());
/*      */       case DATE:
/*      */       case TIME:
/*  322 */         return new Short(paramBigDecimal.shortValue());
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*  325 */         return new Boolean((0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L))));
/*      */       case CHARACTER:
/*  327 */         return new Long(paramBigDecimal.longValue());
/*      */       case null:
/*  329 */         return convertBigDecimalToBytes(paramBigDecimal, paramBigDecimal.scale());
/*      */     } 
/*  331 */     return paramBigDecimal.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertMoneyToObject(BigDecimal paramBigDecimal, JDBCType paramJDBCType, StreamType paramStreamType, int paramInt) {
/*  337 */     switch (paramJDBCType) {
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  343 */         return paramBigDecimal;
/*      */       case null:
/*      */       case null:
/*  346 */         return new Double(paramBigDecimal.doubleValue());
/*      */       case null:
/*  348 */         return new Float(paramBigDecimal.floatValue());
/*      */       case BINARY:
/*  350 */         return new Integer(paramBigDecimal.intValue());
/*      */       case DATE:
/*      */       case TIME:
/*  353 */         return new Short(paramBigDecimal.shortValue());
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*  356 */         return new Boolean((0 != paramBigDecimal.compareTo(BigDecimal.valueOf(0L))));
/*      */       case CHARACTER:
/*  358 */         return new Long(paramBigDecimal.longValue());
/*      */       case null:
/*  360 */         return convertToBytes(paramBigDecimal, paramBigDecimal.scale(), paramInt);
/*      */     } 
/*  362 */     return paramBigDecimal.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static byte[] convertToBytes(BigDecimal paramBigDecimal, int paramInt1, int paramInt2) {
/*  369 */     boolean bool = (paramBigDecimal.signum() < 0) ? true : false;
/*      */     
/*  371 */     paramBigDecimal = paramBigDecimal.setScale(paramInt1, RoundingMode.DOWN);
/*      */     
/*  373 */     BigInteger bigInteger = paramBigDecimal.unscaledValue();
/*      */     
/*  375 */     byte[] arrayOfByte1 = bigInteger.toByteArray();
/*      */     
/*  377 */     byte[] arrayOfByte2 = new byte[paramInt2];
/*  378 */     if (arrayOfByte1.length < paramInt2)
/*      */     {
/*  380 */       for (byte b = 0; b < paramInt2 - arrayOfByte1.length; b++)
/*      */       {
/*  382 */         arrayOfByte2[b] = (byte)(bool ? -1 : 0);
/*      */       }
/*      */     }
/*  385 */     int i = paramInt2 - arrayOfByte1.length;
/*  386 */     for (int j = i; j < paramInt2; j++)
/*      */     {
/*  388 */       arrayOfByte2[j] = arrayOfByte1[j - i];
/*      */     }
/*  390 */     return arrayOfByte2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertBytesToObject(byte[] paramArrayOfbyte, JDBCType paramJDBCType, TypeInfo paramTypeInfo) throws SQLServerException {
/*      */     String str;
/*  403 */     switch (paramJDBCType) {
/*      */       
/*      */       case null:
/*  406 */         str = Util.bytesToHexString(paramArrayOfbyte, paramArrayOfbyte.length);
/*      */         
/*  408 */         if (SSType.BINARY == paramTypeInfo.getSSType() && str.length() < paramTypeInfo.getPrecision() * 2) {
/*      */ 
/*      */           
/*  411 */           StringBuffer stringBuffer = new StringBuffer(str);
/*      */           
/*  413 */           while (stringBuffer.length() < paramTypeInfo.getPrecision() * 2) {
/*  414 */             stringBuffer.append('0');
/*      */           }
/*  416 */           return stringBuffer.toString();
/*      */         } 
/*  418 */         return str;
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  423 */         if (SSType.BINARY == paramTypeInfo.getSSType() && paramArrayOfbyte.length < paramTypeInfo.getPrecision()) {
/*      */ 
/*      */           
/*  426 */           byte[] arrayOfByte = new byte[paramTypeInfo.getPrecision()];
/*  427 */           System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramArrayOfbyte.length);
/*  428 */           return arrayOfByte;
/*      */         } 
/*      */         
/*  431 */         return paramArrayOfbyte;
/*      */     } 
/*      */     
/*  434 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionFromTo"));
/*  435 */     throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getSSType().name(), paramJDBCType }, ), null, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertStringToObject(String paramString1, String paramString2, JDBCType paramJDBCType, StreamType paramStreamType) throws UnsupportedEncodingException, IllegalArgumentException {
/*      */     String str;
/*      */     Timestamp timestamp;
/*      */     GregorianCalendar gregorianCalendar;
/*  451 */     switch (paramJDBCType) {
/*      */ 
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  458 */         return new BigDecimal(paramString1.trim());
/*      */       case null:
/*      */       case null:
/*  461 */         return Double.valueOf(paramString1.trim());
/*      */       case null:
/*  463 */         return Float.valueOf(paramString1.trim());
/*      */       case BINARY:
/*  465 */         return Integer.valueOf(paramString1.trim());
/*      */       case DATE:
/*      */       case TIME:
/*  468 */         return Short.valueOf(paramString1.trim());
/*      */       case TIMESTAMP:
/*      */       case DATETIMEOFFSET:
/*  471 */         str = paramString1.trim();
/*  472 */         return (1 == str.length()) ? Boolean.valueOf(('1' == str.charAt(0))) : Boolean.valueOf(str);
/*      */ 
/*      */       
/*      */       case CHARACTER:
/*  476 */         return Long.valueOf(paramString1.trim());
/*      */ 
/*      */       
/*      */       case null:
/*  480 */         return Timestamp.valueOf(paramString1.trim());
/*      */       case null:
/*  482 */         return Date.valueOf(getDatePart(paramString1.trim()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  493 */         timestamp = Timestamp.valueOf("1970-01-01 " + getTimePart(paramString1.trim()));
/*  494 */         gregorianCalendar = new GregorianCalendar(Locale.US);
/*  495 */         gregorianCalendar.clear();
/*  496 */         gregorianCalendar.setTimeInMillis(timestamp.getTime());
/*  497 */         if (timestamp.getNanos() % 1000000 >= 500000)
/*  498 */           gregorianCalendar.add(14, 1); 
/*  499 */         gregorianCalendar.set(1970, 0, 1);
/*  500 */         return new Time(gregorianCalendar.getTimeInMillis());
/*      */ 
/*      */       
/*      */       case null:
/*  504 */         return paramString1.getBytes(paramString2);
/*      */     } 
/*      */ 
/*      */     
/*  508 */     switch (paramStreamType) {
/*      */       
/*      */       case BINARY:
/*  511 */         return new StringReader(paramString1);
/*      */       case DATE:
/*  513 */         return new ByteArrayInputStream(paramString1.getBytes("US-ASCII"));
/*      */       case TIME:
/*  515 */         return new ByteArrayInputStream(paramString1.getBytes());
/*      */     } 
/*      */     
/*  518 */     return paramString1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertStreamToObject(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs) throws SQLServerException {
/*  531 */     if (null == paramBaseInputStream) {
/*  532 */       return null;
/*      */     }
/*  534 */     assert null != paramTypeInfo;
/*  535 */     assert null != paramInputStreamGetterArgs;
/*      */     
/*  537 */     SSType sSType = paramTypeInfo.getSSType();
/*      */ 
/*      */     
/*      */     try {
/*  541 */       switch (paramJDBCType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/*  554 */           if (SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.TIMESTAMP == sSType || SSType.IMAGE == sSType || SSType.UDT == sSType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  561 */             if (StreamType.ASCII == paramInputStreamGetterArgs.streamType)
/*      */             {
/*  563 */               return paramBaseInputStream;
/*      */             }
/*      */ 
/*      */             
/*  567 */             assert StreamType.CHARACTER == paramInputStreamGetterArgs.streamType || StreamType.NONE == paramInputStreamGetterArgs.streamType;
/*      */ 
/*      */             
/*  570 */             byte[] arrayOfByte = paramBaseInputStream.getBytes();
/*  571 */             if (JDBCType.GUID == paramJDBCType)
/*      */             {
/*  573 */               return Util.readGUID(arrayOfByte);
/*      */             }
/*      */ 
/*      */             
/*  577 */             String str = Util.bytesToHexString(arrayOfByte, arrayOfByte.length);
/*      */             
/*  579 */             if (StreamType.NONE == paramInputStreamGetterArgs.streamType) {
/*  580 */               return str;
/*      */             }
/*  582 */             return new StringReader(str);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  588 */           if (StreamType.ASCII == paramInputStreamGetterArgs.streamType) {
/*      */ 
/*      */             
/*  591 */             if (paramTypeInfo.supportsFastAsciiConversion()) {
/*  592 */               return new AsciiFilteredInputStream(paramBaseInputStream);
/*      */             }
/*      */             
/*  595 */             if (paramInputStreamGetterArgs.isAdaptive)
/*      */             {
/*  597 */               return AsciiFilteredUnicodeInputStream.MakeAsciiFilteredUnicodeInputStream(paramBaseInputStream, new BufferedReader(new InputStreamReader(paramBaseInputStream, paramTypeInfo.getCharset())));
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  603 */             return new ByteArrayInputStream((new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset())).getBytes("US-ASCII"));
/*      */           } 
/*      */           
/*  606 */           if (StreamType.CHARACTER == paramInputStreamGetterArgs.streamType || StreamType.NCHARACTER == paramInputStreamGetterArgs.streamType) {
/*      */ 
/*      */             
/*  609 */             if (paramInputStreamGetterArgs.isAdaptive) {
/*  610 */               return new BufferedReader(new InputStreamReader(paramBaseInputStream, paramTypeInfo.getCharset()));
/*      */             }
/*  612 */             return new StringReader(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()));
/*      */           } 
/*      */ 
/*      */           
/*  616 */           return convertStringToObject(new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getCharset(), paramJDBCType, paramInputStreamGetterArgs.streamType);
/*      */         
/*      */         case null:
/*  619 */           return new SQLServerClob(paramBaseInputStream, paramTypeInfo);
/*      */         
/*      */         case null:
/*  622 */           return new SQLServerNClob(paramBaseInputStream, paramTypeInfo);
/*      */         case null:
/*  624 */           return new SQLServerSQLXML(paramBaseInputStream, paramInputStreamGetterArgs, paramTypeInfo);
/*      */         
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */         case null:
/*      */           break;
/*      */       } 
/*      */       
/*  633 */       if (StreamType.BINARY == paramInputStreamGetterArgs.streamType) {
/*  634 */         return paramBaseInputStream;
/*      */       }
/*  636 */       if (JDBCType.BLOB == paramJDBCType) {
/*  637 */         return new SQLServerBlob(paramBaseInputStream);
/*      */       }
/*  639 */       return paramBaseInputStream.getBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  650 */     catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/*  652 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/*  653 */       throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getSSType(), paramJDBCType }, ), null, 0, illegalArgumentException);
/*      */     }
/*  655 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */       
/*  657 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/*  658 */       throw new SQLServerException(messageFormat.format(new Object[] { paramTypeInfo.getSSType(), paramJDBCType }, ), null, 0, unsupportedEncodingException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String getDatePart(String paramString) {
/*  666 */     int i = paramString.indexOf(' ');
/*  667 */     if (-1 == i) return paramString; 
/*  668 */     return paramString.substring(0, i);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String getTimePart(String paramString) {
/*  674 */     int i = paramString.indexOf(' ');
/*  675 */     if (-1 == i) return paramString; 
/*  676 */     return paramString.substring(i + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String fractionalSecondsString(long paramLong, int paramInt) {
/*  683 */     assert 0L <= paramLong && paramLong < 1000000000L;
/*  684 */     assert 0 <= paramInt && paramInt <= 7;
/*      */ 
/*      */ 
/*      */     
/*  688 */     if (0 == paramInt) {
/*  689 */       return "";
/*      */     }
/*  691 */     return BigDecimal.valueOf(paramLong % 1000000000L, 9).setScale(paramInt).toPlainString().substring(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Object convertTemporalToObject(JDBCType paramJDBCType, SSType paramSSType, Calendar paramCalendar, int paramInt1, long paramLong, int paramInt2) {
/*      */     Timestamp timestamp2;
/*      */     int k;
/*      */     Timestamp timestamp1;
/*      */     int j;
/*      */     Timestamp timestamp3;
/*      */     int m;
/*  759 */     TimeZone timeZone1 = (null != paramCalendar) ? paramCalendar.getTimeZone() : TimeZone.getDefault();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  768 */     TimeZone timeZone2 = (SSType.DATETIMEOFFSET == paramSSType) ? UTC.timeZone : timeZone1;
/*      */     
/*  770 */     int i = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  775 */     GregorianCalendar gregorianCalendar = new GregorianCalendar(timeZone2, Locale.US);
/*      */ 
/*      */ 
/*      */     
/*  779 */     gregorianCalendar.setLenient(true);
/*      */ 
/*      */ 
/*      */     
/*  783 */     gregorianCalendar.clear();
/*      */ 
/*      */ 
/*      */     
/*  787 */     switch (paramSSType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  801 */         gregorianCalendar.set(1900, 0, 1, 0, 0, 0);
/*  802 */         gregorianCalendar.set(14, (int)(paramLong / 1000000L));
/*      */         
/*  804 */         i = (int)(paramLong % 1000000000L);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*      */       case null:
/*      */       case null:
/*  818 */         if (paramInt1 >= GregorianChange.DAYS_SINCE_BASE_DATE_HINT) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  825 */           gregorianCalendar.set(1, 0, 1 + paramInt1 + GregorianChange.EXTRA_DAYS_TO_BE_ADDED, 0, 0, 0);
/*  826 */           gregorianCalendar.set(14, (int)(paramLong / 1000000L));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  840 */           gregorianCalendar.setGregorianChange(GregorianChange.PURE_CHANGE_DATE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  846 */           gregorianCalendar.set(1, 0, 1 + paramInt1, 0, 0, 0);
/*  847 */           gregorianCalendar.set(14, (int)(paramLong / 1000000L));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  852 */           int n = gregorianCalendar.get(1);
/*  853 */           int i1 = gregorianCalendar.get(2);
/*  854 */           int i2 = gregorianCalendar.get(5);
/*  855 */           int i3 = gregorianCalendar.get(11);
/*  856 */           int i4 = gregorianCalendar.get(12);
/*  857 */           int i5 = gregorianCalendar.get(13);
/*  858 */           int i6 = gregorianCalendar.get(14);
/*      */           
/*  860 */           gregorianCalendar.setGregorianChange(GregorianChange.STANDARD_CHANGE_DATE);
/*  861 */           gregorianCalendar.set(n, i1, i2, i3, i4, i5);
/*  862 */           gregorianCalendar.set(14, i6);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  871 */         if (SSType.DATETIMEOFFSET == paramSSType && !timeZone2.hasSameRules(timeZone1)) {
/*      */           
/*  873 */           GregorianCalendar gregorianCalendar1 = new GregorianCalendar(timeZone1, Locale.US);
/*  874 */           gregorianCalendar1.clear();
/*  875 */           gregorianCalendar1.setTimeInMillis(gregorianCalendar.getTimeInMillis());
/*  876 */           gregorianCalendar = gregorianCalendar1;
/*      */         } 
/*      */         
/*  879 */         i = (int)(paramLong % 1000000000L);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case null:
/*  894 */         gregorianCalendar.set(1900, 0, 1 + paramInt1, 0, 0, 0);
/*  895 */         gregorianCalendar.set(14, (int)paramLong);
/*      */         
/*  897 */         i = (int)(paramLong * 1000000L % 1000000000L);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  903 */         throw new AssertionError("Unexpected SSType: " + paramSSType);
/*      */     } 
/*      */ 
/*      */     
/*  907 */     switch (paramJDBCType.category) {
/*      */ 
/*      */       
/*      */       case BINARY:
/*  911 */         switch (paramSSType) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*  917 */             gregorianCalendar.set(11, 0);
/*  918 */             gregorianCalendar.set(12, 0);
/*  919 */             gregorianCalendar.set(13, 0);
/*  920 */             gregorianCalendar.set(14, 0);
/*  921 */             return new Date(gregorianCalendar.getTimeInMillis());
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*      */           case null:
/*  927 */             timestamp2 = new Timestamp(gregorianCalendar.getTimeInMillis());
/*  928 */             timestamp2.setNanos(i);
/*  929 */             return timestamp2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*  936 */             assert SSType.DATETIMEOFFSET == paramSSType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  943 */             k = paramCalendar.get(15);
/*  944 */             assert 0 == k % 60000;
/*      */             
/*  946 */             timestamp3 = new Timestamp(gregorianCalendar.getTimeInMillis());
/*  947 */             timestamp3.setNanos(i);
/*  948 */             return DateTimeOffset.valueOf(timestamp3, k / 60000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/*  957 */             if (i % 1000000 >= 500000) {
/*  958 */               gregorianCalendar.add(14, 1);
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  964 */             gregorianCalendar.set(1970, 0, 1);
/*      */             
/*  966 */             return new Time(gregorianCalendar.getTimeInMillis());
/*      */         } 
/*      */ 
/*      */         
/*  970 */         throw new AssertionError("Unexpected SSType: " + paramSSType);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DATE:
/*  978 */         gregorianCalendar.set(11, 0);
/*  979 */         gregorianCalendar.set(12, 0);
/*  980 */         gregorianCalendar.set(13, 0);
/*  981 */         gregorianCalendar.set(14, 0);
/*  982 */         return new Date(gregorianCalendar.getTimeInMillis());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TIME:
/*  992 */         if (i % 1000000 >= 500000) {
/*  993 */           gregorianCalendar.add(14, 1);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  999 */         gregorianCalendar.set(1970, 0, 1);
/*      */         
/* 1001 */         return new Time(gregorianCalendar.getTimeInMillis());
/*      */ 
/*      */ 
/*      */       
/*      */       case TIMESTAMP:
/* 1006 */         timestamp1 = new Timestamp(gregorianCalendar.getTimeInMillis());
/* 1007 */         timestamp1.setNanos(i);
/* 1008 */         return timestamp1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DATETIMEOFFSET:
/* 1015 */         assert SSType.DATETIMEOFFSET == paramSSType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1022 */         j = paramCalendar.get(15);
/* 1023 */         assert 0 == j % 60000;
/*      */         
/* 1025 */         timestamp3 = new Timestamp(gregorianCalendar.getTimeInMillis());
/* 1026 */         timestamp3.setNanos(i);
/* 1027 */         return DateTimeOffset.valueOf(timestamp3, j / 60000);
/*      */ 
/*      */ 
/*      */       
/*      */       case CHARACTER:
/* 1032 */         switch (paramSSType) {
/*      */ 
/*      */           
/*      */           case null:
/* 1036 */             return String.format(Locale.US, "%1$tF", new Object[] { gregorianCalendar });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1044 */             return String.format(Locale.US, "%1$tT%2$s", new Object[] { gregorianCalendar, fractionalSecondsString(i, paramInt2) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1055 */             return String.format(Locale.US, "%1$tF %1$tT%2$s", new Object[] { gregorianCalendar, fractionalSecondsString(i, paramInt2) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1068 */             j = paramCalendar.get(15);
/* 1069 */             assert 0 == j % 60000;
/*      */             
/* 1071 */             m = Math.abs(j / 60000);
/* 1072 */             return String.format(Locale.US, "%1$tF %1$tT%2$s %3$c%4$02d:%5$02d", new Object[] { gregorianCalendar, fractionalSecondsString(i, paramInt2), Character.valueOf((j >= 0) ? 43 : 45), Integer.valueOf(m / 60), Integer.valueOf(m % 60) });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case null:
/* 1086 */             return (new Timestamp(gregorianCalendar.getTimeInMillis())).toString();
/*      */         } 
/*      */ 
/*      */         
/* 1090 */         throw new AssertionError("Unexpected SSType: " + paramSSType);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1095 */     throw new AssertionError("Unexpected JDBCType: " + paramJDBCType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int daysSinceBaseDate(int paramInt1, int paramInt2, int paramInt3) {
/* 1109 */     assert paramInt1 >= 1;
/* 1110 */     assert paramInt3 >= 1;
/* 1111 */     assert paramInt2 >= 1;
/*      */     
/* 1113 */     return paramInt2 - 1 + (paramInt1 - paramInt3) * 365 + leapDaysBeforeYear(paramInt1) - leapDaysBeforeYear(paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int leapDaysBeforeYear(int paramInt) {
/* 1126 */     assert paramInt >= 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1137 */     return (paramInt - 1) / 4 - (paramInt - 1) / 100 + (paramInt - 1) / 400;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1142 */   private static final BigInteger maxRPCDecimalValue = new BigInteger("99999999999999999999999999999999999999");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean exceedsMaxRPCDecimalPrecisionOrScale(BigDecimal paramBigDecimal) {
/* 1148 */     if (null == paramBigDecimal) return false;
/*      */ 
/*      */     
/* 1151 */     if (paramBigDecimal.scale() > 38) return true;
/*      */ 
/*      */ 
/*      */     
/* 1155 */     BigInteger bigInteger = (paramBigDecimal.scale() < 0) ? paramBigDecimal.setScale(0).unscaledValue() : paramBigDecimal.unscaledValue();
/*      */     
/* 1157 */     if (paramBigDecimal.signum() < 0) bigInteger = bigInteger.negate(); 
/* 1158 */     return (bigInteger.compareTo(maxRPCDecimalValue) > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static String convertReaderToString(Reader paramReader, int paramInt) throws SQLServerException {
/* 1164 */     assert -1 == paramInt || paramInt >= 0;
/*      */ 
/*      */     
/* 1167 */     if (null == paramReader) return null; 
/* 1168 */     if (0 == paramInt) return "";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1175 */       StringBuilder stringBuilder = new StringBuilder((-1 != paramInt) ? paramInt : 4000);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1180 */       char[] arrayOfChar = new char[(-1 != paramInt && paramInt < 4000) ? paramInt : 4000];
/*      */ 
/*      */       
/*      */       int i;
/*      */       
/* 1185 */       while ((i = paramReader.read(arrayOfChar, 0, arrayOfChar.length)) > 0) {
/*      */ 
/*      */         
/* 1188 */         if (i > arrayOfChar.length) {
/*      */           
/* 1190 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1191 */           Object[] arrayOfObject = { SQLServerException.getErrString("R_streamReadReturnedInvalidValue") };
/* 1192 */           SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
/*      */         } 
/*      */         
/* 1195 */         stringBuilder.append(arrayOfChar, 0, i);
/*      */       } 
/*      */       
/* 1198 */       return stringBuilder.toString();
/*      */     }
/* 1200 */     catch (IOException iOException) {
/*      */       
/* 1202 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1203 */       Object[] arrayOfObject = { iOException.toString() };
/* 1204 */       SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
/*      */ 
/*      */ 
/*      */       
/* 1208 */       return null;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\DDC.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */