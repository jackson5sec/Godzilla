/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ public enum SQLServerSortOrder {
/*  4 */   Ascending(0),
/*  5 */   Descending(1),
/*  6 */   Unspecified(-1);
/*    */   
/*    */   int value;
/*    */   
/*    */   SQLServerSortOrder(int paramInt1) {
/* 11 */     this.value = paramInt1;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerSortOrder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */