/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DriverJDBCVersion
/*    */ {
/*    */   static final int major = 4;
/*    */   static final int minor = 1;
/*    */   
/*    */   static final void checkSupportsJDBC4() {}
/*    */   
/*    */   static final void checkSupportsJDBC41() {}
/*    */   
/*    */   static final void checkSupportsJDBC42() {
/* 22 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static final void throwBatchUpdateException(SQLServerException paramSQLServerException, long[] paramArrayOflong) {
/* 28 */     throw new UnsupportedOperationException(SQLServerException.getErrString("R_notSupported"));
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\DriverJDBCVersion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */