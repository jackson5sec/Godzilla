/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class TDSParser
/*     */ {
/*  25 */   private static Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.TOKEN");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void parse(TDSReader paramTDSReader, String paramString) throws SQLServerException {
/*  36 */     parse(paramTDSReader, new TDSTokenHandler(paramString));
/*     */   }
/*     */ 
/*     */   
/*     */   static void parse(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
/*  41 */     boolean bool1 = logger.isLoggable(Level.FINEST);
/*     */ 
/*     */     
/*  44 */     boolean bool2 = true;
/*     */ 
/*     */     
/*  47 */     boolean bool3 = false;
/*  48 */     boolean bool4 = false;
/*  49 */     while (bool2) {
/*     */       
/*  51 */       int i = paramTDSReader.peekTokenType();
/*  52 */       if (bool1)
/*     */       {
/*  54 */         logger.finest(paramTDSReader.toString() + ": " + paramTDSTokenHandler.logContext + ": Processing " + ((-1 == i) ? "EOF" : TDS.getTokenName(i)));
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  60 */       switch (i) {
/*     */         case 237:
/*  62 */           bool2 = paramTDSTokenHandler.onSSPI(paramTDSReader); continue;
/*     */         case 173:
/*  64 */           bool3 = true;
/*  65 */           bool2 = paramTDSTokenHandler.onLoginAck(paramTDSReader);
/*     */           continue;
/*     */         case 174:
/*  68 */           bool4 = true;
/*  69 */           paramTDSReader.getConnection().processFeatureExtAck(paramTDSReader);
/*  70 */           bool2 = true; continue;
/*     */         case 227:
/*  72 */           bool2 = paramTDSTokenHandler.onEnvChange(paramTDSReader); continue;
/*  73 */         case 121: bool2 = paramTDSTokenHandler.onRetStatus(paramTDSReader); continue;
/*  74 */         case 172: bool2 = paramTDSTokenHandler.onRetValue(paramTDSReader); continue;
/*     */         case 253:
/*     */         case 254:
/*     */         case 255:
/*  78 */           paramTDSReader.getCommand().checkForInterrupt();
/*  79 */           bool2 = paramTDSTokenHandler.onDone(paramTDSReader);
/*     */           continue;
/*     */         
/*     */         case 170:
/*  83 */           bool2 = paramTDSTokenHandler.onError(paramTDSReader); continue;
/*     */         case 171:
/*  85 */           bool2 = paramTDSTokenHandler.onInfo(paramTDSReader); continue;
/*  86 */         case 169: bool2 = paramTDSTokenHandler.onOrder(paramTDSReader); continue;
/*  87 */         case 129: bool2 = paramTDSTokenHandler.onColMetaData(paramTDSReader); continue;
/*  88 */         case 209: bool2 = paramTDSTokenHandler.onRow(paramTDSReader); continue;
/*  89 */         case 210: bool2 = paramTDSTokenHandler.onNBCRow(paramTDSReader); continue;
/*  90 */         case 165: bool2 = paramTDSTokenHandler.onColInfo(paramTDSReader); continue;
/*  91 */         case 164: bool2 = paramTDSTokenHandler.onTabName(paramTDSReader);
/*     */           continue;
/*     */         case 238:
/*  94 */           bool2 = paramTDSTokenHandler.onFedAuthInfo(paramTDSReader);
/*     */           continue;
/*     */         
/*     */         case -1:
/*  98 */           paramTDSReader.getCommand().onTokenEOF();
/*  99 */           paramTDSTokenHandler.onEOF(paramTDSReader);
/* 100 */           bool2 = false;
/*     */           continue;
/*     */       } 
/*     */       
/* 104 */       throwUnexpectedTokenException(paramTDSReader, paramTDSTokenHandler.logContext);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     if (bool3 && !bool4) {
/* 111 */       paramTDSReader.TryProcessFeatureExtAck(bool4);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static void throwUnexpectedTokenException(TDSReader paramTDSReader, String paramString) throws SQLServerException {
/* 117 */     if (logger.isLoggable(Level.SEVERE))
/* 118 */       logger.severe(paramTDSReader.toString() + ": " + paramString + ": Encountered unexpected " + TDS.getTokenName(paramTDSReader.peekTokenType())); 
/* 119 */     paramTDSReader.throwInvalidTDSToken(TDS.getTokenName(paramTDSReader.peekTokenType()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void ignoreLengthPrefixedToken(TDSReader paramTDSReader) throws SQLServerException {
/* 125 */     paramTDSReader.readUnsignedByte();
/* 126 */     int i = paramTDSReader.readUnsignedShort();
/* 127 */     byte[] arrayOfByte = new byte[i];
/* 128 */     paramTDSReader.readBytes(arrayOfByte, 0, i);
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\TDSParser.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */