/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Path;
/*     */ import java.security.Key;
/*     */ import java.security.KeyStore;
/*     */ import java.security.KeyStoreException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.CertificateEncodingException;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Locale;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.bind.DatatypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerColumnEncryptionCertificateStoreProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  29 */   private static final Logger windowsCertificateStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionCertificateStoreProvider");
/*     */ 
/*     */   
/*     */   static boolean isWindows;
/*     */   
/*  34 */   String name = "MSSQL_CERTIFICATE_STORE";
/*     */   
/*     */   static final String localMachineDirectory = "LocalMachine";
/*     */   
/*     */   static final String currentUserDirectory = "CurrentUser";
/*     */   static final String myCertificateStore = "My";
/*     */   
/*     */   static {
/*  42 */     if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
/*     */       
/*  44 */       isWindows = true;
/*     */     }
/*     */     else {
/*     */       
/*  48 */       isWindows = false;
/*     */     } 
/*     */   }
/*  51 */   private Path keyStoreDirectoryPath = null;
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionCertificateStoreProvider() {
/*  55 */     windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "SQLServerColumnEncryptionCertificateStoreProvider");
/*     */   }
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/*  60 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  65 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/*  87 */     throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidWindowsCertificateStoreEncryption"), null, 0, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decryptColumnEncryptionKeyWindows(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/*     */     try {
/* 100 */       return AuthenticationJNI.DecryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfbyte);
/*     */     
/*     */     }
/* 103 */     catch (DLLException dLLException) {
/*     */       
/* 105 */       DLLException.buildException(dLLException.GetErrCode(), dLLException.GetParam1(), dLLException.GetParam2(), dLLException.GetParam3());
/* 106 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CertificateDetails getCertificateDetails(String paramString) throws SQLServerException {
/* 114 */     String str1 = null;
/*     */     
/* 116 */     String[] arrayOfString = paramString.split("/");
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (arrayOfString.length > 3) {
/*     */       
/* 122 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertpathBad"));
/* 123 */       Object[] arrayOfObject = { paramString };
/* 124 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */ 
/*     */     
/* 128 */     if (arrayOfString.length > 2)
/*     */     {
/* 130 */       if (arrayOfString[0].equalsIgnoreCase("LocalMachine")) {
/*     */         
/* 132 */         str1 = "LocalMachine";
/*     */       }
/* 134 */       else if (arrayOfString[0].equalsIgnoreCase("CurrentUser")) {
/*     */         
/* 136 */         str1 = "CurrentUser";
/*     */       }
/*     */       else {
/*     */         
/* 140 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertLocBad"));
/* 141 */         Object[] arrayOfObject = { arrayOfString[0], paramString };
/* 142 */         throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 147 */     if (arrayOfString.length > 1)
/*     */     {
/* 149 */       if (!arrayOfString[arrayOfString.length - 2].equalsIgnoreCase("My")) {
/*     */         
/* 151 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertStoreBad"));
/* 152 */         Object[] arrayOfObject = { arrayOfString[arrayOfString.length - 2], paramString };
/* 153 */         throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 158 */     String str2 = arrayOfString[arrayOfString.length - 1];
/* 159 */     if (null == str2 || 0 == str2.length()) {
/*     */ 
/*     */       
/* 162 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AECertHashEmpty"));
/* 163 */       Object[] arrayOfObject = { paramString };
/* 164 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */ 
/*     */     
/* 168 */     return getCertificateByThumbprint(str1, str2, paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   private String getThumbPrint(X509Certificate paramX509Certificate) throws NoSuchAlgorithmException, CertificateEncodingException {
/* 173 */     MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
/* 174 */     byte[] arrayOfByte1 = paramX509Certificate.getEncoded();
/* 175 */     messageDigest.update(arrayOfByte1);
/* 176 */     byte[] arrayOfByte2 = messageDigest.digest();
/* 177 */     return DatatypeConverter.printHexBinary(arrayOfByte2);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private CertificateDetails getCertificateByThumbprint(String paramString1, String paramString2, String paramString3) throws SQLServerException {
/* 183 */     FileInputStream fileInputStream = null;
/*     */     
/* 185 */     if (null == this.keyStoreDirectoryPath) {
/*     */       
/* 187 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AEKeyPathEmptyOrReserved"));
/* 188 */       Object[] arrayOfObject = { this.keyStoreDirectoryPath };
/* 189 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */     
/* 192 */     Path path = this.keyStoreDirectoryPath.resolve(paramString1);
/*     */ 
/*     */     
/* 195 */     KeyStore keyStore = null;
/*     */     
/*     */     try {
/* 198 */       keyStore = KeyStore.getInstance("PKCS12");
/*     */     }
/* 200 */     catch (KeyStoreException keyStoreException) {
/*     */       
/* 202 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/* 203 */       Object[] arrayOfObject = { paramString3, this.name };
/* 204 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 207 */     File file = path.toFile();
/* 208 */     File[] arrayOfFile = file.listFiles();
/*     */     
/* 210 */     if (null == arrayOfFile || (null != arrayOfFile && 0 == arrayOfFile.length))
/*     */     {
/*     */       
/* 213 */       throw new SQLServerException(SQLServerException.getErrString("R_KeyStoreNotFound"), null);
/*     */     }
/*     */     
/* 216 */     for (File file1 : arrayOfFile) {
/*     */       
/* 218 */       if (!file1.isDirectory()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 224 */         char[] arrayOfChar = "".toCharArray();
/*     */         
/*     */         try {
/* 227 */           fileInputStream = new FileInputStream(file1);
/* 228 */           keyStore.load(fileInputStream, arrayOfChar);
/*     */         }
/* 230 */         catch (IOException|CertificateException|NoSuchAlgorithmException iOException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 241 */           for (Enumeration<String> enumeration = keyStore.aliases(); enumeration.hasMoreElements(); ) {
/*     */ 
/*     */             
/* 244 */             String str = enumeration.nextElement();
/*     */             
/* 246 */             X509Certificate x509Certificate = (X509Certificate)keyStore.getCertificate(str);
/*     */             
/* 248 */             if (paramString2.matches(getThumbPrint(x509Certificate)))
/*     */             {
/*     */               
/* 251 */               Key key = null;
/*     */               
/*     */               try {
/* 254 */                 key = keyStore.getKey(str, "".toCharArray());
/*     */ 
/*     */                 
/* 257 */                 if (null == key)
/*     */                 {
/* 259 */                   MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/* 260 */                   Object[] arrayOfObject = { paramString3 };
/* 261 */                   throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */                 }
/*     */               
/* 264 */               } catch (UnrecoverableKeyException|NoSuchAlgorithmException|KeyStoreException unrecoverableKeyException) {
/*     */                 
/* 266 */                 MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/* 267 */                 Object[] arrayOfObject = { paramString3 };
/* 268 */                 throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */               } 
/* 270 */               return new CertificateDetails(x509Certificate, key);
/*     */             }
/*     */           
/*     */           } 
/* 274 */         } catch (CertificateException|NoSuchAlgorithmException|KeyStoreException certificateException) {
/*     */ 
/*     */ 
/*     */           
/* 278 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/*     */           
/* 280 */           Object[] arrayOfObject = { paramString3, this.name };
/* 281 */           throw new SQLServerException(messageFormat.format(arrayOfObject), certificateException);
/*     */         } 
/*     */       } 
/*     */     } 
/* 285 */     throw new SQLServerException(SQLServerException.getErrString("R_KeyStoreNotFound"), null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decryptColumnEncryptionKeyLinux(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/* 291 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
/* 292 */     CertificateDetails certificateDetails = getCertificateDetails(paramString1);
/* 293 */     return KeyStoreProviderCommon.decryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfbyte, certificateDetails);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/* 299 */     windowsCertificateStoreLogger.entering(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
/* 300 */     byte[] arrayOfByte = null;
/* 301 */     if (isWindows) {
/*     */       
/* 303 */       arrayOfByte = decryptColumnEncryptionKeyWindows(paramString1, paramString2, paramArrayOfbyte);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 309 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null);
/*     */     } 
/* 311 */     windowsCertificateStoreLogger.exiting(SQLServerColumnEncryptionCertificateStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
/* 312 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionCertificateStoreProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */