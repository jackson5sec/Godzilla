/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.KeyStore;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Signature;
/*     */ import java.security.UnrecoverableKeyException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Cipher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerColumnEncryptionJavaKeyStoreProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  32 */   String name = "MSSQL_JAVA_KEYSTORE";
/*     */ 
/*     */   
/*  35 */   String keyStorePath = null;
/*  36 */   char[] keyStorePwd = null;
/*     */   
/*  38 */   private static final Logger javaKeyStoreLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/*  43 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  48 */     return this.name;
/*     */   }
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionJavaKeyStoreProvider(String paramString, char[] paramArrayOfchar) throws SQLServerException {
/*  53 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */     
/*  55 */     if (null == paramString || 0 == paramString.length()) {
/*     */       
/*  57 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/*  58 */       Object[] arrayOfObject = { "keyStoreLocation", paramString };
/*  59 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */     
/*  62 */     this.keyStorePath = paramString;
/*     */     
/*  64 */     if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
/*  65 */       javaKeyStoreLogger.fine("Path of key store provider is set.");
/*     */     }
/*     */ 
/*     */     
/*  69 */     if (null == paramArrayOfchar)
/*     */     {
/*  71 */       paramArrayOfchar = "".toCharArray();
/*     */     }
/*     */     
/*  74 */     this.keyStorePwd = new char[paramArrayOfchar.length];
/*  75 */     System.arraycopy(paramArrayOfchar, 0, this.keyStorePwd, 0, paramArrayOfchar.length);
/*     */     
/*  77 */     if (javaKeyStoreLogger.isLoggable(Level.FINE)) {
/*  78 */       javaKeyStoreLogger.fine("Password for key store provider is set.");
/*     */     }
/*     */     
/*  81 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "SQLServerColumnEncryptionJavaKeyStoreProvider");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/*  90 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Decrypting Column Encryption Key.");
/*     */     
/*  92 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
/*  93 */     CertificateDetails certificateDetails = getCertificateDetails(paramString1);
/*  94 */     byte[] arrayOfByte = KeyStoreProviderCommon.decryptColumnEncryptionKey(paramString1, paramString2, paramArrayOfbyte, certificateDetails);
/*     */     
/*  96 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), "decryptColumnEncryptionKey", "Finished decrypting Column Encryption Key.");
/*  97 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CertificateDetails getCertificateDetails(String paramString) throws SQLServerException {
/* 104 */     FileInputStream fileInputStream = null;
/* 105 */     KeyStore keyStore = null;
/* 106 */     CertificateDetails certificateDetails = null;
/*     */ 
/*     */     
/*     */     try {
/* 110 */       if (null == paramString || 0 == paramString.length())
/*     */       {
/* 112 */         throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 123 */         keyStore = KeyStore.getInstance("JKS");
/* 124 */         fileInputStream = new FileInputStream(this.keyStorePath);
/* 125 */         keyStore.load(fileInputStream, this.keyStorePwd);
/*     */       }
/* 127 */       catch (IOException iOException) {
/*     */         
/* 129 */         if (null != fileInputStream) fileInputStream.close();
/*     */ 
/*     */         
/* 132 */         keyStore = KeyStore.getInstance("PKCS12");
/* 133 */         fileInputStream = new FileInputStream(this.keyStorePath);
/* 134 */         keyStore.load(fileInputStream, this.keyStorePwd);
/*     */       } 
/*     */       
/* 137 */       certificateDetails = getCertificateDetailsByAlias(keyStore, paramString);
/*     */     }
/* 139 */     catch (FileNotFoundException fileNotFoundException) {
/*     */       
/* 141 */       throw new SQLServerException(this, SQLServerException.getErrString("R_KeyStoreNotFound"), null, 0, false);
/*     */     }
/* 143 */     catch (IOException|java.security.cert.CertificateException|NoSuchAlgorithmException|java.security.KeyStoreException iOException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 148 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidKeyStoreFile"));
/*     */       
/* 150 */       Object[] arrayOfObject = { this.keyStorePath };
/* 151 */       throw new SQLServerException(messageFormat.format(arrayOfObject), iOException);
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 157 */         if (null != fileInputStream) fileInputStream.close();
/*     */       
/*     */       }
/* 160 */       catch (IOException iOException) {}
/*     */     } 
/*     */     
/* 163 */     return certificateDetails;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CertificateDetails getCertificateDetailsByAlias(KeyStore paramKeyStore, String paramString) throws SQLServerException {
/*     */     try {
/* 172 */       X509Certificate x509Certificate = (X509Certificate)paramKeyStore.getCertificate(paramString);
/* 173 */       Key key = paramKeyStore.getKey(paramString, this.keyStorePwd);
/* 174 */       if (null == x509Certificate) {
/*     */ 
/*     */         
/* 177 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateNotFoundForAlias"));
/*     */         
/* 179 */         Object[] arrayOfObject = { paramString, "MSSQL_JAVA_KEYSTORE" };
/* 180 */         throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */       } 
/*     */ 
/*     */       
/* 184 */       if (null == key) {
/* 185 */         throw new UnrecoverableKeyException();
/*     */       }
/*     */       
/* 188 */       return new CertificateDetails(x509Certificate, key);
/*     */     }
/* 190 */     catch (UnrecoverableKeyException unrecoverableKeyException) {
/*     */       
/* 192 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecoverableKeyAE"));
/*     */       
/* 194 */       Object[] arrayOfObject = { paramString };
/* 195 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/* 197 */     catch (NoSuchAlgorithmException|java.security.KeyStoreException noSuchAlgorithmException) {
/* 198 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CertificateError"));
/*     */       
/* 200 */       Object[] arrayOfObject = { paramString, this.name };
/* 201 */       throw new SQLServerException(messageFormat.format(arrayOfObject), noSuchAlgorithmException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/*     */     byte[] arrayOfByte4;
/* 209 */     javaKeyStoreLogger.entering(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Encrypting Column Encryption Key.");
/*     */     
/* 211 */     byte[] arrayOfByte1 = KeyStoreProviderCommon.version;
/* 212 */     KeyStoreProviderCommon.validateNonEmptyMasterKeyPath(paramString1);
/*     */     
/* 214 */     if (null == paramArrayOfbyte)
/*     */     {
/* 216 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (0 == paramArrayOfbyte.length)
/*     */     {
/* 226 */       throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     KeyStoreProviderCommon.validateEncryptionAlgorithm(paramString2, true);
/*     */     
/* 237 */     CertificateDetails certificateDetails = getCertificateDetails(paramString1);
/* 238 */     byte[] arrayOfByte2 = encryptRSAOAEP(paramArrayOfbyte, certificateDetails);
/* 239 */     byte[] arrayOfByte3 = getLittleEndianBytesFromShort((short)arrayOfByte2.length);
/*     */ 
/*     */     
/*     */     try {
/* 243 */       arrayOfByte4 = paramString1.toLowerCase().getBytes("UTF-16LE");
/*     */     }
/* 245 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 246 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 247 */       throw new SQLServerException(messageFormat.format(new Object[] { "UTF-16LE" }, ), null, 0, null);
/*     */     } 
/*     */     
/* 250 */     byte[] arrayOfByte5 = getLittleEndianBytesFromShort((short)arrayOfByte4.length);
/*     */     
/* 252 */     byte[] arrayOfByte6 = new byte[arrayOfByte1.length + arrayOfByte5.length + arrayOfByte3.length + arrayOfByte4.length + arrayOfByte2.length];
/* 253 */     int i = arrayOfByte1.length;
/* 254 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte6, 0, arrayOfByte1.length);
/*     */     
/* 256 */     System.arraycopy(arrayOfByte5, 0, arrayOfByte6, i, arrayOfByte5.length);
/* 257 */     i += arrayOfByte5.length;
/*     */     
/* 259 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte6, i, arrayOfByte3.length);
/* 260 */     i += arrayOfByte3.length;
/*     */     
/* 262 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte6, i, arrayOfByte4.length);
/* 263 */     i += arrayOfByte4.length;
/*     */     
/* 265 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte6, i, arrayOfByte2.length);
/* 266 */     byte[] arrayOfByte7 = rsaSignHashedData(arrayOfByte6, certificateDetails);
/*     */     
/* 268 */     int j = arrayOfByte1.length + arrayOfByte3.length + arrayOfByte5.length + arrayOfByte2.length + arrayOfByte4.length + arrayOfByte7.length;
/* 269 */     byte[] arrayOfByte8 = new byte[j];
/*     */     
/* 271 */     int k = 0;
/* 272 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte8, k, arrayOfByte1.length);
/* 273 */     k += arrayOfByte1.length;
/*     */     
/* 275 */     System.arraycopy(arrayOfByte5, 0, arrayOfByte8, k, arrayOfByte5.length);
/* 276 */     k += arrayOfByte5.length;
/*     */     
/* 278 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte8, k, arrayOfByte3.length);
/* 279 */     k += arrayOfByte3.length;
/*     */     
/* 281 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte8, k, arrayOfByte4.length);
/* 282 */     k += arrayOfByte4.length;
/*     */     
/* 284 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte8, k, arrayOfByte2.length);
/* 285 */     k += arrayOfByte2.length;
/*     */     
/* 287 */     System.arraycopy(arrayOfByte7, 0, arrayOfByte8, k, arrayOfByte7.length);
/*     */     
/* 289 */     javaKeyStoreLogger.exiting(SQLServerColumnEncryptionJavaKeyStoreProvider.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Finished encrypting Column Encryption Key.");
/* 290 */     return arrayOfByte8;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] encryptRSAOAEP(byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
/* 303 */     byte[] arrayOfByte = null;
/*     */     
/*     */     try {
/* 306 */       Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 307 */       cipher.init(1, paramCertificateDetails.certificate.getPublicKey());
/* 308 */       cipher.update(paramArrayOfbyte);
/* 309 */       arrayOfByte = cipher.doFinal();
/*     */     }
/* 311 */     catch (InvalidKeyException|NoSuchAlgorithmException|javax.crypto.IllegalBlockSizeException|javax.crypto.NoSuchPaddingException|javax.crypto.BadPaddingException invalidKeyException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 317 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */       
/* 319 */       Object[] arrayOfObject = { invalidKeyException.getMessage() };
/* 320 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 323 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] rsaSignHashedData(byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
/* 329 */     byte[] arrayOfByte = null;
/*     */     
/*     */     try {
/* 332 */       Signature signature = Signature.getInstance("SHA256withRSA");
/* 333 */       signature.initSign((PrivateKey)paramCertificateDetails.privateKey);
/* 334 */       signature.update(paramArrayOfbyte);
/* 335 */       arrayOfByte = signature.sign();
/* 336 */     } catch (InvalidKeyException|NoSuchAlgorithmException|java.security.SignatureException invalidKeyException) {
/* 337 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */       
/* 339 */       Object[] arrayOfObject = { invalidKeyException.getMessage() };
/* 340 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 343 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] getLittleEndianBytesFromShort(short paramShort) {
/* 352 */     ByteBuffer byteBuffer = ByteBuffer.allocate(2);
/* 353 */     byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 354 */     return byteBuffer.putShort(paramShort).array();
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionJavaKeyStoreProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */