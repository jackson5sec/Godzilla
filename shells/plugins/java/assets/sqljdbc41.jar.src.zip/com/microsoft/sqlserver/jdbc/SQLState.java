/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum SQLState
/*    */ {
/* 17 */   STATEMENT_CANCELED("HY008"),
/* 18 */   DATA_EXCEPTION_NOT_SPECIFIC("22000"),
/* 19 */   DATA_EXCEPTION_DATETIME_FIELD_OVERFLOW("22008"),
/* 20 */   DATA_EXCEPTION_LENGTH_MISMATCH("22026"),
/* 21 */   COL_NOT_FOUND("42S22");
/*    */   
/*    */   final String getSQLStateCode() {
/* 24 */     return this.sqlStateCode;
/*    */   }
/*    */   private final String sqlStateCode;
/*    */   SQLState(String paramString1) {
/* 28 */     this.sqlStateCode = paramString1;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLState.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */