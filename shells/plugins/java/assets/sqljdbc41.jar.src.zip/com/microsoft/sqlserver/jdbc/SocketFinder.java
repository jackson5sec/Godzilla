/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.net.Inet4Address;
/*      */ import java.net.Inet6Address;
/*      */ import java.net.InetAddress;
/*      */ import java.net.InetSocketAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.channels.SelectionKey;
/*      */ import java.nio.channels.Selector;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.SynchronousQueue;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class SocketFinder
/*      */ {
/*      */   enum Result
/*      */   {
/* 2112 */     UNKNOWN,
/* 2113 */     SUCCESS,
/* 2114 */     FAILURE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2119 */   private static final ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(0, 2147483647, 5L, TimeUnit.SECONDS, new SynchronousQueue<>());
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int minTimeoutForParallelConnections = 1500;
/*      */ 
/*      */   
/* 2126 */   private final Object socketFinderlock = new Object();
/*      */ 
/*      */ 
/*      */   
/* 2130 */   private final Object parentThreadLock = new Object();
/*      */ 
/*      */ 
/*      */   
/* 2134 */   private volatile Result result = Result.UNKNOWN;
/*      */ 
/*      */ 
/*      */   
/* 2138 */   private int noOfSpawnedThreads = 0;
/*      */ 
/*      */ 
/*      */   
/* 2142 */   private volatile int noOfThreadsThatNotified = 0;
/*      */ 
/*      */ 
/*      */   
/* 2146 */   private volatile Socket selectedSocket = null;
/*      */ 
/*      */ 
/*      */   
/* 2150 */   private volatile IOException selectedException = null;
/*      */ 
/*      */   
/* 2153 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SocketFinder");
/*      */ 
/*      */ 
/*      */   
/*      */   private final String traceID;
/*      */ 
/*      */   
/*      */   private static final int ipAddressLimit = 64;
/*      */ 
/*      */   
/*      */   private final SQLServerConnection conn;
/*      */ 
/*      */ 
/*      */   
/*      */   SocketFinder(String paramString, SQLServerConnection paramSQLServerConnection) {
/* 2168 */     this.traceID = "SocketFinder(" + paramString + ")";
/* 2169 */     this.conn = paramSQLServerConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Socket findSocket(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3) throws SQLServerException {
/* 2190 */     assert paramInt2 != 0 : "The driver does not allow a time out of 0";
/*      */ 
/*      */     
/*      */     try {
/* 2194 */       InetAddress[] arrayOfInetAddress = null;
/*      */ 
/*      */       
/* 2197 */       if (paramBoolean1 || paramBoolean2) {
/*      */ 
/*      */         
/* 2200 */         arrayOfInetAddress = InetAddress.getAllByName(paramString);
/*      */         
/* 2202 */         if (paramBoolean2 && arrayOfInetAddress.length > 64) {
/*      */           
/* 2204 */           paramBoolean2 = false;
/* 2205 */           paramInt2 = paramInt3;
/*      */         } 
/*      */       } 
/*      */       
/* 2209 */       if (!paramBoolean1) {
/*      */ 
/*      */ 
/*      */         
/* 2213 */         if (paramBoolean2 && paramBoolean3)
/*      */         {
/* 2215 */           return getDefaultSocket(paramString, paramInt1, 500);
/*      */         }
/* 2217 */         if (!paramBoolean2)
/*      */         {
/* 2219 */           return getDefaultSocket(paramString, paramInt1, paramInt2);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2225 */       if (logger.isLoggable(Level.FINER)) {
/*      */         
/* 2227 */         String str = toString() + " Total no of InetAddresses: " + arrayOfInetAddress.length + ". They are: ";
/* 2228 */         for (InetAddress inetAddress : arrayOfInetAddress)
/*      */         {
/* 2230 */           str = str + inetAddress.toString() + ";";
/*      */         }
/*      */         
/* 2233 */         logger.finer(str);
/*      */       } 
/*      */       
/* 2236 */       if (arrayOfInetAddress.length > 64) {
/*      */         
/* 2238 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ipAddressLimitWithMultiSubnetFailover"));
/* 2239 */         Object[] arrayOfObject = { Integer.toString(64) };
/* 2240 */         String str = messageFormat.format(arrayOfObject);
/*      */ 
/*      */         
/* 2243 */         this.conn.terminate(6, str);
/*      */       } 
/*      */       
/* 2246 */       if (Util.isIBM()) {
/*      */         
/* 2248 */         paramInt2 = Math.max(paramInt2, 1500);
/* 2249 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2251 */           logger.finer(toString() + "Using Java NIO with timeout:" + paramInt2);
/*      */         }
/* 2253 */         findSocketUsingJavaNIO(arrayOfInetAddress, paramInt1, paramInt2);
/*      */       } else {
/*      */         int i;
/*      */         
/* 2257 */         LinkedList<Inet4Address> linkedList = new LinkedList();
/* 2258 */         LinkedList<Inet6Address> linkedList1 = new LinkedList();
/*      */         
/* 2260 */         for (InetAddress inetAddress : arrayOfInetAddress) {
/*      */           
/* 2262 */           if (inetAddress instanceof Inet4Address) {
/*      */             
/* 2264 */             linkedList.add((Inet4Address)inetAddress);
/*      */           }
/*      */           else {
/*      */             
/* 2268 */             assert inetAddress instanceof Inet6Address : "Unexpected IP address " + inetAddress.toString();
/* 2269 */             linkedList1.add((Inet6Address)inetAddress);
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2275 */         if (!linkedList.isEmpty() && !linkedList1.isEmpty()) {
/*      */           
/* 2277 */           i = Math.max(paramInt2 / 2, 1500);
/*      */         } else {
/*      */           
/* 2280 */           i = Math.max(paramInt2, 1500);
/*      */         } 
/* 2282 */         if (!linkedList.isEmpty()) {
/*      */           
/* 2284 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2286 */             logger.finer(toString() + "Using Java NIO with timeout:" + i);
/*      */           }
/*      */ 
/*      */           
/* 2290 */           findSocketUsingJavaNIO(linkedList.<InetAddress>toArray(new InetAddress[0]), paramInt1, i);
/*      */         } 
/*      */         
/* 2293 */         if (!this.result.equals(Result.SUCCESS))
/*      */         {
/*      */           
/* 2296 */           if (!linkedList1.isEmpty()) {
/*      */ 
/*      */             
/* 2299 */             if (linkedList1.size() == 1)
/*      */             {
/* 2301 */               return getConnectedSocket(linkedList1.get(0), paramInt1, i);
/*      */             }
/*      */             
/* 2304 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2306 */               logger.finer(toString() + "Using Threading with timeout:" + i);
/*      */             }
/*      */             
/* 2309 */             findSocketUsingThreading(linkedList1, paramInt1, i);
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2318 */       if (this.result.equals(Result.UNKNOWN))
/*      */       {
/* 2320 */         synchronized (this.socketFinderlock) {
/*      */           
/* 2322 */           if (this.result.equals(Result.UNKNOWN)) {
/*      */             
/* 2324 */             this.result = Result.FAILURE;
/* 2325 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2327 */               logger.finer(toString() + " The parent thread updated the result to failure");
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2337 */       if (this.result.equals(Result.FAILURE))
/*      */       {
/* 2339 */         if (this.selectedException == null) {
/*      */           
/* 2341 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2343 */             logger.finer(toString() + " There is no selectedException. The wait calls timed out before any connect call returned or timed out.");
/*      */           }
/* 2345 */           String str = SQLServerException.getErrString("R_connectionTimedOut");
/* 2346 */           this.selectedException = new IOException(str);
/*      */         } 
/* 2348 */         throw this.selectedException;
/*      */       }
/*      */     
/*      */     }
/* 2352 */     catch (InterruptedException interruptedException) {
/*      */       
/* 2354 */       close(this.selectedSocket);
/* 2355 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, interruptedException);
/*      */     }
/* 2357 */     catch (IOException iOException) {
/*      */       
/* 2359 */       close(this.selectedSocket);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2369 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.conn, iOException);
/*      */     } 
/*      */ 
/*      */     
/* 2373 */     assert this.result.equals(Result.SUCCESS) == true;
/* 2374 */     assert this.selectedSocket != null : "Bug in code. Selected Socket cannot be null here.";
/*      */     
/* 2376 */     return this.selectedSocket;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void findSocketUsingJavaNIO(InetAddress[] paramArrayOfInetAddress, int paramInt1, int paramInt2) throws IOException {
/* 2394 */     assert paramInt2 != 0 : "The timeout cannot be zero";
/* 2395 */     assert paramArrayOfInetAddress.length != 0 : "Number of inetAddresses should not be zero in this function";
/*      */     
/* 2397 */     Selector selector = null;
/* 2398 */     LinkedList<SocketChannel> linkedList = new LinkedList();
/* 2399 */     SocketChannel socketChannel = null;
/*      */ 
/*      */     
/*      */     try {
/* 2403 */       selector = Selector.open();
/*      */       
/* 2405 */       for (byte b = 0; b < paramArrayOfInetAddress.length; b++) {
/*      */         
/* 2407 */         SocketChannel socketChannel1 = SocketChannel.open();
/* 2408 */         linkedList.add(socketChannel1);
/*      */ 
/*      */         
/* 2411 */         socketChannel1.configureBlocking(false);
/*      */ 
/*      */         
/* 2414 */         byte b1 = 8;
/* 2415 */         SelectionKey selectionKey = socketChannel1.register(selector, b1);
/*      */         
/* 2417 */         socketChannel1.connect(new InetSocketAddress(paramArrayOfInetAddress[b], paramInt1));
/*      */         
/* 2419 */         if (logger.isLoggable(Level.FINER)) {
/* 2420 */           logger.finer(toString() + " initiated connection to address: " + paramArrayOfInetAddress[b] + ", portNumber: " + paramInt1);
/*      */         }
/*      */       } 
/* 2423 */       long l1 = System.currentTimeMillis();
/* 2424 */       long l2 = l1 + paramInt2;
/*      */ 
/*      */       
/* 2427 */       int i = paramArrayOfInetAddress.length;
/*      */ 
/*      */       
/*      */       while (true) {
/* 2431 */         long l = l2 - l1;
/*      */         
/* 2433 */         if (l <= 0L || socketChannel != null || i <= 0) {
/*      */           break;
/*      */         }
/*      */ 
/*      */         
/* 2438 */         int j = selector.select(l);
/*      */         
/* 2440 */         if (logger.isLoggable(Level.FINER)) {
/* 2441 */           logger.finer(toString() + " no of channels ready: " + j);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2447 */         if (j != 0) {
/*      */           
/* 2449 */           Set<SelectionKey> set = selector.selectedKeys();
/* 2450 */           Iterator<SelectionKey> iterator = set.iterator();
/*      */           
/* 2452 */           while (iterator.hasNext()) {
/*      */ 
/*      */             
/* 2455 */             SelectionKey selectionKey = iterator.next();
/* 2456 */             SocketChannel socketChannel1 = (SocketChannel)selectionKey.channel();
/*      */             
/* 2458 */             if (logger.isLoggable(Level.FINER)) {
/* 2459 */               logger.finer(toString() + " processing the channel :" + socketChannel1);
/*      */             }
/* 2461 */             boolean bool = false;
/*      */             
/*      */             try {
/* 2464 */               bool = socketChannel1.finishConnect();
/*      */ 
/*      */ 
/*      */               
/* 2468 */               assert bool == true : "finishConnect on channel:" + socketChannel1 + " cannot be false";
/*      */               
/* 2470 */               socketChannel = socketChannel1;
/*      */               
/* 2472 */               if (logger.isLoggable(Level.FINER)) {
/* 2473 */                 logger.finer(toString() + " selected the channel :" + socketChannel);
/*      */               }
/*      */               
/*      */               break;
/* 2477 */             } catch (IOException iOException) {
/*      */               
/* 2479 */               if (logger.isLoggable(Level.FINER)) {
/* 2480 */                 logger.finer(toString() + " the exception: " + iOException.getClass() + " with message: " + iOException.getMessage() + " occured while processing the channel: " + socketChannel1);
/*      */               }
/*      */               
/* 2483 */               updateSelectedException(iOException, toString());
/*      */ 
/*      */               
/* 2486 */               socketChannel1.close();
/*      */ 
/*      */ 
/*      */               
/* 2490 */               selectionKey.cancel();
/* 2491 */               iterator.remove();
/* 2492 */               i--;
/*      */             } 
/*      */           } 
/*      */         } 
/* 2496 */         l1 = System.currentTimeMillis();
/*      */       }
/*      */     
/* 2499 */     } catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2504 */       close(socketChannel);
/* 2505 */       throw iOException;
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2515 */       close(selector);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2523 */       for (SocketChannel socketChannel1 : linkedList) {
/*      */         
/* 2525 */         if (socketChannel1 != socketChannel)
/*      */         {
/* 2527 */           close(socketChannel1);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2533 */     if (socketChannel != null) {
/*      */ 
/*      */ 
/*      */       
/* 2537 */       socketChannel.configureBlocking(true);
/* 2538 */       this.selectedSocket = socketChannel.socket();
/* 2539 */       this.result = Result.SUCCESS;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Socket getDefaultSocket(String paramString, int paramInt1, int paramInt2) throws IOException {
/* 2556 */     InetSocketAddress inetSocketAddress = new InetSocketAddress(paramString, paramInt1);
/* 2557 */     return getConnectedSocket(inetSocketAddress, paramInt2);
/*      */   }
/*      */ 
/*      */   
/*      */   private Socket getConnectedSocket(InetAddress paramInetAddress, int paramInt1, int paramInt2) throws IOException {
/* 2562 */     InetSocketAddress inetSocketAddress = new InetSocketAddress(paramInetAddress, paramInt1);
/* 2563 */     return getConnectedSocket(inetSocketAddress, paramInt2);
/*      */   }
/*      */ 
/*      */   
/*      */   private Socket getConnectedSocket(InetSocketAddress paramInetSocketAddress, int paramInt) throws IOException {
/* 2568 */     assert paramInt != 0 : "timeout cannot be zero";
/* 2569 */     if (paramInetSocketAddress.isUnresolved())
/* 2570 */       throw new UnknownHostException(); 
/* 2571 */     this.selectedSocket = new Socket();
/* 2572 */     this.selectedSocket.connect(paramInetSocketAddress, paramInt);
/* 2573 */     return this.selectedSocket;
/*      */   }
/*      */ 
/*      */   
/*      */   private void findSocketUsingThreading(LinkedList<Inet6Address> paramLinkedList, int paramInt1, int paramInt2) throws IOException, InterruptedException {
/* 2578 */     assert paramInt2 != 0 : "The timeout cannot be zero";
/* 2579 */     assert !paramLinkedList.isEmpty() : "Number of inetAddresses should not be zero in this function";
/*      */     
/* 2581 */     LinkedList<Socket> linkedList = new LinkedList();
/* 2582 */     LinkedList<SocketConnector> linkedList1 = new LinkedList();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2588 */       this.noOfSpawnedThreads = paramLinkedList.size();
/* 2589 */       for (InetAddress inetAddress : paramLinkedList) {
/*      */         
/* 2591 */         Socket socket = new Socket();
/* 2592 */         linkedList.add(socket);
/*      */         
/* 2594 */         InetSocketAddress inetSocketAddress = new InetSocketAddress(inetAddress, paramInt1);
/*      */         
/* 2596 */         SocketConnector socketConnector = new SocketConnector(socket, inetSocketAddress, paramInt2, this);
/* 2597 */         linkedList1.add(socketConnector);
/*      */       } 
/*      */ 
/*      */       
/* 2601 */       synchronized (this.parentThreadLock)
/*      */       {
/* 2603 */         for (SocketConnector socketConnector : linkedList1)
/*      */         {
/* 2605 */           threadPoolExecutor.execute(socketConnector);
/*      */         }
/*      */         
/* 2608 */         long l1 = System.currentTimeMillis();
/* 2609 */         long l2 = l1 + paramInt2;
/*      */ 
/*      */ 
/*      */         
/*      */         while (true) {
/* 2614 */           long l = l2 - l1;
/*      */           
/* 2616 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2618 */             logger.finer(toString() + " TimeRemaining:" + l + "; Result:" + this.result + "; Max. open thread count: " + threadPoolExecutor.getLargestPoolSize() + "; Current open thread count:" + threadPoolExecutor.getActiveCount());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2632 */           if (l <= 0L || !this.result.equals(Result.UNKNOWN)) {
/*      */             break;
/*      */           }
/* 2635 */           this.parentThreadLock.wait(l);
/*      */           
/* 2637 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2639 */             logger.finer(toString() + " The parent thread wokeup.");
/*      */           }
/*      */ 
/*      */           
/* 2643 */           l1 = System.currentTimeMillis();
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */       
/* 2660 */       for (Socket socket : linkedList) {
/*      */         
/* 2662 */         if (socket != this.selectedSocket)
/*      */         {
/* 2664 */           close(socket);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Result getResult() {
/* 2677 */     return this.result;
/*      */   }
/*      */ 
/*      */   
/*      */   void close(Selector paramSelector) {
/* 2682 */     if (null != paramSelector) {
/*      */       
/* 2684 */       if (logger.isLoggable(Level.FINER)) {
/* 2685 */         logger.finer(toString() + ": Closing Selector");
/*      */       }
/*      */       
/*      */       try {
/* 2689 */         paramSelector.close();
/*      */       }
/* 2691 */       catch (IOException iOException) {
/*      */         
/* 2693 */         if (logger.isLoggable(Level.FINE)) {
/* 2694 */           logger.log(Level.FINE, toString() + ": Ignored the following error while closing Selector", iOException);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void close(Socket paramSocket) {
/* 2701 */     if (null != paramSocket) {
/*      */       
/* 2703 */       if (logger.isLoggable(Level.FINER)) {
/* 2704 */         logger.finer(toString() + ": Closing TCP socket:" + paramSocket);
/*      */       }
/*      */       
/*      */       try {
/* 2708 */         paramSocket.close();
/*      */       }
/* 2710 */       catch (IOException iOException) {
/*      */         
/* 2712 */         if (logger.isLoggable(Level.FINE)) {
/* 2713 */           logger.log(Level.FINE, toString() + ": Ignored the following error while closing socket", iOException);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   void close(SocketChannel paramSocketChannel) {
/* 2720 */     if (null != paramSocketChannel) {
/*      */       
/* 2722 */       if (logger.isLoggable(Level.FINER)) {
/* 2723 */         logger.finer(toString() + ": Closing TCP socket channel:" + paramSocketChannel);
/*      */       }
/*      */       
/*      */       try {
/* 2727 */         paramSocketChannel.close();
/*      */       }
/* 2729 */       catch (IOException iOException) {
/*      */         
/* 2731 */         if (logger.isLoggable(Level.FINE)) {
/* 2732 */           logger.log(Level.FINE, toString() + "Ignored the following error while closing socketChannel", iOException);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateResult(Socket paramSocket, IOException paramIOException, String paramString) {
/* 2753 */     if (this.result.equals(Result.UNKNOWN)) {
/*      */       
/* 2755 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2757 */         logger.finer("The following child thread is waiting for socketFinderLock:" + paramString);
/*      */       }
/*      */       
/* 2760 */       synchronized (this.socketFinderlock) {
/*      */         
/* 2762 */         if (logger.isLoggable(Level.FINER))
/*      */         {
/* 2764 */           logger.finer("The following child thread acquired socketFinderLock:" + paramString);
/*      */         }
/*      */         
/* 2767 */         if (this.result.equals(Result.UNKNOWN)) {
/*      */ 
/*      */ 
/*      */           
/* 2771 */           if (paramIOException == null && this.selectedSocket == null) {
/*      */             
/* 2773 */             this.selectedSocket = paramSocket;
/* 2774 */             this.result = Result.SUCCESS;
/* 2775 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2777 */               logger.finer("The socket of the following thread has been chosen:" + paramString);
/*      */             }
/*      */           } 
/*      */ 
/*      */           
/* 2782 */           if (paramIOException != null)
/*      */           {
/* 2784 */             updateSelectedException(paramIOException, paramString);
/*      */           }
/*      */         } 
/*      */         
/* 2788 */         this.noOfThreadsThatNotified++;
/*      */ 
/*      */ 
/*      */         
/* 2792 */         if (this.noOfThreadsThatNotified >= this.noOfSpawnedThreads && this.result.equals(Result.UNKNOWN))
/*      */         {
/*      */           
/* 2795 */           this.result = Result.FAILURE;
/*      */         }
/*      */         
/* 2798 */         if (!this.result.equals(Result.UNKNOWN)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2822 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2824 */             logger.finer("The following child thread is waiting for parentThreadLock:" + paramString);
/*      */           }
/*      */           
/* 2827 */           synchronized (this.parentThreadLock) {
/*      */             
/* 2829 */             if (logger.isLoggable(Level.FINER))
/*      */             {
/* 2831 */               logger.finer("The following child thread acquired parentThreadLock:" + paramString);
/*      */             }
/*      */             
/* 2834 */             this.parentThreadLock.notify();
/*      */           } 
/*      */           
/* 2837 */           if (logger.isLoggable(Level.FINER))
/*      */           {
/* 2839 */             logger.finer("The following child thread released parentThreadLock and notified the parent thread:" + paramString);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 2844 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2846 */         logger.finer("The following child thread released socketFinderLock:" + paramString);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSelectedException(IOException paramIOException, String paramString) {
/* 2861 */     boolean bool = false;
/* 2862 */     if (this.selectedException == null) {
/*      */       
/* 2864 */       this.selectedException = paramIOException;
/* 2865 */       bool = true;
/*      */     }
/* 2867 */     else if (!(paramIOException instanceof java.net.SocketTimeoutException) && this.selectedException instanceof java.net.SocketTimeoutException) {
/*      */       
/* 2869 */       this.selectedException = paramIOException;
/* 2870 */       bool = true;
/*      */     } 
/*      */     
/* 2873 */     if (bool)
/*      */     {
/* 2875 */       if (logger.isLoggable(Level.FINER))
/*      */       {
/* 2877 */         logger.finer("The selected exception is updated to the following: ExceptionType:" + paramIOException.getClass() + "; ExceptionMessage:" + paramIOException.getMessage() + "; by the following thread:" + paramString);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2889 */     return this.traceID;
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SocketFinder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */