/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TDSTokenHandler
/*     */ {
/*     */   final String logContext;
/*     */   private StreamError databaseError;
/*     */   
/*     */   final StreamError getDatabaseError() {
/* 168 */     return this.databaseError;
/*     */   }
/*     */   
/*     */   TDSTokenHandler(String paramString) {
/* 172 */     this.logContext = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onSSPI(TDSReader paramTDSReader) throws SQLServerException {
/* 177 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 178 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onLoginAck(TDSReader paramTDSReader) throws SQLServerException {
/* 183 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 184 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onFeatureExtensionAck(TDSReader paramTDSReader) throws SQLServerException {
/* 189 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onEnvChange(TDSReader paramTDSReader) throws SQLServerException {
/* 195 */     paramTDSReader.getConnection().processEnvChange(paramTDSReader);
/* 196 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onRetStatus(TDSReader paramTDSReader) throws SQLServerException {
/* 201 */     (new StreamRetStatus()).setFromTDS(paramTDSReader);
/* 202 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onRetValue(TDSReader paramTDSReader) throws SQLServerException {
/* 207 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 208 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onDone(TDSReader paramTDSReader) throws SQLServerException {
/* 213 */     StreamDone streamDone = new StreamDone();
/* 214 */     streamDone.setFromTDS(paramTDSReader);
/* 215 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onError(TDSReader paramTDSReader) throws SQLServerException {
/* 220 */     if (null == this.databaseError) {
/*     */       
/* 222 */       this.databaseError = new StreamError();
/* 223 */       this.databaseError.setFromTDS(paramTDSReader);
/*     */     }
/*     */     else {
/*     */       
/* 227 */       (new StreamError()).setFromTDS(paramTDSReader);
/*     */     } 
/*     */     
/* 230 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onInfo(TDSReader paramTDSReader) throws SQLServerException {
/* 235 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 236 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onOrder(TDSReader paramTDSReader) throws SQLServerException {
/* 241 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 242 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onColMetaData(TDSReader paramTDSReader) throws SQLServerException {
/* 247 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onRow(TDSReader paramTDSReader) throws SQLServerException {
/* 253 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 254 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onNBCRow(TDSReader paramTDSReader) throws SQLServerException {
/* 259 */     TDSParser.throwUnexpectedTokenException(paramTDSReader, this.logContext);
/* 260 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onColInfo(TDSReader paramTDSReader) throws SQLServerException {
/* 265 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 266 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean onTabName(TDSReader paramTDSReader) throws SQLServerException {
/* 271 */     TDSParser.ignoreLengthPrefixedToken(paramTDSReader);
/* 272 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   void onEOF(TDSReader paramTDSReader) throws SQLServerException {
/* 277 */     if (null != getDatabaseError())
/*     */     {
/* 279 */       SQLServerException.makeFromDatabaseError(paramTDSReader.getConnection(), null, getDatabaseError().getMessage(), getDatabaseError(), false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean onFedAuthInfo(TDSReader paramTDSReader) throws SQLServerException {
/* 290 */     paramTDSReader.getConnection().processFedAuthInfo(paramTDSReader, this);
/* 291 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\TDSTokenHandler.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */