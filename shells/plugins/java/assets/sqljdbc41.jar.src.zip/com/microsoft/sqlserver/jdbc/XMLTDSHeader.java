/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XMLTDSHeader
/*    */ {
/*    */   private final String databaseName;
/*    */   private final String owningSchema;
/*    */   private final String xmlSchemaCollection;
/*    */   
/*    */   XMLTDSHeader(TDSReader paramTDSReader) throws SQLServerException {
/* 34 */     if (0 != paramTDSReader.readUnsignedByte()) {
/*    */ 
/*    */       
/* 37 */       this.databaseName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 38 */       this.owningSchema = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 39 */       this.xmlSchemaCollection = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/*    */     }
/*    */     else {
/*    */       
/* 43 */       this.xmlSchemaCollection = null;
/* 44 */       this.owningSchema = null;
/* 45 */       this.databaseName = null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\XMLTDSHeader.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */