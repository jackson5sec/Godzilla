/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import javax.xml.bind.DatatypeConverter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class SQLServerAeadAes256CbcHmac256Factory
/*    */   extends SQLServerEncryptionAlgorithmFactory
/*    */ {
/* 16 */   private byte algorithmVersion = 1;
/* 17 */   private ConcurrentHashMap<String, SQLServerAeadAes256CbcHmac256Algorithm> encryptionAlgorithms = new ConcurrentHashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SQLServerEncryptionAlgorithm create(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString) throws SQLServerException {
/* 24 */     assert paramSQLServerSymmetricKey != null;
/* 25 */     if (paramSQLServerEncryptionType != SQLServerEncryptionType.Deterministic && paramSQLServerEncryptionType != SQLServerEncryptionType.Randomized) {
/* 26 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidEncryptionType"));
/* 27 */       Object[] arrayOfObject = { paramSQLServerEncryptionType, paramString, "'" + SQLServerEncryptionType.Deterministic + "," + SQLServerEncryptionType.Randomized + "'" };
/* 28 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*    */     } 
/*    */     
/* 31 */     String str = "";
/*    */     
/*    */     try {
/* 34 */       StringBuffer stringBuffer = new StringBuffer();
/* 35 */       stringBuffer.append(DatatypeConverter.printBase64Binary((new String(paramSQLServerSymmetricKey.getRootKey(), "UTF-8")).getBytes()));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 44 */       stringBuffer.append(":");
/* 45 */       stringBuffer.append(paramSQLServerEncryptionType);
/* 46 */       stringBuffer.append(":");
/* 47 */       stringBuffer.append(this.algorithmVersion);
/*    */       
/* 49 */       str = stringBuffer.toString();
/*    */ 
/*    */ 
/*    */       
/* 53 */       if (!this.encryptionAlgorithms.containsKey(str)) {
/* 54 */         SQLServerAeadAes256CbcHmac256EncryptionKey sQLServerAeadAes256CbcHmac256EncryptionKey = new SQLServerAeadAes256CbcHmac256EncryptionKey(paramSQLServerSymmetricKey.getRootKey(), "AEAD_AES_256_CBC_HMAC_SHA256");
/* 55 */         SQLServerAeadAes256CbcHmac256Algorithm sQLServerAeadAes256CbcHmac256Algorithm = new SQLServerAeadAes256CbcHmac256Algorithm(sQLServerAeadAes256CbcHmac256EncryptionKey, paramSQLServerEncryptionType, this.algorithmVersion);
/* 56 */         this.encryptionAlgorithms.putIfAbsent(str, sQLServerAeadAes256CbcHmac256Algorithm);
/*    */       
/*    */       }
/*    */     
/*    */     }
/* 61 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 62 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*    */       
/* 64 */       Object[] arrayOfObject = { "UTF-8" };
/* 65 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*    */     } 
/* 67 */     return this.encryptionAlgorithms.get(str);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerAeadAes256CbcHmac256Factory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */