package com.microsoft.sqlserver.jdbc;

abstract class ColumnFilter {
  abstract Object apply(Object paramObject, JDBCType paramJDBCType) throws SQLServerException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\ColumnFilter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */