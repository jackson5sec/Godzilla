/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.DatagramPacket;
/*      */ import java.net.DatagramSocket;
/*      */ import java.net.IDN;
/*      */ import java.net.InetAddress;
/*      */ import java.net.SocketException;
/*      */ import java.net.UnknownHostException;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.NClob;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLClientInfoException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLPermission;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Struct;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.UUID;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.xml.bind.DatatypeConverter;
/*      */ 
/*      */ public class SQLServerConnection
/*      */   implements ISQLServerConnection {
/*      */   long timerExpire;
/*      */   boolean attemptRefreshTokenLocked = false;
/*      */   private boolean fedAuthRequiredByUser = false;
/*      */   private boolean fedAuthRequiredPreLoginResponse = false;
/*      */   private boolean federatedAuthenticationAcknowledged = false;
/*      */   private boolean federatedAuthenticationRequested = false;
/*      */   private boolean federatedAuthenticationInfoRequested = false;
/*   54 */   private FederatedAuthenticationFeatureExtensionData fedAuthFeatureExtensionData = null;
/*   55 */   private String authenticationString = null;
/*   56 */   private byte[] accessTokenInByte = null;
/*      */   
/*   58 */   private SqlFedAuthToken fedAuthToken = null; private static final float TIMEOUTSTEP = 0.08F; static final int TnirFirstAttemptTimeoutMs = 500; private static final int INTERMITTENT_TLS_MAX_RETRY = 5;
/*      */   
/*      */   SqlFedAuthToken getAuthenticationResult() {
/*   61 */     return this.fedAuthToken;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   class FederatedAuthenticationFeatureExtensionData
/*      */   {
/*      */     boolean fedAuthRequiredPreLoginResponse;
/*      */     
/*   70 */     int libraryType = -1;
/*   71 */     byte[] accessToken = null;
/*   72 */     SqlAuthentication authentication = null;
/*      */     
/*      */     FederatedAuthenticationFeatureExtensionData(int param1Int, String param1String, boolean param1Boolean) throws SQLServerException {
/*   75 */       this.libraryType = param1Int;
/*   76 */       this.fedAuthRequiredPreLoginResponse = param1Boolean;
/*      */       
/*   78 */       switch (param1String.toUpperCase(Locale.ENGLISH).trim()) {
/*      */         case "ACTIVEDIRECTORYPASSWORD":
/*   80 */           this.authentication = SqlAuthentication.ActiveDirectoryPassword;
/*      */           return;
/*      */         case "ACTIVEDIRECTORYINTEGRATED":
/*   83 */           this.authentication = SqlAuthentication.ActiveDirectoryIntegrated;
/*      */           return;
/*      */       } 
/*      */       assert false;
/*   87 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/*   88 */       Object[] arrayOfObject = { "authentication", param1String };
/*   89 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     }
/*      */ 
/*      */     
/*      */     FederatedAuthenticationFeatureExtensionData(int param1Int, boolean param1Boolean, byte[] param1ArrayOfbyte) {
/*   94 */       this.libraryType = param1Int;
/*   95 */       this.fedAuthRequiredPreLoginResponse = param1Boolean;
/*   96 */       this.accessToken = param1ArrayOfbyte;
/*      */     }
/*      */   }
/*      */   
/*      */   class SqlFedAuthInfo
/*      */   {
/*      */     private String spn;
/*      */     private String stsurl;
/*      */     
/*      */     public String toString() {
/*  106 */       return "STSURL: " + this.stsurl + ", SPN: " + this.spn;
/*      */     }
/*      */   }
/*      */   
/*      */   final class SqlFedAuthToken {
/*      */     private final Date expiresOn;
/*      */     private final String accessToken;
/*      */     
/*      */     SqlFedAuthToken(String param1String, long param1Long) {
/*  115 */       this.accessToken = param1String;
/*      */       
/*  117 */       Date date = new Date();
/*  118 */       date.setTime(date.getTime() + param1Long * 1000L);
/*  119 */       this.expiresOn = date;
/*      */     }
/*      */     
/*      */     Date getExpiresOnDate() {
/*  123 */       return this.expiresOn;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class ActiveDirectoryAuthentication
/*      */   {
/*      */     private static final String jdbcFedauthClientId = "7f98cb04-cd1e-40df-9140-3bf7e2cea4db";
/*      */     
/*      */     private static final String AdalGetAccessTokenFunctionName = "ADALGetAccessToken";
/*      */     
/*      */     private static final int GetAccessTokenSuccess = 0;
/*      */     
/*      */     private static final int GetAccessTokenInvalidGrant = 1;
/*      */     
/*      */     private static final int GetAccessTokenTansisentError = 2;
/*      */     private static final int GetAccessTokenOtherError = 3;
/*      */   }
/*      */   
/*      */   private enum State
/*      */   {
/*  144 */     Initialized,
/*  145 */     Connected,
/*  146 */     Opened,
/*  147 */     Closed;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isRoutedInCurrentAttempt = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   private ServerPortPlaceHolder routingInfo = null;
/*      */ 
/*      */   
/*      */   private static final String callAbortPerm = "callAbort";
/*      */ 
/*      */   
/*  171 */   private boolean sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue(); private boolean lastUpdateCount; boolean sendStringParametersAsUnicode() {
/*  172 */     return this.sendStringParametersAsUnicode;
/*      */   } final boolean useLastUpdateCount() {
/*  174 */     return this.lastUpdateCount;
/*      */   }
/*      */   
/*  177 */   private boolean serverNameAsACE = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue(); private boolean multiSubnetFailover; private boolean transparentNetworkIPResolution; boolean serverNameAsACE() {
/*  178 */     return this.serverNameAsACE;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean getMultiSubnetFailover() {
/*  184 */     return this.multiSubnetFailover;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean getTransparentNetworkIPResolution() {
/*  190 */     return this.transparentNetworkIPResolution;
/*      */   }
/*      */ 
/*      */   
/*  194 */   private ApplicationIntent applicationIntent = null; private int nLockTimeout; private String selectMethod; private String responseBuffering;
/*      */   
/*      */   final ApplicationIntent getApplicationIntent() {
/*  197 */     return this.applicationIntent;
/*      */   }
/*      */ 
/*      */   
/*      */   final String getSelectMethod() {
/*  202 */     return this.selectMethod;
/*      */   } final String getResponseBuffering() {
/*  204 */     return this.responseBuffering;
/*      */   }
/*  206 */   private boolean sendTimeAsDatetime = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue();
/*      */ 
/*      */   
/*      */   public final synchronized boolean getSendTimeAsDatetime() {
/*  210 */     return (!isKatmaiOrLater() || this.sendTimeAsDatetime);
/*      */   }
/*      */ 
/*      */   
/*      */   final int baseYear() {
/*  215 */     return getSendTimeAsDatetime() ? 1970 : 1900;
/*      */   }
/*      */   
/*  218 */   private byte requestedEncryptionLevel = -1; private boolean trustServerCertificate;
/*      */   
/*      */   final byte getRequestedEncryptionLevel() {
/*  221 */     assert -1 != this.requestedEncryptionLevel;
/*  222 */     return this.requestedEncryptionLevel;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean trustServerCertificate() {
/*  227 */     return this.trustServerCertificate;
/*      */   }
/*  229 */   private byte negotiatedEncryptionLevel = -1; static final String RESERVED_PROVIDER_NAME_PREFIX = "MSSQL_";
/*      */   
/*      */   final byte getNegotiatedEncryptionLevel() {
/*  232 */     assert -1 != this.negotiatedEncryptionLevel;
/*  233 */     return this.negotiatedEncryptionLevel;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  238 */   String columnEncryptionSetting = null;
/*      */   boolean isColumnEncryptionSettingEnabled() {
/*  240 */     return this.columnEncryptionSetting.equalsIgnoreCase(ColumnEncryptionSetting.Enabled.toString());
/*      */   }
/*      */   
/*  243 */   String keyStoreAuthentication = null;
/*  244 */   String keyStoreSecret = null;
/*  245 */   String keyStoreLocation = null;
/*      */   private boolean serverSupportsColumnEncryption = false;
/*      */   static boolean isWindows;
/*      */   
/*      */   boolean getServerSupportsColumnEncryption() {
/*  250 */     return this.serverSupportsColumnEncryption;
/*      */   }
/*      */   
/*  253 */   static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalSystemColumnEncryptionKeyStoreProviders = new HashMap<>();
/*      */ 
/*      */   
/*      */   static {
/*  257 */     if (System.getProperty("os.name").toLowerCase(Locale.ENGLISH).startsWith("windows")) {
/*      */       
/*  259 */       isWindows = true;
/*  260 */       SQLServerColumnEncryptionCertificateStoreProvider sQLServerColumnEncryptionCertificateStoreProvider = new SQLServerColumnEncryptionCertificateStoreProvider();
/*  261 */       globalSystemColumnEncryptionKeyStoreProviders.put(sQLServerColumnEncryptionCertificateStoreProvider.getName(), sQLServerColumnEncryptionCertificateStoreProvider);
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  267 */       isWindows = false;
/*      */     } 
/*      */   }
/*  270 */   static Map<String, SQLServerColumnEncryptionKeyStoreProvider> globalCustomColumnEncryptionKeyStoreProviders = null;
/*      */   
/*  272 */   Map<String, SQLServerColumnEncryptionKeyStoreProvider> systemColumnEncryptionKeyStoreProvider = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void registerColumnEncryptionKeyStoreProviders(Map<String, SQLServerColumnEncryptionKeyStoreProvider> paramMap) throws SQLServerException {
/*  278 */     loggerExternal.entering(SQLServerConnection.class.getName(), "registerColumnEncryptionKeyStoreProviders", "Registering Column Encryption Key Store Providers");
/*      */     
/*  280 */     if (null == paramMap)
/*      */     {
/*  282 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderMapNull"), null, 0, false);
/*      */     }
/*      */     
/*  285 */     if (null != globalCustomColumnEncryptionKeyStoreProviders)
/*      */     {
/*  287 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomKeyStoreProviderSetOnce"), null, 0, false);
/*      */     }
/*      */     
/*  290 */     globalCustomColumnEncryptionKeyStoreProviders = new HashMap<>();
/*      */     
/*  292 */     for (Map.Entry<String, SQLServerColumnEncryptionKeyStoreProvider> entry : paramMap.entrySet()) {
/*      */       
/*  294 */       String str = (String)entry.getKey();
/*  295 */       if (null == str || 0 == str.length())
/*      */       {
/*  297 */         throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyCustomKeyStoreProviderName"), null, 0, false);
/*      */       }
/*  299 */       if (str.substring(0, 6).equalsIgnoreCase("MSSQL_")) {
/*      */         
/*  301 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCustomKeyStoreProviderName"));
/*  302 */         Object[] arrayOfObject = { str, "MSSQL_" };
/*  303 */         throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*      */       } 
/*  305 */       if (null == entry.getValue()) {
/*      */         
/*  307 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CustomKeyStoreProviderValueNull"));
/*  308 */         Object[] arrayOfObject = { str, "MSSQL_" };
/*  309 */         throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*      */       } 
/*  311 */       globalCustomColumnEncryptionKeyStoreProviders.put((String)entry.getKey(), (SQLServerColumnEncryptionKeyStoreProvider)entry.getValue());
/*      */     } 
/*      */     
/*  314 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "registerColumnEncryptionKeyStoreProviders", "Number of Key store providers that are registered:" + globalCustomColumnEncryptionKeyStoreProviders.size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalSystemColumnEncryptionKeyStoreProvider(String paramString) {
/*  323 */     if (null != globalSystemColumnEncryptionKeyStoreProviders && globalSystemColumnEncryptionKeyStoreProviders.containsKey(paramString))
/*      */     {
/*      */       
/*  326 */       return globalSystemColumnEncryptionKeyStoreProviders.get(paramString);
/*      */     }
/*  328 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   static synchronized String getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders() {
/*  333 */     if (null != globalCustomColumnEncryptionKeyStoreProviders) {
/*  334 */       return globalCustomColumnEncryptionKeyStoreProviders.keySet().toString();
/*      */     }
/*  336 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized String getAllSystemColumnEncryptionKeyStoreProviders() {
/*  341 */     String str = "";
/*  342 */     if (0 != this.systemColumnEncryptionKeyStoreProvider.size())
/*  343 */       str = this.systemColumnEncryptionKeyStoreProvider.keySet().toString(); 
/*  344 */     if (0 != globalSystemColumnEncryptionKeyStoreProviders.size())
/*  345 */       str = str + "," + globalSystemColumnEncryptionKeyStoreProviders.keySet().toString(); 
/*  346 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   static synchronized SQLServerColumnEncryptionKeyStoreProvider getGlobalCustomColumnEncryptionKeyStoreProvider(String paramString) {
/*  351 */     if (null != globalCustomColumnEncryptionKeyStoreProviders && globalCustomColumnEncryptionKeyStoreProviders.containsKey(paramString))
/*      */     {
/*      */       
/*  354 */       return globalCustomColumnEncryptionKeyStoreProviders.get(paramString);
/*      */     }
/*  356 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   synchronized SQLServerColumnEncryptionKeyStoreProvider getSystemColumnEncryptionKeyStoreProvider(String paramString) {
/*  361 */     if (null != this.systemColumnEncryptionKeyStoreProvider && this.systemColumnEncryptionKeyStoreProvider.containsKey(paramString))
/*      */     {
/*      */       
/*  364 */       return this.systemColumnEncryptionKeyStoreProvider.get(paramString);
/*      */     }
/*      */ 
/*      */     
/*  368 */     return null;
/*      */   }
/*      */ 
/*      */   
/*  372 */   private String trustedServerNameAE = null;
/*  373 */   private static Map<String, List<String>> columnEncryptionTrustedMasterKeyPaths = new HashMap<>();
/*      */   Properties activeConnectionProperties;
/*      */   
/*      */   public static synchronized void setColumnEncryptionTrustedMasterKeyPaths(Map<String, List<String>> paramMap) {
/*  377 */     loggerExternal.entering(SQLServerConnection.class.getName(), "setColumnEncryptionTrustedMasterKeyPaths", "Setting Trusted Master Key Paths");
/*      */ 
/*      */     
/*  380 */     columnEncryptionTrustedMasterKeyPaths.clear();
/*  381 */     for (Map.Entry<String, List<String>> entry : paramMap.entrySet())
/*      */     {
/*  383 */       columnEncryptionTrustedMasterKeyPaths.put(((String)entry.getKey()).toUpperCase(), (List<String>)entry.getValue());
/*      */     }
/*      */     
/*  386 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "setColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
/*      */   }
/*      */ 
/*      */   
/*      */   public static synchronized void updateColumnEncryptionTrustedMasterKeyPaths(String paramString, List<String> paramList) {
/*  391 */     loggerExternal.entering(SQLServerConnection.class.getName(), "updateColumnEncryptionTrustedMasterKeyPaths", "Updating Trusted Master Key Paths");
/*      */ 
/*      */     
/*  394 */     columnEncryptionTrustedMasterKeyPaths.put(paramString.toUpperCase(), paramList);
/*      */     
/*  396 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "updateColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
/*      */   }
/*      */ 
/*      */   
/*      */   public static synchronized void removeColumnEncryptionTrustedMasterKeyPaths(String paramString) {
/*  401 */     loggerExternal.entering(SQLServerConnection.class.getName(), "removeColumnEncryptionTrustedMasterKeyPaths", "Removing Trusted Master Key Paths");
/*      */ 
/*      */     
/*  404 */     columnEncryptionTrustedMasterKeyPaths.remove(paramString.toUpperCase());
/*      */     
/*  406 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "removeColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + columnEncryptionTrustedMasterKeyPaths.size());
/*      */   }
/*      */ 
/*      */   
/*      */   public static synchronized Map<String, List<String>> getColumnEncryptionTrustedMasterKeyPaths() {
/*  411 */     loggerExternal.entering(SQLServerConnection.class.getName(), "getColumnEncryptionTrustedMasterKeyPaths", "Getting Trusted Master Key Paths");
/*      */     
/*  413 */     HashMap<Object, Object> hashMap = new HashMap<>();
/*      */     
/*  415 */     for (Map.Entry<String, List<String>> entry : columnEncryptionTrustedMasterKeyPaths.entrySet()) {
/*  416 */       hashMap.put(entry.getKey(), entry.getValue());
/*      */     }
/*      */     
/*  419 */     loggerExternal.exiting(SQLServerConnection.class.getName(), "getColumnEncryptionTrustedMasterKeyPaths", "Number of Trusted Master Key Paths: " + hashMap.size());
/*      */     
/*  421 */     return (Map)hashMap;
/*      */   }
/*      */ 
/*      */   
/*      */   static synchronized List<String> getColumnEncryptionTrustedMasterKeyPaths(String paramString, Boolean[] paramArrayOfBoolean) {
/*  426 */     if (columnEncryptionTrustedMasterKeyPaths.containsKey(paramString)) {
/*      */       
/*  428 */       paramArrayOfBoolean[0] = Boolean.valueOf(true);
/*  429 */       return columnEncryptionTrustedMasterKeyPaths.get(paramString);
/*      */     } 
/*      */ 
/*      */     
/*  433 */     paramArrayOfBoolean[0] = Boolean.valueOf(false);
/*  434 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  439 */   private boolean integratedSecurity = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue();
/*  440 */   private AuthenticationScheme intAuthScheme = AuthenticationScheme.nativeAuthentication;
/*      */   
/*  442 */   ServerPortPlaceHolder currentConnectPlaceHolder = null;
/*      */   
/*      */   String sqlServerVersion;
/*      */   boolean xopenStates;
/*      */   private boolean databaseAutoCommitMode;
/*      */   private boolean inXATransaction = false;
/*  448 */   private byte[] transactionDescriptor = new byte[8];
/*      */   
/*      */   private boolean rolledBackTransaction;
/*      */   
/*      */   final boolean rolledBackTransaction() {
/*  453 */     return this.rolledBackTransaction;
/*      */   }
/*  455 */   private State state = State.Initialized; static final int maxDecimalPrecision = 38; static final int defaultDecimalPrecision = 18; final String traceID; private int maxFieldSize; private int maxRows;
/*      */   private SQLCollation databaseCollation;
/*      */   
/*      */   private void setState(State paramState) {
/*  459 */     this.state = paramState;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isSessionUnAvailable() {
/*  465 */     return !this.state.equals(State.Opened);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setMaxFieldSize(int paramInt) throws SQLServerException {
/*  477 */     if (this.maxFieldSize != paramInt) {
/*      */       
/*  479 */       if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */       {
/*  481 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*      */       
/*  484 */       connectionCommand("SET TEXTSIZE " + ((0 == paramInt) ? Integer.MAX_VALUE : paramInt), "setMaxFieldSize");
/*  485 */       this.maxFieldSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initResettableValues() {
/*  496 */     this.rolledBackTransaction = false;
/*  497 */     this.transactionIsolationLevel = 2;
/*  498 */     this.maxFieldSize = 0;
/*  499 */     this.maxRows = 0;
/*  500 */     this.nLockTimeout = -1;
/*  501 */     this.databaseAutoCommitMode = true;
/*  502 */     this.holdability = 1;
/*  503 */     this.sqlWarnings = null;
/*  504 */     this.sCatalog = this.originalCatalog;
/*  505 */     this.databaseMetaData = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setMaxRows(int paramInt) throws SQLServerException {
/*  513 */     if (this.maxRows != paramInt) {
/*      */       
/*  515 */       if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */       {
/*  517 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*  519 */       connectionCommand("SET ROWCOUNT " + paramInt, "setMaxRows");
/*  520 */       this.maxRows = paramInt;
/*      */     } 
/*      */   }
/*      */   
/*      */   final SQLCollation getDatabaseCollation() {
/*  525 */     return this.databaseCollation;
/*      */   }
/*  527 */   private static int baseConnectionID = 0;
/*      */   
/*  529 */   private String sCatalog = "master";
/*      */   
/*  531 */   private String originalCatalog = "master";
/*      */   
/*      */   private int transactionIsolationLevel;
/*      */   private SQLServerPooledConnection pooledConnectionParent;
/*      */   private DatabaseMetaData databaseMetaData;
/*  536 */   private int nNextSavePointId = 10000;
/*      */   
/*  538 */   private static final Logger connectionlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerConnection");
/*      */   
/*  540 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Connection");
/*      */ 
/*      */ 
/*      */   
/*      */   private final String loggingClassName;
/*      */ 
/*      */   
/*  547 */   private String failoverPartnerServerProvided = null; private int holdability;
/*      */   
/*      */   final int getHoldabilityInternal() {
/*  550 */     return this.holdability;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  555 */   private int tdsPacketSize = 4096;
/*  556 */   private int requestedPacketSize = 8000; private TDSChannel tdsChannel; final int getTDSPacketSize() {
/*  557 */     return this.tdsPacketSize;
/*      */   }
/*      */ 
/*      */   
/*  561 */   private TDSCommand currentCommand = null;
/*      */   
/*  563 */   private int tdsVersion = 0; private int serverMajorVersion;
/*      */   private SQLServerConnectionPoolProxy proxy;
/*      */   
/*      */   final boolean isKatmaiOrLater() {
/*  567 */     assert 0 != this.tdsVersion;
/*  568 */     assert this.tdsVersion >= 1913192450;
/*  569 */     return (this.tdsVersion >= 1930100739);
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean isDenaliOrLater() {
/*  574 */     return (this.tdsVersion >= 1946157060);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int getServerMajorVersion() {
/*  580 */     return this.serverMajorVersion;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  585 */   private UUID clientConnectionId = null;
/*      */   
/*      */   static final int MAX_SQL_LOGIN_NAME_WCHARS = 128;
/*      */ 
/*      */   
/*      */   public UUID getClientConnectionId() throws SQLServerException {
/*  591 */     checkClosed();
/*  592 */     return this.clientConnectionId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final UUID getClientConIdInternal() {
/*  599 */     return this.clientConnectionId;
/*      */   }
/*      */ 
/*      */   
/*      */   final boolean attachConnId() {
/*  604 */     return this.state.equals(State.Connected);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setFailoverPartnerServerProvided(String paramString) {
/*  631 */     this.failoverPartnerServerProvided = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setAssociatedProxy(SQLServerConnectionPoolProxy paramSQLServerConnectionPoolProxy) {
/*  637 */     this.proxy = paramSQLServerConnectionPoolProxy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Connection getConnection() {
/*  648 */     if (null != this.proxy) {
/*  649 */       return this.proxy;
/*      */     }
/*  651 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   final void resetPooledConnection() {
/*  656 */     this.tdsChannel.resetPooledConnection();
/*  657 */     initResettableValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized int nextConnectionID() {
/*  666 */     baseConnectionID++;
/*  667 */     return baseConnectionID;
/*      */   }
/*      */   
/*      */   Logger getConnectionLogger() {
/*  671 */     return connectionlogger;
/*      */   }
/*      */ 
/*      */   
/*      */   String getClassNameLogging() {
/*  676 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  685 */     if (null != this.clientConnectionId) {
/*  686 */       return this.traceID + " ClientConnectionId: " + this.clientConnectionId.toString();
/*      */     }
/*  688 */     return this.traceID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void NotImplemented() throws SQLServerException {
/*  698 */     SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_notSupported"), (String)null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkClosed() throws SQLServerException {
/*  708 */     if (isSessionUnAvailable())
/*      */     {
/*  710 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_connectionIsClosed"), (String)null, false);
/*      */     }
/*      */     
/*  713 */     if (null != this.fedAuthToken && 
/*  714 */       Util.checkIfNeedNewAccessToken(this))
/*      */     {
/*  716 */       connect(this.activeConnectionProperties, null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean booleanPropertyOn(String paramString1, String paramString2) throws SQLServerException {
/*  731 */     if (null == paramString2) return false; 
/*  732 */     String str = paramString2.toLowerCase(Locale.US);
/*      */     
/*  734 */     if (str.equals("true")) return true; 
/*  735 */     if (str.equals("false")) return false; 
/*  736 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidBooleanValue"));
/*  737 */     Object[] arrayOfObject = { new String(paramString1) };
/*  738 */     SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     
/*  740 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void ValidateMaxSQLLoginName(String paramString1, String paramString2) throws SQLServerException {
/*  756 */     if (paramString2 != null && paramString2.length() > 128) {
/*      */       
/*  758 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_propertyMaximumExceedsChars"));
/*  759 */       Object[] arrayOfObject = { paramString1, Integer.toString(128) };
/*  760 */       SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   Connection connect(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException {
/*  766 */     int i = 0;
/*  767 */     long l = System.currentTimeMillis();
/*      */     
/*  769 */     byte b = 0;
/*      */     
/*      */     while (true) {
/*      */       try {
/*  773 */         return connectInternal(paramProperties, paramSQLServerPooledConnection);
/*      */       }
/*  775 */       catch (SQLServerException sQLServerException) {
/*      */ 
/*      */         
/*  778 */         if (7 != sQLServerException.getDriverErrorCode())
/*      */         {
/*      */           
/*  781 */           throw sQLServerException;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  788 */         if (0 == b) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  793 */           i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  794 */           String str = paramProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/*  795 */           if (null != str && str.length() > 0)
/*      */           {
/*  797 */             i = Integer.parseInt(str);
/*      */           }
/*      */         } 
/*      */         
/*  801 */         b++;
/*  802 */         long l1 = (System.currentTimeMillis() - l) / 1000L;
/*      */         
/*  804 */         if (5 < b) {
/*      */ 
/*      */           
/*  807 */           if (connectionlogger.isLoggable(Level.FINE))
/*      */           {
/*  809 */             connectionlogger.fine("Connection failed during SSL handshake. Maximum retry attempt (5) reached.  ");
/*      */           }
/*  811 */           throw sQLServerException;
/*      */         } 
/*  813 */         if (l1 >= i) {
/*      */ 
/*      */           
/*  816 */           if (connectionlogger.isLoggable(Level.FINE))
/*      */           {
/*  818 */             connectionlogger.fine("Connection failed during SSL handshake. Not retrying as timeout expired.");
/*      */           }
/*  820 */           throw sQLServerException;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  825 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/*  827 */           connectionlogger.fine("Connection failed during SSL handshake. Retrying due to an intermittent TLS 1.2 failure issue. Retry attempt = " + b + ".");
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void registerKeyStoreProviderOnConnection(String paramString1, String paramString2, String paramString3) throws SQLServerException {
/*  837 */     if (null == paramString1) {
/*      */ 
/*      */       
/*  840 */       if (null != paramString2) {
/*      */         
/*  842 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/*  843 */         Object[] arrayOfObject = { "keyStoreSecret" };
/*  844 */         throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */       } 
/*  846 */       if (null != paramString3) {
/*      */         
/*  848 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_keyStoreAuthenticationNotSet"));
/*  849 */         Object[] arrayOfObject = { "keyStoreLocation" };
/*  850 */         throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */       } 
/*      */     } else {
/*      */       SQLServerColumnEncryptionJavaKeyStoreProvider sQLServerColumnEncryptionJavaKeyStoreProvider;
/*      */       
/*  855 */       KeyStoreAuthentication keyStoreAuthentication = KeyStoreAuthentication.valueOfString(paramString1);
/*  856 */       switch (keyStoreAuthentication) {
/*      */ 
/*      */         
/*      */         case ActiveDirectoryPassword:
/*  860 */           if (null == paramString2 || null == paramString3)
/*      */           {
/*  862 */             throw new SQLServerException(SQLServerException.getErrString("R_keyStoreSecretOrLocationNotSet"), null);
/*      */           }
/*      */ 
/*      */           
/*  866 */           sQLServerColumnEncryptionJavaKeyStoreProvider = new SQLServerColumnEncryptionJavaKeyStoreProvider(paramString3, paramString2.toCharArray());
/*  867 */           this.systemColumnEncryptionKeyStoreProvider.put(sQLServerColumnEncryptionJavaKeyStoreProvider.getName(), sQLServerColumnEncryptionJavaKeyStoreProvider);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Connection connectInternal(Properties paramProperties, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException {
/*      */     try {
/*  920 */       this.activeConnectionProperties = (Properties)paramProperties.clone();
/*      */       
/*  922 */       this.pooledConnectionParent = paramSQLServerPooledConnection;
/*      */       
/*  924 */       String str1 = null;
/*  925 */       String str2 = null;
/*      */       
/*  927 */       str1 = SQLServerDriverStringProperty.USER.toString();
/*  928 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  929 */       if (str2 == null) {
/*      */         
/*  931 */         str2 = SQLServerDriverStringProperty.USER.getDefaultValue();
/*  932 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*  934 */       ValidateMaxSQLLoginName(str1, str2);
/*      */ 
/*      */       
/*  937 */       str1 = SQLServerDriverStringProperty.PASSWORD.toString();
/*  938 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  939 */       if (str2 == null) {
/*      */         
/*  941 */         str2 = SQLServerDriverStringProperty.PASSWORD.getDefaultValue();
/*  942 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*  944 */       ValidateMaxSQLLoginName(str1, str2);
/*      */       
/*  946 */       str1 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/*  947 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  948 */       ValidateMaxSQLLoginName(str1, str2);
/*      */ 
/*      */       
/*  951 */       int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  952 */       str2 = this.activeConnectionProperties.getProperty(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString());
/*  953 */       if (null != str2 && str2.length() > 0) {
/*      */ 
/*      */         
/*      */         try {
/*  957 */           i = Integer.parseInt(str2);
/*      */         }
/*  959 */         catch (NumberFormatException numberFormatException) {
/*      */           
/*  961 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/*  962 */           Object[] arrayOfObject = { str2 };
/*  963 */           SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */         } 
/*      */         
/*  966 */         if (i < 0 || i > 65535) {
/*      */           
/*  968 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTimeOut"));
/*  969 */           Object[] arrayOfObject = { str2 };
/*  970 */           SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  975 */       str1 = SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString();
/*  976 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*  977 */       if (str2 == null) {
/*      */         
/*  979 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue());
/*  980 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*  982 */       this.serverNameAsACE = booleanPropertyOn(str1, str2);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  987 */       str1 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*  988 */       str2 = this.activeConnectionProperties.getProperty(str1);
/*      */       
/*  990 */       if (str2 == null)
/*      */       {
/*  992 */         str2 = "localhost";
/*      */       }
/*      */       
/*  995 */       String str3 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*  996 */       String str4 = this.activeConnectionProperties.getProperty(str3);
/*      */       
/*  998 */       int j = str2.indexOf('\\');
/*      */       
/* 1000 */       Object object = null;
/* 1001 */       String str5 = null;
/*      */       
/* 1003 */       String str6 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/*      */       
/* 1005 */       if (j >= 0) {
/*      */         
/* 1007 */         str5 = str2.substring(j + 1, str2.length());
/* 1008 */         ValidateMaxSQLLoginName(str6, str5);
/* 1009 */         str2 = str2.substring(0, j);
/*      */       } 
/* 1011 */       this.trustedServerNameAE = str2;
/*      */       
/* 1013 */       if (true == this.serverNameAsACE) {
/*      */         
/*      */         try {
/*      */           
/* 1017 */           str2 = IDN.toASCII(str2);
/*      */         }
/* 1019 */         catch (IllegalArgumentException illegalArgumentException) {
/*      */           
/* 1021 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidConnectionSetting"));
/* 1022 */           Object[] arrayOfObject = { "serverNameAsACE", str2 };
/* 1023 */           throw new SQLServerException(messageFormat.format(arrayOfObject), illegalArgumentException);
/*      */         } 
/*      */       }
/* 1026 */       this.activeConnectionProperties.setProperty(str1, str2);
/*      */       
/* 1028 */       String str7 = this.activeConnectionProperties.getProperty(str6);
/*      */       
/* 1030 */       if (null != str7) {
/* 1031 */         str5 = str7;
/*      */       }
/* 1033 */       if (str5 != null) {
/*      */         
/* 1035 */         ValidateMaxSQLLoginName(str6, str5);
/*      */         
/* 1037 */         this.activeConnectionProperties.setProperty(str6, str5);
/* 1038 */         this.trustedServerNameAE += "\\" + str5;
/*      */       } 
/*      */       
/* 1041 */       if (null != str4)
/*      */       {
/* 1043 */         this.trustedServerNameAE += ":" + str4;
/*      */       }
/*      */       
/* 1046 */       str1 = SQLServerDriverStringProperty.APPLICATION_NAME.toString();
/* 1047 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1048 */       if (str2 != null) {
/* 1049 */         ValidateMaxSQLLoginName(str1, str2);
/*      */       } else {
/* 1051 */         this.activeConnectionProperties.setProperty(str1, "Microsoft JDBC Driver for SQL Server");
/*      */       } 
/* 1053 */       str1 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/* 1054 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1055 */       if (str2 == null) {
/*      */         
/* 1057 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
/* 1058 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*      */       
/* 1061 */       str1 = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString();
/* 1062 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1063 */       if (null == str2) {
/*      */         
/* 1065 */         str2 = SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue();
/* 1066 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/* 1068 */       this.columnEncryptionSetting = ColumnEncryptionSetting.valueOfString(str2).toString();
/*      */       
/* 1070 */       str1 = SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString();
/* 1071 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1072 */       if (null != str2)
/*      */       {
/* 1074 */         this.keyStoreAuthentication = KeyStoreAuthentication.valueOfString(str2).toString();
/*      */       }
/*      */       
/* 1077 */       str1 = SQLServerDriverStringProperty.KEY_STORE_SECRET.toString();
/* 1078 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1079 */       if (null != str2)
/*      */       {
/* 1081 */         this.keyStoreSecret = str2;
/*      */       }
/*      */       
/* 1084 */       str1 = SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString();
/* 1085 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1086 */       if (null != str2)
/*      */       {
/* 1088 */         this.keyStoreLocation = str2;
/*      */       }
/*      */       
/* 1091 */       registerKeyStoreProviderOnConnection(this.keyStoreAuthentication, this.keyStoreSecret, this.keyStoreLocation);
/*      */ 
/*      */       
/* 1094 */       str1 = SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString();
/* 1095 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1096 */       if (str2 == null) {
/*      */         
/* 1098 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
/* 1099 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/* 1101 */       this.multiSubnetFailover = booleanPropertyOn(str1, str2);
/*      */       
/* 1103 */       str1 = SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString();
/* 1104 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1105 */       if (str2 == null) {
/*      */         
/* 1107 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue());
/* 1108 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/* 1110 */       this.transparentNetworkIPResolution = booleanPropertyOn(str1, str2);
/*      */       
/* 1112 */       str1 = SQLServerDriverBooleanProperty.ENCRYPT.toString();
/* 1113 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1114 */       if (str2 == null) {
/*      */         
/* 1116 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
/* 1117 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*      */ 
/*      */       
/* 1121 */       this.requestedEncryptionLevel = booleanPropertyOn(str1, str2) ? 1 : 0;
/*      */       
/* 1123 */       str1 = SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString();
/* 1124 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1125 */       if (str2 == null) {
/*      */         
/* 1127 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
/* 1128 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*      */       
/* 1131 */       this.trustServerCertificate = booleanPropertyOn(str1, str2);
/*      */       
/* 1133 */       str1 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/* 1134 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1135 */       if (str2 == null) str2 = SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue(); 
/* 1136 */       if (str2.equalsIgnoreCase("cursor") || str2.equalsIgnoreCase("direct")) {
/*      */         
/* 1138 */         this.activeConnectionProperties.setProperty(str1, str2.toLowerCase());
/*      */       }
/*      */       else {
/*      */         
/* 1142 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidselectMethod"));
/* 1143 */         Object[] arrayOfObject = { new String(str2) };
/* 1144 */         SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */       } 
/*      */       
/* 1147 */       str1 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/* 1148 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1149 */       if (str2 == null) str2 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue(); 
/* 1150 */       if (str2.equalsIgnoreCase("full") || str2.equalsIgnoreCase("adaptive")) {
/*      */         
/* 1152 */         this.activeConnectionProperties.setProperty(str1, str2.toLowerCase());
/*      */       }
/*      */       else {
/*      */         
/* 1156 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
/* 1157 */         Object[] arrayOfObject = { new String(str2) };
/* 1158 */         SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */       } 
/*      */ 
/*      */       
/* 1162 */       str1 = SQLServerDriverStringProperty.APPLICATION_INTENT.toString();
/* 1163 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1164 */       if (str2 == null) str2 = SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue(); 
/* 1165 */       this.applicationIntent = ApplicationIntent.valueOfString(str2);
/* 1166 */       this.activeConnectionProperties.setProperty(str1, this.applicationIntent.toString());
/*      */       
/* 1168 */       str1 = SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString();
/* 1169 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1170 */       if (str2 == null) {
/*      */         
/* 1172 */         str2 = Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
/* 1173 */         this.activeConnectionProperties.setProperty(str1, str2);
/*      */       } 
/*      */       
/* 1176 */       this.sendTimeAsDatetime = booleanPropertyOn(str1, str2);
/*      */       
/* 1178 */       str1 = SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString();
/* 1179 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1180 */       if (str2 != null && false == 
/* 1181 */         booleanPropertyOn(str1, str2)) {
/*      */         
/* 1183 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invaliddisableStatementPooling"));
/* 1184 */         Object[] arrayOfObject = { new String(str2) };
/* 1185 */         SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */       } 
/*      */       
/* 1188 */       str1 = SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString();
/* 1189 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1190 */       if (str2 != null)
/*      */       {
/* 1192 */         this.integratedSecurity = booleanPropertyOn(str1, str2);
/*      */       }
/*      */ 
/*      */       
/* 1196 */       if (this.integratedSecurity) {
/*      */         
/* 1198 */         str1 = SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString();
/* 1199 */         str2 = this.activeConnectionProperties.getProperty(str1);
/* 1200 */         if (str2 != null)
/*      */         {
/* 1202 */           this.intAuthScheme = AuthenticationScheme.valueOfString(str2);
/*      */         }
/*      */       } 
/*      */       
/* 1206 */       str1 = SQLServerDriverStringProperty.AUTHENTICATION.toString();
/* 1207 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1208 */       if (str2 == null)
/*      */       {
/* 1210 */         str2 = SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue();
/*      */       }
/* 1212 */       this.authenticationString = SqlAuthentication.valueOfString(str2).toString();
/*      */       
/* 1214 */       if (true == this.integratedSecurity && !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) {
/*      */         
/* 1216 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"));
/* 1217 */         throw new SQLServerException(SQLServerException.getErrString("R_SetAuthenticationWhenIntegratedSecurityTrue"), null);
/*      */       } 
/*      */       
/* 1220 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && (!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1225 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"));
/* 1226 */         throw new SQLServerException(SQLServerException.getErrString("R_IntegratedAuthenticationWithUserPassword"), null);
/*      */       } 
/*      */       
/* 1229 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString()) && (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/*      */ 
/*      */ 
/*      */         
/* 1233 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_NoUserPasswordForActivePassword"));
/* 1234 */         throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForActivePassword"), null);
/*      */       } 
/*      */       
/* 1237 */       if (this.authenticationString.equalsIgnoreCase(SqlAuthentication.SqlPassword.toString()) && (this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/*      */ 
/*      */ 
/*      */         
/* 1241 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"));
/* 1242 */         throw new SQLServerException(SQLServerException.getErrString("R_NoUserPasswordForSqlPassword"), null);
/*      */       } 
/*      */       
/* 1245 */       str1 = SQLServerDriverStringProperty.ACCESS_TOKEN.toString();
/* 1246 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1247 */       if (null != str2) {
/*      */         
/*      */         try {
/* 1250 */           this.accessTokenInByte = str2.getBytes("UTF-16LE");
/* 1251 */         } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 1252 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */           
/* 1254 */           Object[] arrayOfObject = { "UTF-16LE" };
/* 1255 */           throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */         } 
/*      */       }
/*      */       
/* 1259 */       if (null != this.accessTokenInByte && 0 == this.accessTokenInByte.length) {
/*      */         
/* 1261 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"));
/* 1262 */         throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenCannotBeEmpty"), null);
/*      */       } 
/*      */       
/* 1265 */       if (true == this.integratedSecurity && null != this.accessTokenInByte) {
/*      */         
/* 1267 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"));
/* 1268 */         throw new SQLServerException(SQLServerException.getErrString("R_SetAccesstokenWhenIntegratedSecurityTrue"), null);
/*      */       } 
/*      */       
/* 1271 */       if (!this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) && null != this.accessTokenInByte) {
/*      */ 
/*      */         
/* 1274 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"));
/* 1275 */         throw new SQLServerException(SQLServerException.getErrString("R_SetBothAuthenticationAndAccessToken"), null);
/*      */       } 
/*      */       
/* 1278 */       if (null != this.accessTokenInByte && (!this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString()).isEmpty() || !this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString()).isEmpty())) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1283 */         connectionlogger.severe(toString() + " " + SQLServerException.getErrString("R_AccessTokenWithUserPassword"));
/* 1284 */         throw new SQLServerException(SQLServerException.getErrString("R_AccessTokenWithUserPassword"), null);
/*      */       } 
/*      */       
/* 1287 */       if (!System.getProperty("os.name").toLowerCase().startsWith("windows") && (null != this.accessTokenInByte || !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())))
/*      */       {
/* 1289 */         throw new SQLServerException(SQLServerException.getErrString("R_FedAuthOnNonWindows"), null);
/*      */       }
/*      */       
/* 1292 */       str1 = SQLServerDriverStringProperty.WORKSTATION_ID.toString();
/* 1293 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1294 */       ValidateMaxSQLLoginName(str1, str2);
/*      */       
/* 1296 */       int k = 0;
/* 1297 */       str1 = SQLServerDriverIntProperty.PORT_NUMBER.toString();
/*      */       
/*      */       try {
/* 1300 */         String str = this.activeConnectionProperties.getProperty(str1);
/* 1301 */         if (null != str) {
/*      */           
/* 1303 */           k = (new Integer(str)).intValue();
/*      */           
/* 1305 */           if (k < 0 || k > 65535)
/*      */           {
/* 1307 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1308 */             Object[] arrayOfObject = { Integer.toString(k) };
/* 1309 */             SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */           }
/*      */         
/*      */         } 
/* 1313 */       } catch (NumberFormatException numberFormatException) {
/*      */         
/* 1315 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1316 */         Object[] arrayOfObject = { this.activeConnectionProperties.getProperty(str1) };
/* 1317 */         SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */       } 
/*      */ 
/*      */       
/* 1321 */       str1 = SQLServerDriverIntProperty.PACKET_SIZE.toString();
/* 1322 */       str2 = this.activeConnectionProperties.getProperty(str1);
/* 1323 */       if (null != str2 && str2.length() > 0) {
/*      */ 
/*      */         
/*      */         try {
/* 1327 */           this.requestedPacketSize = Integer.parseInt(str2);
/*      */ 
/*      */           
/* 1330 */           if (-1 == this.requestedPacketSize) {
/* 1331 */             this.requestedPacketSize = 0;
/*      */           
/*      */           }
/* 1334 */           else if (0 == this.requestedPacketSize) {
/* 1335 */             this.requestedPacketSize = 32767;
/*      */           } 
/* 1337 */         } catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */ 
/*      */           
/* 1341 */           this.requestedPacketSize = -1;
/*      */         } 
/*      */         
/* 1344 */         if (0 != this.requestedPacketSize)
/*      */         {
/*      */           
/* 1347 */           if (this.requestedPacketSize < 512 || this.requestedPacketSize > 32767) {
/*      */             
/* 1349 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPacketSize"));
/* 1350 */             Object[] arrayOfObject = { str2 };
/* 1351 */             SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1360 */       str1 = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString();
/* 1361 */       if (null == this.activeConnectionProperties.getProperty(str1)) {
/*      */         
/* 1363 */         this.sendStringParametersAsUnicode = SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue();
/*      */       }
/*      */       else {
/*      */         
/* 1367 */         this.sendStringParametersAsUnicode = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
/*      */       } 
/*      */       
/* 1370 */       str1 = SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString();
/* 1371 */       this.lastUpdateCount = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
/* 1372 */       str1 = SQLServerDriverBooleanProperty.XOPEN_STATES.toString();
/* 1373 */       this.xopenStates = booleanPropertyOn(str1, this.activeConnectionProperties.getProperty(str1));
/*      */       
/* 1375 */       str1 = SQLServerDriverStringProperty.SELECT_METHOD.toString();
/* 1376 */       this.selectMethod = null;
/* 1377 */       if (this.activeConnectionProperties.getProperty(str1) != null && this.activeConnectionProperties.getProperty(str1).length() > 0)
/*      */       {
/*      */         
/* 1380 */         this.selectMethod = this.activeConnectionProperties.getProperty(str1);
/*      */       }
/*      */       
/* 1383 */       str1 = SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString();
/* 1384 */       this.responseBuffering = null;
/* 1385 */       if (this.activeConnectionProperties.getProperty(str1) != null && this.activeConnectionProperties.getProperty(str1).length() > 0)
/*      */       {
/*      */         
/* 1388 */         this.responseBuffering = this.activeConnectionProperties.getProperty(str1);
/*      */       }
/*      */       
/* 1391 */       str1 = SQLServerDriverIntProperty.LOCK_TIMEOUT.toString();
/* 1392 */       int m = SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue();
/* 1393 */       this.nLockTimeout = m;
/* 1394 */       if (this.activeConnectionProperties.getProperty(str1) != null && this.activeConnectionProperties.getProperty(str1).length() > 0) {
/*      */         
/*      */         try {
/*      */ 
/*      */           
/* 1399 */           int n = (new Integer(this.activeConnectionProperties.getProperty(str1))).intValue();
/* 1400 */           if (n >= m) {
/* 1401 */             this.nLockTimeout = n;
/*      */           } else {
/*      */             
/* 1404 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/* 1405 */             Object[] arrayOfObject = { this.activeConnectionProperties.getProperty(str1) };
/* 1406 */             SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */           }
/*      */         
/* 1409 */         } catch (NumberFormatException numberFormatException) {
/*      */           
/* 1411 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLockTimeOut"));
/* 1412 */           Object[] arrayOfObject = { this.activeConnectionProperties.getProperty(str1) };
/* 1413 */           SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */         } 
/*      */       }
/* 1416 */       FailoverInfo failoverInfo = null;
/* 1417 */       String str8 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 1418 */       String str9 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/* 1419 */       String str10 = SQLServerDriverStringProperty.FAILOVER_PARTNER.toString();
/* 1420 */       String str11 = this.activeConnectionProperties.getProperty(str10);
/*      */ 
/*      */       
/* 1423 */       if (this.multiSubnetFailover && str11 != null)
/*      */       {
/* 1425 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover"), (String)null, false);
/*      */       }
/*      */ 
/*      */       
/* 1429 */       if (this.multiSubnetFailover || null != str11)
/*      */       {
/* 1431 */         this.transparentNetworkIPResolution = false;
/*      */       }
/*      */ 
/*      */       
/* 1435 */       if (this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY) && str11 != null)
/*      */       {
/* 1437 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent"), (String)null, false);
/*      */       }
/*      */ 
/*      */       
/* 1441 */       if (null != this.activeConnectionProperties.getProperty(str8)) {
/*      */ 
/*      */         
/* 1444 */         failoverInfo = FailoverMapSingleton.getFailoverInfo(this, this.activeConnectionProperties.getProperty(str9), this.activeConnectionProperties.getProperty(str6), this.activeConnectionProperties.getProperty(str8));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1450 */       else if (null != str11) {
/* 1451 */         SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_failoverPartnerWithoutDB"), (String)null, true);
/*      */       } 
/*      */       
/* 1454 */       String str12 = null;
/* 1455 */       if (null == failoverInfo) {
/* 1456 */         str12 = str11;
/*      */       }
/* 1458 */       long l = System.currentTimeMillis();
/* 1459 */       login(this.activeConnectionProperties.getProperty(str9), str5, k, str12, failoverInfo, i, l);
/*      */ 
/*      */ 
/*      */       
/* 1463 */       if (1 == this.negotiatedEncryptionLevel || 3 == this.negotiatedEncryptionLevel) {
/*      */ 
/*      */         
/* 1466 */         char c = Util.isIBM() ? ' ' : '䀀';
/*      */         
/* 1468 */         if (this.tdsPacketSize > c) {
/*      */           
/* 1470 */           connectionlogger.finer(toString() + " Negotiated tdsPacketSize " + this.tdsPacketSize + " is too large for SSL with JRE " + Util.SYSTEM_JRE + " (max size is " + c + ")");
/* 1471 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_packetSizeTooBigForSSL"));
/* 1472 */           Object[] arrayOfObject = { Integer.toString(c) };
/* 1473 */           terminate(6, messageFormat.format(arrayOfObject));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1478 */       this.state = State.Opened;
/*      */ 
/*      */       
/* 1481 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 1483 */         connectionlogger.finer(toString() + " End of connect");
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1490 */       if (!this.state.equals(State.Opened))
/*      */       {
/*      */         
/* 1493 */         if (!this.state.equals(State.Closed)) {
/* 1494 */           close();
/*      */         }
/*      */       }
/*      */     } 
/* 1498 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void login(String paramString1, String paramString2, int paramInt1, String paramString3, FailoverInfo paramFailoverInfo, int paramInt2, long paramLong) throws SQLServerException {
/*      */     long l1;
/* 1512 */     boolean bool = (null == paramString3 && null == paramFailoverInfo) ? false : true;
/* 1513 */     byte b1 = 100;
/*      */ 
/*      */     
/* 1516 */     boolean bool1 = false;
/* 1517 */     FailoverInfo failoverInfo = null;
/*      */     
/* 1519 */     ServerPortPlaceHolder serverPortPlaceHolder1 = null;
/*      */     
/* 1521 */     ServerPortPlaceHolder serverPortPlaceHolder2 = null;
/*      */     
/* 1523 */     if (null != paramFailoverInfo) {
/*      */       
/* 1525 */       failoverInfo = paramFailoverInfo;
/* 1526 */       bool1 = paramFailoverInfo.getUseFailoverPartner();
/*      */ 
/*      */     
/*      */     }
/* 1530 */     else if (bool) {
/*      */       
/* 1532 */       failoverInfo = new FailoverInfo(paramString3, this, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1538 */     boolean bool2 = getMultiSubnetFailover();
/* 1539 */     boolean bool3 = getTransparentNetworkIPResolution();
/*      */ 
/*      */ 
/*      */     
/* 1543 */     if (0 == paramInt2)
/*      */     {
/* 1545 */       paramInt2 = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*      */     }
/* 1547 */     long l3 = (paramInt2 * 1000);
/* 1548 */     this.timerExpire = paramLong + l3;
/*      */ 
/*      */     
/* 1551 */     if (bool || bool2 || bool3) {
/*      */       
/* 1553 */       l1 = (long)(0.08F * (float)l3);
/*      */     }
/*      */     else {
/*      */       
/* 1557 */       l1 = l3;
/*      */     } 
/* 1559 */     long l2 = paramLong + l1;
/*      */ 
/*      */     
/* 1562 */     long l4 = paramLong + l3;
/*      */     
/* 1564 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 1566 */       connectionlogger.finer(toString() + " Start time: " + paramLong + " Time out time: " + this.timerExpire + " Timeout Unit Interval: " + l1);
/*      */     }
/*      */ 
/*      */     
/* 1570 */     byte b2 = 0;
/*      */ 
/*      */     
/* 1573 */     byte b3 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 1584 */       this.clientConnectionId = null;
/* 1585 */       this.state = State.Initialized;
/*      */ 
/*      */       
/*      */       try {
/* 1589 */         if (bool && bool1) {
/*      */ 
/*      */           
/* 1592 */           if (null == serverPortPlaceHolder1)
/*      */           {
/*      */             
/* 1595 */             serverPortPlaceHolder1 = failoverInfo.failoverPermissionCheck(this, this.integratedSecurity);
/*      */           }
/* 1597 */           this.currentConnectPlaceHolder = serverPortPlaceHolder1;
/*      */         }
/*      */         else {
/*      */           
/* 1601 */           if (this.routingInfo != null) {
/*      */             
/* 1603 */             serverPortPlaceHolder2 = this.routingInfo;
/* 1604 */             this.routingInfo = null;
/*      */           }
/* 1606 */           else if (null == serverPortPlaceHolder2) {
/*      */             
/* 1608 */             serverPortPlaceHolder2 = primaryPermissionCheck(paramString1, paramString2, paramInt1);
/*      */           } 
/* 1610 */           this.currentConnectPlaceHolder = serverPortPlaceHolder2;
/*      */         } 
/*      */ 
/*      */         
/* 1614 */         if (connectionlogger.isLoggable(Level.FINE)) {
/*      */           
/* 1616 */           connectionlogger.fine(toString() + " This attempt server name: " + this.currentConnectPlaceHolder.getServerName() + " port: " + this.currentConnectPlaceHolder.getPortNumber() + " InstanceName: " + this.currentConnectPlaceHolder.getInstanceName() + " useParallel: " + bool2);
/*      */ 
/*      */ 
/*      */           
/* 1620 */           connectionlogger.fine(toString() + " This attempt endtime: " + l2);
/* 1621 */           connectionlogger.fine(toString() + " This attempt No: " + b2);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1628 */         connectHelper(this.currentConnectPlaceHolder, TimerRemaining(l2), paramInt2, bool2, bool3, (0 == b2), TimerRemaining(l4));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1638 */         if (this.isRoutedInCurrentAttempt) {
/*      */ 
/*      */ 
/*      */           
/* 1642 */           if (bool) {
/*      */             
/* 1644 */             String str = SQLServerException.getErrString("R_invalidRoutingInfo");
/* 1645 */             terminate(6, str);
/*      */           } 
/*      */           
/* 1648 */           b3++;
/*      */           
/* 1650 */           if (b3 > 1) {
/*      */             
/* 1652 */             String str = SQLServerException.getErrString("R_multipleRedirections");
/* 1653 */             terminate(6, str);
/*      */           } 
/*      */ 
/*      */           
/* 1657 */           if (this.tdsChannel != null) {
/* 1658 */             this.tdsChannel.close();
/*      */           }
/* 1660 */           initResettableValues();
/*      */ 
/*      */ 
/*      */           
/* 1664 */           resetNonRoutingEnvchangeValues();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1670 */           b2++;
/*      */ 
/*      */           
/* 1673 */           this.isRoutedInCurrentAttempt = false;
/*      */ 
/*      */           
/* 1676 */           bool2 = false;
/* 1677 */           bool3 = false;
/*      */ 
/*      */           
/* 1680 */           l2 = this.timerExpire;
/*      */ 
/*      */           
/* 1683 */           if (timerHasExpired(this.timerExpire)) {
/*      */             
/* 1685 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 1686 */             Object[] arrayOfObject = { this.currentConnectPlaceHolder.getServerName(), Integer.toString(this.currentConnectPlaceHolder.getPortNumber()), SQLServerException.getErrString("R_timedOutBeforeRouting") };
/* 1687 */             String str = messageFormat.format(arrayOfObject);
/* 1688 */             terminate(6, str);
/*      */           }
/*      */           else {
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } else {
/*      */           
/*      */           break;
/*      */         } 
/* 1698 */       } catch (SQLServerException sQLServerException) {
/*      */         
/* 1700 */         if (18456 == sQLServerException.getErrorCode() || 18488 == sQLServerException.getErrorCode() || 4 == sQLServerException.getDriverErrorCode() || 5 == sQLServerException.getDriverErrorCode() || 7 == sQLServerException.getDriverErrorCode() || 6 == sQLServerException.getDriverErrorCode() || timerHasExpired(this.timerExpire) || (this.state.equals(State.Connected) && !bool)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1713 */           close();
/* 1714 */           throw sQLServerException;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1720 */         if (null != this.tdsChannel) {
/* 1721 */           this.tdsChannel.close();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1726 */         if (!bool || 1 == b2 % 2) {
/*      */ 
/*      */ 
/*      */           
/* 1730 */           long l = TimerRemaining(this.timerExpire);
/* 1731 */           if (l <= b1)
/*      */           {
/* 1733 */             throw sQLServerException;
/*      */           }
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1743 */       if (!bool || 1 == b2 % 2) {
/*      */         
/* 1745 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1747 */           connectionlogger.fine(toString() + " sleeping milisec: " + b1);
/*      */         }
/*      */         
/*      */         try {
/* 1751 */           Thread.sleep(b1);
/* 1752 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */ 
/*      */         
/* 1756 */         b1 = (b1 < 'Ǵ') ? (b1 * 2) : 1000;
/*      */       } 
/*      */ 
/*      */       
/* 1760 */       b2++;
/*      */       
/* 1762 */       if (bool2 || bool3) {
/*      */         
/* 1764 */         l2 = System.currentTimeMillis() + l1 * (b2 + 1);
/*      */       }
/* 1766 */       else if (bool) {
/*      */         
/* 1768 */         l2 = System.currentTimeMillis() + l1 * (b2 / 2 + 1);
/*      */       } else {
/*      */         
/* 1771 */         l2 = this.timerExpire;
/*      */       } 
/*      */       
/* 1774 */       if (l2 > this.timerExpire)
/*      */       {
/* 1776 */         l2 = this.timerExpire;
/*      */       }
/*      */       
/* 1779 */       if (bool) {
/* 1780 */         bool1 = !bool1;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1785 */     if (bool1 && null == this.failoverPartnerServerProvided) {
/*      */       
/* 1787 */       String str = this.currentConnectPlaceHolder.getServerName();
/* 1788 */       if (null != serverPortPlaceHolder1.getInstanceName()) {
/*      */         
/* 1790 */         str = str + "\\";
/* 1791 */         str = str + serverPortPlaceHolder1.getInstanceName();
/*      */       } 
/* 1793 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPartnerConfiguration"));
/* 1794 */       Object[] arrayOfObject = { new String(this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString())), str };
/*      */       
/* 1796 */       terminate(6, messageFormat.format(arrayOfObject));
/*      */     } 
/*      */     
/* 1799 */     if (null != this.failoverPartnerServerProvided) {
/*      */ 
/*      */       
/* 1802 */       if (this.multiSubnetFailover) {
/*      */         
/* 1804 */         String str = SQLServerException.getErrString("R_dbMirroringWithMultiSubnetFailover");
/* 1805 */         terminate(6, str);
/*      */       } 
/*      */ 
/*      */       
/* 1809 */       if (this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) {
/*      */         
/* 1811 */         String str = SQLServerException.getErrString("R_dbMirroringWithReadOnlyIntent");
/* 1812 */         terminate(6, str);
/*      */       } 
/*      */ 
/*      */       
/* 1816 */       if (null == failoverInfo) {
/* 1817 */         failoverInfo = new FailoverInfo(this.failoverPartnerServerProvided, this, false);
/*      */       }
/* 1819 */       if (null != paramFailoverInfo) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1824 */         paramFailoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
/*      */       }
/*      */       else {
/*      */         
/* 1828 */         String str1 = SQLServerDriverStringProperty.DATABASE_NAME.toString();
/* 1829 */         String str2 = SQLServerDriverStringProperty.INSTANCE_NAME.toString();
/* 1830 */         String str3 = SQLServerDriverStringProperty.SERVER_NAME.toString();
/*      */         
/* 1832 */         if (connectionlogger.isLoggable(Level.FINE))
/*      */         {
/* 1834 */           connectionlogger.fine(toString() + " adding new failover info server: " + this.activeConnectionProperties.getProperty(str3) + " instance: " + this.activeConnectionProperties.getProperty(str2) + " database: " + this.activeConnectionProperties.getProperty(str1) + " server provided failover: " + this.failoverPartnerServerProvided);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1840 */         failoverInfo.failoverAdd(this, bool1, this.failoverPartnerServerProvided);
/* 1841 */         FailoverMapSingleton.putFailoverInfo(this, paramString1, this.activeConnectionProperties.getProperty(str2), this.activeConnectionProperties.getProperty(str1), failoverInfo, bool1, this.failoverPartnerServerProvided);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNonRoutingEnvchangeValues() {
/* 1851 */     this.tdsPacketSize = 4096;
/* 1852 */     this.databaseCollation = null;
/* 1853 */     this.rolledBackTransaction = false;
/* 1854 */     Arrays.fill(getTransactionDescriptor(), (byte)0);
/* 1855 */     this.sCatalog = this.originalCatalog;
/* 1856 */     this.failoverPartnerServerProvided = null;
/*      */   }
/*      */   
/* 1859 */   static final int DEFAULTPORT = SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue(); private final Object schedulerLock; volatile SQLWarning sqlWarnings; Integer warningSynchronization; private static final int ENVCHANGE_DATABASE = 1; private static final int ENVCHANGE_LANGUAGE = 2; private static final int ENVCHANGE_CHARSET = 3; private static final int ENVCHANGE_PACKETSIZE = 4; private static final int ENVCHANGE_SORTLOCALEID = 5; private static final int ENVCHANGE_SORTFLAGS = 6; private static final int ENVCHANGE_SQLCOLLATION = 7; private static final int ENVCHANGE_XACT_BEGIN = 8; private static final int ENVCHANGE_XACT_COMMIT = 9; private static final int ENVCHANGE_XACT_ROLLBACK = 10; private static final int ENVCHANGE_DTC_ENLIST = 11; private static final int ENVCHANGE_DTC_DEFECT = 12; private static final int ENVCHANGE_CHANGE_MIRROR = 13; private static final int ENVCHANGE_UNUSED_14 = 14; private static final int ENVCHANGE_DTC_PROMOTE = 15;
/*      */   private static final int ENVCHANGE_DTC_MGR_ADDR = 16;
/*      */   private static final int ENVCHANGE_XACT_ENDED = 17;
/*      */   private static final int ENVCHANGE_RESET_COMPLETE = 18;
/*      */   private static final int ENVCHANGE_USER_INFO = 19;
/*      */   private static final int ENVCHANGE_ROUTING = 20;
/*      */   
/*      */   ServerPortPlaceHolder primaryPermissionCheck(String paramString1, String paramString2, int paramInt) throws SQLServerException {
/* 1867 */     if (0 == paramInt)
/*      */     {
/* 1869 */       if (null != paramString2) {
/*      */         
/* 1871 */         String str = getInstancePort(paramString1, paramString2);
/* 1872 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 1873 */           connectionlogger.fine(toString() + " SQL Server port returned by SQL Browser: " + str);
/*      */         }
/*      */         try {
/* 1876 */           if (null != str) {
/*      */             
/* 1878 */             paramInt = (new Integer(str)).intValue();
/*      */             
/* 1880 */             if (paramInt < 0 || paramInt > 65535) {
/*      */               
/* 1882 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1883 */               Object[] arrayOfObject = { Integer.toString(paramInt) };
/* 1884 */               SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */             } 
/*      */           } else {
/*      */             
/* 1888 */             paramInt = DEFAULTPORT;
/*      */           }
/*      */         
/* 1891 */         } catch (NumberFormatException numberFormatException) {
/*      */           
/* 1893 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPortNumber"));
/* 1894 */           Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 1895 */           SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */         } 
/*      */       } else {
/*      */         
/* 1899 */         paramInt = DEFAULTPORT;
/*      */       } 
/*      */     }
/*      */     
/* 1903 */     this.activeConnectionProperties.setProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString(), String.valueOf(paramInt));
/* 1904 */     return new ServerPortPlaceHolder(paramString1, paramInt, paramString2, this.integratedSecurity);
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean timerHasExpired(long paramLong) {
/* 1909 */     return (System.currentTimeMillis() > paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static int TimerRemaining(long paramLong) {
/* 1915 */     long l1 = System.currentTimeMillis();
/* 1916 */     long l2 = paramLong - l1;
/*      */     
/* 1918 */     if (l2 > 2147483647L) {
/* 1919 */       l2 = 2147483647L;
/*      */     }
/*      */     
/* 1922 */     if (l2 <= 0L)
/* 1923 */       l2 = 1L; 
/* 1924 */     return (int)l2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void connectHelper(ServerPortPlaceHolder paramServerPortPlaceHolder, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3) throws SQLServerException {
/* 1952 */     if (connectionlogger.isLoggable(Level.FINE))
/*      */     {
/* 1954 */       connectionlogger.fine(toString() + " Connecting with server: " + paramServerPortPlaceHolder.getServerName() + " port: " + paramServerPortPlaceHolder.getPortNumber() + " Timeout slice: " + paramInt1 + " Timeout Full: " + paramInt2);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1959 */     this.tdsChannel = new TDSChannel(this);
/* 1960 */     if (0 == paramInt2) {
/* 1961 */       this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), 0, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
/*      */     } else {
/* 1963 */       this.tdsChannel.open(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber(), paramInt1, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
/*      */     } 
/*      */     
/* 1966 */     setState(State.Connected);
/*      */ 
/*      */     
/* 1969 */     this.clientConnectionId = UUID.randomUUID();
/* 1970 */     assert null != this.clientConnectionId;
/*      */ 
/*      */     
/* 1973 */     Prelogin(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
/*      */ 
/*      */     
/* 1976 */     if (2 != this.negotiatedEncryptionLevel) {
/* 1977 */       this.tdsChannel.enableSSL(paramServerPortPlaceHolder.getServerName(), paramServerPortPlaceHolder.getPortNumber());
/*      */     }
/*      */ 
/*      */     
/* 1981 */     executeCommand(new LogonCommand());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void Prelogin(String paramString, int paramInt) throws SQLServerException {
/*      */     byte b1, b2;
/*      */     int j;
/* 1990 */     if (!this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.NotSpecified.toString()) || null != this.accessTokenInByte)
/*      */     {
/*      */       
/* 1993 */       this.fedAuthRequiredByUser = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1999 */     if (this.fedAuthRequiredByUser) {
/*      */       
/* 2001 */       b1 = 73;
/* 2002 */       this.requestedEncryptionLevel = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2007 */       b2 = 5;
/*      */     }
/*      */     else {
/*      */       
/* 2011 */       b1 = 67;
/* 2012 */       b2 = 0;
/*      */     } 
/*      */     
/* 2015 */     byte[] arrayOfByte1 = new byte[b1];
/*      */     
/* 2017 */     int i = 0;
/*      */     
/* 2019 */     byte[] arrayOfByte2 = { 18, 1, 0, b1, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2029 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i, arrayOfByte2.length);
/* 2030 */     i += arrayOfByte2.length;
/*      */     
/* 2032 */     byte[] arrayOfByte3 = { 0, 0, (byte)(16 + b2), 0, 6, 1, 0, (byte)(22 + b2), 0, 1, 5, 0, (byte)(23 + b2), 0, 36 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2038 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte1, i, arrayOfByte3.length);
/* 2039 */     i += arrayOfByte3.length;
/*      */     
/* 2041 */     if (this.fedAuthRequiredByUser) {
/* 2042 */       byte[] arrayOfByte = { 6, 0, 64, 0, 1 };
/*      */ 
/*      */       
/* 2045 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, i, arrayOfByte.length);
/* 2046 */       i += arrayOfByte.length;
/*      */     } 
/*      */     
/* 2049 */     arrayOfByte1[i] = -1;
/* 2050 */     i++;
/*      */ 
/*      */     
/* 2053 */     byte[] arrayOfByte4 = { 0, 0, 0, 0, 0, 0, this.requestedEncryptionLevel, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2065 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte1, i, arrayOfByte4.length);
/* 2066 */     i += arrayOfByte4.length;
/*      */ 
/*      */ 
/*      */     
/* 2070 */     if (this.fedAuthRequiredByUser) {
/* 2071 */       arrayOfByte1[i] = 1;
/* 2072 */       i++;
/*      */     } 
/*      */     
/* 2075 */     byte[] arrayOfByte5 = new byte[4096];
/* 2076 */     String str = " Prelogin error: host " + paramString + " port " + paramInt;
/*      */     
/* 2078 */     ActivityId activityId = ActivityCorrelator.getNext();
/* 2079 */     byte[] arrayOfByte6 = Util.asGuidByteArray(activityId.getId());
/* 2080 */     byte[] arrayOfByte7 = Util.asGuidByteArray(this.clientConnectionId);
/*      */ 
/*      */ 
/*      */     
/* 2084 */     if (this.fedAuthRequiredByUser) {
/* 2085 */       j = arrayOfByte1.length - 36 - 1;
/*      */     }
/*      */     else {
/*      */       
/* 2089 */       j = arrayOfByte1.length - 36;
/*      */     } 
/*      */ 
/*      */     
/* 2093 */     System.arraycopy(arrayOfByte7, 0, arrayOfByte1, j, arrayOfByte7.length);
/* 2094 */     j += arrayOfByte7.length;
/*      */ 
/*      */     
/* 2097 */     System.arraycopy(arrayOfByte6, 0, arrayOfByte1, j, arrayOfByte6.length);
/* 2098 */     j += arrayOfByte6.length;
/*      */     
/* 2100 */     long l = activityId.getSequence();
/* 2101 */     Util.writeInt((int)l, arrayOfByte1, j);
/* 2102 */     j += 4;
/*      */     
/* 2104 */     if (connectionlogger.isLoggable(Level.FINER)) {
/*      */       
/* 2106 */       connectionlogger.finer(toString() + " Requesting encryption level:" + TDS.getEncryptionLevel(this.requestedEncryptionLevel));
/* 2107 */       connectionlogger.finer(toString() + " ActivityId " + activityId.toString());
/*      */     } 
/*      */ 
/*      */     
/* 2111 */     if (this.tdsChannel.isLoggingPackets()) {
/* 2112 */       this.tdsChannel.logPacket(arrayOfByte1, 0, arrayOfByte1.length, toString() + " Prelogin request");
/*      */     }
/*      */     
/*      */     try {
/* 2116 */       this.tdsChannel.write(arrayOfByte1, 0, arrayOfByte1.length);
/* 2117 */       this.tdsChannel.flush();
/*      */     }
/* 2119 */     catch (SQLServerException sQLServerException) {
/*      */       
/* 2121 */       connectionlogger.warning(toString() + str + " Error sending prelogin request: " + sQLServerException.getMessage());
/* 2122 */       throw sQLServerException;
/*      */     } 
/*      */     
/* 2125 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*      */ 
/*      */     
/* 2128 */     int k = arrayOfByte5.length;
/* 2129 */     int m = 0;
/* 2130 */     boolean bool1 = false;
/* 2131 */     while (m < k) {
/*      */       int n;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2137 */         n = this.tdsChannel.read(arrayOfByte5, m, k - m);
/*      */       }
/* 2139 */       catch (SQLServerException sQLServerException) {
/*      */         
/* 2141 */         connectionlogger.warning(toString() + str + " Error reading prelogin response: " + sQLServerException.getMessage());
/* 2142 */         throw sQLServerException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2150 */       if (-1 == n) {
/*      */         
/* 2152 */         connectionlogger.warning(toString() + str + " Unexpected end of prelogin response after " + m + " bytes read");
/* 2153 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2154 */         Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2155 */         terminate(3, messageFormat.format(arrayOfObject));
/*      */       } 
/*      */ 
/*      */       
/* 2159 */       assert n >= 0;
/* 2160 */       assert n <= k - m;
/*      */       
/* 2162 */       if (this.tdsChannel.isLoggingPackets()) {
/* 2163 */         this.tdsChannel.logPacket(arrayOfByte5, m, n, toString() + " Prelogin response");
/*      */       }
/* 2165 */       m += n;
/*      */ 
/*      */ 
/*      */       
/* 2169 */       if (!bool1 && m >= 8) {
/*      */ 
/*      */         
/* 2172 */         if (4 != arrayOfByte5[0]) {
/*      */           
/* 2174 */           connectionlogger.warning(toString() + str + " Unexpected response type:" + arrayOfByte5[0]);
/* 2175 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2176 */           Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2177 */           terminate(3, messageFormat.format(arrayOfObject));
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2183 */         if (1 != (0x1 & arrayOfByte5[1])) {
/*      */           
/* 2185 */           connectionlogger.warning(toString() + str + " Unexpected response status:" + arrayOfByte5[1]);
/* 2186 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2187 */           Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2188 */           terminate(3, messageFormat.format(arrayOfObject));
/*      */         } 
/*      */ 
/*      */         
/* 2192 */         k = Util.readUnsignedShortBigEndian(arrayOfByte5, 2);
/* 2193 */         assert k >= 0;
/*      */         
/* 2195 */         if (k >= arrayOfByte5.length) {
/*      */           
/* 2197 */           connectionlogger.warning(toString() + str + " Response length:" + k + " is greater than allowed length:" + arrayOfByte5.length);
/* 2198 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_tcpipConnectionFailed"));
/* 2199 */           Object[] arrayOfObject = { paramString, Integer.toString(paramInt), SQLServerException.getErrString("R_notSQLServer") };
/* 2200 */           terminate(3, messageFormat.format(arrayOfObject));
/*      */         } 
/*      */         
/* 2203 */         bool1 = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2209 */     boolean bool2 = false;
/* 2210 */     this.negotiatedEncryptionLevel = -1;
/*      */     
/* 2212 */     byte b3 = 8;
/*      */ 
/*      */     
/*      */     while (true) {
/* 2216 */       if (b3 >= k) {
/*      */         
/* 2218 */         connectionlogger.warning(toString() + " Option token not found");
/* 2219 */         throwInvalidTDS();
/*      */       } 
/* 2221 */       byte b = arrayOfByte5[b3++];
/*      */ 
/*      */       
/* 2224 */       if (-1 == b) {
/*      */         break;
/*      */       }
/*      */       
/* 2228 */       if (b3 + 4 >= k) {
/*      */         
/* 2230 */         connectionlogger.warning(toString() + " Offset/Length not found for option:" + b);
/* 2231 */         throwInvalidTDS();
/*      */       } 
/*      */       
/* 2234 */       int n = Util.readUnsignedShortBigEndian(arrayOfByte5, b3) + 8;
/* 2235 */       b3 += 2;
/* 2236 */       assert n >= 0;
/*      */       
/* 2238 */       int i1 = Util.readUnsignedShortBigEndian(arrayOfByte5, b3);
/* 2239 */       b3 += 2;
/* 2240 */       assert i1 >= 0;
/*      */       
/* 2242 */       if (n + i1 > k) {
/*      */         
/* 2244 */         connectionlogger.warning(toString() + " Offset:" + n + " and length:" + i1 + " exceed response length:" + k);
/* 2245 */         throwInvalidTDS();
/*      */       } 
/*      */       
/* 2248 */       switch (b) {
/*      */         
/*      */         case 0:
/* 2251 */           if (bool2) {
/*      */             
/* 2253 */             connectionlogger.warning(toString() + " Version option already received");
/* 2254 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 2257 */           if (6 != i1) {
/*      */             
/* 2259 */             connectionlogger.warning(toString() + " Version option length:" + i1 + " is incorrect.  Correct value is 6.");
/* 2260 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 2263 */           this.serverMajorVersion = arrayOfByte5[n];
/* 2264 */           if (this.serverMajorVersion < 9) {
/*      */             
/* 2266 */             connectionlogger.warning(toString() + " Server major version:" + this.serverMajorVersion + " is not supported by this driver.");
/* 2267 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedServerVersion"));
/* 2268 */             Object[] arrayOfObject = { Integer.toString(arrayOfByte5[n]) };
/* 2269 */             terminate(6, messageFormat.format(arrayOfObject));
/*      */           } 
/*      */           
/* 2272 */           if (connectionlogger.isLoggable(Level.FINE)) {
/* 2273 */             connectionlogger.fine(toString() + " Server returned major version:" + arrayOfByte5[n]);
/*      */           }
/* 2275 */           bool2 = true;
/*      */           continue;
/*      */         
/*      */         case 1:
/* 2279 */           if (-1 != this.negotiatedEncryptionLevel) {
/*      */             
/* 2281 */             connectionlogger.warning(toString() + " Encryption option already received");
/* 2282 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 2285 */           if (1 != i1) {
/*      */             
/* 2287 */             connectionlogger.warning(toString() + " Encryption option length:" + i1 + " is incorrect.  Correct value is 1.");
/* 2288 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 2291 */           this.negotiatedEncryptionLevel = arrayOfByte5[n];
/*      */ 
/*      */           
/* 2294 */           if (0 != this.negotiatedEncryptionLevel && 1 != this.negotiatedEncryptionLevel && 3 != this.negotiatedEncryptionLevel && 2 != this.negotiatedEncryptionLevel) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 2299 */             connectionlogger.warning(toString() + " Server returned " + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
/* 2300 */             throwInvalidTDS();
/*      */           } 
/*      */           
/* 2303 */           if (connectionlogger.isLoggable(Level.FINER)) {
/* 2304 */             connectionlogger.finer(toString() + " Negotiated encryption level:" + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
/*      */           }
/*      */           
/* 2307 */           if (1 == this.requestedEncryptionLevel && 1 != this.negotiatedEncryptionLevel && 3 != this.negotiatedEncryptionLevel)
/*      */           {
/*      */ 
/*      */             
/* 2311 */             terminate(5, SQLServerException.getErrString("R_sslRequiredNoServerSupport"));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 2316 */           if (2 == this.requestedEncryptionLevel && 2 != this.negotiatedEncryptionLevel) {
/*      */ 
/*      */ 
/*      */             
/* 2320 */             if (3 == this.negotiatedEncryptionLevel) {
/* 2321 */               terminate(5, SQLServerException.getErrString("R_sslRequiredByServer"));
/*      */             }
/* 2323 */             connectionlogger.warning(toString() + " Client requested encryption level: " + TDS.getEncryptionLevel(this.requestedEncryptionLevel) + " Server returned unexpected encryption level: " + TDS.getEncryptionLevel(this.negotiatedEncryptionLevel));
/*      */ 
/*      */             
/* 2326 */             throwInvalidTDS();
/*      */           } 
/*      */           continue;
/*      */ 
/*      */         
/*      */         case 6:
/* 2332 */           if (0 != arrayOfByte5[n] && 1 != arrayOfByte5[n]) {
/* 2333 */             connectionlogger.severe(toString() + " Server sent an unexpected value for FedAuthRequired PreLogin Option. Value was " + arrayOfByte5[n]);
/* 2334 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthRequiredPreLoginResponseInvalidValue"));
/* 2335 */             throw new SQLServerException(messageFormat.format(new Object[] { Byte.valueOf(arrayOfByte5[n]) }, ), null);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2341 */           if ((null != this.authenticationString && !this.authenticationString.equalsIgnoreCase(SqlAuthentication.NotSpecified.toString())) || null != this.accessTokenInByte)
/*      */           {
/*      */ 
/*      */             
/* 2345 */             this.fedAuthRequiredPreLoginResponse = (arrayOfByte5[n] == 1);
/*      */           }
/*      */           continue;
/*      */       } 
/*      */       
/* 2350 */       if (connectionlogger.isLoggable(Level.FINER)) {
/* 2351 */         connectionlogger.finer(toString() + " Ignoring prelogin response option:" + b);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 2356 */     if (!bool2 || -1 == this.negotiatedEncryptionLevel) {
/*      */       
/* 2358 */       connectionlogger.warning(toString() + " Prelogin response is missing version and/or encryption option.");
/* 2359 */       throwInvalidTDS();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void throwInvalidTDS() throws SQLServerException {
/* 2365 */     terminate(4, SQLServerException.getErrString("R_invalidTDS"));
/*      */   }
/*      */ 
/*      */   
/*      */   final void throwInvalidTDSToken(String paramString) throws SQLServerException {
/* 2370 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unexpectedToken"));
/* 2371 */     Object[] arrayOfObject = { paramString };
/* 2372 */     String str = SQLServerException.getErrString("R_invalidTDS") + messageFormat.format(arrayOfObject);
/* 2373 */     terminate(4, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void terminate(int paramInt, String paramString) throws SQLServerException {
/* 2384 */     terminate(paramInt, paramString, null);
/*      */   } boolean executeCommand(TDSCommand paramTDSCommand) throws SQLServerException { synchronized (this.schedulerLock) { if (null != this.currentCommand) { this.currentCommand.detach(); this.currentCommand = null; }  boolean bool = false; try { bool = paramTDSCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(paramTDSCommand)); } finally { if (!bool && !isSessionUnAvailable()) this.currentCommand = paramTDSCommand;  }  return bool; }  } void resetCurrentCommand() throws SQLServerException { if (null != this.currentCommand) { this.currentCommand.detach(); this.currentCommand = null; }  } private final void connectionCommand(String paramString1, String paramString2) throws SQLServerException { final class ConnectionCommand extends UninterruptableTDSCommand {
/*      */       final String sql; ConnectionCommand(String param1String1, String param1String2) { super(param1String2); this.sql = param1String1; }
/*      */       final boolean doExecute() throws SQLServerException { startRequest((byte)1).writeString(this.sql); TDSParser.parse(startResponse(), getLogContext()); return true; } }; executeCommand(new ConnectionCommand(paramString1, paramString2)); }
/*      */   private String sqlStatementToInitialize() { String str = null; if (this.nLockTimeout > -1) str = " set lock_timeout " + this.nLockTimeout;  return str; }
/* 2389 */   final void terminate(int paramInt, String paramString, Throwable paramThrowable) throws SQLServerException { String str = this.state.equals(State.Opened) ? "08006" : "08001";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2394 */     if (!this.xopenStates) {
/* 2395 */       str = SQLServerException.mapFromXopen(str);
/*      */     }
/* 2397 */     SQLServerException sQLServerException = new SQLServerException(this, SQLServerException.checkAndAppendClientConnId(paramString, this), str, 0, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2405 */     if (null != paramThrowable) {
/* 2406 */       sQLServerException.initCause(paramThrowable);
/*      */     }
/* 2408 */     sQLServerException.setDriverErrorCode(paramInt);
/*      */     
/* 2410 */     notifyPooledConnection(sQLServerException);
/*      */     
/* 2412 */     close();
/*      */     
/* 2414 */     throw sQLServerException; } void setCatalogName(String paramString) { if (paramString != null)
/*      */       if (paramString.length() > 0)
/*      */         this.sCatalog = paramString;   }
/*      */   String sqlStatementToSetTransactionIsolationLevel() throws SQLServerException { String str = "set transaction isolation level "; switch (this.transactionIsolationLevel) { case 1: str = str + " read uncommitted "; return str;case 2: str = str + " read committed "; return str;
/*      */       case 4: str = str + " repeatable read "; return str;
/*      */       case 8: str = str + " serializable "; return str;
/*      */       case 4096: str = str + " snapshot "; return str; }  MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidTransactionLevel")); Object[] arrayOfObject = { Integer.toString(this.transactionIsolationLevel) }; SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, false); return str; }
/*      */   static String sqlStatementToSetCommit(boolean paramBoolean) { return (true == paramBoolean) ? "set implicit_transactions off " : "set implicit_transactions on "; }
/* 2422 */   SQLServerConnection(String paramString) throws SQLServerException { this.schedulerLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2896 */     this.warningSynchronization = new Integer(1); int i = nextConnectionID(); this.traceID = "ConnectionID:" + i; this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerConnection:" + i; if (connectionlogger.isLoggable(Level.FINE)) connectionlogger.fine(toString() + " created by (" + paramString + ")");  initResettableValues(); }
/*      */   public Statement createStatement() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "createStatement"); Statement statement = createStatement(1003, 1007); loggerExternal.exiting(getClassNameLogging(), "createStatement", statement); return statement; }
/*      */   public PreparedStatement prepareStatement(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "prepareStatement", paramString); PreparedStatement preparedStatement = prepareStatement(paramString, 1003, 1007); loggerExternal.exiting(getClassNameLogging(), "prepareStatement", preparedStatement); return preparedStatement; }
/*      */   public CallableStatement prepareCall(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "prepareCall", paramString); CallableStatement callableStatement = prepareCall(paramString, 1003, 1007); loggerExternal.exiting(getClassNameLogging(), "prepareCall", callableStatement); return callableStatement; } public String nativeSQL(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "nativeSQL", paramString); checkClosed(); loggerExternal.exiting(getClassNameLogging(), "nativeSQL", paramString); return paramString; } public void setAutoCommit(boolean paramBoolean) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) { loggerExternal.entering(getClassNameLogging(), "setAutoCommit", Boolean.valueOf(paramBoolean)); if (Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  }  String str = ""; checkClosed(); if (paramBoolean == this.databaseAutoCommitMode) return;  if (paramBoolean == true) str = "IF @@TRANCOUNT > 0 COMMIT TRAN ";  if (connectionlogger.isLoggable(Level.FINER)) connectionlogger.finer(toString() + " Autocommitmode current :" + this.databaseAutoCommitMode + " new: " + paramBoolean);  this.rolledBackTransaction = false; connectionCommand(str + sqlStatementToSetCommit(paramBoolean), "setAutoCommit"); this.databaseAutoCommitMode = paramBoolean; loggerExternal.exiting(getClassNameLogging(), "setAutoCommit"); } public boolean getAutoCommit() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getAutoCommit"); checkClosed(); boolean bool = (!this.inXATransaction && this.databaseAutoCommitMode) ? true : false; if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(getClassNameLogging(), "getAutoCommit", Boolean.valueOf(bool));  return bool; } final byte[] getTransactionDescriptor() { return this.transactionDescriptor; } public void commit() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "commit"); if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  checkClosed(); if (!this.databaseAutoCommitMode) connectionCommand("IF @@TRANCOUNT > 0 COMMIT TRAN", "Connection.commit");  loggerExternal.exiting(getClassNameLogging(), "commit"); } public void rollback() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "rollback"); if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  checkClosed(); if (this.databaseAutoCommitMode) { SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), (String)null, true); } else { connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "Connection.rollback"); }  loggerExternal.exiting(getClassNameLogging(), "rollback"); } public void abort(Executor paramExecutor) throws SQLException { loggerExternal.entering(getClassNameLogging(), "abort", paramExecutor); DriverJDBCVersion.checkSupportsJDBC41(); if (isClosed()) return;  if (null == paramExecutor) { MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument")); Object[] arrayOfObject = { "executor" }; SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, false); }  SecurityManager securityManager = System.getSecurityManager(); if (securityManager != null) try { SQLPermission sQLPermission = new SQLPermission("callAbort"); securityManager.checkPermission(sQLPermission); } catch (SecurityException securityException) { MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_permissionDenied")); Object[] arrayOfObject = { "callAbort" }; SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, true); }   setState(State.Closed); paramExecutor.execute(new Runnable() {
/*      */           public void run() { if (null != SQLServerConnection.this.tdsChannel) SQLServerConnection.this.tdsChannel.close();  }
/* 2901 */         }); loggerExternal.exiting(getClassNameLogging(), "abort"); } public SQLWarning getWarnings() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 2902 */     checkClosed();
/*      */     
/* 2904 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", this.sqlWarnings);
/* 2905 */     return this.sqlWarnings; }
/*      */   public void close() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "close"); setState(State.Closed); if (null != this.tdsChannel)
/*      */       this.tdsChannel.close();  loggerExternal.exiting(getClassNameLogging(), "close"); }
/*      */   final void poolCloseEventNotify() throws SQLServerException { if (this.state.equals(State.Opened) && null != this.pooledConnectionParent) { if (!this.databaseAutoCommitMode && !(this.pooledConnectionParent instanceof javax.sql.XAConnection))
/*      */         connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN", "close connection");  notifyPooledConnection(null); if (connectionlogger.isLoggable(Level.FINER))
/*      */         connectionlogger.finer(toString() + " Connection closed and returned to connection pool");  }  }
/* 2911 */   public boolean isClosed() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "isClosed"); loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(isSessionUnAvailable())); return isSessionUnAvailable(); } private void addWarning(String paramString) { synchronized (this.warningSynchronization)
/*      */     
/* 2913 */     { SQLWarning sQLWarning = new SQLWarning(paramString);
/*      */ 
/*      */       
/* 2916 */       if (null == this.sqlWarnings)
/*      */       
/* 2918 */       { this.sqlWarnings = sQLWarning; }
/*      */       
/*      */       else
/*      */       
/* 2922 */       { this.sqlWarnings.setNextWarning(sQLWarning); }  }  } public DatabaseMetaData getMetaData() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getMetaData"); checkClosed(); if (this.databaseMetaData == null) this.databaseMetaData = new SQLServerDatabaseMetaData(this);  loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.databaseMetaData); return this.databaseMetaData; }
/*      */   public void setReadOnly(boolean paramBoolean) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.entering(getClassNameLogging(), "setReadOnly", Boolean.valueOf(paramBoolean));  checkClosed(); loggerExternal.exiting(getClassNameLogging(), "setReadOnly"); }
/*      */   public boolean isReadOnly() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "isReadOnly"); checkClosed(); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(getClassNameLogging(), "isReadOnly", Boolean.valueOf(false));  return false; }
/*      */   public void setCatalog(String paramString) throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "setCatalog", paramString); if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  checkClosed(); if (paramString != null) { connectionCommand("use " + Util.escapeSQLId(paramString), "setCatalog"); this.sCatalog = paramString; }  loggerExternal.exiting(getClassNameLogging(), "setCatalog"); }
/*      */   public String getCatalog() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getCatalog"); checkClosed(); loggerExternal.exiting(getClassNameLogging(), "getCatalog", this.sCatalog); return this.sCatalog; }
/*      */   public void setTransactionIsolation(int paramInt) throws SQLServerException { if (loggerExternal.isLoggable(Level.FINER)) { loggerExternal.entering(getClassNameLogging(), "setTransactionIsolation", new Integer(paramInt)); if (Util.IsActivityTraceOn()) loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());  }  checkClosed(); if (paramInt == 0) return;  this.transactionIsolationLevel = paramInt; String str = sqlStatementToSetTransactionIsolationLevel(); connectionCommand(str, "setTransactionIsolation"); loggerExternal.exiting(getClassNameLogging(), "setTransactionIsolation"); }
/*      */   public int getTransactionIsolation() throws SQLServerException { loggerExternal.entering(getClassNameLogging(), "getTransactionIsolation"); checkClosed(); if (loggerExternal.isLoggable(Level.FINER)) loggerExternal.exiting(getClassNameLogging(), "getTransactionIsolation", new Integer(this.transactionIsolationLevel));  return this.transactionIsolationLevel; }
/* 2929 */   public void clearWarnings() throws SQLServerException { synchronized (this.warningSynchronization) {
/*      */       
/* 2931 */       loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/* 2932 */       checkClosed();
/* 2933 */       this.sqlWarnings = null;
/* 2934 */       loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement(int paramInt1, int paramInt2) throws SQLServerException {
/* 2941 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2942 */       loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2) }); 
/* 2943 */     checkClosed();
/* 2944 */     SQLServerStatement sQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/* 2945 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", sQLServerStatement);
/* 2946 */     return sQLServerStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLServerException {
/* 2951 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2952 */       loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) }); 
/* 2953 */     checkClosed();
/* 2954 */     SQLServerPreparedStatement sQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */ 
/*      */     
/* 2957 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 2958 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   private PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 2963 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2964 */       loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2), paramSQLServerStatementColumnEncryptionSetting }); 
/* 2965 */     checkClosed();
/* 2966 */     SQLServerPreparedStatement sQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */     
/* 2968 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 2969 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLServerException {
/* 2974 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2975 */       loggerExternal.entering(getClassNameLogging(), "prepareCall", new Object[] { paramString, new Integer(paramInt1), new Integer(paramInt2) }); 
/* 2976 */     checkClosed();
/* 2977 */     SQLServerCallableStatement sQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2983 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", sQLServerCallableStatement);
/* 2984 */     return sQLServerCallableStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setTypeMap(Map<String, Class<?>> paramMap) throws SQLServerException {
/* 2989 */     loggerExternal.entering(getClassNameLogging(), "setTypeMap", paramMap);
/* 2990 */     checkClosed();
/* 2991 */     if (paramMap != null && paramMap instanceof HashMap)
/*      */     {
/*      */       
/* 2994 */       if (paramMap.isEmpty()) {
/*      */         
/* 2996 */         loggerExternal.exiting(getClassNameLogging(), "setTypeMap");
/*      */         
/*      */         return;
/*      */       } 
/*      */     }
/* 3001 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Class<?>> getTypeMap() throws SQLServerException {
/* 3006 */     loggerExternal.entering(getClassNameLogging(), "getTypeMap");
/* 3007 */     checkClosed();
/* 3008 */     HashMap<Object, Object> hashMap = new HashMap<>();
/* 3009 */     loggerExternal.exiting(getClassNameLogging(), "getTypeMap", hashMap);
/* 3010 */     return (Map)hashMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int writeAEFeatureRequest(boolean paramBoolean, TDSWriter paramTDSWriter) throws SQLServerException {
/* 3018 */     byte b = 6;
/*      */     
/* 3020 */     if (paramBoolean) {
/*      */       
/* 3022 */       paramTDSWriter.writeByte((byte)4);
/* 3023 */       paramTDSWriter.writeInt(1);
/* 3024 */       paramTDSWriter.writeByte((byte)1);
/*      */     } 
/* 3026 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   int writeFedAuthFeatureRequest(boolean paramBoolean, TDSWriter paramTDSWriter, FederatedAuthenticationFeatureExtensionData paramFederatedAuthenticationFeatureExtensionData) throws SQLServerException {
/* 3031 */     assert paramFederatedAuthenticationFeatureExtensionData.libraryType == 2 || paramFederatedAuthenticationFeatureExtensionData.libraryType == 1;
/*      */     
/* 3033 */     int i = 0;
/* 3034 */     int j = 0;
/*      */ 
/*      */     
/* 3037 */     switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
/*      */       case 2:
/* 3039 */         i = 2;
/*      */         break;
/*      */       case 1:
/* 3042 */         assert null != paramFederatedAuthenticationFeatureExtensionData.accessToken;
/* 3043 */         i = 5 + paramFederatedAuthenticationFeatureExtensionData.accessToken.length;
/*      */         break;
/*      */       
/*      */       default:
/*      */         assert false;
/*      */         break;
/*      */     } 
/* 3050 */     j = i + 5;
/*      */ 
/*      */     
/* 3053 */     if (paramBoolean)
/* 3054 */     { byte b1; paramTDSWriter.writeByte((byte)2);
/*      */ 
/*      */       
/* 3057 */       byte b = 0;
/*      */ 
/*      */       
/* 3060 */       switch (paramFederatedAuthenticationFeatureExtensionData.libraryType) {
/*      */         case 2:
/* 3062 */           assert this.federatedAuthenticationInfoRequested == true;
/* 3063 */           b = (byte)(b | 0x4);
/*      */           break;
/*      */         case 1:
/* 3066 */           assert this.federatedAuthenticationRequested == true;
/* 3067 */           b = (byte)(b | 0x2);
/*      */           break;
/*      */         
/*      */         default:
/*      */           assert false;
/*      */           break;
/*      */       } 
/* 3074 */       b = (byte)(b | (byte)((paramFederatedAuthenticationFeatureExtensionData.fedAuthRequiredPreLoginResponse == true) ? 1 : 0));
/*      */ 
/*      */       
/* 3077 */       paramTDSWriter.writeInt(i);
/*      */ 
/*      */ 
/*      */       
/* 3081 */       paramTDSWriter.writeByte(b);
/*      */ 
/*      */ 
/*      */       
/* 3085 */       switch (paramFederatedAuthenticationFeatureExtensionData.libraryType)
/*      */       { case 2:
/* 3087 */           b1 = 0;
/* 3088 */           switch (paramFederatedAuthenticationFeatureExtensionData.authentication) {
/*      */             case ActiveDirectoryPassword:
/* 3090 */               b1 = 1;
/*      */               break;
/*      */             case ActiveDirectoryIntegrated:
/* 3093 */               b1 = 2;
/*      */               break;
/*      */             
/*      */             default:
/*      */               assert false;
/*      */               break;
/*      */           } 
/* 3100 */           paramTDSWriter.writeByte(b1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3111 */           return j;case 1: paramTDSWriter.writeInt(paramFederatedAuthenticationFeatureExtensionData.accessToken.length); paramTDSWriter.writeBytes(paramFederatedAuthenticationFeatureExtensionData.accessToken, 0, paramFederatedAuthenticationFeatureExtensionData.accessToken.length); return j; }  assert false; }  return j;
/*      */   }
/*      */   
/*      */   private final class LogonCommand
/*      */     extends UninterruptableTDSCommand
/*      */   {
/*      */     LogonCommand() {
/* 3118 */       super("logon");
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/* 3123 */       SQLServerConnection.this.logon(this);
/* 3124 */       return true;
/*      */     }
/*      */   }
/*      */   
/*      */   private final void logon(LogonCommand paramLogonCommand) throws SQLServerException {
/*      */     KerbAuthentication kerbAuthentication;
/* 3130 */     AuthenticationJNI authenticationJNI = null;
/* 3131 */     if (this.integratedSecurity && AuthenticationScheme.nativeAuthentication == this.intAuthScheme)
/* 3132 */       authenticationJNI = new AuthenticationJNI(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber()); 
/* 3133 */     if (this.integratedSecurity && AuthenticationScheme.javaKerberos == this.intAuthScheme) {
/* 3134 */       kerbAuthentication = new KerbAuthentication(this, this.currentConnectPlaceHolder.getServerName(), this.currentConnectPlaceHolder.getPortNumber());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3139 */     if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString()) || (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && this.fedAuthRequiredPreLoginResponse)) {
/*      */       
/* 3141 */       this.federatedAuthenticationInfoRequested = true;
/* 3142 */       this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(2, this.authenticationString, this.fedAuthRequiredPreLoginResponse);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3148 */     if (null != this.accessTokenInByte) {
/* 3149 */       this.fedAuthFeatureExtensionData = new FederatedAuthenticationFeatureExtensionData(1, this.fedAuthRequiredPreLoginResponse, this.accessTokenInByte);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3155 */       this.federatedAuthenticationRequested = true;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 3160 */       sendLogon(paramLogonCommand, kerbAuthentication, this.fedAuthFeatureExtensionData);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3165 */       if (!this.isRoutedInCurrentAttempt)
/*      */       {
/* 3167 */         this.originalCatalog = this.sCatalog;
/* 3168 */         String str = sqlStatementToInitialize();
/* 3169 */         if (str != null)
/*      */         {
/* 3171 */           connectionCommand(str, "Change Settings");
/*      */         }
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 3177 */       if (this.integratedSecurity) {
/*      */         
/* 3179 */         if (null != kerbAuthentication)
/* 3180 */           kerbAuthentication.ReleaseClientContext(); 
/* 3181 */         kerbAuthentication = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void processEnvChange(TDSReader paramTDSReader) throws SQLServerException {
/*      */     byte[] arrayOfByte;
/*      */     int k, m, n, i1;
/*      */     String str1, str2;
/* 3210 */     paramTDSReader.readUnsignedByte();
/* 3211 */     int i = paramTDSReader.readUnsignedShort();
/*      */     
/* 3213 */     TDSReaderMark tDSReaderMark = paramTDSReader.mark();
/* 3214 */     int j = paramTDSReader.readUnsignedByte();
/* 3215 */     switch (j) {
/*      */       
/*      */       case 4:
/*      */         
/*      */         try {
/*      */           
/* 3221 */           this.tdsPacketSize = Integer.parseInt(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/*      */         }
/* 3223 */         catch (NumberFormatException numberFormatException) {
/*      */           
/* 3225 */           paramTDSReader.throwInvalidTDS();
/*      */         } 
/* 3227 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3228 */           connectionlogger.finer(toString() + " Network packet size is " + this.tdsPacketSize + " bytes");
/*      */         }
/*      */         break;
/*      */       case 7:
/* 3232 */         if (SQLCollation.tdsLength() != paramTDSReader.readUnsignedByte()) {
/* 3233 */           paramTDSReader.throwInvalidTDS();
/*      */         }
/*      */         
/*      */         try {
/* 3237 */           this.databaseCollation = new SQLCollation(paramTDSReader);
/*      */         }
/* 3239 */         catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */           
/* 3241 */           terminate(4, unsupportedEncodingException.getMessage(), unsupportedEncodingException);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 8:
/*      */       case 11:
/* 3248 */         this.rolledBackTransaction = false;
/* 3249 */         arrayOfByte = getTransactionDescriptor();
/*      */         
/* 3251 */         if (arrayOfByte.length != paramTDSReader.readUnsignedByte()) {
/* 3252 */           paramTDSReader.throwInvalidTDS();
/*      */         }
/* 3254 */         paramTDSReader.readBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */         
/* 3256 */         if (connectionlogger.isLoggable(Level.FINER)) {
/*      */           String str;
/*      */           
/* 3259 */           if (8 == j) {
/* 3260 */             str = " started";
/*      */           } else {
/* 3262 */             str = " enlisted";
/*      */           } 
/* 3264 */           connectionlogger.finer(toString() + str);
/*      */         } 
/*      */         break;
/*      */ 
/*      */       
/*      */       case 10:
/* 3270 */         this.rolledBackTransaction = true;
/*      */         
/* 3272 */         if (this.inXATransaction) {
/*      */           
/* 3274 */           if (connectionlogger.isLoggable(Level.FINER)) {
/* 3275 */             connectionlogger.finer(toString() + " rolled back. (DTC)");
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */ 
/*      */         
/* 3284 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3285 */           connectionlogger.finer(toString() + " rolled back");
/*      */         }
/*      */         
/* 3288 */         Arrays.fill(getTransactionDescriptor(), (byte)0);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 9:
/* 3294 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3295 */           connectionlogger.finer(toString() + " committed");
/*      */         }
/* 3297 */         Arrays.fill(getTransactionDescriptor(), (byte)0);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 12:
/* 3302 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3303 */           connectionlogger.finer(toString() + " defected");
/*      */         }
/* 3305 */         Arrays.fill(getTransactionDescriptor(), (byte)0);
/*      */         break;
/*      */ 
/*      */       
/*      */       case 1:
/* 3310 */         setCatalogName(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/*      */         break;
/*      */       
/*      */       case 13:
/* 3314 */         setFailoverPartnerServerProvided(paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte()));
/*      */         break;
/*      */       
/*      */       case 2:
/*      */       case 3:
/*      */       case 5:
/*      */       case 6:
/*      */       case 15:
/*      */       case 16:
/*      */       case 17:
/*      */       case 18:
/*      */       case 19:
/* 3326 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 3327 */           connectionlogger.finer(toString() + " Ignored env change: " + j);
/*      */         }
/*      */         break;
/*      */ 
/*      */       
/*      */       case 20:
/* 3333 */         k = m = n = i1 = -1;
/*      */         
/* 3335 */         str1 = null;
/*      */ 
/*      */         
/*      */         try {
/* 3339 */           k = paramTDSReader.readUnsignedShort();
/* 3340 */           if (k <= 5)
/*      */           {
/* 3342 */             throwInvalidTDS();
/*      */           }
/*      */           
/* 3345 */           m = paramTDSReader.readUnsignedByte();
/* 3346 */           if (m != 0)
/*      */           {
/* 3348 */             throwInvalidTDS();
/*      */           }
/*      */           
/* 3351 */           n = paramTDSReader.readUnsignedShort();
/* 3352 */           if (n <= 0 || n > 65535)
/*      */           {
/* 3354 */             throwInvalidTDS();
/*      */           }
/*      */           
/* 3357 */           i1 = paramTDSReader.readUnsignedShort();
/* 3358 */           if (i1 <= 0 || i1 > 1024)
/*      */           {
/* 3360 */             throwInvalidTDS();
/*      */           }
/*      */           
/* 3363 */           str1 = paramTDSReader.readUnicodeString(i1);
/* 3364 */           assert str1 != null;
/*      */         
/*      */         }
/*      */         finally {
/*      */           
/* 3369 */           if (connectionlogger.isLoggable(Level.FINER))
/*      */           {
/* 3371 */             connectionlogger.finer(toString() + " Received routing ENVCHANGE with the following values." + " routingDataValueLength:" + k + " protocol:" + m + " portNumber:" + n + " serverNameLength:" + i1 + " serverName:" + ((str1 != null) ? str1 : "null"));
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3382 */         str2 = this.activeConnectionProperties.getProperty("hostNameInCertificate");
/* 3383 */         if (null != str2 && str2.startsWith("*") && str1.indexOf('.') != -1) {
/*      */           
/* 3385 */           char[] arrayOfChar1 = str2.toCharArray();
/* 3386 */           char[] arrayOfChar2 = str1.toCharArray();
/* 3387 */           boolean bool = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3394 */           for (int i2 = str2.length() - 1, i3 = str1.length() - 1; i2 > 0 && i3 > 0; i2--, i3--) {
/*      */             
/* 3396 */             if (arrayOfChar2[i3] != arrayOfChar1[i2]) {
/*      */               
/* 3398 */               bool = false;
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/* 3403 */           if (bool) {
/*      */             
/* 3405 */             String str = "*" + str1.substring(str1.indexOf('.'));
/* 3406 */             this.activeConnectionProperties.setProperty("hostNameInCertificate", str);
/*      */             
/* 3408 */             if (connectionlogger.isLoggable(Level.FINER))
/*      */             {
/* 3410 */               connectionlogger.finer(toString() + "Using new host to validate the SSL certificate");
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 3415 */         this.isRoutedInCurrentAttempt = true;
/* 3416 */         this.routingInfo = new ServerPortPlaceHolder(str1, n, null, this.integratedSecurity);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 3422 */         connectionlogger.warning(toString() + " Unknown environment change: " + j);
/* 3423 */         throwInvalidTDS();
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3429 */     paramTDSReader.reset(tDSReaderMark);
/* 3430 */     paramTDSReader.readBytes(new byte[i], 0, i);
/*      */   }
/*      */   
/*      */   final void processFedAuthInfo(TDSReader paramTDSReader, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
/* 3434 */     SqlFedAuthInfo sqlFedAuthInfo = new SqlFedAuthInfo();
/*      */     
/* 3436 */     paramTDSReader.readUnsignedByte();
/*      */ 
/*      */     
/* 3439 */     int i = paramTDSReader.readInt();
/*      */     
/* 3441 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 3443 */       connectionlogger.fine(toString() + " FEDAUTHINFO token stream length = " + i);
/*      */     }
/*      */     
/* 3446 */     if (i < 4) {
/*      */ 
/*      */       
/* 3449 */       connectionlogger.severe(toString() + "FEDAUTHINFO token stream length too short for CountOfInfoIDs.");
/* 3450 */       throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForCountOfInfoIds"), null);
/*      */     } 
/*      */ 
/*      */     
/* 3454 */     int j = paramTDSReader.readInt();
/*      */     
/* 3456 */     i -= 4;
/*      */     
/* 3458 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 3460 */       connectionlogger.fine(toString() + " CountOfInfoIDs = " + j);
/*      */     }
/*      */     
/* 3463 */     if (i > 0) {
/*      */       
/* 3465 */       byte[] arrayOfByte = new byte[i];
/*      */       
/* 3467 */       paramTDSReader.readBytes(arrayOfByte, 0, i);
/*      */       
/* 3469 */       if (connectionlogger.isLoggable(Level.FINER))
/*      */       {
/* 3471 */         connectionlogger.fine(toString() + " Read rest of FEDAUTHINFO token stream: " + Arrays.toString(arrayOfByte));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3482 */       int k = j * 9;
/*      */       
/* 3484 */       for (byte b = 0; b < j; b++) {
/* 3485 */         int m = b * 9;
/*      */         
/* 3487 */         byte b1 = arrayOfByte[m];
/* 3488 */         byte[] arrayOfByte1 = new byte[4];
/* 3489 */         arrayOfByte1[3] = arrayOfByte[m + 1];
/* 3490 */         arrayOfByte1[2] = arrayOfByte[m + 2];
/* 3491 */         arrayOfByte1[1] = arrayOfByte[m + 3];
/* 3492 */         arrayOfByte1[0] = arrayOfByte[m + 4];
/* 3493 */         ByteBuffer byteBuffer = ByteBuffer.wrap(arrayOfByte1);
/* 3494 */         int n = byteBuffer.getInt();
/*      */         
/* 3496 */         arrayOfByte1 = new byte[4];
/* 3497 */         arrayOfByte1[3] = arrayOfByte[m + 5];
/* 3498 */         arrayOfByte1[2] = arrayOfByte[m + 6];
/* 3499 */         arrayOfByte1[1] = arrayOfByte[m + 7];
/* 3500 */         arrayOfByte1[0] = arrayOfByte[m + 8];
/* 3501 */         byteBuffer = ByteBuffer.wrap(arrayOfByte1);
/* 3502 */         int i1 = byteBuffer.getInt();
/*      */         
/* 3504 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3506 */           connectionlogger.fine(toString() + " FedAuthInfoOpt: ID=" + b1 + ", DataLen=" + n + ", Offset=" + i1);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3511 */         i1 -= 4;
/*      */ 
/*      */         
/* 3514 */         if (i1 < k || i1 >= i) {
/* 3515 */           connectionlogger.severe(toString() + "FedAuthInfoDataOffset points to an invalid location.");
/* 3516 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoInvalidOffset"));
/* 3517 */           throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(i1) }, ), null);
/*      */         } 
/*      */ 
/*      */         
/* 3521 */         String str = null;
/*      */         try {
/* 3523 */           byte[] arrayOfByte2 = new byte[n];
/* 3524 */           System.arraycopy(arrayOfByte, i1, arrayOfByte2, 0, n);
/* 3525 */           str = new String(arrayOfByte2, "UTF-16LE");
/*      */         }
/* 3527 */         catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 3528 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */           
/* 3530 */           Object[] arrayOfObject = { "UTF-16LE" };
/* 3531 */           throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */         }
/* 3533 */         catch (Exception exception) {
/* 3534 */           connectionlogger.severe(toString() + "Failed to read FedAuthInfoData.");
/* 3535 */           throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoFailedToReadData"), null);
/*      */         } 
/*      */         
/* 3538 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3540 */           connectionlogger.fine(toString() + " FedAuthInfoData: " + str);
/*      */         }
/*      */ 
/*      */         
/* 3544 */         switch (b1) {
/*      */           case 2:
/* 3546 */             sqlFedAuthInfo.spn = str;
/*      */             break;
/*      */           case 1:
/* 3549 */             sqlFedAuthInfo.stsurl = str;
/*      */             break;
/*      */           default:
/* 3552 */             if (connectionlogger.isLoggable(Level.FINER))
/*      */             {
/* 3554 */               connectionlogger.fine(toString() + " Ignoring unknown federated authentication info option: " + b1);
/*      */             }
/*      */             break;
/*      */         } 
/*      */       
/*      */       } 
/*      */     } else {
/* 3561 */       connectionlogger.severe(toString() + "FEDAUTHINFO token stream is not long enough to contain the data it claims to.");
/* 3562 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthInfoLengthTooShortForData"));
/* 3563 */       throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(i) }, ), null);
/*      */     } 
/*      */     
/* 3566 */     if (null == sqlFedAuthInfo.spn || null == sqlFedAuthInfo.stsurl || sqlFedAuthInfo.spn.trim().isEmpty() || sqlFedAuthInfo.stsurl.trim().isEmpty()) {
/*      */       
/* 3568 */       connectionlogger.severe(toString() + "FEDAUTHINFO token stream does not contain both STSURL and SPN.");
/* 3569 */       throw new SQLServerException(SQLServerException.getErrString("R_FedAuthInfoDoesNotContainStsurlAndSpn"), null);
/*      */     } 
/*      */     
/* 3572 */     onFedAuthInfo(sqlFedAuthInfo, paramTDSTokenHandler);
/*      */   }
/*      */   
/*      */   final class FedAuthTokenCommand
/*      */     extends UninterruptableTDSCommand
/*      */   {
/* 3578 */     TDSTokenHandler tdsTokenHandler = null;
/* 3579 */     SQLServerConnection.SqlFedAuthToken fedAuthToken = null;
/*      */     
/*      */     FedAuthTokenCommand(SQLServerConnection.SqlFedAuthToken param1SqlFedAuthToken, TDSTokenHandler param1TDSTokenHandler) {
/* 3582 */       super("FedAuth");
/* 3583 */       this.tdsTokenHandler = param1TDSTokenHandler;
/* 3584 */       this.fedAuthToken = param1SqlFedAuthToken;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/* 3589 */       SQLServerConnection.this.sendFedAuthToken(this, this.fedAuthToken, this.tdsTokenHandler);
/* 3590 */       return true;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void onFedAuthInfo(SqlFedAuthInfo paramSqlFedAuthInfo, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
/* 3599 */     assert this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString()) && this.fedAuthRequiredPreLoginResponse;
/*      */ 
/*      */     
/* 3602 */     assert null != paramSqlFedAuthInfo;
/*      */     
/* 3604 */     this.attemptRefreshTokenLocked = true;
/* 3605 */     this.fedAuthToken = getFedAuthToken(paramSqlFedAuthInfo);
/* 3606 */     this.attemptRefreshTokenLocked = false;
/*      */ 
/*      */     
/* 3609 */     assert null != this.fedAuthToken;
/*      */     
/* 3611 */     FedAuthTokenCommand fedAuthTokenCommand = new FedAuthTokenCommand(this.fedAuthToken, paramTDSTokenHandler);
/* 3612 */     fedAuthTokenCommand.execute(this.tdsChannel.getWriter(), this.tdsChannel.getReader(fedAuthTokenCommand));
/*      */   }
/*      */ 
/*      */   
/*      */   private SqlFedAuthToken getFedAuthToken(SqlFedAuthInfo paramSqlFedAuthInfo) throws SQLServerException {
/* 3617 */     assert null != paramSqlFedAuthInfo;
/*      */ 
/*      */     
/* 3620 */     int i = 100;
/*      */ 
/*      */     
/* 3623 */     byte b = 0;
/*      */     
/* 3625 */     FedAuthDllInfo fedAuthDllInfo = null;
/*      */     
/* 3627 */     String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
/* 3628 */     String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
/*      */     
/* 3630 */     long l = 0L;
/*      */     
/*      */     while (true) {
/* 3633 */       b++;
/*      */       
/*      */       try {
/* 3636 */         if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryPassword.toString())) {
/* 3637 */           fedAuthDllInfo = AuthenticationJNI.getAccessToken(str1, str2, paramSqlFedAuthInfo.stsurl, paramSqlFedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", l);
/*      */         }
/* 3639 */         else if (this.authenticationString.trim().equalsIgnoreCase(SqlAuthentication.ActiveDirectoryIntegrated.toString())) {
/* 3640 */           fedAuthDllInfo = AuthenticationJNI.getAccessTokenForWindowsIntegrated(paramSqlFedAuthInfo.stsurl, paramSqlFedAuthInfo.spn, this.clientConnectionId.toString(), "7f98cb04-cd1e-40df-9140-3bf7e2cea4db", l);
/*      */         } 
/*      */ 
/*      */         
/* 3644 */         assert null != fedAuthDllInfo.accessTokenBytes;
/*      */ 
/*      */ 
/*      */         
/*      */         break;
/* 3649 */       } catch (DLLException dLLException) {
/*      */ 
/*      */         
/* 3652 */         int j = dLLException.GetCategory();
/* 3653 */         if (-1 == j) {
/* 3654 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnableLoadADALSqlDll"));
/* 3655 */           Object[] arrayOfObject = { Integer.toHexString(dLLException.GetState()) };
/* 3656 */           throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */         } 
/*      */         
/* 3659 */         int k = TimerRemaining(this.timerExpire);
/* 3660 */         if (2 != j || timerHasExpired(this.timerExpire) || i >= k) {
/*      */ 
/*      */           
/* 3663 */           String str4 = Integer.toHexString(dLLException.GetStatus());
/*      */           
/* 3665 */           if (connectionlogger.isLoggable(Level.FINER))
/*      */           {
/* 3667 */             connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken.AdalException category:" + j + " error: " + str4);
/*      */           }
/*      */           
/* 3670 */           MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_ADALAuthenticationMiddleErrorMessage"));
/* 3671 */           String str5 = Integer.toHexString(dLLException.GetStatus()).toUpperCase();
/* 3672 */           Object[] arrayOfObject1 = { str5, Integer.valueOf(dLLException.GetState()) };
/* 3673 */           SQLServerException sQLServerException = new SQLServerException(messageFormat1.format(arrayOfObject1), dLLException);
/*      */           
/* 3675 */           MessageFormat messageFormat2 = new MessageFormat(SQLServerException.getErrString("R_ADALExecution"));
/* 3676 */           Object[] arrayOfObject2 = { str1, this.authenticationString };
/* 3677 */           throw new SQLServerException(messageFormat2.format(arrayOfObject2), null, 0, sQLServerException);
/*      */         } 
/*      */         
/* 3680 */         if (connectionlogger.isLoggable(Level.FINER)) {
/*      */           
/* 3682 */           connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken sleeping: " + i + " milliseconds.");
/* 3683 */           connectionlogger.fine(toString() + " SQLServerConnection.getFedAuthToken remaining: " + k + " milliseconds.");
/*      */         } 
/*      */         
/*      */         try {
/* 3687 */           Thread.sleep(i);
/* 3688 */         } catch (InterruptedException interruptedException) {}
/*      */ 
/*      */         
/* 3691 */         i *= 2;
/*      */       } 
/*      */     } 
/*      */     
/* 3695 */     byte[] arrayOfByte = fedAuthDllInfo.accessTokenBytes;
/*      */     
/* 3697 */     String str3 = null;
/*      */     try {
/* 3699 */       str3 = new String(arrayOfByte, "UTF-16LE");
/*      */     }
/* 3701 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 3702 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */       
/* 3704 */       Object[] arrayOfObject = { "UTF-16LE" };
/* 3705 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */     
/* 3708 */     return new SqlFedAuthToken(str3, fedAuthDllInfo.expiresIn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendFedAuthToken(FedAuthTokenCommand paramFedAuthTokenCommand, SqlFedAuthToken paramSqlFedAuthToken, TDSTokenHandler paramTDSTokenHandler) throws SQLServerException {
/* 3717 */     assert null != paramSqlFedAuthToken;
/* 3718 */     assert null != paramSqlFedAuthToken.accessToken;
/*      */     
/* 3720 */     if (connectionlogger.isLoggable(Level.FINER))
/*      */     {
/* 3722 */       connectionlogger.fine(toString() + " Sending federated authentication token.");
/*      */     }
/*      */     
/* 3725 */     TDSWriter tDSWriter = paramFedAuthTokenCommand.startRequest((byte)8);
/*      */     
/* 3727 */     byte[] arrayOfByte = null;
/*      */     try {
/* 3729 */       arrayOfByte = paramSqlFedAuthToken.accessToken.getBytes("UTF-16LE");
/* 3730 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 3731 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*      */       
/* 3733 */       Object[] arrayOfObject = { "UTF-16LE" };
/* 3734 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3739 */     tDSWriter.writeInt(arrayOfByte.length + 4);
/*      */ 
/*      */     
/* 3742 */     tDSWriter.writeInt(arrayOfByte.length);
/*      */ 
/*      */     
/* 3745 */     tDSWriter.writeBytes(arrayOfByte, 0, arrayOfByte.length);
/*      */ 
/*      */     
/* 3748 */     TDSReader tDSReader = paramFedAuthTokenCommand.startResponse();
/*      */     
/* 3750 */     this.federatedAuthenticationRequested = true;
/*      */     
/* 3752 */     TDSParser.parse(tDSReader, paramTDSTokenHandler);
/*      */   }
/*      */   
/*      */   final void processFeatureExtAck(TDSReader paramTDSReader) throws SQLServerException {
/*      */     byte b;
/* 3757 */     paramTDSReader.readUnsignedByte();
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 3762 */       b = (byte)paramTDSReader.readUnsignedByte();
/*      */       
/* 3764 */       if (b == -1)
/*      */         continue; 
/* 3766 */       int i = paramTDSReader.readInt();
/*      */       
/* 3768 */       byte[] arrayOfByte = new byte[i];
/* 3769 */       if (i > 0) {
/* 3770 */         paramTDSReader.readBytes(arrayOfByte, 0, i);
/*      */       }
/* 3772 */       onFeatureExtAck(b, arrayOfByte);
/*      */     }
/* 3774 */     while (b != -1); } private void onFeatureExtAck(int paramInt, byte[] paramArrayOfbyte) throws SQLServerException {
/*      */     MessageFormat messageFormat;
/*      */     byte b;
/*      */     Object[] arrayOfObject;
/* 3778 */     if (null != this.routingInfo) {
/*      */       return;
/*      */     }
/*      */     
/* 3782 */     switch (paramInt) {
/*      */       case 2:
/* 3784 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3786 */           connectionlogger.fine(toString() + " Received feature extension acknowledgement for federated authentication.");
/*      */         }
/*      */         
/* 3789 */         if (!this.federatedAuthenticationRequested) {
/* 3790 */           connectionlogger.severe(toString() + " Did not request federated authentication.");
/* 3791 */           MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_UnrequestedFeatureAckReceived"));
/* 3792 */           Object[] arrayOfObject1 = { Integer.valueOf(paramInt) };
/* 3793 */           throw new SQLServerException(messageFormat1.format(arrayOfObject1), null);
/*      */         } 
/*      */ 
/*      */         
/* 3797 */         assert null != this.fedAuthFeatureExtensionData;
/*      */         
/* 3799 */         switch (this.fedAuthFeatureExtensionData.libraryType) {
/*      */           
/*      */           case 1:
/*      */           case 2:
/* 3803 */             if (0 != paramArrayOfbyte.length) {
/* 3804 */               connectionlogger.severe(toString() + " Federated authentication feature extension ack for ADAL and Security Token includes extra data.");
/* 3805 */               throw new SQLServerException(SQLServerException.getErrString("R_FedAuthFeatureAckContainsExtraData"), null);
/*      */             } 
/*      */             break;
/*      */           
/*      */           default:
/*      */             assert false;
/* 3811 */             connectionlogger.severe(toString() + " Attempting to use unknown federated authentication library.");
/* 3812 */             messageFormat = new MessageFormat(SQLServerException.getErrString("R_FedAuthFeatureAckUnknownLibraryType"));
/* 3813 */             arrayOfObject = new Object[] { Integer.valueOf(this.fedAuthFeatureExtensionData.libraryType) };
/* 3814 */             throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */         } 
/* 3816 */         this.federatedAuthenticationAcknowledged = true;
/*      */         return;
/*      */ 
/*      */       
/*      */       case 4:
/* 3821 */         if (connectionlogger.isLoggable(Level.FINER))
/*      */         {
/* 3823 */           connectionlogger.fine(toString() + " Received feature extension acknowledgement for AE.");
/*      */         }
/*      */         
/* 3826 */         if (1 > paramArrayOfbyte.length) {
/* 3827 */           connectionlogger.severe(toString() + " Unknown version number for AE.");
/* 3828 */           throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);
/*      */         } 
/*      */         
/* 3831 */         b = paramArrayOfbyte[0];
/* 3832 */         if (0 == b || b > 1) {
/* 3833 */           connectionlogger.severe(toString() + " Invalid version number for AE.");
/* 3834 */           throw new SQLServerException(SQLServerException.getErrString("R_InvalidAEVersionNumber"), null);
/*      */         } 
/*      */         
/* 3837 */         assert b == 1;
/* 3838 */         this.serverSupportsColumnEncryption = true;
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3844 */     connectionlogger.severe(toString() + " Unknown feature ack.");
/* 3845 */     throw new SQLServerException(SQLServerException.getErrString("R_UnknownFeatureAck"), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void executeDTCCommand(int paramInt, byte[] paramArrayOfbyte, String paramString) throws SQLServerException {
/*      */     final class DTCCommand
/*      */       extends UninterruptableTDSCommand
/*      */     {
/*      */       private final int requestType;
/*      */ 
/*      */ 
/*      */       
/*      */       private final byte[] payload;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       DTCCommand(int param1Int, byte[] param1ArrayOfbyte, String param1String) {
/* 3865 */         super(param1String);
/* 3866 */         this.requestType = param1Int;
/* 3867 */         this.payload = param1ArrayOfbyte;
/*      */       }
/*      */ 
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 3872 */         TDSWriter tDSWriter = startRequest((byte)14);
/*      */         
/* 3874 */         tDSWriter.writeShort((short)this.requestType);
/* 3875 */         if (null == this.payload) {
/*      */           
/* 3877 */           tDSWriter.writeShort((short)0);
/*      */         }
/*      */         else {
/*      */           
/* 3881 */           assert this.payload.length <= 32767;
/* 3882 */           tDSWriter.writeShort((short)this.payload.length);
/* 3883 */           tDSWriter.writeBytes(this.payload);
/*      */         } 
/*      */         
/* 3886 */         TDSParser.parse(startResponse(), getLogContext());
/* 3887 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 3891 */     executeCommand(new DTCCommand(paramInt, paramArrayOfbyte, paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void JTAUnenlistConnection() throws SQLServerException {
/* 3901 */     executeDTCCommand(1, null, "MS_DTC unenlist connection");
/* 3902 */     this.inXATransaction = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void JTAEnlistConnection(byte[] paramArrayOfbyte) throws SQLServerException {
/* 3913 */     executeDTCCommand(1, paramArrayOfbyte, "MS_DTC enlist connection");
/*      */ 
/*      */ 
/*      */     
/* 3917 */     connectionCommand(sqlStatementToSetTransactionIsolationLevel(), "JTAEnlistConnection");
/* 3918 */     this.inXATransaction = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] toUCS16(String paramString) throws SQLServerException {
/* 3931 */     if (paramString == null)
/* 3932 */       return new byte[0]; 
/* 3933 */     int i = paramString.length();
/* 3934 */     byte[] arrayOfByte = new byte[i * 2];
/* 3935 */     byte b1 = 0;
/* 3936 */     for (byte b2 = 0; b2 < i; b2++) {
/* 3937 */       char c = paramString.charAt(b2);
/* 3938 */       byte b = (byte)(c & 0xFF);
/* 3939 */       arrayOfByte[b1++] = b;
/* 3940 */       arrayOfByte[b1++] = (byte)(c >> 8 & 0xFF);
/*      */     } 
/* 3942 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] encryptPassword(String paramString) {
/* 3952 */     if (paramString == null) paramString = ""; 
/* 3953 */     int i = paramString.length();
/* 3954 */     byte[] arrayOfByte = new byte[i * 2];
/* 3955 */     for (byte b = 0; b < i; b++) {
/* 3956 */       int j = paramString.charAt(b) ^ 0x5A5A;
/* 3957 */       j = (j & 0xF) << 4 | (j & 0xF0) >> 4 | (j & 0xF00) << 4 | (j & 0xF000) >> 4;
/* 3958 */       byte b1 = (byte)((j & 0xFF00) >> 8);
/* 3959 */       arrayOfByte[b * 2 + 1] = b1;
/* 3960 */       byte b2 = (byte)(j & 0xFF);
/* 3961 */       arrayOfByte[b * 2 + 0] = b2;
/*      */     } 
/* 3963 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendLogon(LogonCommand paramLogonCommand, SSPIAuthentication paramSSPIAuthentication, FederatedAuthenticationFeatureExtensionData paramFederatedAuthenticationFeatureExtensionData) throws SQLServerException {
/*      */     final class LogonProcessor
/*      */       extends TDSTokenHandler
/*      */     {
/*      */       private final SSPIAuthentication auth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3985 */       private byte[] secBlobOut = null;
/*      */       
/*      */       StreamLoginAck loginAckToken;
/*      */       
/*      */       LogonProcessor(SSPIAuthentication param1SSPIAuthentication) {
/* 3990 */         super("logon");
/* 3991 */         this.auth = param1SSPIAuthentication;
/* 3992 */         this.loginAckToken = null;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onSSPI(TDSReader param1TDSReader) throws SQLServerException {
/* 3997 */         StreamSSPI streamSSPI = new StreamSSPI();
/* 3998 */         streamSSPI.setFromTDS(param1TDSReader);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4003 */         boolean[] arrayOfBoolean = { false };
/* 4004 */         this.secBlobOut = this.auth.GenerateClientContext(streamSSPI.sspiBlob, arrayOfBoolean);
/* 4005 */         return true;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onLoginAck(TDSReader param1TDSReader) throws SQLServerException {
/* 4010 */         this.loginAckToken = new StreamLoginAck();
/* 4011 */         this.loginAckToken.setFromTDS(param1TDSReader);
/* 4012 */         SQLServerConnection.this.sqlServerVersion = this.loginAckToken.sSQLServerVersion;
/* 4013 */         SQLServerConnection.this.tdsVersion = this.loginAckToken.tdsVersion;
/* 4014 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       final boolean complete(SQLServerConnection.LogonCommand param1LogonCommand, TDSReader param1TDSReader) throws SQLServerException {
/* 4020 */         if (null != this.loginAckToken) {
/* 4021 */           return true;
/*      */         }
/*      */         
/* 4024 */         if (null != this.secBlobOut && 0 != this.secBlobOut.length) {
/*      */ 
/*      */ 
/*      */           
/* 4028 */           param1LogonCommand.startRequest((byte)17).writeBytes(this.secBlobOut, 0, this.secBlobOut.length);
/* 4029 */           return false;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4038 */         param1LogonCommand.startRequest((byte)17);
/* 4039 */         param1LogonCommand.onRequestComplete();
/* 4040 */         SQLServerConnection.this.tdsChannel.numMsgsSent++;
/*      */         
/* 4042 */         TDSParser.parse(param1TDSReader, this);
/* 4043 */         return true;
/*      */       }
/*      */     };
/*      */ 
/*      */     
/* 4048 */     assert !this.integratedSecurity || !this.fedAuthRequiredPreLoginResponse;
/*      */     
/* 4050 */     assert !this.integratedSecurity || (!this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested);
/*      */     
/* 4052 */     assert null == paramFederatedAuthenticationFeatureExtensionData || this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested;
/*      */     
/* 4054 */     assert null != paramFederatedAuthenticationFeatureExtensionData || (!this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested);
/*      */     
/* 4056 */     String str1 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/* 4057 */     String str2 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.USER.toString());
/* 4058 */     String str3 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.PASSWORD.toString());
/* 4059 */     String str4 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.APPLICATION_NAME.toString());
/* 4060 */     String str5 = "Microsoft JDBC Driver 6.0";
/* 4061 */     String str6 = generateInterfaceLibVersion();
/* 4062 */     String str7 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString());
/* 4063 */     String str8 = null;
/*      */     
/* 4065 */     if (null != this.currentConnectPlaceHolder) {
/*      */       
/* 4067 */       str8 = this.currentConnectPlaceHolder.getServerName();
/*      */     }
/*      */     else {
/*      */       
/* 4071 */       str8 = this.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString());
/*      */     } 
/*      */     
/* 4074 */     if (str8 != null && str8.length() > 128) {
/* 4075 */       str8 = str8.substring(0, 128);
/*      */     }
/* 4077 */     if (str1 == null || str1.length() == 0)
/*      */     {
/* 4079 */       str1 = Util.lookupHostName();
/*      */     }
/*      */     
/* 4082 */     byte[] arrayOfByte1 = new byte[0];
/* 4083 */     boolean[] arrayOfBoolean = { false };
/* 4084 */     if (null != paramSSPIAuthentication) {
/*      */       
/* 4086 */       arrayOfByte1 = paramSSPIAuthentication.GenerateClientContext(arrayOfByte1, arrayOfBoolean);
/* 4087 */       str2 = null;
/* 4088 */       str3 = null;
/*      */     } 
/*      */     
/* 4091 */     byte[] arrayOfByte2 = toUCS16(str1);
/* 4092 */     byte[] arrayOfByte3 = toUCS16(str2);
/* 4093 */     byte[] arrayOfByte4 = encryptPassword(str3);
/* 4094 */     byte b1 = (arrayOfByte4 != null) ? arrayOfByte4.length : 0;
/* 4095 */     byte[] arrayOfByte5 = toUCS16(str4);
/* 4096 */     byte[] arrayOfByte6 = toUCS16(str8);
/* 4097 */     byte[] arrayOfByte7 = toUCS16(str5);
/* 4098 */     byte[] arrayOfByte8 = DatatypeConverter.parseHexBinary(str6);
/* 4099 */     byte[] arrayOfByte9 = toUCS16(str7);
/* 4100 */     byte[] arrayOfByte10 = new byte[6];
/* 4101 */     int i = 0;
/* 4102 */     int j = 0;
/*      */ 
/*      */ 
/*      */     
/* 4106 */     if (this.serverMajorVersion >= 11) {
/*      */       
/* 4108 */       this.tdsVersion = 1946157060;
/*      */     }
/* 4110 */     else if (this.serverMajorVersion >= 10) {
/*      */       
/* 4112 */       this.tdsVersion = 1930100739;
/*      */     
/*      */     }
/* 4115 */     else if (this.serverMajorVersion >= 9) {
/*      */       
/* 4117 */       this.tdsVersion = 1913192450;
/*      */     }
/*      */     else {
/*      */       
/* 4121 */       assert false : "prelogin did not disconnect for the old version: " + this.serverMajorVersion;
/*      */     } 
/*      */     
/* 4124 */     TDSWriter tDSWriter = paramLogonCommand.startRequest((byte)16);
/*      */     
/* 4126 */     i = 94 + arrayOfByte2.length + arrayOfByte5.length + arrayOfByte6.length + arrayOfByte7.length + arrayOfByte9.length + arrayOfByte1.length + 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4136 */     if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested) {
/* 4137 */       i = i + b1 + arrayOfByte3.length;
/*      */     }
/*      */     
/* 4140 */     int k = i;
/*      */     
/* 4142 */     i += writeAEFeatureRequest(false, tDSWriter);
/* 4143 */     if (this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested)
/*      */     {
/* 4145 */       i += writeFedAuthFeatureRequest(false, tDSWriter, paramFederatedAuthenticationFeatureExtensionData);
/*      */     }
/*      */     
/* 4148 */     i++;
/*      */ 
/*      */     
/* 4151 */     tDSWriter.writeInt(i);
/* 4152 */     tDSWriter.writeInt(this.tdsVersion);
/* 4153 */     tDSWriter.writeInt(this.requestedPacketSize);
/* 4154 */     tDSWriter.writeBytes(arrayOfByte8);
/* 4155 */     tDSWriter.writeInt(0);
/* 4156 */     tDSWriter.writeInt(0);
/*      */     
/* 4158 */     tDSWriter.writeByte((byte)-32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4168 */     tDSWriter.writeByte((byte)(0x3 | (this.integratedSecurity ? Byte.MIN_VALUE : 0)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4177 */     tDSWriter.writeByte((byte)(0x0 | ((this.applicationIntent != null && this.applicationIntent.equals(ApplicationIntent.READ_ONLY)) ? 32 : 0)));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4186 */     byte b2 = 0;
/*      */ 
/*      */     
/* 4189 */     b2 = 16;
/*      */     
/* 4191 */     tDSWriter.writeByte((byte)(0x0 | b2 | ((this.serverMajorVersion >= 10) ? 8 : 0)));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4196 */     tDSWriter.writeInt(0);
/* 4197 */     tDSWriter.writeInt(0);
/*      */     
/* 4199 */     tDSWriter.writeShort((short)94);
/*      */ 
/*      */     
/* 4202 */     tDSWriter.writeShort((short)((str1 == null) ? 0 : str1.length()));
/* 4203 */     j += arrayOfByte2.length;
/*      */ 
/*      */ 
/*      */     
/* 4207 */     if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested) {
/*      */ 
/*      */       
/* 4210 */       tDSWriter.writeShort((short)(94 + j));
/* 4211 */       tDSWriter.writeShort((short)((str2 == null) ? 0 : str2.length()));
/* 4212 */       j += arrayOfByte3.length;
/*      */       
/* 4214 */       tDSWriter.writeShort((short)(94 + j));
/* 4215 */       tDSWriter.writeShort((short)((str3 == null) ? 0 : str3.length()));
/* 4216 */       j += b1;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 4222 */       tDSWriter.writeShort((short)0);
/* 4223 */       tDSWriter.writeShort((short)0);
/* 4224 */       tDSWriter.writeShort((short)0);
/* 4225 */       tDSWriter.writeShort((short)0);
/*      */     } 
/*      */ 
/*      */     
/* 4229 */     tDSWriter.writeShort((short)(94 + j));
/* 4230 */     tDSWriter.writeShort((short)((str4 == null) ? 0 : str4.length()));
/* 4231 */     j += arrayOfByte5.length;
/*      */ 
/*      */     
/* 4234 */     tDSWriter.writeShort((short)(94 + j));
/* 4235 */     tDSWriter.writeShort((short)((str8 == null) ? 0 : str8.length()));
/* 4236 */     j += arrayOfByte6.length;
/*      */ 
/*      */     
/* 4239 */     tDSWriter.writeShort((short)(94 + j));
/*      */ 
/*      */     
/* 4242 */     tDSWriter.writeShort((short)4);
/* 4243 */     j += 4;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4248 */     assert null != str5;
/* 4249 */     tDSWriter.writeShort((short)(94 + j));
/* 4250 */     tDSWriter.writeShort((short)str5.length());
/* 4251 */     j += arrayOfByte7.length;
/*      */ 
/*      */     
/* 4254 */     tDSWriter.writeShort((short)0);
/* 4255 */     tDSWriter.writeShort((short)0);
/*      */ 
/*      */     
/* 4258 */     tDSWriter.writeShort((short)(94 + j));
/* 4259 */     tDSWriter.writeShort((short)((str7 == null) ? 0 : str7.length()));
/* 4260 */     j += arrayOfByte9.length;
/*      */ 
/*      */     
/* 4263 */     tDSWriter.writeBytes(arrayOfByte10);
/*      */ 
/*      */ 
/*      */     
/* 4267 */     if (!this.integratedSecurity) {
/*      */       
/* 4269 */       tDSWriter.writeShort((short)0);
/* 4270 */       tDSWriter.writeShort((short)0);
/*      */     }
/*      */     else {
/*      */       
/* 4274 */       tDSWriter.writeShort((short)(94 + j));
/* 4275 */       if (65535 <= arrayOfByte1.length) {
/*      */         
/* 4277 */         tDSWriter.writeShort((short)-1);
/*      */       } else {
/*      */         
/* 4280 */         tDSWriter.writeShort((short)arrayOfByte1.length);
/*      */       } 
/*      */     } 
/*      */     
/* 4284 */     tDSWriter.writeShort((short)0);
/* 4285 */     tDSWriter.writeShort((short)0);
/*      */     
/* 4287 */     if (this.tdsVersion >= 1913192450) {
/*      */ 
/*      */       
/* 4290 */       tDSWriter.writeShort((short)0);
/* 4291 */       tDSWriter.writeShort((short)0);
/*      */ 
/*      */       
/* 4294 */       if (65535 <= arrayOfByte1.length) {
/* 4295 */         tDSWriter.writeInt(arrayOfByte1.length);
/*      */       } else {
/* 4297 */         tDSWriter.writeInt(0);
/*      */       } 
/*      */     } 
/* 4300 */     tDSWriter.writeBytes(arrayOfByte2);
/*      */ 
/*      */     
/* 4303 */     tDSWriter.setDataLoggable(false);
/*      */ 
/*      */     
/* 4306 */     if (!this.integratedSecurity && !this.federatedAuthenticationInfoRequested && !this.federatedAuthenticationRequested) {
/*      */       
/* 4308 */       tDSWriter.writeBytes(arrayOfByte3);
/* 4309 */       tDSWriter.writeBytes(arrayOfByte4);
/*      */     } 
/* 4311 */     tDSWriter.setDataLoggable(true);
/*      */     
/* 4313 */     tDSWriter.writeBytes(arrayOfByte5);
/* 4314 */     tDSWriter.writeBytes(arrayOfByte6);
/*      */ 
/*      */ 
/*      */     
/* 4318 */     tDSWriter.writeInt(k);
/*      */ 
/*      */     
/* 4321 */     tDSWriter.writeBytes(arrayOfByte7);
/* 4322 */     tDSWriter.writeBytes(arrayOfByte9);
/*      */ 
/*      */     
/* 4325 */     tDSWriter.setDataLoggable(false);
/* 4326 */     if (this.integratedSecurity) {
/* 4327 */       tDSWriter.writeBytes(arrayOfByte1, 0, arrayOfByte1.length);
/*      */     }
/*      */ 
/*      */     
/* 4331 */     writeAEFeatureRequest(true, tDSWriter);
/*      */ 
/*      */     
/* 4334 */     if (this.federatedAuthenticationInfoRequested || this.federatedAuthenticationRequested) {
/* 4335 */       writeFedAuthFeatureRequest(true, tDSWriter, paramFederatedAuthenticationFeatureExtensionData);
/*      */     }
/*      */     
/* 4338 */     tDSWriter.writeByte((byte)-1);
/* 4339 */     tDSWriter.setDataLoggable(true);
/*      */     
/* 4341 */     LogonProcessor logonProcessor = new LogonProcessor(paramSSPIAuthentication);
/* 4342 */     TDSReader tDSReader = null;
/*      */     
/*      */     do {
/* 4345 */       tDSReader = paramLogonCommand.startResponse();
/* 4346 */       TDSParser.parse(tDSReader, logonProcessor);
/*      */     }
/* 4348 */     while (!logonProcessor.complete(paramLogonCommand, tDSReader));
/*      */   }
/*      */ 
/*      */   
/*      */   private String generateInterfaceLibVersion() {
/* 4353 */     StringBuffer stringBuffer = new StringBuffer();
/*      */ 
/*      */     
/* 4356 */     int i = String.valueOf(8112).length();
/*      */ 
/*      */     
/* 4359 */     int j = Integer.valueOf(String.valueOf(8112).substring(0, i - 2)).intValue();
/* 4360 */     int k = Integer.valueOf(String.valueOf(8112).substring(i - 2)).intValue();
/*      */ 
/*      */     
/* 4363 */     String str1 = Integer.toHexString(6);
/* 4364 */     String str2 = Integer.toHexString(0);
/* 4365 */     String str3 = Integer.toHexString(j);
/* 4366 */     String str4 = Integer.toHexString(k);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4374 */     if (2 == str4.length()) {
/* 4375 */       stringBuffer.append(str4);
/*      */     } else {
/*      */       
/* 4378 */       stringBuffer.append("0");
/* 4379 */       stringBuffer.append(str4);
/*      */     } 
/* 4381 */     if (2 == str3.length()) {
/* 4382 */       stringBuffer.append(str3);
/*      */     } else {
/*      */       
/* 4385 */       stringBuffer.append("0");
/* 4386 */       stringBuffer.append(str3);
/*      */     } 
/* 4388 */     if (2 == str2.length()) {
/* 4389 */       stringBuffer.append(str2);
/*      */     } else {
/*      */       
/* 4392 */       stringBuffer.append("0");
/* 4393 */       stringBuffer.append(str2);
/*      */     } 
/* 4395 */     if (2 == str1.length()) {
/* 4396 */       stringBuffer.append(str1);
/*      */     } else {
/*      */       
/* 4399 */       stringBuffer.append("0");
/* 4400 */       stringBuffer.append(str1);
/*      */     } 
/*      */     
/* 4403 */     return stringBuffer.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkValidHoldability(int paramInt) throws SQLServerException {
/* 4414 */     if (paramInt != 1 && paramInt != 2) {
/*      */ 
/*      */       
/* 4417 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidHoldability"));
/* 4418 */       SQLServerException.makeFromDriverError(this, this, messageFormat.format(new Object[] { Integer.valueOf(paramInt) }, ), (String)null, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkMatchesCurrentHoldability(int paramInt) throws SQLServerException {
/* 4437 */     if (paramInt != this.holdability)
/*      */     {
/* 4439 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_sqlServerHoldability"), (String)null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
/* 4448 */     loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 4449 */     Statement statement = createStatement(paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/* 4450 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", statement);
/* 4451 */     return statement;
/*      */   }
/*      */ 
/*      */   
/*      */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 4456 */     loggerExternal.entering(getClassNameLogging(), "createStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
/* 4457 */     checkClosed();
/* 4458 */     checkValidHoldability(paramInt3);
/* 4459 */     checkMatchesCurrentHoldability(paramInt3);
/* 4460 */     SQLServerStatement sQLServerStatement = new SQLServerStatement(this, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/* 4461 */     loggerExternal.exiting(getClassNameLogging(), "createStatement", sQLServerStatement);
/* 4462 */     return sQLServerStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
/* 4467 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 4468 */     PreparedStatement preparedStatement = prepareStatement(paramString, paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4474 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", preparedStatement);
/* 4475 */     return preparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 4480 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
/* 4481 */     checkClosed();
/* 4482 */     checkValidHoldability(paramInt3);
/* 4483 */     checkMatchesCurrentHoldability(paramInt3);
/* 4484 */     SQLServerPreparedStatement sQLServerPreparedStatement = new SQLServerPreparedStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4490 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4491 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
/* 4496 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3) });
/* 4497 */     CallableStatement callableStatement = prepareCall(paramString, paramInt1, paramInt2, paramInt3, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/* 4498 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", callableStatement);
/* 4499 */     return callableStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 4504 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { new Integer(paramInt1), new Integer(paramInt2), Integer.valueOf(paramInt3), paramSQLServerStatementColumnEncryptionSetting });
/* 4505 */     checkClosed();
/* 4506 */     checkValidHoldability(paramInt3);
/* 4507 */     checkMatchesCurrentHoldability(paramInt3);
/* 4508 */     SQLServerCallableStatement sQLServerCallableStatement = new SQLServerCallableStatement(this, paramString, paramInt1, paramInt2, paramSQLServerStatementColumnEncryptionSetting);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4514 */     loggerExternal.exiting(getClassNameLogging(), "prepareCall", sQLServerCallableStatement);
/* 4515 */     return sQLServerCallableStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLServerException {
/* 4522 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt) });
/*      */     
/* 4524 */     SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramInt, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/* 4526 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4527 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int paramInt, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 4532 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, new Integer(paramInt), paramSQLServerStatementColumnEncryptionSetting });
/* 4533 */     checkClosed();
/* 4534 */     SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
/* 4535 */     sQLServerPreparedStatement.bRequestedGeneratedKeys = (paramInt == 1);
/* 4536 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4537 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLServerException {
/* 4542 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfint });
/* 4543 */     SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramArrayOfint, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/* 4545 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4546 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 4551 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfint, paramSQLServerStatementColumnEncryptionSetting });
/*      */     
/* 4553 */     checkClosed();
/* 4554 */     if (paramArrayOfint == null || paramArrayOfint.length != 1) {
/* 4555 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */     
/* 4558 */     SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
/* 4559 */     sQLServerPreparedStatement.bRequestedGeneratedKeys = true;
/* 4560 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4561 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLServerException {
/* 4566 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString });
/*      */     
/* 4568 */     SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, paramArrayOfString, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */     
/* 4570 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4571 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/* 4576 */     loggerExternal.entering(getClassNameLogging(), "prepareStatement", new Object[] { paramString, paramArrayOfString, paramSQLServerStatementColumnEncryptionSetting });
/* 4577 */     checkClosed();
/* 4578 */     if (paramArrayOfString == null || paramArrayOfString.length != 1)
/*      */     {
/* 4580 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */     
/* 4583 */     SQLServerPreparedStatement sQLServerPreparedStatement = (SQLServerPreparedStatement)prepareStatement(paramString, 1003, 1007, paramSQLServerStatementColumnEncryptionSetting);
/* 4584 */     sQLServerPreparedStatement.bRequestedGeneratedKeys = true;
/* 4585 */     loggerExternal.exiting(getClassNameLogging(), "prepareStatement", sQLServerPreparedStatement);
/* 4586 */     return sQLServerPreparedStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseSavepoint(Savepoint paramSavepoint) throws SQLServerException {
/* 4593 */     loggerExternal.entering(getClassNameLogging(), "releaseSavepoint", paramSavepoint);
/* 4594 */     NotImplemented();
/*      */   }
/*      */ 
/*      */   
/*      */   private final Savepoint setNamedSavepoint(String paramString) throws SQLServerException {
/* 4599 */     if (true == this.databaseAutoCommitMode)
/*      */     {
/* 4601 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantSetSavepoint"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4609 */     SQLServerSavepoint sQLServerSavepoint = new SQLServerSavepoint(this, paramString);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4618 */     connectionCommand("IF @@TRANCOUNT = 0 BEGIN BEGIN TRAN IF @@TRANCOUNT = 2 COMMIT TRAN END SAVE TRAN " + Util.escapeSQLId(sQLServerSavepoint.getLabel()), "setSavepoint");
/*      */ 
/*      */ 
/*      */     
/* 4622 */     return sQLServerSavepoint;
/*      */   }
/*      */ 
/*      */   
/*      */   public Savepoint setSavepoint(String paramString) throws SQLServerException {
/* 4627 */     loggerExternal.entering(getClassNameLogging(), "setSavepoint", paramString);
/* 4628 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 4630 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4632 */     checkClosed();
/* 4633 */     Savepoint savepoint = setNamedSavepoint(paramString);
/* 4634 */     loggerExternal.exiting(getClassNameLogging(), "setSavepoint", savepoint);
/* 4635 */     return savepoint;
/*      */   }
/*      */ 
/*      */   
/*      */   public Savepoint setSavepoint() throws SQLServerException {
/* 4640 */     loggerExternal.entering(getClassNameLogging(), "setSavepoint");
/* 4641 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 4643 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4645 */     checkClosed();
/* 4646 */     Savepoint savepoint = setNamedSavepoint(null);
/* 4647 */     loggerExternal.exiting(getClassNameLogging(), "setSavepoint", savepoint);
/* 4648 */     return savepoint;
/*      */   }
/*      */ 
/*      */   
/*      */   public void rollback(Savepoint paramSavepoint) throws SQLServerException {
/* 4653 */     loggerExternal.entering(getClassNameLogging(), "rollback", paramSavepoint);
/* 4654 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 4656 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4658 */     checkClosed();
/* 4659 */     if (true == this.databaseAutoCommitMode)
/*      */     {
/* 4661 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_cantInvokeRollback"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4668 */     connectionCommand("IF @@TRANCOUNT > 0 ROLLBACK TRAN " + Util.escapeSQLId(((SQLServerSavepoint)paramSavepoint).getLabel()), "rollbackSavepoint");
/*      */ 
/*      */     
/* 4671 */     loggerExternal.exiting(getClassNameLogging(), "rollback");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLServerException {
/* 4676 */     loggerExternal.entering(getClassNameLogging(), "getHoldability");
/* 4677 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4678 */       loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(this.holdability)); 
/* 4679 */     return this.holdability;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setHoldability(int paramInt) throws SQLServerException {
/* 4684 */     loggerExternal.entering(getClassNameLogging(), "setHoldability", Integer.valueOf(paramInt));
/*      */     
/* 4686 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 4688 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 4690 */     checkValidHoldability(paramInt);
/* 4691 */     checkClosed();
/*      */     
/* 4693 */     if (this.holdability != paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4698 */       assert 1 == paramInt || 2 == paramInt : "invalid holdability " + paramInt;
/*      */       
/* 4700 */       connectionCommand((paramInt == 2) ? "SET CURSOR_CLOSE_ON_COMMIT ON" : "SET CURSOR_CLOSE_ON_COMMIT OFF", "setHoldability");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4706 */       this.holdability = paramInt;
/*      */     } 
/*      */     
/* 4709 */     loggerExternal.exiting(getClassNameLogging(), "setHoldability");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNetworkTimeout() throws SQLException {
/* 4714 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/* 4717 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNetworkTimeout(Executor paramExecutor, int paramInt) throws SQLException {
/* 4722 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/* 4725 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSchema() throws SQLException {
/* 4730 */     loggerExternal.entering(getClassNameLogging(), "getSchema");
/*      */     
/* 4732 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/* 4734 */     checkClosed();
/*      */     
/* 4736 */     SQLServerStatement sQLServerStatement = null;
/* 4737 */     SQLServerResultSet sQLServerResultSet = null;
/*      */ 
/*      */     
/*      */     try {
/* 4741 */       sQLServerStatement = (SQLServerStatement)createStatement();
/* 4742 */       sQLServerResultSet = sQLServerStatement.executeQueryInternal("SELECT SCHEMA_NAME()");
/* 4743 */       if (sQLServerResultSet != null) {
/*      */         
/* 4745 */         sQLServerResultSet.next();
/* 4746 */         return sQLServerResultSet.getString(1);
/*      */       } 
/*      */ 
/*      */       
/* 4750 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), (String)null, true);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4755 */     catch (SQLException sQLException) {
/*      */       
/* 4757 */       if (isSessionUnAvailable())
/*      */       {
/* 4759 */         throw sQLException;
/*      */       }
/*      */       
/* 4762 */       SQLServerException.makeFromDriverError(this, this, SQLServerException.getErrString("R_getSchemaError"), (String)null, true);
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/* 4768 */       if (sQLServerResultSet != null)
/*      */       {
/* 4770 */         sQLServerResultSet.close();
/*      */       }
/* 4772 */       if (sQLServerStatement != null)
/*      */       {
/* 4774 */         sQLServerStatement.close();
/*      */       }
/*      */     } 
/*      */     
/* 4778 */     loggerExternal.exiting(getClassNameLogging(), "getSchema");
/* 4779 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setSchema(String paramString) throws SQLException {
/* 4784 */     loggerExternal.entering(getClassNameLogging(), "setSchema", paramString);
/* 4785 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/* 4787 */     checkClosed();
/* 4788 */     addWarning(SQLServerException.getErrString("R_setSchemaWarning"));
/*      */     
/* 4790 */     loggerExternal.exiting(getClassNameLogging(), "setSchema");
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void setSendTimeAsDatetime(boolean paramBoolean) {
/* 4795 */     this.sendTimeAsDatetime = paramBoolean;
/*      */   }
/*      */ 
/*      */   
/*      */   public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException {
/* 4800 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 4803 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob createBlob() throws SQLException {
/* 4808 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4809 */     checkClosed();
/* 4810 */     return new SQLServerBlob(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob createClob() throws SQLException {
/* 4815 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4816 */     checkClosed();
/* 4817 */     return new SQLServerClob(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob createNClob() throws SQLException {
/* 4822 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4823 */     checkClosed();
/* 4824 */     return new SQLServerNClob(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLXML createSQLXML() throws SQLException {
/* 4829 */     loggerExternal.entering(getClassNameLogging(), "createSQLXML");
/* 4830 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4831 */     SQLServerSQLXML sQLServerSQLXML = null;
/* 4832 */     sQLServerSQLXML = new SQLServerSQLXML(this);
/*      */     
/* 4834 */     if (loggerExternal.isLoggable(Level.FINER))
/* 4835 */       loggerExternal.exiting(getClassNameLogging(), "createSQLXML", sQLServerSQLXML); 
/* 4836 */     return sQLServerSQLXML;
/*      */   }
/*      */ 
/*      */   
/*      */   public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException {
/* 4841 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 4844 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   String getTrustedServerNameAE() throws SQLServerException {
/* 4849 */     return this.trustedServerNameAE.toUpperCase();
/*      */   }
/*      */ 
/*      */   
/*      */   public Properties getClientInfo() throws SQLException {
/* 4854 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4855 */     loggerExternal.entering(getClassNameLogging(), "getClientInfo");
/* 4856 */     checkClosed();
/* 4857 */     Properties properties = new Properties();
/* 4858 */     loggerExternal.exiting(getClassNameLogging(), "getClientInfo", properties);
/* 4859 */     return properties;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getClientInfo(String paramString) throws SQLException {
/* 4864 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4865 */     loggerExternal.entering(getClassNameLogging(), "getClientInfo", paramString);
/* 4866 */     checkClosed();
/* 4867 */     loggerExternal.exiting(getClassNameLogging(), "getClientInfo", null);
/* 4868 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClientInfo(Properties paramProperties) throws SQLClientInfoException {
/* 4873 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4874 */     loggerExternal.entering(getClassNameLogging(), "setClientInfo", paramProperties);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 4879 */       checkClosed();
/* 4880 */     } catch (SQLServerException sQLServerException) {
/*      */       
/* 4882 */       SQLClientInfoException sQLClientInfoException = new SQLClientInfoException();
/* 4883 */       sQLClientInfoException.initCause(sQLServerException);
/* 4884 */       throw sQLClientInfoException;
/*      */     } 
/*      */     
/* 4887 */     if (!paramProperties.isEmpty()) {
/*      */       
/* 4889 */       Enumeration enumeration = paramProperties.keys();
/* 4890 */       while (enumeration.hasMoreElements()) {
/*      */         
/* 4892 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
/* 4893 */         Object[] arrayOfObject = { enumeration.nextElement() };
/* 4894 */         addWarning(messageFormat.format(arrayOfObject));
/*      */       } 
/*      */     } 
/* 4897 */     loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
/*      */   }
/*      */ 
/*      */   
/*      */   public void setClientInfo(String paramString1, String paramString2) throws SQLClientInfoException {
/* 4902 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4903 */     loggerExternal.entering(getClassNameLogging(), "setClientInfo", new Object[] { paramString1, paramString2 });
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 4908 */       checkClosed();
/* 4909 */     } catch (SQLServerException sQLServerException) {
/*      */       
/* 4911 */       SQLClientInfoException sQLClientInfoException = new SQLClientInfoException();
/* 4912 */       sQLClientInfoException.initCause(sQLServerException);
/* 4913 */       throw sQLClientInfoException;
/*      */     } 
/* 4915 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidProperty"));
/* 4916 */     Object[] arrayOfObject = { paramString1 };
/* 4917 */     addWarning(messageFormat.format(arrayOfObject));
/* 4918 */     loggerExternal.exiting(getClassNameLogging(), "setClientInfo");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isValid(int paramInt) throws SQLException {
/* 4942 */     boolean bool = false;
/*      */     
/* 4944 */     loggerExternal.entering(getClassNameLogging(), "isValid", Integer.valueOf(paramInt));
/*      */     
/* 4946 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 4949 */     if (paramInt < 0) {
/*      */       
/* 4951 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
/* 4952 */       Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 4953 */       SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), (String)null, true);
/*      */     } 
/*      */ 
/*      */     
/* 4957 */     if (isSessionUnAvailable()) {
/* 4958 */       return false;
/*      */     }
/*      */     
/*      */     try {
/* 4962 */       SQLServerStatement sQLServerStatement = new SQLServerStatement(this, 1003, 1007, SQLServerStatementColumnEncryptionSetting.UseConnectionSetting);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4970 */       if (0 != paramInt) {
/* 4971 */         sQLServerStatement.setQueryTimeout(paramInt);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4977 */       sQLServerStatement.executeQueryInternal("SELECT 1");
/* 4978 */       sQLServerStatement.close();
/* 4979 */       bool = true;
/*      */     }
/* 4981 */     catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4986 */       connectionlogger.fine(toString() + " Exception checking connection validity: " + sQLException.getMessage());
/*      */     } 
/*      */     
/* 4989 */     loggerExternal.exiting(getClassNameLogging(), "isValid", Boolean.valueOf(bool));
/* 4990 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 4995 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
/* 4996 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4997 */     boolean bool = paramClass.isInstance(this);
/* 4998 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/* 4999 */     return bool;
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/*      */     T t;
/* 5004 */     loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
/* 5005 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*      */     try {
/* 5008 */       t = paramClass.cast(this);
/*      */     }
/* 5010 */     catch (ClassCastException classCastException) {
/*      */ 
/*      */       
/* 5013 */       SQLServerException sQLServerException = new SQLServerException(classCastException.getMessage(), classCastException);
/* 5014 */       throw sQLServerException;
/*      */     } 
/* 5016 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
/* 5017 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5028 */   static final char[] OUT = new char[] { ' ', 'O', 'U', 'T' };
/*      */   private static final int BROWSER_PORT = 1434;
/*      */   
/*      */   String replaceParameterMarkers(String paramString, Parameter[] paramArrayOfParameter, boolean paramBoolean) throws SQLServerException {
/* 5032 */     char[] arrayOfChar = new char[paramString.length() + paramArrayOfParameter.length * (6 + OUT.length)];
/* 5033 */     int i = 0;
/* 5034 */     int j = 0;
/* 5035 */     byte b1 = 0;
/*      */     
/* 5037 */     byte b2 = 0;
/*      */     
/*      */     while (true) {
/* 5040 */       int k = ParameterUtils.scanSQLForChar('?', paramString, j);
/* 5041 */       paramString.getChars(j, k, arrayOfChar, i);
/* 5042 */       i += k - j;
/*      */       
/* 5044 */       if (paramString.length() == k) {
/*      */         break;
/*      */       }
/* 5047 */       i += makeParamName(b1++, arrayOfChar, i);
/* 5048 */       j = k + 1;
/*      */       
/* 5050 */       if (paramArrayOfParameter[b2++].isOutput())
/*      */       {
/* 5052 */         if (!paramBoolean || b2 > 1) {
/*      */           
/* 5054 */           System.arraycopy(OUT, 0, arrayOfChar, i, OUT.length);
/* 5055 */           i += OUT.length;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 5060 */     while (i < arrayOfChar.length) {
/* 5061 */       arrayOfChar[i++] = ' ';
/*      */     }
/* 5063 */     return new String(arrayOfChar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int makeParamName(int paramInt1, char[] paramArrayOfchar, int paramInt2) {
/* 5074 */     paramArrayOfchar[paramInt2 + 0] = '@';
/* 5075 */     paramArrayOfchar[paramInt2 + 1] = 'P';
/* 5076 */     if (paramInt1 < 10) {
/*      */       
/* 5078 */       paramArrayOfchar[paramInt2 + 2] = (char)(48 + paramInt1);
/* 5079 */       return 3;
/*      */     } 
/*      */ 
/*      */     
/* 5083 */     if (paramInt1 < 100) {
/*      */       
/* 5085 */       byte b = 2;
/*      */       
/*      */       while (true) {
/* 5088 */         if (paramInt1 < b * 10) {
/*      */           
/* 5090 */           paramArrayOfchar[paramInt2 + 2] = (char)(48 + b - 1);
/* 5091 */           paramArrayOfchar[paramInt2 + 3] = (char)(48 + paramInt1 - (b - 1) * 10);
/* 5092 */           return 4;
/*      */         } 
/* 5094 */         b++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 5099 */     String str = "" + paramInt1;
/* 5100 */     str.getChars(0, str.length(), paramArrayOfchar, paramInt2 + 2);
/* 5101 */     return 2 + str.length();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notifyPooledConnection(SQLServerException paramSQLServerException) {
/* 5114 */     synchronized (this) {
/*      */       
/* 5116 */       if (null != this.pooledConnectionParent)
/*      */       {
/* 5118 */         this.pooledConnectionParent.notifyEvent(paramSQLServerException);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void DetachFromPool() {
/* 5127 */     synchronized (this) {
/*      */       
/* 5129 */       this.pooledConnectionParent = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getInstancePort(String paramString1, String paramString2) throws SQLServerException {
/* 5144 */     String str1 = null;
/* 5145 */     DatagramSocket datagramSocket = null;
/* 5146 */     String str2 = null;
/*      */ 
/*      */     
/*      */     try {
/* 5150 */       str2 = "Failed to determine instance for the : " + paramString1 + " instance:" + paramString2;
/*      */ 
/*      */       
/* 5153 */       if (null == datagramSocket) {
/*      */         
/*      */         try {
/*      */           
/* 5157 */           datagramSocket = new DatagramSocket();
/* 5158 */           datagramSocket.setSoTimeout(1000);
/*      */         }
/* 5160 */         catch (SocketException socketException) {
/*      */ 
/*      */ 
/*      */           
/* 5164 */           str2 = "Unable to create local datagram socket";
/* 5165 */           throw socketException;
/*      */         } 
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5173 */       assert null != datagramSocket;
/*      */       
/*      */       try {
/* 5176 */         if (this.multiSubnetFailover) {
/*      */ 
/*      */           
/* 5179 */           InetAddress[] arrayOfInetAddress = InetAddress.getAllByName(paramString1);
/* 5180 */           assert null != arrayOfInetAddress;
/* 5181 */           for (InetAddress inetAddress : arrayOfInetAddress)
/*      */           {
/*      */             try
/*      */             {
/*      */               
/* 5186 */               byte[] arrayOfByte = (" " + paramString2).getBytes();
/* 5187 */               arrayOfByte[0] = 4;
/* 5188 */               DatagramPacket datagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length, inetAddress, 1434);
/* 5189 */               datagramSocket.send(datagramPacket);
/*      */             }
/* 5191 */             catch (IOException iOException)
/*      */             {
/* 5193 */               str2 = "Error sending SQL Server Browser Service UDP request to address: " + inetAddress + ", port: " + '֚';
/* 5194 */               throw iOException;
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 5201 */           InetAddress inetAddress = InetAddress.getByName(paramString1);
/*      */           
/* 5203 */           assert null != inetAddress;
/*      */ 
/*      */           
/*      */           try {
/* 5207 */             byte[] arrayOfByte = (" " + paramString2).getBytes();
/* 5208 */             arrayOfByte[0] = 4;
/* 5209 */             DatagramPacket datagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length, inetAddress, 1434);
/* 5210 */             datagramSocket.send(datagramPacket);
/*      */           }
/* 5212 */           catch (IOException iOException) {
/*      */             
/* 5214 */             str2 = "Error sending SQL Server Browser Service UDP request to address: " + inetAddress + ", port: " + '֚';
/* 5215 */             throw iOException;
/*      */           }
/*      */         
/*      */         } 
/* 5219 */       } catch (UnknownHostException unknownHostException) {
/*      */         
/* 5221 */         str2 = "Unable to determine IP address of host: " + paramString1;
/* 5222 */         throw unknownHostException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 5228 */         byte[] arrayOfByte = new byte[4096];
/* 5229 */         DatagramPacket datagramPacket = new DatagramPacket(arrayOfByte, arrayOfByte.length);
/* 5230 */         datagramSocket.receive(datagramPacket);
/* 5231 */         str1 = new String(arrayOfByte, 3, arrayOfByte.length - 3);
/* 5232 */         if (connectionlogger.isLoggable(Level.FINER)) {
/* 5233 */           connectionlogger.fine(toString() + " Received SSRP UDP response from IP address: " + datagramPacket.getAddress().getHostAddress().toString());
/*      */         }
/* 5235 */       } catch (IOException iOException) {
/*      */ 
/*      */         
/* 5238 */         str2 = "Error receiving SQL Server Browser Service UDP response from server: " + paramString1;
/* 5239 */         throw iOException;
/*      */       }
/*      */     
/* 5242 */     } catch (IOException iOException) {
/*      */       
/* 5244 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_sqlBrowserFailed"));
/* 5245 */       Object[] arrayOfObject = { paramString1, paramString2, iOException.toString() };
/* 5246 */       connectionlogger.log(Level.FINE, toString() + " " + str2, iOException);
/* 5247 */       SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), "08001", false);
/*      */     }
/*      */     finally {
/*      */       
/* 5251 */       if (null != datagramSocket)
/* 5252 */         datagramSocket.close(); 
/*      */     } 
/* 5254 */     assert null != str1;
/*      */     
/* 5256 */     int i = str1.indexOf("tcp;");
/* 5257 */     if (-1 == i) {
/*      */       
/* 5259 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_notConfiguredToListentcpip"));
/* 5260 */       Object[] arrayOfObject = { paramString2 };
/* 5261 */       SQLServerException.makeFromDriverError(this, this, messageFormat.format(arrayOfObject), "08001", false);
/*      */     } 
/*      */     
/* 5264 */     int j = i + 4;
/* 5265 */     int k = str1.indexOf(';', j);
/* 5266 */     return str1.substring(j, k);
/*      */   }
/*      */   
/*      */   int getNextSavepointId() {
/* 5270 */     this.nNextSavePointId++;
/* 5271 */     return this.nNextSavePointId;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSecurityCheck() {
/* 5278 */     assert null != this.currentConnectPlaceHolder;
/* 5279 */     this.currentConnectPlaceHolder.doSecurityCheck();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5285 */   private static long columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(2L, TimeUnit.HOURS);
/*      */ 
/*      */   
/*      */   public static synchronized void setColumnEncryptionKeyCacheTtl(int paramInt, TimeUnit paramTimeUnit) throws SQLServerException {
/* 5289 */     if (paramInt < 0 || paramTimeUnit.equals(TimeUnit.MILLISECONDS) || paramTimeUnit.equals(TimeUnit.MICROSECONDS) || paramTimeUnit.equals(TimeUnit.NANOSECONDS))
/*      */     {
/* 5291 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidCEKCacheTtl"), null, 0, false);
/*      */     }
/*      */     
/* 5294 */     columnEncryptionKeyCacheTtl = TimeUnit.SECONDS.convert(paramInt, paramTimeUnit);
/*      */   }
/*      */ 
/*      */   
/*      */   static synchronized long getColumnEncryptionKeyCacheTtl() {
/* 5299 */     return columnEncryptionKeyCacheTtl;
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */