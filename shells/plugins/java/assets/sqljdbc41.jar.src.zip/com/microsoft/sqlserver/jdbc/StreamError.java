/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamError
/*    */   extends StreamPacket
/*    */ {
/* 16 */   String errorMessage = "";
/*    */   
/*    */   int errorNumber;
/*    */   
/*    */   int errorState;
/*    */   
/*    */   int errorSeverity;
/*    */   
/*    */   String serverName;
/*    */   String procName;
/*    */   long lineNumber;
/*    */   
/*    */   final String getMessage() {
/* 29 */     return this.errorMessage;
/*    */   }
/*    */   final int getErrorNumber() {
/* 32 */     return this.errorNumber;
/*    */   }
/*    */   final int getErrorState() {
/* 35 */     return this.errorState;
/*    */   }
/*    */   final int getErrorSeverity() {
/* 38 */     return this.errorSeverity;
/*    */   }
/*    */ 
/*    */   
/*    */   StreamError() {
/* 43 */     super(170);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 48 */     if (170 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 49 */     setContentsFromTDS(paramTDSReader);
/*    */   }
/*    */ 
/*    */   
/*    */   void setContentsFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 54 */     paramTDSReader.readUnsignedShort();
/* 55 */     this.errorNumber = paramTDSReader.readInt();
/* 56 */     this.errorState = paramTDSReader.readUnsignedByte();
/* 57 */     this.errorSeverity = paramTDSReader.readUnsignedByte();
/* 58 */     this.errorMessage = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedShort());
/* 59 */     this.serverName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 60 */     this.procName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 61 */     this.lineNumber = paramTDSReader.readUnsignedInt();
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */