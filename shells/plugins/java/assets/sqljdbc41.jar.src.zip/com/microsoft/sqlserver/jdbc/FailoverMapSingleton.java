/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.logging.Level;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class FailoverMapSingleton
/*    */ {
/* 15 */   private static int INITIALHASHMAPSIZE = 5;
/* 16 */   private static HashMap<String, FailoverInfo> failoverMap = new HashMap<>(INITIALHASHMAPSIZE);
/*    */ 
/*    */   
/*    */   private static String concatPrimaryDatabase(String paramString1, String paramString2, String paramString3) {
/* 20 */     StringBuilder stringBuilder = new StringBuilder();
/* 21 */     stringBuilder.append(paramString1);
/* 22 */     if (null != paramString2) {
/*    */       
/* 24 */       stringBuilder.append("\\");
/* 25 */       stringBuilder.append(paramString2);
/*    */     } 
/* 27 */     stringBuilder.append(";");
/* 28 */     stringBuilder.append(paramString3);
/* 29 */     return stringBuilder.toString();
/*    */   }
/*    */   
/*    */   static FailoverInfo getFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3) {
/* 33 */     synchronized (FailoverMapSingleton.class) {
/*    */       
/* 35 */       if (true == failoverMap.isEmpty())
/*    */       {
/* 37 */         return null;
/*    */       }
/*    */ 
/*    */       
/* 41 */       String str = concatPrimaryDatabase(paramString1, paramString2, paramString3);
/* 42 */       if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINER))
/* 43 */         paramSQLServerConnection.getConnectionLogger().finer(paramSQLServerConnection.toString() + " Looking up info in the map using key: " + str); 
/* 44 */       FailoverInfo failoverInfo = failoverMap.get(str);
/* 45 */       if (null != failoverInfo)
/* 46 */         failoverInfo.log(paramSQLServerConnection); 
/* 47 */       return failoverInfo;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void putFailoverInfo(SQLServerConnection paramSQLServerConnection, String paramString1, String paramString2, String paramString3, FailoverInfo paramFailoverInfo, boolean paramBoolean, String paramString4) throws SQLServerException {
/* 59 */     synchronized (FailoverMapSingleton.class) {
/*    */       FailoverInfo failoverInfo;
/*    */       
/* 62 */       if (null == (failoverInfo = getFailoverInfo(paramSQLServerConnection, paramString1, paramString2, paramString3))) {
/*    */         
/* 64 */         if (paramSQLServerConnection.getConnectionLogger().isLoggable(Level.FINE)) {
/* 65 */           paramSQLServerConnection.getConnectionLogger().fine(paramSQLServerConnection.toString() + " Failover map add server: " + paramString1 + "; database:" + paramString3 + "; Mirror:" + paramString4);
/*    */         }
/* 67 */         failoverMap.put(concatPrimaryDatabase(paramString1, paramString2, paramString3), paramFailoverInfo);
/*    */       }
/*    */       else {
/*    */         
/* 71 */         failoverInfo.failoverAdd(paramSQLServerConnection, paramBoolean, paramString4);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\FailoverMapSingleton.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */