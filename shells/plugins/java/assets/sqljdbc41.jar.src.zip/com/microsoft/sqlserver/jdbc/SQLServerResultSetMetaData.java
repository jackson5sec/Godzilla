/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerResultSetMetaData
/*     */   implements ResultSetMetaData
/*     */ {
/*     */   private SQLServerConnection con;
/*     */   private final SQLServerResultSet rs;
/*     */   public int nBeforeExecuteCols;
/*  20 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSetMetaData");
/*     */ 
/*     */   
/*  23 */   private static int baseID = 0;
/*     */   
/*     */   private final String traceID;
/*     */   
/*     */   private static synchronized int nextInstanceID() {
/*  28 */     baseID++;
/*  29 */     return baseID;
/*     */   }
/*     */   
/*     */   public final String toString() {
/*  33 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerResultSetMetaData(SQLServerConnection paramSQLServerConnection, SQLServerResultSet paramSQLServerResultSet) {
/*  44 */     this.traceID = " SQLServerResultSetMetaData:" + nextInstanceID();
/*  45 */     this.con = paramSQLServerConnection;
/*  46 */     this.rs = paramSQLServerResultSet;
/*  47 */     assert paramSQLServerResultSet != null;
/*  48 */     if (logger.isLoggable(Level.FINE))
/*     */     {
/*  50 */       logger.fine(toString() + " created by (" + paramSQLServerResultSet.toString() + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/*  55 */     this.rs.checkClosed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/*  64 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/*  71 */     DriverJDBCVersion.checkSupportsJDBC4();
/*  72 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   
/*     */   public String getCatalogName(int paramInt) throws SQLServerException {
/*  77 */     checkClosed();
/*  78 */     return this.rs.getColumn(paramInt).getTableName().getDatabaseName();
/*     */   }
/*     */   
/*     */   public int getColumnCount() throws SQLServerException {
/*  82 */     checkClosed();
/*  83 */     if (this.rs == null)
/*  84 */       return 0; 
/*  85 */     return this.rs.getColumnCount();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnDisplaySize(int paramInt) throws SQLServerException {
/*  90 */     checkClosed();
/*     */     
/*  92 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/*  93 */     if (null != cryptoMetadata) {
/*  94 */       return cryptoMetadata.getBaseTypeInfo().getDisplaySize();
/*     */     }
/*     */     
/*  97 */     return this.rs.getColumn(paramInt).getTypeInfo().getDisplaySize();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnLabel(int paramInt) throws SQLServerException {
/* 102 */     checkClosed();
/* 103 */     return this.rs.getColumn(paramInt).getColumnName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName(int paramInt) throws SQLServerException {
/* 108 */     checkClosed();
/* 109 */     return this.rs.getColumn(paramInt).getColumnName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnType(int paramInt) throws SQLServerException {
/* 114 */     checkClosed();
/*     */     
/* 116 */     TypeInfo typeInfo = this.rs.getColumn(paramInt).getTypeInfo();
/*     */     
/* 118 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 119 */     if (null != cryptoMetadata) {
/* 120 */       typeInfo = cryptoMetadata.getBaseTypeInfo();
/*     */     }
/*     */     
/* 123 */     JDBCType jDBCType = typeInfo.getSSType().getJDBCType();
/* 124 */     int i = jDBCType.asJavaSqlType();
/* 125 */     if (this.con.isKatmaiOrLater()) {
/*     */       
/* 127 */       SSType sSType = typeInfo.getSSType();
/*     */       
/* 129 */       switch (sSType) {
/*     */         
/*     */         case VARCHARMAX:
/* 132 */           i = SSType.VARCHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case NVARCHARMAX:
/* 135 */           i = SSType.NVARCHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case VARBINARYMAX:
/* 138 */           i = SSType.VARBINARY.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case DATETIME:
/*     */         case SMALLDATETIME:
/* 142 */           i = SSType.DATETIME2.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case MONEY:
/*     */         case SMALLMONEY:
/* 146 */           i = SSType.DECIMAL.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */         case GUID:
/* 149 */           i = SSType.CHAR.getJDBCType().asJavaSqlType();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */     
/*     */     } 
/* 156 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnTypeName(int paramInt) throws SQLServerException {
/* 161 */     checkClosed();
/*     */     
/* 163 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 164 */     if (null != cryptoMetadata) {
/* 165 */       return cryptoMetadata.getBaseTypeInfo().getSSTypeName();
/*     */     }
/*     */     
/* 168 */     return this.rs.getColumn(paramInt).getTypeInfo().getSSTypeName();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrecision(int paramInt) throws SQLServerException {
/* 173 */     checkClosed();
/*     */     
/* 175 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 176 */     if (null != cryptoMetadata) {
/* 177 */       return cryptoMetadata.getBaseTypeInfo().getPrecision();
/*     */     }
/*     */     
/* 180 */     return this.rs.getColumn(paramInt).getTypeInfo().getPrecision();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScale(int paramInt) throws SQLServerException {
/* 185 */     checkClosed();
/*     */     
/* 187 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 188 */     if (null != cryptoMetadata) {
/* 189 */       return cryptoMetadata.getBaseTypeInfo().getScale();
/*     */     }
/*     */     
/* 192 */     return this.rs.getColumn(paramInt).getTypeInfo().getScale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getSchemaName(int paramInt) throws SQLServerException {
/* 197 */     checkClosed();
/* 198 */     return this.rs.getColumn(paramInt).getTableName().getSchemaName();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getTableName(int paramInt) throws SQLServerException {
/* 203 */     checkClosed();
/* 204 */     return this.rs.getColumn(paramInt).getTableName().getObjectName();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement(int paramInt) throws SQLServerException {
/* 209 */     checkClosed();
/*     */     
/* 211 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 212 */     if (null != cryptoMetadata) {
/* 213 */       return cryptoMetadata.getBaseTypeInfo().isIdentity();
/*     */     }
/*     */     
/* 216 */     return this.rs.getColumn(paramInt).getTypeInfo().isIdentity();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive(int paramInt) throws SQLServerException {
/* 221 */     checkClosed();
/*     */     
/* 223 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 224 */     if (null != cryptoMetadata) {
/* 225 */       return cryptoMetadata.getBaseTypeInfo().isCaseSensitive();
/*     */     }
/*     */     
/* 228 */     return this.rs.getColumn(paramInt).getTypeInfo().isCaseSensitive();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCurrency(int paramInt) throws SQLServerException {
/* 233 */     checkClosed();
/* 234 */     SSType sSType = this.rs.getColumn(paramInt).getTypeInfo().getSSType();
/*     */     
/* 236 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 237 */     if (null != cryptoMetadata) {
/* 238 */       sSType = cryptoMetadata.getBaseTypeInfo().getSSType();
/*     */     }
/*     */     
/* 241 */     return (SSType.MONEY == sSType || SSType.SMALLMONEY == sSType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyWritable(int paramInt) throws SQLServerException {
/* 247 */     checkClosed();
/*     */     
/* 249 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 250 */     if (null != cryptoMetadata) {
/* 251 */       return (TypeInfo.UPDATABLE_READ_WRITE == cryptoMetadata.getBaseTypeInfo().getUpdatability());
/*     */     }
/*     */     
/* 254 */     return (TypeInfo.UPDATABLE_READ_WRITE == this.rs.getColumn(paramInt).getTypeInfo().getUpdatability());
/*     */   }
/*     */ 
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLServerException {
/* 259 */     checkClosed();
/*     */     
/* 261 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 262 */     if (null != cryptoMetadata) {
/* 263 */       return cryptoMetadata.getBaseTypeInfo().isNullable() ? 1 : 0;
/*     */     }
/*     */     
/* 266 */     return this.rs.getColumn(paramInt).getTypeInfo().isNullable() ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(int paramInt) throws SQLServerException {
/* 271 */     checkClosed();
/*     */     
/* 273 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 274 */     if (null != cryptoMetadata) {
/* 275 */       return (TypeInfo.UPDATABLE_READ_ONLY == cryptoMetadata.getBaseTypeInfo().getUpdatability());
/*     */     }
/*     */     
/* 278 */     return (TypeInfo.UPDATABLE_READ_ONLY == this.rs.getColumn(paramInt).getTypeInfo().getUpdatability());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSearchable(int paramInt) throws SQLServerException {
/* 283 */     checkClosed();
/*     */     
/* 285 */     SSType sSType = null;
/* 286 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/*     */     
/* 288 */     if (null != cryptoMetadata) {
/* 289 */       sSType = cryptoMetadata.getBaseTypeInfo().getSSType();
/*     */     } else {
/*     */       
/* 292 */       sSType = this.rs.getColumn(paramInt).getTypeInfo().getSSType();
/*     */     } 
/*     */     
/* 295 */     switch (sSType) {
/*     */       
/*     */       case IMAGE:
/*     */       case TEXT:
/*     */       case NTEXT:
/*     */       case UDT:
/*     */       case XML:
/* 302 */         return false;
/*     */     } 
/*     */     
/* 305 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSigned(int paramInt) throws SQLServerException {
/* 311 */     checkClosed();
/*     */     
/* 313 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 314 */     if (null != cryptoMetadata) {
/* 315 */       return cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().isSigned();
/*     */     }
/*     */     
/* 318 */     return this.rs.getColumn(paramInt).getTypeInfo().getSSType().getJDBCType().isSigned();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSparseColumnSet(int paramInt) throws SQLServerException {
/* 329 */     checkClosed();
/*     */     
/* 331 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 332 */     if (null != cryptoMetadata) {
/* 333 */       return cryptoMetadata.getBaseTypeInfo().isSparseColumnSet();
/*     */     }
/*     */     
/* 336 */     return this.rs.getColumn(paramInt).getTypeInfo().isSparseColumnSet();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWritable(int paramInt) throws SQLServerException {
/* 341 */     checkClosed();
/*     */     
/* 343 */     int i = -1;
/* 344 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 345 */     if (null != cryptoMetadata) {
/* 346 */       i = cryptoMetadata.getBaseTypeInfo().getUpdatability();
/*     */     } else {
/*     */       
/* 349 */       i = this.rs.getColumn(paramInt).getTypeInfo().getUpdatability();
/*     */     } 
/* 351 */     return (TypeInfo.UPDATABLE_READ_WRITE == i || TypeInfo.UPDATABLE_UNKNOWN == i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnClassName(int paramInt) throws SQLServerException {
/* 357 */     checkClosed();
/*     */     
/* 359 */     CryptoMetadata cryptoMetadata = this.rs.getColumn(paramInt).getCryptoMetadata();
/* 360 */     if (null != cryptoMetadata) {
/* 361 */       return cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType().className();
/*     */     }
/*     */     
/* 364 */     return this.rs.getColumn(paramInt).getTypeInfo().getSSType().getJDBCType().className();
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerResultSetMetaData.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */