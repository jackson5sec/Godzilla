/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.UUID;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerException
/*     */   extends SQLException
/*     */ {
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_CANT_ESTABLISH = "08001";
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_DOES_NOT_EXIST = "08003";
/*     */   static final String EXCEPTION_XOPEN_CONNECTION_FAILURE = "08006";
/*     */   static final String LOG_CLIENT_CONNECTION_ID_PREFIX = " ClientConnectionId:";
/*     */   static final int LOGON_FAILED = 18456;
/*     */   static final int PASSWORD_EXPIRED = 18488;
/*  55 */   static Logger exLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerException");
/*     */   
/*     */   static final int DRIVER_ERROR_NONE = 0;
/*     */   
/*     */   static final int DRIVER_ERROR_FROM_DATABASE = 2;
/*     */   static final int DRIVER_ERROR_IO_FAILED = 3;
/*     */   static final int DRIVER_ERROR_INVALID_TDS = 4;
/*     */   static final int DRIVER_ERROR_SSL_FAILED = 5;
/*     */   static final int DRIVER_ERROR_UNSUPPORTED_CONFIG = 6;
/*     */   static final int DRIVER_ERROR_INTERMITTENT_TLS_FAILED = 7;
/*  65 */   private int driverErrorCode = 0;
/*  66 */   final int getDriverErrorCode() { return this.driverErrorCode; } final void setDriverErrorCode(int paramInt) {
/*  67 */     this.driverErrorCode = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logException(Object paramObject, String paramString, boolean paramBoolean) {
/*  78 */     String str = "";
/*  79 */     if (paramObject != null) {
/*  80 */       str = paramObject.toString();
/*     */     }
/*  82 */     if (exLogger.isLoggable(Level.FINE))
/*  83 */       exLogger.fine("*** SQLException:" + str + " " + toString() + " " + paramString); 
/*  84 */     if (paramBoolean)
/*     */     {
/*  86 */       if (exLogger.isLoggable(Level.FINE)) {
/*     */         
/*  88 */         StringBuilder stringBuilder = new StringBuilder(100);
/*  89 */         StackTraceElement[] arrayOfStackTraceElement = getStackTrace();
/*  90 */         for (byte b = 0; b < arrayOfStackTraceElement.length; b++)
/*  91 */           stringBuilder.append(arrayOfStackTraceElement[b].toString()); 
/*  92 */         Throwable throwable = getCause();
/*  93 */         if (throwable != null) {
/*     */           
/*  95 */           stringBuilder.append("\n caused by " + throwable + "\n");
/*  96 */           StackTraceElement[] arrayOfStackTraceElement1 = throwable.getStackTrace();
/*  97 */           for (byte b1 = 0; b1 < arrayOfStackTraceElement1.length; b1++)
/*  98 */             stringBuilder.append(arrayOfStackTraceElement1[b1].toString()); 
/*     */         } 
/* 100 */         exLogger.fine(stringBuilder.toString());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static String getErrString(String paramString) {
/* 107 */     return SQLServerResource.getResource(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerException(String paramString, SQLState paramSQLState, DriverError paramDriverError, Throwable paramThrowable) {
/* 121 */     this(paramString, paramSQLState.getSQLStateCode(), paramDriverError.getErrorCode(), paramThrowable);
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerException(String paramString1, String paramString2, int paramInt, Throwable paramThrowable) {
/* 126 */     super(paramString1, paramString2, paramInt);
/* 127 */     initCause(paramThrowable);
/* 128 */     logException((Object)null, paramString1, true);
/* 129 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerException(String paramString, Throwable paramThrowable) {
/* 134 */     super(paramString);
/* 135 */     initCause(paramThrowable);
/* 136 */     logException((Object)null, paramString, true);
/* 137 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerException(Object paramObject, String paramString1, String paramString2, int paramInt, boolean paramBoolean) {
/* 143 */     super(paramString1, paramString2, paramInt);
/* 144 */     logException(paramObject, paramString1, paramBoolean);
/* 145 */     ActivityCorrelator.setCurrentActivityIdSentFlag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerException(Object paramObject, String paramString1, String paramString2, StreamError paramStreamError, boolean paramBoolean) {
/* 159 */     super(paramString1, paramString2, paramStreamError.getErrorNumber());
/*     */ 
/*     */ 
/*     */     
/* 163 */     paramString1 = "Msg " + paramStreamError.getErrorNumber() + ", Level " + paramStreamError.getErrorSeverity() + ", State " + paramStreamError.getErrorState() + ", " + paramString1;
/* 164 */     logException(paramObject, paramString1, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void makeFromDriverError(SQLServerConnection paramSQLServerConnection, Object paramObject, String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
/* 183 */     String str = "";
/*     */ 
/*     */     
/* 186 */     if (paramString2 != null)
/* 187 */       str = paramString2; 
/* 188 */     if (paramSQLServerConnection == null || !paramSQLServerConnection.xopenStates) {
/* 189 */       str = mapFromXopen(paramString2);
/*     */     }
/* 191 */     SQLServerException sQLServerException = new SQLServerException(paramObject, checkAndAppendClientConnId(paramString1, paramSQLServerConnection), str, 0, paramBoolean);
/* 192 */     if (null != paramString2 && paramString2.equals("08006") && null != paramSQLServerConnection) {
/*     */       
/* 194 */       paramSQLServerConnection.notifyPooledConnection(sQLServerException);
/*     */       
/* 196 */       paramSQLServerConnection.close();
/*     */     } 
/*     */     
/* 199 */     throw sQLServerException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void makeFromDatabaseError(SQLServerConnection paramSQLServerConnection, Object paramObject, String paramString, StreamError paramStreamError, boolean paramBoolean) throws SQLServerException {
/* 215 */     String str = generateStateCode(paramSQLServerConnection, paramStreamError.getErrorNumber(), paramStreamError.getErrorState());
/*     */     
/* 217 */     SQLServerException sQLServerException = new SQLServerException(paramObject, checkAndAppendClientConnId(paramString, paramSQLServerConnection), str, paramStreamError, paramBoolean);
/* 218 */     sQLServerException.setDriverErrorCode(2);
/*     */ 
/*     */     
/* 221 */     if (paramStreamError.getErrorSeverity() >= 20 && null != paramSQLServerConnection) {
/*     */       
/* 223 */       paramSQLServerConnection.notifyPooledConnection(sQLServerException);
/* 224 */       paramSQLServerConnection.close();
/*     */     } 
/*     */     
/* 227 */     throw sQLServerException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void ConvertConnectExceptionToSQLServerException(String paramString, int paramInt, SQLServerConnection paramSQLServerConnection, Exception paramException) throws SQLServerException {
/* 233 */     Exception exception = paramException;
/*     */     
/* 235 */     if (exception != null) {
/*     */       
/* 237 */       MessageFormat messageFormat1 = new MessageFormat(getErrString("R_tcpOpenFailed"));
/* 238 */       Object[] arrayOfObject1 = { exception.getMessage() };
/* 239 */       MessageFormat messageFormat2 = new MessageFormat(getErrString("R_tcpipConnectionFailed"));
/* 240 */       Object[] arrayOfObject2 = { paramString, Integer.toString(paramInt), messageFormat1.format(arrayOfObject1) };
/* 241 */       String str = messageFormat2.format(arrayOfObject2);
/* 242 */       makeFromDriverError(paramSQLServerConnection, paramSQLServerConnection, str, "08001", false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String mapFromXopen(String paramString) {
/* 260 */     if (paramString == null)
/* 261 */       return null; 
/* 262 */     if (paramString.equals("07009")) {
/* 263 */       return "S1093";
/*     */     }
/*     */     
/* 266 */     if (paramString.equals("08001"))
/* 267 */       return "08S01"; 
/* 268 */     if (paramString.equals("08006")) {
/* 269 */       return "08S01";
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 274 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String generateStateCode(SQLServerConnection paramSQLServerConnection, int paramInt1, int paramInt2) {
/* 287 */     boolean bool = (paramSQLServerConnection != null && paramSQLServerConnection.xopenStates) ? true : false;
/* 288 */     if (bool) {
/*     */       
/* 290 */       switch (paramInt1) {
/*     */         case 4060:
/* 292 */           return "08001";
/* 293 */         case 18456: return "08001";
/* 294 */         case 2714: return "42S01";
/* 295 */         case 208: return "42S02";
/* 296 */         case 207: return "42S22";
/*     */       } 
/*     */       
/* 299 */       return "42000";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 304 */     switch (paramInt1) {
/*     */       
/*     */       case 8152:
/* 307 */         return "22001";
/*     */       case 515: case 547:
/* 309 */         return "23000";
/* 310 */       case 2601: return "23000";
/* 311 */       case 2714: return "S0001";
/* 312 */       case 208: return "S0002";
/* 313 */       case 1205: return "40001";
/* 314 */       case 2627: return "23000";
/*     */     } 
/* 316 */     return "S000" + paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String checkAndAppendClientConnId(String paramString, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/* 329 */     if (null != paramSQLServerConnection && paramSQLServerConnection.attachConnId()) {
/*     */       
/* 331 */       UUID uUID = paramSQLServerConnection.getClientConIdInternal();
/* 332 */       assert null != uUID;
/* 333 */       StringBuilder stringBuilder = new StringBuilder(paramString);
/*     */ 
/*     */       
/* 336 */       stringBuilder.append(" ClientConnectionId:");
/* 337 */       stringBuilder.append(uUID.toString());
/* 338 */       return stringBuilder.toString();
/*     */     } 
/*     */     
/* 341 */     return paramString;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerException.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */