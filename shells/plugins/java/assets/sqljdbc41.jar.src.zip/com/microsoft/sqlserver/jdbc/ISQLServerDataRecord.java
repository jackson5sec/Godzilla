package com.microsoft.sqlserver.jdbc;

public interface ISQLServerDataRecord {
  SQLServerMetaData getColumnMetaData(int paramInt);
  
  int getColumnCount();
  
  Object[] getRowData();
  
  boolean next();
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\ISQLServerDataRecord.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */