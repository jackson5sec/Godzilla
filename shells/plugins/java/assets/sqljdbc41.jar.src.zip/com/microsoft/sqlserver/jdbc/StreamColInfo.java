/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamColInfo
/*    */   extends StreamPacket
/*    */ {
/*    */   private TDSReader tdsReader;
/*    */   private TDSReaderMark colInfoMark;
/*    */   
/*    */   StreamColInfo() {
/* 17 */     super(165);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 22 */     if (165 != paramTDSReader.readUnsignedByte() && 
/* 23 */       !$assertionsDisabled) throw new AssertionError("Not a COLINFO token");
/*    */     
/* 25 */     this.tdsReader = paramTDSReader;
/* 26 */     int i = paramTDSReader.readUnsignedShort();
/* 27 */     this.colInfoMark = paramTDSReader.mark();
/* 28 */     paramTDSReader.skip(i);
/*    */   }
/*    */ 
/*    */   
/*    */   int applyTo(Column[] paramArrayOfColumn) throws SQLServerException {
/* 33 */     int i = 0;
/*    */ 
/*    */     
/* 36 */     TDSReaderMark tDSReaderMark = this.tdsReader.mark();
/* 37 */     this.tdsReader.reset(this.colInfoMark);
/* 38 */     for (byte b = 0; b < paramArrayOfColumn.length; b++) {
/*    */       
/* 40 */       Column column = paramArrayOfColumn[b];
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 45 */       this.tdsReader.readUnsignedByte();
/*    */ 
/*    */ 
/*    */       
/* 49 */       column.setTableNum(this.tdsReader.readUnsignedByte());
/* 50 */       if (column.getTableNum() > i) {
/* 51 */         i = column.getTableNum();
/*    */       }
/*    */       
/* 54 */       column.setInfoStatus(this.tdsReader.readUnsignedByte());
/* 55 */       if (column.hasDifferentName()) {
/* 56 */         column.setBaseColumnName(this.tdsReader.readUnicodeString(this.tdsReader.readUnsignedByte()));
/*    */       }
/*    */     } 
/* 59 */     this.tdsReader.reset(tDSReaderMark);
/* 60 */     return i;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamColInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */