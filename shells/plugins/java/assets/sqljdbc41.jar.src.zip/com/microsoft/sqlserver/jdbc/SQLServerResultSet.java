/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ import java.io.Closeable;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.NClob;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.RowId;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.SQLXML;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ public final class SQLServerResultSet implements ISQLServerResultSet {
/*   31 */   private static int lastResultSetID = 0; private final String traceID;
/*      */   private static synchronized int nextResultSetID() {
/*   33 */     return ++lastResultSetID;
/*   34 */   } static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerResultSet");
/*   35 */   public String toString() { return this.traceID; } String logCursorState() {
/*   36 */     return " currentRow:" + this.currentRow + " numFetchedRows:" + this.numFetchedRows + " rowCount:" + this.rowCount;
/*   37 */   } private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.ResultSet"); private final String loggingClassName;
/*      */   private final SQLServerStatement stmt;
/*      */   private final int maxRows;
/*      */   private ResultSetMetaData metaData;
/*      */   
/*      */   String getClassNameLogging() {
/*   43 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isClosed = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private final int serverCursorId;
/*      */ 
/*      */ 
/*      */   
/*      */   private int fetchDirection;
/*      */ 
/*      */ 
/*      */   
/*      */   private int fetchSize;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isOnInsertRow = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean lastValueWasNull = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private int lastColumnIndex;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean areNullCompressedColumnsInitialized = false;
/*      */ 
/*      */ 
/*      */   
/*   81 */   private RowType resultSetCurrentRowType = RowType.UNKNOWN; private Closeable activeStream; private final ScrollWindow scrollWindow; private static final int BEFORE_FIRST_ROW = 0;
/*      */   private static final int AFTER_LAST_ROW = -1;
/*      */   private static final int UNKNOWN_ROW = -2;
/*      */   
/*      */   final RowType getCurrentRowType() {
/*   86 */     return this.resultSetCurrentRowType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setCurrentRowType(RowType paramRowType) {
/*   92 */     this.resultSetCurrentRowType = paramRowType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   private int currentRow = 0;
/*      */   private boolean updatedCurrentRow = false;
/*      */   
/*      */   final boolean getUpdatedCurrentRow() {
/*  116 */     return this.updatedCurrentRow; } final void setUpdatedCurrentRow(boolean paramBoolean) {
/*  117 */     this.updatedCurrentRow = paramBoolean;
/*      */   }
/*      */   private boolean deletedCurrentRow = false; static final int UNKNOWN_ROW_COUNT = -3; private int rowCount; private final Column[] columns;
/*      */   
/*  121 */   final boolean getDeletedCurrentRow() { return this.deletedCurrentRow; } final void setDeletedCurrentRow(boolean paramBoolean) {
/*  122 */     this.deletedCurrentRow = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private CekTable cekTable = null; private TDSReader tdsReader; private final FetchBuffer fetchBuffer;
/*      */   private SQLServerException rowErrorException;
/*      */   private int numFetchedRows;
/*      */   
/*      */   CekTable getCekTable() {
/*  143 */     return this.cekTable;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void setColumnName(int paramInt, String paramString) {
/*  149 */     this.columns[paramInt - 1].setColumnName(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void skipColumns(int paramInt, boolean paramBoolean) throws SQLServerException {
/*  158 */     assert this.lastColumnIndex >= 1;
/*  159 */     assert 0 <= paramInt && paramInt <= this.columns.length;
/*      */     
/*  161 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/*  163 */       Column column = getColumn(this.lastColumnIndex++);
/*  164 */       column.skipValue(this.tdsReader, (paramBoolean && isForwardOnly()));
/*  165 */       if (paramBoolean) {
/*  166 */         column.clear();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/*      */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor");
/*      */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     boolean bool = paramClass.isInstance(this);
/*      */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/*      */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerResultSet(SQLServerStatement paramSQLServerStatement) throws SQLServerException {
/*      */     final class ServerCursorInitializer
/*      */       extends CursorInitializer
/*      */     {
/*      */       private final SQLServerStatement stmt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       final int getRowCount() {
/*  238 */         return this.stmt.getServerCursorRowCount(); } final int getServerCursorId() {
/*  239 */         return this.stmt.getServerCursorId();
/*      */       }
/*      */       
/*      */       ServerCursorInitializer(SQLServerStatement param1SQLServerStatement) {
/*  243 */         super("ServerCursorInitializer");
/*  244 */         this.stmt = param1SQLServerStatement;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetStatus(TDSReader param1TDSReader) throws SQLServerException {
/*  254 */         this.stmt.consumeExecOutParam(param1TDSReader);
/*  255 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
/*  263 */         return false;
/*      */       }
/*      */     };
/*      */ 
/*      */     
/*      */     final class ClientCursorInitializer
/*      */       extends CursorInitializer
/*      */     {
/*  271 */       private int rowCount = -3;
/*  272 */       final int getRowCount() { return this.rowCount; } final int getServerCursorId() {
/*  273 */         return 0;
/*      */       }
/*      */       
/*      */       ClientCursorInitializer() {
/*  277 */         super("ClientCursorInitializer");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRow(TDSReader param1TDSReader) throws SQLServerException {
/*  283 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onNBCRow(TDSReader param1TDSReader) throws SQLServerException {
/*  289 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onError(TDSReader param1TDSReader) throws SQLServerException {
/*  297 */         this.rowCount = 0;
/*  298 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
/*  305 */         this.rowCount = 0;
/*  306 */         return false;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  375 */     this.rowErrorException = null; int i = nextResultSetID(); this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerResultSet:" + i; this.traceID = "SQLServerResultSet:" + i; this.stmt = paramSQLServerStatement; this.maxRows = paramSQLServerStatement.maxRows; this.fetchSize = paramSQLServerStatement.nFetchSize; this.fetchDirection = paramSQLServerStatement.nFetchDirection; TDSTokenHandler tDSTokenHandler = (TDSTokenHandler)(paramSQLServerStatement.executedSqlDirectly ? new ClientCursorInitializer() : new ServerCursorInitializer(paramSQLServerStatement)); TDSParser.parse(paramSQLServerStatement.resultsReader(), tDSTokenHandler); this.columns = tDSTokenHandler.buildColumns(); this.rowCount = tDSTokenHandler.getRowCount();
/*      */     this.serverCursorId = tDSTokenHandler.getServerCursorId();
/*      */     this.tdsReader = (0 == this.serverCursorId) ? paramSQLServerStatement.resultsReader() : null;
/*      */     this.fetchBuffer = new FetchBuffer();
/*      */     this.scrollWindow = isForwardOnly() ? null : new ScrollWindow(this.fetchSize);
/*      */     this.numFetchedRows = 0;
/*      */     paramSQLServerStatement.incrResultSetCount();
/*      */     if (logger.isLoggable(Level.FINE))
/*  383 */       logger.fine(toString() + " created by (" + this.stmt.toString() + ")");  } void checkClosed() throws SQLServerException { if (this.isClosed) {
/*  384 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_resultsetClosed"), (String)null, false);
/*      */     }
/*      */     
/*  387 */     this.stmt.checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  392 */     if (null != this.rowErrorException)
/*  393 */       throw this.rowErrorException;  } public <T> T unwrap(Class<T> paramClass) throws SQLException { T t; loggerExternal.entering(getClassNameLogging(), "unwrap"); DriverJDBCVersion.checkSupportsJDBC4(); try {
/*      */       t = paramClass.cast(this);
/*      */     } catch (ClassCastException classCastException) {
/*      */       throw new SQLServerException(classCastException.getMessage(), classCastException);
/*      */     }  loggerExternal.exiting(getClassNameLogging(), "unwrap", t); return t; }
/*  398 */   public boolean isClosed() throws SQLException { DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/*  400 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/*  401 */     boolean bool = (this.isClosed || this.stmt.isClosed()) ? true : false;
/*  402 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(bool));
/*  403 */     return bool; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void throwNotScrollable() throws SQLServerException {
/*  414 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_requestedOpNotSupportedOnForward"), (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isForwardOnly() {
/*  424 */     return (2003 == this.stmt.getSQLResultSetType() || 2004 == this.stmt.getSQLResultSetType());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isDynamic() {
/*  431 */     return (0 != this.serverCursorId && 2 == this.stmt.getCursorType());
/*      */   }
/*      */ 
/*      */   
/*      */   private final void verifyResultSetIsScrollable() throws SQLServerException {
/*  436 */     if (isForwardOnly()) {
/*  437 */       throwNotScrollable();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void throwNotUpdatable() throws SQLServerException {
/*  448 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_resultsetNotUpdatable"), (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void verifyResultSetIsUpdatable() throws SQLServerException {
/*  458 */     if (1007 == this.stmt.resultSetConcurrency || 0 == this.serverCursorId) {
/*  459 */       throwNotUpdatable();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean hasCurrentRow() {
/*  470 */     return (0 != this.currentRow && -1 != this.currentRow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyResultSetHasCurrentRow() throws SQLServerException {
/*  493 */     if (!hasCurrentRow())
/*      */     {
/*  495 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_resultsetNoCurrentRow"), (String)null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyCurrentRowIsNotDeleted(String paramString) throws SQLServerException {
/*  512 */     if (currentRowDeleted())
/*      */     {
/*  514 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString(paramString), (String)null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyValidColumnIndex(int paramInt) throws SQLServerException {
/*  531 */     int i = this.columns.length;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  536 */     if (0 != this.serverCursorId) {
/*  537 */       i--;
/*      */     }
/*  539 */     if (paramInt < 1 || paramInt > i) {
/*      */       
/*  541 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_indexOutOfRange"));
/*  542 */       Object[] arrayOfObject = { new Integer(paramInt) };
/*  543 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, messageFormat.format(arrayOfObject), "07009", false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void verifyResultSetIsNotOnInsertRow() throws SQLServerException {
/*  556 */     if (this.isOnInsertRow)
/*      */     {
/*  558 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_mustNotBeOnInsertRow"), (String)null, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void throwUnsupportedCursorOp() throws SQLServerException {
/*  566 */     SQLServerException.makeFromDriverError(this.stmt.connection, this, SQLServerException.getErrString("R_unsupportedCursorOperation"), (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void closeInternal() {
/*  586 */     if (this.isClosed) {
/*      */       return;
/*      */     }
/*      */     
/*  590 */     this.isClosed = true;
/*      */ 
/*      */     
/*  593 */     discardFetchBuffer();
/*      */ 
/*      */     
/*  596 */     closeServerCursor();
/*      */ 
/*      */     
/*  599 */     this.metaData = null;
/*      */ 
/*      */     
/*  602 */     this.stmt.decrResultSetCount();
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws SQLServerException {
/*  607 */     loggerExternal.entering(getClassNameLogging(), "close");
/*  608 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  610 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  612 */     closeInternal();
/*  613 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLServerException {
/*  624 */     loggerExternal.entering(getClassNameLogging(), "findColumn", paramString);
/*  625 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     byte b;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  648 */     for (b = 0; b < this.columns.length; b++) {
/*      */       
/*  650 */       if (this.columns[b].getColumnName().equals(paramString)) {
/*      */         
/*  652 */         loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(b + 1));
/*  653 */         return b + 1;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  661 */     for (b = 0; b < this.columns.length; b++) {
/*      */       
/*  663 */       if (this.columns[b].getColumnName().equalsIgnoreCase(paramString)) {
/*      */         
/*  665 */         loggerExternal.exiting(getClassNameLogging(), "findColumn", Integer.valueOf(b + 1));
/*  666 */         return b + 1;
/*      */       } 
/*      */     } 
/*  669 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumnName"));
/*  670 */     Object[] arrayOfObject = { paramString };
/*  671 */     SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, messageFormat.format(arrayOfObject), "07009", false);
/*      */ 
/*      */     
/*  674 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   final int getColumnCount() {
/*  679 */     int i = this.columns.length;
/*  680 */     if (0 != this.serverCursorId)
/*  681 */       i--; 
/*  682 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Column getColumn(int paramInt) throws SQLServerException {
/*  689 */     if (null != this.activeStream) {
/*      */       
/*      */       try {
/*      */         
/*  693 */         this.activeStream.close();
/*      */       }
/*  695 */       catch (IOException iOException) {
/*      */         
/*  697 */         SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, iOException.getMessage(), (String)null, true);
/*      */       }
/*      */       finally {
/*      */         
/*  701 */         this.activeStream = null;
/*      */       } 
/*      */     }
/*      */     
/*  705 */     return this.columns[paramInt - 1];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void initializeNullCompressedColumns() throws SQLServerException {
/*  718 */     if (this.resultSetCurrentRowType.equals(RowType.NBCROW) && !this.areNullCompressedColumnsInitialized) {
/*      */       
/*  720 */       int i = 0;
/*      */       
/*  722 */       int j = (this.columns.length - 1 >> 3) + 1;
/*  723 */       for (byte b = 0; b < j; b++) {
/*      */ 
/*      */         
/*  726 */         int k = this.tdsReader.readUnsignedByte();
/*      */ 
/*      */ 
/*      */         
/*  730 */         if (k == 0) {
/*      */           
/*  732 */           i += 8;
/*      */         }
/*      */         else {
/*      */           
/*  736 */           for (byte b1 = 0; b1 < 8 && i < this.columns.length; b1++) {
/*      */             
/*  738 */             if ((k & 1 << b1) != 0)
/*      */             {
/*  740 */               this.columns[i].initFromCompressedNull();
/*      */             }
/*  742 */             i++;
/*      */           } 
/*      */         } 
/*  745 */       }  this.areNullCompressedColumnsInitialized = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final Column loadColumn(int paramInt) throws SQLServerException {
/*  751 */     assert 1 <= paramInt && paramInt <= this.columns.length;
/*      */     
/*  753 */     initializeNullCompressedColumns();
/*      */ 
/*      */ 
/*      */     
/*  757 */     if (paramInt > this.lastColumnIndex && !this.columns[paramInt - 1].isInitialized()) {
/*  758 */       skipColumns(paramInt - this.lastColumnIndex, false);
/*      */     }
/*      */     
/*  761 */     return getColumn(paramInt);
/*      */   }
/*      */   
/*      */   private void NotImplemented() throws SQLServerException {
/*  765 */     SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_notSupported"), (String)null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLServerException {
/*  775 */     loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/*  776 */     loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void moverInit() throws SQLServerException {
/*  783 */     cancelInsert();
/*  784 */     cancelUpdates();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLServerException {
/*  789 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*  790 */       loggerExternal.entering(getClassNameLogging(), "relative", Integer.valueOf(paramInt));
/*      */     }
/*  792 */     if (logger.isLoggable(Level.FINER)) {
/*  793 */       logger.finer(toString() + " rows:" + paramInt + logCursorState());
/*      */     }
/*  795 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  800 */     verifyResultSetIsScrollable();
/*  801 */     verifyResultSetHasCurrentRow();
/*      */     
/*  803 */     moverInit();
/*  804 */     moveRelative(paramInt);
/*  805 */     boolean bool = hasCurrentRow();
/*  806 */     loggerExternal.exiting(getClassNameLogging(), "relative", Boolean.valueOf(bool));
/*  807 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void moveRelative(int paramInt) throws SQLServerException {
/*  813 */     assert hasCurrentRow();
/*      */ 
/*      */     
/*  816 */     if (0 == paramInt) {
/*      */       return;
/*      */     }
/*  819 */     if (paramInt > 0) {
/*  820 */       moveForward(paramInt);
/*      */     } else {
/*  822 */       moveBackward(paramInt);
/*      */     } 
/*      */   }
/*      */   
/*      */   private final void moveForward(int paramInt) throws SQLServerException {
/*  827 */     assert hasCurrentRow();
/*  828 */     assert paramInt > 0;
/*      */ 
/*      */     
/*  831 */     if (this.scrollWindow.getRow() + paramInt <= this.scrollWindow.getMaxRows()) {
/*      */       
/*  833 */       byte b = 0;
/*  834 */       while (paramInt > 0 && this.scrollWindow.next(this)) {
/*      */         
/*  836 */         b++;
/*  837 */         paramInt--;
/*      */       } 
/*      */ 
/*      */       
/*  841 */       updateCurrentRow(b);
/*      */ 
/*      */       
/*  844 */       if (0 == paramInt) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/*  849 */     assert paramInt > 0;
/*      */ 
/*      */ 
/*      */     
/*  853 */     if (0 == this.serverCursorId) {
/*      */       
/*  855 */       assert -2 != this.currentRow;
/*  856 */       this.currentRow = clientMoveAbsolute(this.currentRow + paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  871 */     if (1 == paramInt) {
/*  872 */       doServerFetch(2, 0, this.fetchSize);
/*      */     } else {
/*  874 */       doServerFetch(32, paramInt + this.scrollWindow.getRow() - 1, this.fetchSize);
/*      */     } 
/*      */     
/*  877 */     if (!this.scrollWindow.next(this)) {
/*      */       
/*  879 */       this.currentRow = -1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  884 */     updateCurrentRow(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void moveBackward(int paramInt) throws SQLServerException {
/*  889 */     assert hasCurrentRow();
/*  890 */     assert paramInt < 0;
/*      */ 
/*      */     
/*  893 */     if (this.scrollWindow.getRow() + paramInt >= 1) {
/*      */       
/*  895 */       for (byte b = 0; b > paramInt; b--) {
/*  896 */         this.scrollWindow.previous(this);
/*      */       }
/*  898 */       updateCurrentRow(paramInt);
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */     
/*  906 */     if (0 == this.serverCursorId) {
/*      */       
/*  908 */       assert -2 != this.currentRow;
/*      */ 
/*      */ 
/*      */       
/*  912 */       if (this.currentRow + paramInt < 1) {
/*      */         
/*  914 */         moveBeforeFirst();
/*      */       }
/*      */       else {
/*      */         
/*  918 */         this.currentRow = clientMoveAbsolute(this.currentRow + paramInt);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     if (-1 == paramInt) {
/*      */       
/*  944 */       doServerFetch(512, 0, this.fetchSize);
/*      */ 
/*      */       
/*  947 */       if (!this.scrollWindow.next(this)) {
/*      */         
/*  949 */         this.currentRow = 0;
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  954 */       while (this.scrollWindow.next(this));
/*      */ 
/*      */ 
/*      */       
/*  958 */       this.scrollWindow.previous(this);
/*      */     }
/*      */     else {
/*      */       
/*  962 */       doServerFetch(32, paramInt + this.scrollWindow.getRow() - 1, this.fetchSize);
/*      */ 
/*      */       
/*  965 */       if (!this.scrollWindow.next(this)) {
/*      */         
/*  967 */         this.currentRow = 0;
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  973 */     updateCurrentRow(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void updateCurrentRow(int paramInt) {
/*  984 */     if (-2 != this.currentRow) {
/*      */       
/*  986 */       assert this.currentRow >= 1;
/*  987 */       this.currentRow += paramInt;
/*  988 */       assert this.currentRow >= 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLServerException {
/* 1001 */     loggerExternal.entering(getClassNameLogging(), "next");
/* 1002 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1004 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1006 */     if (logger.isLoggable(Level.FINER)) {
/* 1007 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1009 */     checkClosed();
/*      */     
/* 1011 */     moverInit();
/*      */ 
/*      */ 
/*      */     
/* 1015 */     if (-1 == this.currentRow) {
/*      */       
/* 1017 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1018 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1022 */     if (!isForwardOnly()) {
/*      */       
/* 1024 */       if (0 == this.currentRow) {
/* 1025 */         moveFirst();
/*      */       } else {
/* 1027 */         moveForward(1);
/* 1028 */       }  boolean bool = hasCurrentRow();
/* 1029 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(bool));
/* 1030 */       return bool;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1037 */     if (0 != this.serverCursorId && this.maxRows > 0)
/*      */     {
/* 1039 */       if (this.currentRow == this.maxRows) {
/*      */         
/* 1041 */         this.currentRow = -1;
/* 1042 */         loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1043 */         return false;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1049 */     if (fetchBufferNext()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1054 */       if (0 == this.currentRow) {
/* 1055 */         this.currentRow = 1;
/*      */       } else {
/* 1057 */         updateCurrentRow(1);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1062 */       assert 0 == this.maxRows || this.currentRow <= this.maxRows;
/* 1063 */       loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
/*      */       
/* 1065 */       return true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1071 */     if (0 != this.serverCursorId) {
/*      */       
/* 1073 */       doServerFetch(2, 0, this.fetchSize);
/*      */ 
/*      */ 
/*      */       
/* 1077 */       if (fetchBufferNext()) {
/*      */         
/* 1079 */         if (0 == this.currentRow) {
/* 1080 */           this.currentRow = 1;
/*      */         } else {
/* 1082 */           updateCurrentRow(1);
/*      */         } 
/* 1084 */         assert 0 == this.maxRows || this.currentRow <= this.maxRows;
/* 1085 */         loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(true));
/* 1086 */         return true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1091 */     if (-3 == this.rowCount) {
/* 1092 */       this.rowCount = this.currentRow;
/*      */     }
/* 1094 */     this.currentRow = -1;
/* 1095 */     loggerExternal.exiting(getClassNameLogging(), "next", Boolean.valueOf(false));
/* 1096 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLServerException {
/* 1101 */     loggerExternal.entering(getClassNameLogging(), "wasNull");
/* 1102 */     checkClosed();
/* 1103 */     loggerExternal.exiting(getClassNameLogging(), "wasNull", Boolean.valueOf(this.lastValueWasNull));
/* 1104 */     return this.lastValueWasNull;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLServerException {
/* 1113 */     loggerExternal.entering(getClassNameLogging(), "isBeforeFirst");
/* 1114 */     if (logger.isLoggable(Level.FINER)) {
/* 1115 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1117 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1126 */     if (0 != this.serverCursorId)
/*      */     {
/* 1128 */       switch (this.stmt.getCursorType()) {
/*      */         
/*      */         case 4:
/* 1131 */           throwNotScrollable();
/*      */           break;
/*      */         
/*      */         case 2:
/* 1135 */           throwUnsupportedCursorOp();
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 16:
/* 1142 */           throwNotScrollable();
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1152 */     if (this.isOnInsertRow) {
/* 1153 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1157 */     if (0 != this.currentRow) {
/* 1158 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1165 */     if (0 == this.serverCursorId) {
/* 1166 */       return fetchBufferHasRows();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1171 */     assert this.rowCount >= 0;
/* 1172 */     boolean bool = (this.rowCount > 0) ? true : false;
/* 1173 */     loggerExternal.exiting(getClassNameLogging(), "isBeforeFirst", Boolean.valueOf(bool));
/* 1174 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLServerException {
/* 1179 */     loggerExternal.entering(getClassNameLogging(), "isAfterLast");
/* 1180 */     if (logger.isLoggable(Level.FINER)) {
/* 1181 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1183 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1190 */     if (0 != this.serverCursorId) {
/*      */       
/* 1192 */       verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1197 */       if (2 == this.stmt.getCursorType() && !isForwardOnly()) {
/* 1198 */         throwUnsupportedCursorOp();
/*      */       }
/*      */     } 
/*      */     
/* 1202 */     if (this.isOnInsertRow) {
/* 1203 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1207 */     assert -1 != this.currentRow || -3 != this.rowCount;
/*      */     
/* 1209 */     boolean bool = (-1 == this.currentRow && this.rowCount > 0) ? true : false;
/* 1210 */     loggerExternal.exiting(getClassNameLogging(), "isAfterLast", Boolean.valueOf(bool));
/* 1211 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLServerException {
/* 1229 */     loggerExternal.entering(getClassNameLogging(), "isFirst");
/* 1230 */     if (logger.isLoggable(Level.FINER)) {
/* 1231 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1233 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1237 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 1241 */     if (isDynamic()) {
/* 1242 */       throwUnsupportedCursorOp();
/*      */     }
/*      */     
/* 1245 */     if (this.isOnInsertRow) {
/* 1246 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1250 */     assert -2 != this.currentRow;
/*      */ 
/*      */     
/* 1253 */     boolean bool = (1 == this.currentRow) ? true : false;
/* 1254 */     loggerExternal.exiting(getClassNameLogging(), "isFirst", Boolean.valueOf(bool));
/* 1255 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLServerException {
/* 1273 */     loggerExternal.entering(getClassNameLogging(), "isLast");
/* 1274 */     if (logger.isLoggable(Level.FINER)) {
/* 1275 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1277 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1281 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 1285 */     if (isDynamic()) {
/* 1286 */       throwUnsupportedCursorOp();
/*      */     }
/*      */     
/* 1289 */     if (this.isOnInsertRow) {
/* 1290 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1294 */     if (!hasCurrentRow()) {
/* 1295 */       return false;
/*      */     }
/*      */     
/* 1298 */     assert this.currentRow >= 1;
/*      */ 
/*      */     
/* 1301 */     if (-3 != this.rowCount) {
/*      */       
/* 1303 */       assert this.currentRow <= this.rowCount;
/* 1304 */       return (this.currentRow == this.rowCount);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1311 */     assert 0 == this.serverCursorId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1318 */     boolean bool = !next() ? true : false;
/* 1319 */     previous();
/* 1320 */     loggerExternal.exiting(getClassNameLogging(), "isLast", Boolean.valueOf(bool));
/* 1321 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLServerException {
/* 1326 */     loggerExternal.entering(getClassNameLogging(), "beforeFirst");
/* 1327 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1329 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1331 */     if (logger.isLoggable(Level.FINER)) {
/* 1332 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1334 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1338 */     verifyResultSetIsScrollable();
/*      */     
/* 1340 */     moverInit();
/* 1341 */     moveBeforeFirst();
/* 1342 */     loggerExternal.exiting(getClassNameLogging(), "beforeFirst");
/*      */   }
/*      */ 
/*      */   
/*      */   private final void moveBeforeFirst() throws SQLServerException {
/* 1347 */     if (0 == this.serverCursorId) {
/*      */       
/* 1349 */       fetchBufferBeforeFirst();
/* 1350 */       this.scrollWindow.clear();
/*      */     }
/*      */     else {
/*      */       
/* 1354 */       doServerFetch(1, 0, 0);
/*      */     } 
/*      */     
/* 1357 */     this.currentRow = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLServerException {
/* 1362 */     loggerExternal.entering(getClassNameLogging(), "afterLast");
/* 1363 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1365 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/* 1368 */     if (logger.isLoggable(Level.FINER)) {
/* 1369 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1371 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1375 */     verifyResultSetIsScrollable();
/*      */     
/* 1377 */     moverInit();
/* 1378 */     moveAfterLast();
/* 1379 */     loggerExternal.exiting(getClassNameLogging(), "afterLast");
/*      */   }
/*      */ 
/*      */   
/*      */   private void moveAfterLast() throws SQLServerException {
/* 1384 */     assert !isForwardOnly();
/*      */     
/* 1386 */     if (0 == this.serverCursorId) {
/* 1387 */       clientMoveAfterLast();
/*      */     } else {
/* 1389 */       doServerFetch(8, 0, 0);
/*      */     } 
/* 1391 */     this.currentRow = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLServerException {
/* 1409 */     loggerExternal.entering(getClassNameLogging(), "first");
/* 1410 */     if (logger.isLoggable(Level.FINER)) {
/* 1411 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1413 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1417 */     verifyResultSetIsScrollable();
/*      */     
/* 1419 */     moverInit();
/* 1420 */     moveFirst();
/* 1421 */     boolean bool = hasCurrentRow();
/* 1422 */     loggerExternal.exiting(getClassNameLogging(), "first", Boolean.valueOf(bool));
/* 1423 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void moveFirst() throws SQLServerException {
/* 1428 */     if (0 == this.serverCursorId) {
/*      */       
/* 1430 */       moveBeforeFirst();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1435 */       doServerFetch(1, 0, this.fetchSize);
/*      */     } 
/*      */ 
/*      */     
/* 1439 */     if (!this.scrollWindow.next(this)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1446 */       this.currentRow = -1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1451 */     this.currentRow = isDynamic() ? -2 : 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLServerException {
/* 1469 */     loggerExternal.entering(getClassNameLogging(), "last");
/* 1470 */     if (logger.isLoggable(Level.FINER)) {
/* 1471 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1473 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1477 */     verifyResultSetIsScrollable();
/*      */     
/* 1479 */     moverInit();
/* 1480 */     moveLast();
/* 1481 */     boolean bool = hasCurrentRow();
/* 1482 */     loggerExternal.exiting(getClassNameLogging(), "last", Boolean.valueOf(bool));
/* 1483 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void moveLast() throws SQLServerException {
/* 1488 */     if (0 == this.serverCursorId) {
/*      */       
/* 1490 */       this.currentRow = clientMoveAbsolute(-1);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1495 */     doServerFetch(8, 0, this.fetchSize);
/*      */ 
/*      */     
/* 1498 */     if (!this.scrollWindow.next(this)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1505 */       this.currentRow = -1;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1510 */     while (this.scrollWindow.next(this));
/*      */     
/* 1512 */     this.scrollWindow.previous(this);
/*      */ 
/*      */     
/* 1515 */     this.currentRow = isDynamic() ? -2 : this.rowCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLServerException {
/* 1526 */     loggerExternal.entering(getClassNameLogging(), "getRow");
/* 1527 */     if (logger.isLoggable(Level.FINER)) {
/* 1528 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1530 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1534 */     if (isDynamic() && !isForwardOnly()) {
/* 1535 */       throwUnsupportedCursorOp();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1542 */     if (!hasCurrentRow() || this.isOnInsertRow) {
/* 1543 */       return 0;
/*      */     }
/*      */     
/* 1546 */     assert this.currentRow >= 1;
/*      */ 
/*      */     
/* 1549 */     loggerExternal.exiting(getClassNameLogging(), "getRow", Integer.valueOf(this.currentRow));
/* 1550 */     return this.currentRow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLServerException {
/* 1569 */     loggerExternal.entering(getClassNameLogging(), "absolute");
/* 1570 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1572 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1574 */     if (logger.isLoggable(Level.FINER)) {
/* 1575 */       logger.finer(toString() + " row:" + paramInt + logCursorState());
/*      */     }
/* 1577 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1581 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 1585 */     if (isDynamic()) {
/* 1586 */       throwUnsupportedCursorOp();
/*      */     }
/* 1588 */     moverInit();
/* 1589 */     moveAbsolute(paramInt);
/* 1590 */     boolean bool = hasCurrentRow();
/* 1591 */     loggerExternal.exiting(getClassNameLogging(), "absolute", Boolean.valueOf(bool));
/* 1592 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void moveAbsolute(int paramInt) throws SQLServerException {
/* 1599 */     assert -2 != this.currentRow;
/* 1600 */     assert !isDynamic();
/*      */     
/* 1602 */     switch (paramInt) {
/*      */ 
/*      */       
/*      */       case 0:
/* 1606 */         moveBeforeFirst();
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/* 1611 */         moveFirst();
/*      */         return;
/*      */ 
/*      */       
/*      */       case -1:
/* 1616 */         moveLast();
/*      */         return;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1625 */     if (hasCurrentRow()) {
/*      */       
/* 1627 */       assert this.currentRow >= 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1633 */       if (paramInt > 0) {
/*      */         
/* 1635 */         moveRelative(paramInt - this.currentRow);
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/* 1643 */       if (-3 != this.rowCount) {
/*      */         
/* 1645 */         assert paramInt < 0;
/* 1646 */         moveRelative(this.rowCount + paramInt + 1 - this.currentRow);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1658 */     if (0 == this.serverCursorId) {
/*      */       
/* 1660 */       this.currentRow = clientMoveAbsolute(paramInt);
/*      */       
/*      */       return;
/*      */     } 
/* 1664 */     doServerFetch(16, paramInt, this.fetchSize);
/*      */ 
/*      */ 
/*      */     
/* 1668 */     if (!this.scrollWindow.next(this)) {
/*      */       
/* 1670 */       this.currentRow = (paramInt < 0) ? 0 : -1;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1676 */     if (paramInt > 0) {
/*      */ 
/*      */       
/* 1679 */       this.currentRow = paramInt;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1684 */       assert paramInt < 0;
/* 1685 */       assert this.rowCount + paramInt + 1 >= 1;
/* 1686 */       this.currentRow = this.rowCount + paramInt + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean fetchBufferHasRows() throws SQLServerException {
/* 1694 */     assert 0 == this.serverCursorId;
/* 1695 */     assert null != this.tdsReader;
/*      */     
/* 1697 */     assert this.lastColumnIndex >= 0;
/*      */ 
/*      */     
/* 1700 */     if (this.lastColumnIndex >= 1) {
/* 1701 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 1705 */     int i = this.tdsReader.peekTokenType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1712 */     return (209 == i || 210 == i || 171 == i || 170 == i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void discardCurrentRow() throws SQLServerException {
/* 1720 */     assert this.lastColumnIndex >= 0;
/*      */     
/* 1722 */     this.updatedCurrentRow = false;
/* 1723 */     this.deletedCurrentRow = false;
/* 1724 */     if (this.lastColumnIndex >= 1) {
/*      */       
/* 1726 */       initializeNullCompressedColumns();
/*      */       
/* 1728 */       for (byte b = 1; b < this.lastColumnIndex; b++) {
/* 1729 */         getColumn(b).clear();
/*      */       }
/*      */ 
/*      */       
/* 1733 */       skipColumns(this.columns.length + 1 - this.lastColumnIndex, true);
/*      */     } 
/*      */ 
/*      */     
/* 1737 */     this.resultSetCurrentRowType = RowType.UNKNOWN;
/* 1738 */     this.areNullCompressedColumnsInitialized = false;
/*      */   }
/*      */ 
/*      */   
/*      */   final int fetchBufferGetRow() {
/* 1743 */     if (isForwardOnly()) {
/* 1744 */       return this.numFetchedRows;
/*      */     }
/* 1746 */     return this.scrollWindow.getRow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void fetchBufferBeforeFirst() throws SQLServerException {
/* 1753 */     assert 0 == this.serverCursorId;
/* 1754 */     assert null != this.tdsReader;
/*      */     
/* 1756 */     discardCurrentRow();
/*      */     
/* 1758 */     this.fetchBuffer.reset();
/* 1759 */     this.lastColumnIndex = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final TDSReaderMark fetchBufferMark() {
/* 1765 */     assert null != this.tdsReader;
/*      */     
/* 1767 */     return this.tdsReader.mark();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void fetchBufferReset(TDSReaderMark paramTDSReaderMark) throws SQLServerException {
/* 1773 */     assert null != this.tdsReader;
/*      */     
/* 1775 */     assert null != paramTDSReaderMark;
/*      */     
/* 1777 */     discardCurrentRow();
/*      */     
/* 1779 */     this.tdsReader.reset(paramTDSReaderMark);
/*      */     
/* 1781 */     this.lastColumnIndex = 1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean fetchBufferNext() throws SQLServerException {
/* 1787 */     if (null == this.tdsReader) {
/* 1788 */       return false;
/*      */     }
/*      */     
/* 1791 */     discardCurrentRow();
/*      */ 
/*      */ 
/*      */     
/* 1795 */     RowType rowType = RowType.UNKNOWN;
/*      */     
/*      */     try {
/* 1798 */       rowType = this.fetchBuffer.nextRow();
/* 1799 */       if (rowType.equals(RowType.UNKNOWN)) {
/* 1800 */         return false;
/*      */       }
/* 1802 */     } catch (SQLServerException sQLServerException) {
/*      */       
/* 1804 */       this.currentRow = -1;
/* 1805 */       this.rowErrorException = sQLServerException;
/* 1806 */       throw sQLServerException;
/*      */     }
/*      */     finally {
/*      */       
/* 1810 */       this.lastColumnIndex = 0;
/* 1811 */       this.resultSetCurrentRowType = rowType;
/*      */     } 
/*      */ 
/*      */     
/* 1815 */     this.numFetchedRows++;
/* 1816 */     this.lastColumnIndex = 1;
/* 1817 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void clientMoveAfterLast() throws SQLServerException {
/* 1822 */     assert -2 != this.currentRow;
/*      */     
/* 1824 */     byte b = 0;
/* 1825 */     while (fetchBufferNext()) {
/* 1826 */       b++;
/*      */     }
/* 1828 */     if (-3 == this.rowCount) {
/*      */       
/* 1830 */       assert -1 != this.currentRow;
/* 1831 */       this.rowCount = ((0 == this.currentRow) ? 0 : this.currentRow) + b;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int clientMoveAbsolute(int paramInt) throws SQLServerException {
/* 1837 */     assert 0 == this.serverCursorId;
/*      */     
/* 1839 */     this.scrollWindow.clear();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1846 */     if (paramInt < 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1852 */       if (-3 == this.rowCount) {
/*      */         
/* 1854 */         clientMoveAfterLast();
/* 1855 */         this.currentRow = -1;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1860 */       assert this.rowCount >= 0;
/*      */ 
/*      */ 
/*      */       
/* 1864 */       if (this.rowCount + paramInt < 0) {
/*      */         
/* 1866 */         moveBeforeFirst();
/* 1867 */         return 0;
/*      */       } 
/*      */       
/* 1870 */       paramInt = this.rowCount + paramInt + 1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1877 */     assert paramInt > 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1883 */     if (-1 == this.currentRow || paramInt <= this.currentRow) {
/* 1884 */       moveBeforeFirst();
/*      */     }
/*      */ 
/*      */     
/* 1888 */     assert 0 == this.currentRow || this.currentRow < paramInt;
/* 1889 */     while (this.currentRow != paramInt) {
/*      */       
/* 1891 */       if (!fetchBufferNext()) {
/*      */         
/* 1893 */         if (-3 == this.rowCount)
/* 1894 */           this.rowCount = this.currentRow; 
/* 1895 */         return -1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1901 */       if (0 == this.currentRow) {
/* 1902 */         this.currentRow = 1; continue;
/*      */       } 
/* 1904 */       updateCurrentRow(1);
/*      */     } 
/*      */     
/* 1907 */     return paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLServerException {
/* 1925 */     loggerExternal.entering(getClassNameLogging(), "previous");
/* 1926 */     if (logger.isLoggable(Level.FINER)) {
/* 1927 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 1929 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1933 */     verifyResultSetIsScrollable();
/*      */     
/* 1935 */     moverInit();
/*      */     
/* 1937 */     if (0 == this.currentRow) {
/* 1938 */       return false;
/*      */     }
/* 1940 */     if (-1 == this.currentRow) {
/* 1941 */       moveLast();
/*      */     } else {
/* 1943 */       moveBackward(-1);
/*      */     } 
/* 1945 */     boolean bool = hasCurrentRow();
/* 1946 */     loggerExternal.exiting(getClassNameLogging(), "previous", Boolean.valueOf(bool));
/* 1947 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void cancelInsert() {
/* 1952 */     if (this.isOnInsertRow) {
/*      */       
/* 1954 */       this.isOnInsertRow = false;
/* 1955 */       clearColumnsValues();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void clearColumnsValues() {
/* 1962 */     int i = this.columns.length;
/* 1963 */     for (byte b = 0; b < i; b++) {
/* 1964 */       this.columns[b].cancelUpdates();
/*      */     }
/*      */   }
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLServerException {
/* 1969 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 1970 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", null);
/* 1971 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLServerException {
/* 1976 */     loggerExternal.entering(getClassNameLogging(), "setFetchDirection", Integer.valueOf(paramInt));
/* 1977 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1981 */     verifyResultSetIsScrollable();
/*      */     
/* 1983 */     if ((1000 != paramInt && 1001 != paramInt && 1002 != paramInt) || (1000 != paramInt && (2003 == this.stmt.resultSetType || 2004 == this.stmt.resultSetType))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1991 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
/* 1992 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 1993 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/*      */     
/* 1996 */     this.fetchDirection = paramInt;
/* 1997 */     loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLServerException {
/* 2002 */     loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
/* 2003 */     checkClosed();
/* 2004 */     loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", Integer.valueOf(this.fetchDirection));
/* 2005 */     return this.fetchDirection;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLServerException {
/* 2010 */     loggerExternal.entering(getClassNameLogging(), "setFetchSize", Integer.valueOf(paramInt));
/* 2011 */     checkClosed();
/* 2012 */     if (paramInt < 0) {
/* 2013 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_invalidFetchSize"), (String)null, false);
/*      */     }
/* 2015 */     this.fetchSize = (0 == paramInt) ? this.stmt.defaultFetchSize : paramInt;
/* 2016 */     loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
/*      */   }
/*      */   
/*      */   public int getFetchSize() throws SQLServerException {
/* 2020 */     loggerExternal.entering(getClassNameLogging(), "getFetchSize");
/* 2021 */     checkClosed();
/* 2022 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", Integer.valueOf(this.fetchSize));
/* 2023 */     return this.fetchSize;
/*      */   }
/*      */   
/*      */   public int getType() throws SQLServerException {
/* 2027 */     loggerExternal.entering(getClassNameLogging(), "getType");
/* 2028 */     checkClosed();
/*      */     
/* 2030 */     int i = this.stmt.getResultSetType();
/* 2031 */     loggerExternal.exiting(getClassNameLogging(), "getType", Integer.valueOf(i));
/* 2032 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLServerException {
/* 2037 */     loggerExternal.entering(getClassNameLogging(), "getConcurrency");
/* 2038 */     checkClosed();
/* 2039 */     int i = this.stmt.getResultSetConcurrency();
/* 2040 */     loggerExternal.exiting(getClassNameLogging(), "getConcurrency", Integer.valueOf(i));
/* 2041 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Column getterGetColumn(int paramInt) throws SQLServerException {
/* 2064 */     verifyResultSetHasCurrentRow();
/* 2065 */     verifyCurrentRowIsNotDeleted("R_cantGetColumnValueFromDeletedRow");
/* 2066 */     verifyValidColumnIndex(paramInt);
/*      */ 
/*      */     
/* 2069 */     if (this.updatedCurrentRow) {
/*      */       
/* 2071 */       doRefreshRow();
/* 2072 */       verifyResultSetHasCurrentRow();
/*      */     } 
/*      */ 
/*      */     
/* 2076 */     if (logger.isLoggable(Level.FINER)) {
/* 2077 */       logger.finer(toString() + " Getting Column:" + paramInt);
/*      */     }
/* 2079 */     return loadColumn(paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType) throws SQLServerException {
/* 2084 */     return getValue(paramInt, paramJDBCType, null, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType, Calendar paramCalendar) throws SQLServerException {
/* 2089 */     return getValue(paramInt, paramJDBCType, null, paramCalendar);
/*      */   }
/*      */ 
/*      */   
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs) throws SQLServerException {
/* 2094 */     return getValue(paramInt, paramJDBCType, paramInputStreamGetterArgs, null);
/*      */   }
/*      */ 
/*      */   
/*      */   private final Object getValue(int paramInt, JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar) throws SQLServerException {
/* 2099 */     Object object = getterGetColumn(paramInt).getValue(paramJDBCType, paramInputStreamGetterArgs, paramCalendar, this.tdsReader);
/* 2100 */     this.lastValueWasNull = (null == object);
/* 2101 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   private Object getStream(int paramInt, StreamType paramStreamType) throws SQLServerException {
/* 2106 */     Object object = getValue(paramInt, paramStreamType.getJDBCType(), new InputStreamGetterArgs(paramStreamType, this.stmt.getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2115 */     this.activeStream = (Closeable)object;
/* 2116 */     return object;
/*      */   }
/*      */   
/*      */   private SQLXML getSQLXMLInternal(int paramInt) throws SQLServerException {
/* 2120 */     SQLServerSQLXML sQLServerSQLXML = (SQLServerSQLXML)getValue(paramInt, JDBCType.SQLXML, new InputStreamGetterArgs(StreamType.SQLXML, this.stmt.getExecProps().isResponseBufferingAdaptive(), isForwardOnly(), toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2129 */     if (null != sQLServerSQLXML)
/* 2130 */       this.activeStream = sQLServerSQLXML.getStream(); 
/* 2131 */     return sQLServerSQLXML;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLServerException {
/* 2137 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", Integer.valueOf(paramInt));
/* 2138 */     checkClosed();
/* 2139 */     InputStream inputStream = (InputStream)getStream(paramInt, StreamType.ASCII);
/* 2140 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
/* 2141 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLServerException {
/* 2146 */     loggerExternal.entering(getClassNameLogging(), "getAsciiStream", paramString);
/* 2147 */     checkClosed();
/* 2148 */     InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.ASCII);
/* 2149 */     loggerExternal.exiting(getClassNameLogging(), "getAsciiStream", inputStream);
/* 2150 */     return inputStream;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLServerException {
/* 2155 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2156 */       loggerExternal.entering(getClassNameLogging(), "getBigDecimal", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }); 
/* 2157 */     checkClosed();
/* 2158 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt1, JDBCType.DECIMAL);
/* 2159 */     if (null != bigDecimal)
/* 2160 */       bigDecimal = bigDecimal.setScale(paramInt2, 1); 
/* 2161 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/* 2162 */     return bigDecimal;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLServerException {
/* 2167 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2168 */       loggerExternal.entering(getClassNameLogging(), "columnName", new Object[] { paramString, Integer.valueOf(paramInt) }); 
/* 2169 */     checkClosed();
/* 2170 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 2171 */     if (null != bigDecimal)
/* 2172 */       bigDecimal = bigDecimal.setScale(paramInt, 1); 
/* 2173 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/* 2174 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLServerException {
/* 2179 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", Integer.valueOf(paramInt));
/* 2180 */     checkClosed();
/* 2181 */     InputStream inputStream = (InputStream)getStream(paramInt, StreamType.BINARY);
/* 2182 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
/* 2183 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLServerException {
/* 2188 */     loggerExternal.entering(getClassNameLogging(), "getBinaryStream", paramString);
/* 2189 */     checkClosed();
/* 2190 */     InputStream inputStream = (InputStream)getStream(findColumn(paramString), StreamType.BINARY);
/* 2191 */     loggerExternal.exiting(getClassNameLogging(), "getBinaryStream", inputStream);
/* 2192 */     return inputStream;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLServerException {
/* 2197 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", Integer.valueOf(paramInt));
/* 2198 */     checkClosed();
/* 2199 */     Boolean bool = (Boolean)getValue(paramInt, JDBCType.BIT);
/* 2200 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
/* 2201 */     return (null != bool) ? bool.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLServerException {
/* 2206 */     loggerExternal.entering(getClassNameLogging(), "getBoolean", paramString);
/* 2207 */     checkClosed();
/* 2208 */     Boolean bool = (Boolean)getValue(findColumn(paramString), JDBCType.BIT);
/* 2209 */     loggerExternal.exiting(getClassNameLogging(), "getBoolean", bool);
/* 2210 */     return (null != bool) ? bool.booleanValue() : false;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLServerException {
/* 2215 */     loggerExternal.entering(getClassNameLogging(), "getByte", Integer.valueOf(paramInt));
/* 2216 */     checkClosed();
/* 2217 */     Short short_ = (Short)getValue(paramInt, JDBCType.TINYINT);
/* 2218 */     loggerExternal.exiting(getClassNameLogging(), "getByte", short_);
/* 2219 */     return (null != short_) ? short_.byteValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLServerException {
/* 2224 */     loggerExternal.entering(getClassNameLogging(), "getByte", paramString);
/* 2225 */     checkClosed();
/* 2226 */     Short short_ = (Short)getValue(findColumn(paramString), JDBCType.TINYINT);
/* 2227 */     loggerExternal.exiting(getClassNameLogging(), "getByte", short_);
/* 2228 */     return (null != short_) ? short_.byteValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLServerException {
/* 2233 */     loggerExternal.entering(getClassNameLogging(), "getBytes", Integer.valueOf(paramInt));
/* 2234 */     checkClosed();
/* 2235 */     byte[] arrayOfByte = (byte[])getValue(paramInt, JDBCType.BINARY);
/* 2236 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/* 2237 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLServerException {
/* 2242 */     loggerExternal.entering(getClassNameLogging(), "getBytes", paramString);
/* 2243 */     checkClosed();
/* 2244 */     byte[] arrayOfByte = (byte[])getValue(findColumn(paramString), JDBCType.BINARY);
/* 2245 */     loggerExternal.exiting(getClassNameLogging(), "getBytes", arrayOfByte);
/* 2246 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLServerException {
/* 2251 */     loggerExternal.entering(getClassNameLogging(), "getDate", Integer.valueOf(paramInt));
/* 2252 */     checkClosed();
/* 2253 */     Date date = (Date)getValue(paramInt, JDBCType.DATE);
/* 2254 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/* 2255 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLServerException {
/* 2260 */     loggerExternal.entering(getClassNameLogging(), "getDate", paramString);
/* 2261 */     checkClosed();
/* 2262 */     Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE);
/* 2263 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/* 2264 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLServerException {
/* 2269 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2270 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/* 2271 */     checkClosed();
/* 2272 */     Date date = (Date)getValue(paramInt, JDBCType.DATE, paramCalendar);
/* 2273 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/* 2274 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLServerException {
/* 2279 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2280 */       loggerExternal.entering(getClassNameLogging(), "getDate", new Object[] { paramString, paramCalendar }); 
/* 2281 */     checkClosed();
/* 2282 */     Date date = (Date)getValue(findColumn(paramString), JDBCType.DATE, paramCalendar);
/* 2283 */     loggerExternal.exiting(getClassNameLogging(), "getDate", date);
/* 2284 */     return date;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLServerException {
/* 2289 */     loggerExternal.entering(getClassNameLogging(), "getDouble", Integer.valueOf(paramInt));
/* 2290 */     checkClosed();
/* 2291 */     Double double_ = (Double)getValue(paramInt, JDBCType.DOUBLE);
/* 2292 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
/* 2293 */     return (null != double_) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLServerException {
/* 2298 */     loggerExternal.entering(getClassNameLogging(), "getDouble", paramString);
/* 2299 */     checkClosed();
/* 2300 */     Double double_ = (Double)getValue(findColumn(paramString), JDBCType.DOUBLE);
/* 2301 */     loggerExternal.exiting(getClassNameLogging(), "getDouble", double_);
/* 2302 */     return (null != double_) ? double_.doubleValue() : 0.0D;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLServerException {
/* 2307 */     loggerExternal.entering(getClassNameLogging(), "getFloat", Integer.valueOf(paramInt));
/* 2308 */     checkClosed();
/* 2309 */     Float float_ = (Float)getValue(paramInt, JDBCType.REAL);
/* 2310 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
/* 2311 */     return (null != float_) ? float_.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLServerException {
/* 2316 */     loggerExternal.entering(getClassNameLogging(), "getFloat", paramString);
/* 2317 */     checkClosed();
/* 2318 */     Float float_ = (Float)getValue(findColumn(paramString), JDBCType.REAL);
/* 2319 */     loggerExternal.exiting(getClassNameLogging(), "getFloat", float_);
/* 2320 */     return (null != float_) ? float_.floatValue() : 0.0F;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLServerException {
/* 2325 */     loggerExternal.entering(getClassNameLogging(), "getInt", Integer.valueOf(paramInt));
/* 2326 */     checkClosed();
/* 2327 */     Integer integer = (Integer)getValue(paramInt, JDBCType.INTEGER);
/* 2328 */     loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
/* 2329 */     return (null != integer) ? integer.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLServerException {
/* 2334 */     loggerExternal.entering(getClassNameLogging(), "getInt", paramString);
/* 2335 */     checkClosed();
/* 2336 */     Integer integer = (Integer)getValue(findColumn(paramString), JDBCType.INTEGER);
/* 2337 */     loggerExternal.exiting(getClassNameLogging(), "getInt", integer);
/* 2338 */     return (null != integer) ? integer.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLServerException {
/* 2343 */     loggerExternal.entering(getClassNameLogging(), "getLong", Integer.valueOf(paramInt));
/* 2344 */     checkClosed();
/* 2345 */     Long long_ = (Long)getValue(paramInt, JDBCType.BIGINT);
/* 2346 */     loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
/* 2347 */     return (null != long_) ? long_.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLServerException {
/* 2352 */     loggerExternal.entering(getClassNameLogging(), "getLong", paramString);
/* 2353 */     checkClosed();
/* 2354 */     Long long_ = (Long)getValue(findColumn(paramString), JDBCType.BIGINT);
/* 2355 */     loggerExternal.exiting(getClassNameLogging(), "getLong", long_);
/* 2356 */     return (null != long_) ? long_.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLServerException {
/* 2361 */     loggerExternal.entering(getClassNameLogging(), "getMetaData");
/* 2362 */     checkClosed();
/* 2363 */     if (this.metaData == null)
/* 2364 */       this.metaData = new SQLServerResultSetMetaData(this.stmt.connection, this); 
/* 2365 */     loggerExternal.exiting(getClassNameLogging(), "getMetaData", this.metaData);
/* 2366 */     return this.metaData;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLServerException {
/* 2371 */     loggerExternal.entering(getClassNameLogging(), "getObject", Integer.valueOf(paramInt));
/* 2372 */     checkClosed();
/* 2373 */     Object object = getValue(paramInt, getterGetColumn(paramInt).getTypeInfo().getSSType().getJDBCType());
/* 2374 */     loggerExternal.exiting(getClassNameLogging(), "getObject", object);
/* 2375 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(int paramInt, Class<T> paramClass) throws SQLException {
/* 2380 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/* 2383 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLServerException {
/* 2388 */     loggerExternal.entering(getClassNameLogging(), "getObject", paramString);
/* 2389 */     checkClosed();
/* 2390 */     Object object = getObject(findColumn(paramString));
/* 2391 */     loggerExternal.exiting(getClassNameLogging(), "getObject", object);
/* 2392 */     return object;
/*      */   }
/*      */ 
/*      */   
/*      */   public <T> T getObject(String paramString, Class<T> paramClass) throws SQLException {
/* 2397 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/* 2400 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLServerException {
/* 2405 */     loggerExternal.entering(getClassNameLogging(), "getShort", Integer.valueOf(paramInt));
/* 2406 */     checkClosed();
/* 2407 */     Short short_ = (Short)getValue(paramInt, JDBCType.SMALLINT);
/* 2408 */     loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
/* 2409 */     return (null != short_) ? short_.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLServerException {
/* 2414 */     loggerExternal.entering(getClassNameLogging(), "getShort", paramString);
/* 2415 */     checkClosed();
/* 2416 */     Short short_ = (Short)getValue(findColumn(paramString), JDBCType.SMALLINT);
/* 2417 */     loggerExternal.exiting(getClassNameLogging(), "getShort", short_);
/* 2418 */     return (null != short_) ? short_.shortValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLServerException {
/* 2423 */     loggerExternal.entering(getClassNameLogging(), "getString", Integer.valueOf(paramInt));
/* 2424 */     checkClosed();
/*      */     
/* 2426 */     String str = null;
/* 2427 */     Object object = getValue(paramInt, JDBCType.CHAR);
/* 2428 */     if (null != object) {
/* 2429 */       str = object.toString();
/*      */     }
/* 2431 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/* 2432 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLServerException {
/* 2437 */     loggerExternal.entering(getClassNameLogging(), "getString", paramString);
/* 2438 */     checkClosed();
/*      */     
/* 2440 */     String str = null;
/* 2441 */     Object object = getValue(findColumn(paramString), JDBCType.CHAR);
/* 2442 */     if (null != object) {
/* 2443 */       str = object.toString();
/*      */     }
/* 2445 */     loggerExternal.exiting(getClassNameLogging(), "getString", str);
/* 2446 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNString(int paramInt) throws SQLException {
/* 2451 */     loggerExternal.entering(getClassNameLogging(), "getNString", Integer.valueOf(paramInt));
/* 2452 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2453 */     checkClosed();
/* 2454 */     String str = (String)getValue(paramInt, JDBCType.NCHAR);
/* 2455 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/* 2456 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNString(String paramString) throws SQLException {
/* 2461 */     loggerExternal.entering(getClassNameLogging(), "getNString", paramString);
/* 2462 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2463 */     checkClosed();
/* 2464 */     String str = (String)getValue(findColumn(paramString), JDBCType.NCHAR);
/* 2465 */     loggerExternal.exiting(getClassNameLogging(), "getNString", str);
/* 2466 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUniqueIdentifier(int paramInt) throws SQLException {
/* 2471 */     loggerExternal.entering(getClassNameLogging(), "getUniqueIdentifier", Integer.valueOf(paramInt));
/* 2472 */     checkClosed();
/* 2473 */     String str = (String)getValue(paramInt, JDBCType.GUID);
/* 2474 */     loggerExternal.exiting(getClassNameLogging(), "getUniqueIdentifier", str);
/* 2475 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getUniqueIdentifier(String paramString) throws SQLException {
/* 2480 */     loggerExternal.entering(getClassNameLogging(), "getUniqueIdentifier", paramString);
/* 2481 */     checkClosed();
/* 2482 */     String str = (String)getValue(findColumn(paramString), JDBCType.GUID);
/* 2483 */     loggerExternal.exiting(getClassNameLogging(), "getUniqueIdentifier", str);
/* 2484 */     return str;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLServerException {
/* 2489 */     loggerExternal.entering(getClassNameLogging(), "getTime", Integer.valueOf(paramInt));
/* 2490 */     checkClosed();
/* 2491 */     Time time = (Time)getValue(paramInt, JDBCType.TIME);
/* 2492 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/* 2493 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLServerException {
/* 2498 */     loggerExternal.entering(getClassNameLogging(), "getTime", paramString);
/* 2499 */     checkClosed();
/* 2500 */     Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME);
/* 2501 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/* 2502 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
/* 2507 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2508 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/* 2509 */     checkClosed();
/* 2510 */     Time time = (Time)getValue(paramInt, JDBCType.TIME, paramCalendar);
/* 2511 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/* 2512 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLServerException {
/* 2517 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2518 */       loggerExternal.entering(getClassNameLogging(), "getTime", new Object[] { paramString, paramCalendar }); 
/* 2519 */     checkClosed();
/* 2520 */     Time time = (Time)getValue(findColumn(paramString), JDBCType.TIME, paramCalendar);
/* 2521 */     loggerExternal.exiting(getClassNameLogging(), "getTime", time);
/* 2522 */     return time;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLServerException {
/* 2527 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", Integer.valueOf(paramInt));
/* 2528 */     checkClosed();
/* 2529 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
/* 2530 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/* 2531 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLServerException {
/* 2536 */     loggerExternal.entering(getClassNameLogging(), "getTimestamp", paramString);
/* 2537 */     checkClosed();
/* 2538 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
/* 2539 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/* 2540 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLServerException {
/* 2545 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2546 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/* 2547 */     checkClosed();
/* 2548 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
/* 2549 */     loggerExternal.exiting(getClassNameLogging(), "getTimeStamp", timestamp);
/* 2550 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLServerException {
/* 2555 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2556 */       loggerExternal.entering(getClassNameLogging(), "getTimestamp", new Object[] { paramString, paramCalendar }); 
/* 2557 */     checkClosed();
/* 2558 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
/* 2559 */     loggerExternal.exiting(getClassNameLogging(), "getTimestamp", timestamp);
/* 2560 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int paramInt) throws SQLServerException {
/* 2565 */     loggerExternal.entering(getClassNameLogging(), "getDateTime", Integer.valueOf(paramInt));
/* 2566 */     checkClosed();
/* 2567 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
/* 2568 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/* 2569 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String paramString) throws SQLServerException {
/* 2574 */     loggerExternal.entering(getClassNameLogging(), "getDateTime", paramString);
/* 2575 */     checkClosed();
/* 2576 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
/* 2577 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/* 2578 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
/* 2583 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2584 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/* 2585 */     checkClosed();
/* 2586 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
/* 2587 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/* 2588 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
/* 2593 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2594 */       loggerExternal.entering(getClassNameLogging(), "getDateTime", new Object[] { paramString, paramCalendar }); 
/* 2595 */     checkClosed();
/* 2596 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
/* 2597 */     loggerExternal.exiting(getClassNameLogging(), "getDateTime", timestamp);
/* 2598 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int paramInt) throws SQLServerException {
/* 2603 */     loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", Integer.valueOf(paramInt));
/* 2604 */     checkClosed();
/* 2605 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP);
/* 2606 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/* 2607 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String paramString) throws SQLServerException {
/* 2612 */     loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", paramString);
/* 2613 */     checkClosed();
/* 2614 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP);
/* 2615 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/* 2616 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(int paramInt, Calendar paramCalendar) throws SQLServerException {
/* 2621 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2622 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramCalendar }); 
/* 2623 */     checkClosed();
/* 2624 */     Timestamp timestamp = (Timestamp)getValue(paramInt, JDBCType.TIMESTAMP, paramCalendar);
/* 2625 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/* 2626 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public Timestamp getSmallDateTime(String paramString, Calendar paramCalendar) throws SQLServerException {
/* 2631 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2632 */       loggerExternal.entering(getClassNameLogging(), "getSmallDateTime", new Object[] { paramString, paramCalendar }); 
/* 2633 */     checkClosed();
/* 2634 */     Timestamp timestamp = (Timestamp)getValue(findColumn(paramString), JDBCType.TIMESTAMP, paramCalendar);
/* 2635 */     loggerExternal.exiting(getClassNameLogging(), "getSmallDateTime", timestamp);
/* 2636 */     return timestamp;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(int paramInt) throws SQLException {
/* 2641 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", Integer.valueOf(paramInt));
/* 2642 */     checkClosed();
/*      */ 
/*      */     
/* 2645 */     if (!this.stmt.connection.isKatmaiOrLater()) {
/* 2646 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2652 */     DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(paramInt, JDBCType.DATETIMEOFFSET);
/* 2653 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
/* 2654 */     return dateTimeOffset;
/*      */   }
/*      */ 
/*      */   
/*      */   public DateTimeOffset getDateTimeOffset(String paramString) throws SQLException {
/* 2659 */     loggerExternal.entering(getClassNameLogging(), "getDateTimeOffset", paramString);
/* 2660 */     checkClosed();
/*      */ 
/*      */     
/* 2663 */     if (!this.stmt.connection.isKatmaiOrLater()) {
/* 2664 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2670 */     DateTimeOffset dateTimeOffset = (DateTimeOffset)getValue(findColumn(paramString), JDBCType.DATETIMEOFFSET);
/* 2671 */     loggerExternal.exiting(getClassNameLogging(), "getDateTimeOffset", dateTimeOffset);
/* 2672 */     return dateTimeOffset;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLServerException {
/* 2677 */     loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", Integer.valueOf(paramInt));
/* 2678 */     NotImplemented();
/* 2679 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLServerException {
/* 2684 */     loggerExternal.entering(getClassNameLogging(), "getUnicodeStream", paramString);
/* 2685 */     NotImplemented();
/* 2686 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map<String, Class<?>> paramMap) throws SQLServerException {
/* 2691 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2692 */       loggerExternal.entering(getClassNameLogging(), "getObject", new Object[] { Integer.valueOf(paramInt), paramMap }); 
/* 2693 */     NotImplemented();
/* 2694 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLServerException {
/* 2699 */     loggerExternal.entering(getClassNameLogging(), "getRef");
/* 2700 */     NotImplemented();
/* 2701 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLServerException {
/* 2706 */     loggerExternal.entering(getClassNameLogging(), "getBlob", Integer.valueOf(paramInt));
/* 2707 */     checkClosed();
/* 2708 */     Blob blob = (Blob)getValue(paramInt, JDBCType.BLOB);
/* 2709 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
/* 2710 */     return blob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLServerException {
/* 2715 */     loggerExternal.entering(getClassNameLogging(), "getBlob", paramString);
/* 2716 */     checkClosed();
/* 2717 */     Blob blob = (Blob)getValue(findColumn(paramString), JDBCType.BLOB);
/* 2718 */     loggerExternal.exiting(getClassNameLogging(), "getBlob", blob);
/* 2719 */     return blob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLServerException {
/* 2724 */     loggerExternal.entering(getClassNameLogging(), "getClob", Integer.valueOf(paramInt));
/* 2725 */     checkClosed();
/* 2726 */     Clob clob = (Clob)getValue(paramInt, JDBCType.CLOB);
/* 2727 */     loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
/* 2728 */     return clob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLServerException {
/* 2733 */     loggerExternal.entering(getClassNameLogging(), "getClob", paramString);
/* 2734 */     checkClosed();
/* 2735 */     Clob clob = (Clob)getValue(findColumn(paramString), JDBCType.CLOB);
/* 2736 */     loggerExternal.exiting(getClassNameLogging(), "getClob", clob);
/* 2737 */     return clob;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(int paramInt) throws SQLException {
/* 2742 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2743 */     loggerExternal.entering(getClassNameLogging(), "getNClob", Integer.valueOf(paramInt));
/* 2744 */     checkClosed();
/* 2745 */     NClob nClob = (NClob)getValue(paramInt, JDBCType.NCLOB);
/* 2746 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
/* 2747 */     return nClob;
/*      */   }
/*      */ 
/*      */   
/*      */   public NClob getNClob(String paramString) throws SQLException {
/* 2752 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2753 */     loggerExternal.entering(getClassNameLogging(), "getNClob", paramString);
/* 2754 */     checkClosed();
/* 2755 */     NClob nClob = (NClob)getValue(findColumn(paramString), JDBCType.NCLOB);
/* 2756 */     loggerExternal.exiting(getClassNameLogging(), "getNClob", nClob);
/* 2757 */     return nClob;
/*      */   }
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLServerException {
/* 2762 */     NotImplemented();
/* 2763 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map<String, Class<?>> paramMap) throws SQLServerException {
/* 2768 */     NotImplemented();
/* 2769 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLServerException {
/* 2774 */     NotImplemented();
/* 2775 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLServerException {
/* 2780 */     NotImplemented();
/* 2781 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLServerException {
/* 2786 */     loggerExternal.entering(getClassNameLogging(), "getCursorName");
/* 2787 */     SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_positionedUpdatesNotSupported"), (String)null, false);
/* 2788 */     loggerExternal.exiting(getClassNameLogging(), "getCursorName", null);
/* 2789 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLServerException {
/* 2794 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", Integer.valueOf(paramInt));
/* 2795 */     checkClosed();
/* 2796 */     Reader reader = (Reader)getStream(paramInt, StreamType.CHARACTER);
/* 2797 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
/* 2798 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLServerException {
/* 2803 */     checkClosed();
/* 2804 */     loggerExternal.entering(getClassNameLogging(), "getCharacterStream", paramString);
/* 2805 */     Reader reader = (Reader)getStream(findColumn(paramString), StreamType.CHARACTER);
/* 2806 */     loggerExternal.exiting(getClassNameLogging(), "getCharacterStream", reader);
/* 2807 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(int paramInt) throws SQLException {
/* 2812 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2813 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", Integer.valueOf(paramInt));
/* 2814 */     checkClosed();
/* 2815 */     Reader reader = (Reader)getStream(paramInt, StreamType.NCHARACTER);
/* 2816 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
/* 2817 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public Reader getNCharacterStream(String paramString) throws SQLException {
/* 2822 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2823 */     loggerExternal.entering(getClassNameLogging(), "getNCharacterStream", paramString);
/* 2824 */     checkClosed();
/* 2825 */     Reader reader = (Reader)getStream(findColumn(paramString), StreamType.NCHARACTER);
/* 2826 */     loggerExternal.exiting(getClassNameLogging(), "getNCharacterStream", reader);
/* 2827 */     return reader;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLServerException {
/* 2832 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", Integer.valueOf(paramInt));
/* 2833 */     checkClosed();
/* 2834 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
/* 2835 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/* 2836 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLServerException {
/* 2841 */     loggerExternal.entering(getClassNameLogging(), "getBigDecimal", paramString);
/* 2842 */     checkClosed();
/* 2843 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 2844 */     loggerExternal.exiting(getClassNameLogging(), "getBigDecimal", bigDecimal);
/* 2845 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(int paramInt) throws SQLServerException {
/* 2850 */     loggerExternal.entering(getClassNameLogging(), "getMoney", Integer.valueOf(paramInt));
/* 2851 */     checkClosed();
/* 2852 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
/* 2853 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
/* 2854 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getMoney(String paramString) throws SQLServerException {
/* 2859 */     loggerExternal.entering(getClassNameLogging(), "getMoney", paramString);
/* 2860 */     checkClosed();
/* 2861 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 2862 */     loggerExternal.exiting(getClassNameLogging(), "getMoney", bigDecimal);
/* 2863 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(int paramInt) throws SQLServerException {
/* 2868 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", Integer.valueOf(paramInt));
/* 2869 */     checkClosed();
/* 2870 */     BigDecimal bigDecimal = (BigDecimal)getValue(paramInt, JDBCType.DECIMAL);
/* 2871 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
/* 2872 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public BigDecimal getSmallMoney(String paramString) throws SQLServerException {
/* 2877 */     loggerExternal.entering(getClassNameLogging(), "getSmallMoney", paramString);
/* 2878 */     checkClosed();
/* 2879 */     BigDecimal bigDecimal = (BigDecimal)getValue(findColumn(paramString), JDBCType.DECIMAL);
/* 2880 */     loggerExternal.exiting(getClassNameLogging(), "getSmallMoney", bigDecimal);
/* 2881 */     return bigDecimal;
/*      */   }
/*      */ 
/*      */   
/*      */   public RowId getRowId(int paramInt) throws SQLException {
/* 2886 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 2889 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public RowId getRowId(String paramString) throws SQLException {
/* 2894 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 2897 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(int paramInt) throws SQLException {
/* 2902 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2903 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", Integer.valueOf(paramInt));
/* 2904 */     SQLXML sQLXML = getSQLXMLInternal(paramInt);
/* 2905 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLXML);
/* 2906 */     return sQLXML;
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLXML getSQLXML(String paramString) throws SQLException {
/* 2911 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2912 */     loggerExternal.entering(getClassNameLogging(), "getSQLXML", paramString);
/* 2913 */     SQLXML sQLXML = getSQLXMLInternal(findColumn(paramString));
/* 2914 */     loggerExternal.exiting(getClassNameLogging(), "getSQLXML", sQLXML);
/* 2915 */     return sQLXML;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLServerException {
/* 2920 */     loggerExternal.entering(getClassNameLogging(), "rowUpdated");
/* 2921 */     checkClosed();
/*      */ 
/*      */     
/* 2924 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */     
/* 2928 */     loggerExternal.exiting(getClassNameLogging(), "rowUpdated", Boolean.valueOf(false));
/* 2929 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLServerException {
/* 2934 */     loggerExternal.entering(getClassNameLogging(), "rowInserted");
/* 2935 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 2939 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */     
/* 2943 */     loggerExternal.exiting(getClassNameLogging(), "rowInserted", Boolean.valueOf(false));
/* 2944 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLServerException {
/* 2949 */     loggerExternal.entering(getClassNameLogging(), "rowDeleted");
/* 2950 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 2954 */     verifyResultSetIsUpdatable();
/*      */     
/* 2956 */     if (this.isOnInsertRow || !hasCurrentRow()) {
/* 2957 */       return false;
/*      */     }
/* 2959 */     boolean bool = currentRowDeleted();
/* 2960 */     loggerExternal.exiting(getClassNameLogging(), "rowDeleted", Boolean.valueOf(bool));
/* 2961 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean currentRowDeleted() throws SQLServerException {
/* 2974 */     assert hasCurrentRow();
/*      */ 
/*      */     
/* 2977 */     assert null != this.tdsReader;
/*      */ 
/*      */     
/* 2980 */     return (this.deletedCurrentRow || (0 != this.serverCursorId && 2 == loadColumn(this.columns.length).getInt(this.tdsReader)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Column updaterGetColumn(int paramInt) throws SQLServerException {
/* 2997 */     verifyResultSetIsUpdatable();
/*      */     
/* 2999 */     verifyValidColumnIndex(paramInt);
/*      */ 
/*      */     
/* 3002 */     if (!this.columns[paramInt - 1].isUpdatable())
/*      */     {
/* 3004 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_cantUpdateColumn"), "07009", false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3014 */     if (!this.isOnInsertRow) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3020 */       if (!hasCurrentRow())
/*      */       {
/* 3022 */         SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_resultsetNoCurrentRow"), (String)null, true);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3032 */       verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     } 
/*      */     
/* 3035 */     return getColumn(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, boolean paramBoolean) throws SQLServerException {
/* 3045 */     updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, paramBoolean, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Calendar paramCalendar, boolean paramBoolean) throws SQLServerException {
/* 3067 */     updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, paramCalendar, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, paramBoolean, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateValue(int paramInt, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
/* 3090 */     updaterGetColumn(paramInt).updateValue(paramJDBCType, paramObject, paramJavaType, null, null, paramInteger2, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, paramInteger1, paramBoolean, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void updateStream(int paramInt, StreamType paramStreamType, Object paramObject, JavaType paramJavaType, long paramLong) throws SQLServerException {
/* 3111 */     updaterGetColumn(paramInt).updateValue(paramStreamType.getJDBCType(), paramObject, paramJavaType, new StreamSetterArgs(paramStreamType, paramLong), null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, false, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void updateSQLXMLInternal(int paramInt, SQLXML paramSQLXML) throws SQLServerException {
/* 3127 */     updaterGetColumn(paramInt).updateValue(JDBCType.SQLXML, paramSQLXML, JavaType.SQLXML, new StreamSetterArgs(StreamType.SQLXML, -1L), null, null, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, null, false, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLServerException {
/* 3143 */     loggerExternal.entering(getClassNameLogging(), "updateNull", Integer.valueOf(paramInt));
/*      */     
/* 3145 */     checkClosed();
/* 3146 */     updateValue(paramInt, updaterGetColumn(paramInt).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3153 */     loggerExternal.exiting(getClassNameLogging(), "updateNull");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLServerException {
/* 3158 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3159 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) }); 
/* 3160 */     checkClosed();
/* 3161 */     updateValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3168 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
/* 3173 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3174 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) }); 
/* 3175 */     checkClosed();
/* 3176 */     updateValue(paramInt, JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3183 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(int paramInt, byte paramByte) throws SQLServerException {
/* 3188 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3189 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte) });
/*      */     }
/* 3191 */     checkClosed();
/* 3192 */     updateValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3199 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(int paramInt, byte paramByte, boolean paramBoolean) throws SQLServerException {
/* 3204 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3205 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { Integer.valueOf(paramInt), Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3207 */     checkClosed();
/* 3208 */     updateValue(paramInt, JDBCType.TINYINT, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3215 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(int paramInt, short paramShort) throws SQLServerException {
/* 3220 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3221 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort) });
/*      */     }
/* 3223 */     checkClosed();
/* 3224 */     updateValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3231 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(int paramInt, short paramShort, boolean paramBoolean) throws SQLServerException {
/* 3236 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3237 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { Integer.valueOf(paramInt), Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3239 */     checkClosed();
/* 3240 */     updateValue(paramInt, JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3247 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(int paramInt1, int paramInt2) throws SQLServerException {
/* 3252 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3253 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*      */     }
/* 3255 */     checkClosed();
/* 3256 */     updateValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3263 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 3268 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3269 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3271 */     checkClosed();
/* 3272 */     updateValue(paramInt1, JDBCType.INTEGER, Integer.valueOf(paramInt2), JavaType.INTEGER, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3279 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(int paramInt, long paramLong) throws SQLServerException {
/* 3284 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3285 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong) });
/*      */     }
/* 3287 */     checkClosed();
/* 3288 */     updateValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3295 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(int paramInt, long paramLong, boolean paramBoolean) throws SQLServerException {
/* 3300 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3301 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { Integer.valueOf(paramInt), Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3303 */     checkClosed();
/* 3304 */     updateValue(paramInt, JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3311 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(int paramInt, float paramFloat) throws SQLServerException {
/* 3316 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3317 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat) });
/*      */     }
/* 3319 */     checkClosed();
/* 3320 */     updateValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3327 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(int paramInt, float paramFloat, boolean paramBoolean) throws SQLServerException {
/* 3332 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3333 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { Integer.valueOf(paramInt), Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3335 */     checkClosed();
/* 3336 */     updateValue(paramInt, JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3343 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(int paramInt, double paramDouble) throws SQLServerException {
/* 3348 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3349 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble) });
/*      */     }
/* 3351 */     checkClosed();
/* 3352 */     updateValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3359 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(int paramInt, double paramDouble, boolean paramBoolean) throws SQLServerException {
/* 3364 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3365 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { Integer.valueOf(paramInt), Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3367 */     checkClosed();
/* 3368 */     updateValue(paramInt, JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3375 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
/* 3380 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3381 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
/* 3382 */     checkClosed();
/* 3383 */     updateValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3390 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 3395 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3396 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 3397 */     checkClosed();
/* 3398 */     updateValue(paramInt, JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3405 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
/* 3410 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3411 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { paramString, paramBigDecimal }); 
/* 3412 */     checkClosed();
/* 3413 */     updateValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3420 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 3425 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3426 */       loggerExternal.entering(getClassNameLogging(), "updateMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 3427 */     checkClosed();
/* 3428 */     updateValue(findColumn(paramString), JDBCType.MONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3435 */     loggerExternal.exiting(getClassNameLogging(), "updateMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
/* 3440 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3441 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal }); 
/* 3442 */     checkClosed();
/* 3443 */     updateValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3450 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(int paramInt, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 3455 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3456 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 3457 */     checkClosed();
/* 3458 */     updateValue(paramInt, JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3465 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
/* 3470 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3471 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { paramString, paramBigDecimal }); 
/* 3472 */     checkClosed();
/* 3473 */     updateValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3480 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallMoney(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 3485 */     if (loggerExternal.isLoggable(Level.FINER))
/* 3486 */       loggerExternal.entering(getClassNameLogging(), "updateSmallMoney", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) }); 
/* 3487 */     checkClosed();
/* 3488 */     updateValue(findColumn(paramString), JDBCType.SMALLMONEY, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3495 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallMoney");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLServerException {
/* 3500 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3501 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal });
/*      */     }
/* 3503 */     checkClosed();
/* 3504 */     updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3511 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2) throws SQLServerException {
/* 3516 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3517 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, paramInteger2 });
/*      */     }
/* 3519 */     checkClosed();
/* 3520 */     updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3529 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
/* 3534 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3535 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { Integer.valueOf(paramInt), paramBigDecimal, paramInteger2, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3537 */     checkClosed();
/* 3538 */     updateValue(paramInt, JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3547 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(int paramInt, String paramString) throws SQLServerException {
/* 3552 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3553 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { Integer.valueOf(paramInt), paramString });
/*      */     }
/* 3555 */     checkClosed();
/* 3556 */     updateValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3563 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(int paramInt, String paramString, boolean paramBoolean) throws SQLServerException {
/* 3568 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3569 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3571 */     checkClosed();
/* 3572 */     updateValue(paramInt, JDBCType.VARCHAR, paramString, JavaType.STRING, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3579 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(int paramInt, String paramString) throws SQLException {
/* 3584 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3585 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { Integer.valueOf(paramInt), paramString });
/*      */     }
/* 3587 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3588 */     checkClosed();
/* 3589 */     updateValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3596 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(int paramInt, String paramString, boolean paramBoolean) throws SQLException {
/* 3601 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3602 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3604 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3605 */     checkClosed();
/* 3606 */     updateValue(paramInt, JDBCType.NVARCHAR, paramString, JavaType.STRING, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3613 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(String paramString1, String paramString2) throws SQLException {
/* 3618 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3619 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { paramString1, paramString2 });
/*      */     }
/* 3621 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3622 */     checkClosed();
/* 3623 */     updateValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3630 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNString(String paramString1, String paramString2, boolean paramBoolean) throws SQLException {
/* 3635 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3636 */       loggerExternal.entering(getClassNameLogging(), "updateNString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3638 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 3639 */     checkClosed();
/* 3640 */     updateValue(findColumn(paramString1), JDBCType.NVARCHAR, paramString2, JavaType.STRING, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3647 */     loggerExternal.exiting(getClassNameLogging(), "updateNString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLServerException {
/* 3652 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3653 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte });
/*      */     }
/* 3655 */     checkClosed();
/* 3656 */     updateValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3663 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
/* 3668 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3669 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { Integer.valueOf(paramInt), paramArrayOfbyte, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3671 */     checkClosed();
/* 3672 */     updateValue(paramInt, JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3679 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate) throws SQLServerException {
/* 3684 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3685 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(paramInt), paramDate });
/*      */     }
/* 3687 */     checkClosed();
/* 3688 */     updateValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3695 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate, boolean paramBoolean) throws SQLServerException {
/* 3700 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3701 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { Integer.valueOf(paramInt), paramDate, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3703 */     checkClosed();
/* 3704 */     updateValue(paramInt, JDBCType.DATE, paramDate, JavaType.DATE, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3711 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime) throws SQLServerException {
/* 3716 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3717 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime });
/*      */     }
/* 3719 */     checkClosed();
/* 3720 */     updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3727 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime, Integer paramInteger) throws SQLServerException {
/* 3732 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3733 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramInteger });
/*      */     }
/* 3735 */     checkClosed();
/* 3736 */     updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, null, paramInteger, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3745 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
/* 3750 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3751 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { Integer.valueOf(paramInt), paramTime, paramInteger, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3753 */     checkClosed();
/* 3754 */     updateValue(paramInt, JDBCType.TIME, paramTime, JavaType.TIME, null, paramInteger, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3763 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
/* 3768 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3769 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
/*      */     }
/* 3771 */     checkClosed();
/* 3772 */     updateValue(paramInt, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3779 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2) throws SQLServerException {
/* 3784 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3785 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2) });
/*      */     }
/* 3787 */     checkClosed();
/* 3788 */     updateValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt2), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3797 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt1, Timestamp paramTimestamp, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 3802 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3803 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { Integer.valueOf(paramInt1), paramTimestamp, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3805 */     checkClosed();
/* 3806 */     updateValue(paramInt1, JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt2), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3815 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
/* 3820 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3821 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
/*      */     }
/* 3823 */     checkClosed();
/* 3824 */     updateValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3831 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger) throws SQLServerException {
/* 3836 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3837 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger });
/*      */     }
/* 3839 */     checkClosed();
/* 3840 */     updateValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3849 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
/* 3854 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3855 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3857 */     checkClosed();
/* 3858 */     updateValue(paramInt, JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3867 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(int paramInt, Timestamp paramTimestamp) throws SQLServerException {
/* 3872 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3873 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp });
/*      */     }
/* 3875 */     checkClosed();
/* 3876 */     updateValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3883 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger) throws SQLServerException {
/* 3888 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3889 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger });
/*      */     }
/* 3891 */     checkClosed();
/* 3892 */     updateValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3901 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(int paramInt, Timestamp paramTimestamp, Integer paramInteger, boolean paramBoolean) throws SQLServerException {
/* 3906 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3907 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { Integer.valueOf(paramInt), paramTimestamp, paramInteger, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3909 */     checkClosed();
/* 3910 */     updateValue(paramInt, JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, paramInteger, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3919 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException {
/* 3924 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3925 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset });
/*      */     }
/* 3927 */     checkClosed();
/* 3928 */     updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3935 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset, Integer paramInteger) throws SQLException {
/* 3940 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3941 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset, paramInteger });
/*      */     }
/* 3943 */     checkClosed();
/* 3944 */     updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, paramInteger, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3953 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset, Integer paramInteger, boolean paramBoolean) throws SQLException {
/* 3958 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3959 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { Integer.valueOf(paramInt), paramDateTimeOffset, paramInteger, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3961 */     checkClosed();
/* 3962 */     updateValue(paramInt, JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, paramInteger, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3971 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(int paramInt, String paramString) throws SQLException {
/* 3976 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3977 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString });
/*      */     }
/* 3979 */     checkClosed();
/* 3980 */     updateValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, null, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3988 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(int paramInt, String paramString, boolean paramBoolean) throws SQLException {
/* 3993 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 3994 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { Integer.valueOf(paramInt), paramString, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 3996 */     checkClosed();
/* 3997 */     updateValue(paramInt, JDBCType.GUID, paramString, JavaType.STRING, null, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4005 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 4010 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4011 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4012 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*      */     }
/* 4014 */     checkClosed();
/* 4015 */     updateStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4022 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLServerException {
/* 4027 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4028 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
/*      */     }
/* 4030 */     checkClosed();
/* 4031 */     updateStream(paramInt1, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4038 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 4043 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4044 */     loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*      */     
/* 4046 */     checkClosed();
/* 4047 */     updateStream(paramInt, StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4054 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 4059 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4060 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4061 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream });
/*      */     }
/* 4063 */     checkClosed();
/* 4064 */     updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4071 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLServerException {
/* 4076 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4077 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
/*      */     }
/* 4079 */     checkClosed();
/* 4080 */     updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4087 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 4092 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4093 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4094 */       loggerExternal.entering(getClassNameLogging(), "updateAsciiStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 4096 */     checkClosed();
/* 4097 */     updateStream(findColumn(paramString), StreamType.ASCII, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4104 */     loggerExternal.exiting(getClassNameLogging(), "updateAsciiStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream) throws SQLException {
/* 4109 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4110 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4111 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*      */     }
/* 4113 */     checkClosed();
/* 4114 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4121 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 4126 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4127 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt1), paramInputStream, Integer.valueOf(paramInt2) });
/*      */     }
/* 4129 */     checkClosed();
/* 4130 */     updateStream(paramInt1, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4137 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 4142 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4143 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4144 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 4146 */     checkClosed();
/* 4147 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4154 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream) throws SQLException {
/* 4159 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4160 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4161 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream });
/*      */     }
/* 4163 */     checkClosed();
/* 4164 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4171 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 4176 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4177 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream, Integer.valueOf(paramInt) });
/*      */     }
/* 4179 */     checkClosed();
/* 4180 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4187 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 4192 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4193 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4194 */       loggerExternal.entering(getClassNameLogging(), "updateBinaryStream", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 4196 */     checkClosed();
/* 4197 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4204 */     loggerExternal.exiting(getClassNameLogging(), "updateBinaryStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 4209 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4210 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4211 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 4213 */     checkClosed();
/* 4214 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4221 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLServerException {
/* 4226 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4227 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt1), paramReader, Integer.valueOf(paramInt2) });
/*      */     }
/* 4229 */     checkClosed();
/* 4230 */     updateStream(paramInt1, StreamType.CHARACTER, paramReader, JavaType.READER, paramInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4237 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 4242 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4243 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4244 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4246 */     checkClosed();
/* 4247 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4254 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 4259 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4260 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4261 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader });
/*      */     }
/* 4263 */     checkClosed();
/* 4264 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4271 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLServerException {
/* 4276 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4277 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader, Integer.valueOf(paramInt) });
/*      */     }
/* 4279 */     checkClosed();
/* 4280 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4287 */     loggerExternal.exiting(getClassNameLogging(), "updateCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 4292 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4293 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4294 */       loggerExternal.entering(getClassNameLogging(), "updateCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4296 */     checkClosed();
/* 4297 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4304 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader) throws SQLException {
/* 4309 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4310 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4311 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 4313 */     checkClosed();
/* 4314 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4321 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 4326 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4327 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4328 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4330 */     checkClosed();
/* 4331 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4338 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(String paramString, Reader paramReader) throws SQLException {
/* 4343 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4344 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4345 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { paramString, paramReader });
/*      */     }
/* 4347 */     checkClosed();
/* 4348 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4355 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNCharacterStream(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 4360 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 4361 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4362 */       loggerExternal.entering(getClassNameLogging(), "updateNCharacterStream", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 4364 */     checkClosed();
/* 4365 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4372 */     loggerExternal.exiting(getClassNameLogging(), "updateNCharacterStream");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt, Object paramObject) throws SQLServerException {
/* 4377 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4378 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt), paramObject });
/*      */     }
/* 4380 */     checkClosed();
/* 4381 */     updateObject(paramInt, paramObject, (Integer)null, null, null, false);
/*      */     
/* 4383 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt, Object paramObject, SQLType paramSQLType) throws SQLServerException {
/* 4389 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 4391 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4392 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt), paramObject, paramSQLType });
/*      */     }
/* 4394 */     checkClosed();
/*      */     
/* 4396 */     updateObject(paramInt, paramObject, (Integer)null, JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);
/*      */     
/* 4398 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLServerException {
/* 4403 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4404 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt2) });
/*      */     }
/* 4406 */     checkClosed();
/* 4407 */     updateObject(paramInt1, paramObject, Integer.valueOf(paramInt2), null, null, false);
/*      */     
/* 4409 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLServerException {
/* 4414 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4415 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt3) });
/*      */     }
/* 4417 */     checkClosed();
/* 4418 */     updateObject(paramInt1, paramObject, Integer.valueOf(paramInt3), null, Integer.valueOf(paramInt2), false);
/*      */     
/* 4420 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3, boolean paramBoolean) throws SQLServerException {
/* 4425 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4426 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, Integer.valueOf(paramInt3), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4428 */     checkClosed();
/* 4429 */     updateObject(paramInt1, paramObject, Integer.valueOf(paramInt3), null, Integer.valueOf(paramInt2), paramBoolean);
/*      */     
/* 4431 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2) throws SQLServerException {
/* 4436 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 4438 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4439 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, paramSQLType, Integer.valueOf(paramInt2) });
/*      */     }
/* 4441 */     checkClosed();
/*      */     
/* 4443 */     updateObject(paramInt1, paramObject, Integer.valueOf(paramInt2), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);
/*      */     
/* 4445 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, SQLType paramSQLType, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 4450 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 4452 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4453 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { Integer.valueOf(paramInt1), paramObject, paramSQLType, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4455 */     checkClosed();
/*      */     
/* 4457 */     updateObject(paramInt1, paramObject, Integer.valueOf(paramInt2), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, paramBoolean);
/*      */     
/* 4459 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   private final void updateObject(int paramInt, Object paramObject, Integer paramInteger1, JDBCType paramJDBCType, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
/* 4464 */     Column column = updaterGetColumn(paramInt);
/* 4465 */     SSType sSType = column.getTypeInfo().getSSType();
/*      */     
/* 4467 */     if (null == paramObject) {
/*      */       
/* 4469 */       if (null == paramJDBCType || paramJDBCType.isUnsupported())
/*      */       {
/*      */         
/* 4472 */         paramJDBCType = sSType.getJDBCType();
/*      */       }
/*      */       
/* 4475 */       column.updateValue(paramJDBCType, paramObject, JavaType.OBJECT, null, null, paramInteger1, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, paramInteger2, paramBoolean, paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4490 */       JavaType javaType = JavaType.of(paramObject);
/* 4491 */       JDBCType jDBCType = javaType.getJDBCType(sSType, sSType.getJDBCType());
/*      */       
/* 4493 */       if (null == paramJDBCType) {
/*      */ 
/*      */         
/* 4496 */         paramJDBCType = jDBCType;
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 4501 */       else if (!jDBCType.convertsTo(paramJDBCType)) {
/* 4502 */         DataTypes.throwConversionError(jDBCType.toString(), paramJDBCType.toString());
/*      */       } 
/*      */       
/* 4505 */       StreamSetterArgs streamSetterArgs = null;
/* 4506 */       switch (javaType) {
/*      */         
/*      */         case READER:
/* 4509 */           streamSetterArgs = new StreamSetterArgs(StreamType.CHARACTER, -1L);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case INPUTSTREAM:
/* 4515 */           streamSetterArgs = new StreamSetterArgs(paramJDBCType.isTextual() ? StreamType.CHARACTER : StreamType.BINARY, -1L);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case SQLXML:
/* 4521 */           streamSetterArgs = new StreamSetterArgs(StreamType.SQLXML, -1L);
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4531 */       column.updateValue(paramJDBCType, paramObject, javaType, streamSetterArgs, null, paramInteger1, this.stmt.connection, this.stmt.stmtColumnEncriptionSetting, paramInteger2, paramBoolean, paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String paramString) throws SQLServerException {
/* 4548 */     loggerExternal.entering(getClassNameLogging(), "updateNull", paramString);
/*      */     
/* 4550 */     checkClosed();
/* 4551 */     int i = findColumn(paramString);
/* 4552 */     updateValue(i, updaterGetColumn(i).getTypeInfo().getSSType().getJDBCType(), null, JavaType.OBJECT, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4559 */     loggerExternal.exiting(getClassNameLogging(), "updateNull");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(String paramString, boolean paramBoolean) throws SQLServerException {
/* 4565 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4566 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4568 */     checkClosed();
/* 4569 */     updateValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean), JavaType.BOOLEAN, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4576 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBoolean(String paramString, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
/* 4581 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4582 */       loggerExternal.entering(getClassNameLogging(), "updateBoolean", new Object[] { paramString, Boolean.valueOf(paramBoolean1), Boolean.valueOf(paramBoolean2) });
/*      */     }
/* 4584 */     checkClosed();
/* 4585 */     updateValue(findColumn(paramString), JDBCType.BIT, Boolean.valueOf(paramBoolean1), JavaType.BOOLEAN, paramBoolean2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4592 */     loggerExternal.exiting(getClassNameLogging(), "updateBoolean");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(String paramString, byte paramByte) throws SQLServerException {
/* 4597 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4598 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { paramString, Byte.valueOf(paramByte) });
/*      */     }
/* 4600 */     checkClosed();
/* 4601 */     updateValue(findColumn(paramString), JDBCType.BINARY, Byte.valueOf(paramByte), JavaType.BYTE, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4608 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateByte(String paramString, byte paramByte, boolean paramBoolean) throws SQLServerException {
/* 4613 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4614 */       loggerExternal.entering(getClassNameLogging(), "updateByte", new Object[] { paramString, Byte.valueOf(paramByte), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4616 */     checkClosed();
/* 4617 */     updateValue(findColumn(paramString), JDBCType.BINARY, Byte.valueOf(paramByte), JavaType.BYTE, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4624 */     loggerExternal.exiting(getClassNameLogging(), "updateByte");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(String paramString, short paramShort) throws SQLServerException {
/* 4629 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4630 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { paramString, Short.valueOf(paramShort) });
/*      */     }
/* 4632 */     checkClosed();
/* 4633 */     updateValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4640 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateShort(String paramString, short paramShort, boolean paramBoolean) throws SQLServerException {
/* 4645 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4646 */       loggerExternal.entering(getClassNameLogging(), "updateShort", new Object[] { paramString, Short.valueOf(paramShort), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4648 */     checkClosed();
/* 4649 */     updateValue(findColumn(paramString), JDBCType.SMALLINT, Short.valueOf(paramShort), JavaType.SHORT, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4656 */     loggerExternal.exiting(getClassNameLogging(), "updateShort");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(String paramString, int paramInt) throws SQLServerException {
/* 4661 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4662 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { paramString, Integer.valueOf(paramInt) });
/*      */     }
/* 4664 */     checkClosed();
/* 4665 */     updateValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4672 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateInt(String paramString, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 4677 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4678 */       loggerExternal.entering(getClassNameLogging(), "updateInt", new Object[] { paramString, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4680 */     checkClosed();
/* 4681 */     updateValue(findColumn(paramString), JDBCType.INTEGER, Integer.valueOf(paramInt), JavaType.INTEGER, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4688 */     loggerExternal.exiting(getClassNameLogging(), "updateInt");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(String paramString, long paramLong) throws SQLServerException {
/* 4693 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4694 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { paramString, Long.valueOf(paramLong) });
/*      */     }
/* 4696 */     checkClosed();
/* 4697 */     updateValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4704 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateLong(String paramString, long paramLong, boolean paramBoolean) throws SQLServerException {
/* 4709 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4710 */       loggerExternal.entering(getClassNameLogging(), "updateLong", new Object[] { paramString, Long.valueOf(paramLong), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4712 */     checkClosed();
/* 4713 */     updateValue(findColumn(paramString), JDBCType.BIGINT, Long.valueOf(paramLong), JavaType.LONG, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4720 */     loggerExternal.exiting(getClassNameLogging(), "updateLong");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(String paramString, float paramFloat) throws SQLServerException {
/* 4725 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4726 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { paramString, Float.valueOf(paramFloat) });
/*      */     }
/* 4728 */     checkClosed();
/* 4729 */     updateValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4736 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFloat(String paramString, float paramFloat, boolean paramBoolean) throws SQLServerException {
/* 4741 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4742 */       loggerExternal.entering(getClassNameLogging(), "updateFloat", new Object[] { paramString, Float.valueOf(paramFloat), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4744 */     checkClosed();
/* 4745 */     updateValue(findColumn(paramString), JDBCType.REAL, Float.valueOf(paramFloat), JavaType.FLOAT, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4752 */     loggerExternal.exiting(getClassNameLogging(), "updateFloat");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(String paramString, double paramDouble) throws SQLServerException {
/* 4757 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4758 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { paramString, Double.valueOf(paramDouble) });
/*      */     }
/* 4760 */     checkClosed();
/* 4761 */     updateValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4768 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDouble(String paramString, double paramDouble, boolean paramBoolean) throws SQLServerException {
/* 4773 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4774 */       loggerExternal.entering(getClassNameLogging(), "updateDouble", new Object[] { paramString, Double.valueOf(paramDouble), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4776 */     checkClosed();
/* 4777 */     updateValue(findColumn(paramString), JDBCType.DOUBLE, Double.valueOf(paramDouble), JavaType.DOUBLE, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4784 */     loggerExternal.exiting(getClassNameLogging(), "updateDouble");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLServerException {
/* 4789 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4790 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal });
/*      */     }
/* 4792 */     checkClosed();
/* 4793 */     updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4800 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, boolean paramBoolean) throws SQLServerException {
/* 4805 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4806 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4808 */     checkClosed();
/* 4809 */     updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4816 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2) throws SQLServerException {
/* 4821 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4822 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal, paramInteger1, paramInteger2 });
/*      */     }
/* 4824 */     checkClosed();
/* 4825 */     updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4834 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal, Integer paramInteger1, Integer paramInteger2, boolean paramBoolean) throws SQLServerException {
/* 4839 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4840 */       loggerExternal.entering(getClassNameLogging(), "updateBigDecimal", new Object[] { paramString, paramBigDecimal, paramInteger1, paramInteger2, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4842 */     checkClosed();
/* 4843 */     updateValue(findColumn(paramString), JDBCType.DECIMAL, paramBigDecimal, JavaType.BIGDECIMAL, paramInteger1, paramInteger2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4852 */     loggerExternal.exiting(getClassNameLogging(), "updateBigDecimal");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(String paramString1, String paramString2) throws SQLServerException {
/* 4857 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4858 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { paramString1, paramString2 });
/*      */     }
/* 4860 */     checkClosed();
/* 4861 */     updateValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4868 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateString(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
/* 4873 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4874 */       loggerExternal.entering(getClassNameLogging(), "updateString", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4876 */     checkClosed();
/* 4877 */     updateValue(findColumn(paramString1), JDBCType.VARCHAR, paramString2, JavaType.STRING, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4884 */     loggerExternal.exiting(getClassNameLogging(), "updateString");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfbyte) throws SQLServerException {
/* 4889 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4890 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { paramString, paramArrayOfbyte });
/*      */     }
/* 4892 */     checkClosed();
/* 4893 */     updateValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4900 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
/* 4905 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4906 */       loggerExternal.entering(getClassNameLogging(), "updateBytes", new Object[] { paramString, paramArrayOfbyte, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4908 */     checkClosed();
/* 4909 */     updateValue(findColumn(paramString), JDBCType.BINARY, paramArrayOfbyte, JavaType.BYTEARRAY, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4916 */     loggerExternal.exiting(getClassNameLogging(), "updateBytes");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(String paramString, Date paramDate) throws SQLServerException {
/* 4921 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4922 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { paramString, paramDate });
/*      */     }
/* 4924 */     checkClosed();
/* 4925 */     updateValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4932 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDate(String paramString, Date paramDate, boolean paramBoolean) throws SQLServerException {
/* 4937 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4938 */       loggerExternal.entering(getClassNameLogging(), "updateDate", new Object[] { paramString, paramDate, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4940 */     checkClosed();
/* 4941 */     updateValue(findColumn(paramString), JDBCType.DATE, paramDate, JavaType.DATE, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4948 */     loggerExternal.exiting(getClassNameLogging(), "updateDate");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(String paramString, Time paramTime) throws SQLServerException {
/* 4953 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4954 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime });
/*      */     }
/* 4956 */     checkClosed();
/* 4957 */     updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4964 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(String paramString, Time paramTime, int paramInt) throws SQLServerException {
/* 4969 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4970 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime, Integer.valueOf(paramInt) });
/*      */     }
/* 4972 */     checkClosed();
/* 4973 */     updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, null, Integer.valueOf(paramInt), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4982 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTime(String paramString, Time paramTime, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 4987 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 4988 */       loggerExternal.entering(getClassNameLogging(), "updateTime", new Object[] { paramString, paramTime, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 4990 */     checkClosed();
/* 4991 */     updateValue(findColumn(paramString), JDBCType.TIME, paramTime, JavaType.TIME, null, Integer.valueOf(paramInt), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5000 */     loggerExternal.exiting(getClassNameLogging(), "updateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp) throws SQLServerException {
/* 5005 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5006 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp });
/*      */     }
/* 5008 */     checkClosed();
/* 5009 */     updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5016 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
/* 5021 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5022 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt) });
/*      */     }
/* 5024 */     checkClosed();
/* 5025 */     updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5034 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 5039 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5040 */       loggerExternal.entering(getClassNameLogging(), "updateTimestamp", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5042 */     checkClosed();
/* 5043 */     updateValue(findColumn(paramString), JDBCType.TIMESTAMP, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5052 */     loggerExternal.exiting(getClassNameLogging(), "updateTimestamp");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
/* 5057 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5058 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { paramString, paramTimestamp });
/*      */     }
/* 5060 */     checkClosed();
/* 5061 */     updateValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5068 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
/* 5073 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5074 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt) });
/*      */     }
/* 5076 */     checkClosed();
/* 5077 */     updateValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5086 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTime(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 5091 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5092 */       loggerExternal.entering(getClassNameLogging(), "updateDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5094 */     checkClosed();
/* 5095 */     updateValue(findColumn(paramString), JDBCType.DATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5104 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(String paramString, Timestamp paramTimestamp) throws SQLServerException {
/* 5109 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5110 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { paramString, paramTimestamp });
/*      */     }
/* 5112 */     checkClosed();
/* 5113 */     updateValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5120 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(String paramString, Timestamp paramTimestamp, int paramInt) throws SQLServerException {
/* 5125 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5126 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt) });
/*      */     }
/* 5128 */     checkClosed();
/* 5129 */     updateValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5138 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSmallDateTime(String paramString, Timestamp paramTimestamp, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 5143 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5144 */       loggerExternal.entering(getClassNameLogging(), "updateSmallDateTime", new Object[] { paramString, paramTimestamp, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5146 */     checkClosed();
/* 5147 */     updateValue(findColumn(paramString), JDBCType.SMALLDATETIME, paramTimestamp, JavaType.TIMESTAMP, null, Integer.valueOf(paramInt), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5156 */     loggerExternal.exiting(getClassNameLogging(), "updateSmallDateTime");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset) throws SQLException {
/* 5161 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5162 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset });
/*      */     }
/* 5164 */     checkClosed();
/* 5165 */     updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5172 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt) throws SQLException {
/* 5177 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5178 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset, Integer.valueOf(paramInt) });
/*      */     }
/* 5180 */     checkClosed();
/* 5181 */     updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, Integer.valueOf(paramInt), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5190 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateDateTimeOffset(String paramString, DateTimeOffset paramDateTimeOffset, int paramInt, boolean paramBoolean) throws SQLException {
/* 5195 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5196 */       loggerExternal.entering(getClassNameLogging(), "updateDateTimeOffset", new Object[] { paramString, paramDateTimeOffset, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5198 */     checkClosed();
/* 5199 */     updateValue(findColumn(paramString), JDBCType.DATETIMEOFFSET, paramDateTimeOffset, JavaType.DATETIMEOFFSET, null, Integer.valueOf(paramInt), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5208 */     loggerExternal.exiting(getClassNameLogging(), "updateDateTimeOffset");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(String paramString1, String paramString2) throws SQLException {
/* 5213 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5214 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { paramString1, paramString2 });
/*      */     }
/* 5216 */     checkClosed();
/* 5217 */     updateValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, null, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5225 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateUniqueIdentifier(String paramString1, String paramString2, boolean paramBoolean) throws SQLException {
/* 5230 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5231 */       loggerExternal.entering(getClassNameLogging(), "updateUniqueIdentifier", new Object[] { paramString1, paramString2, Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5233 */     checkClosed();
/* 5234 */     updateValue(findColumn(paramString1), JDBCType.GUID, paramString2, JavaType.STRING, null, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5242 */     loggerExternal.exiting(getClassNameLogging(), "updateUniqueIdentifier");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt) throws SQLServerException {
/* 5247 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5248 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt) });
/*      */     }
/* 5250 */     checkClosed();
/* 5251 */     updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt), null, null, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5259 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
/* 5264 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5265 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*      */     }
/* 5267 */     checkClosed();
/* 5268 */     updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt2), null, Integer.valueOf(paramInt1), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5276 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt1, int paramInt2, boolean paramBoolean) throws SQLServerException {
/* 5281 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5282 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5284 */     checkClosed();
/* 5285 */     updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt2), null, Integer.valueOf(paramInt1), paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5293 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt) throws SQLServerException {
/* 5298 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 5300 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5301 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt) });
/*      */     }
/* 5303 */     checkClosed();
/*      */ 
/*      */     
/* 5306 */     updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5314 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, SQLType paramSQLType, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 5319 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 5321 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5322 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, paramSQLType, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) });
/*      */     }
/* 5324 */     checkClosed();
/*      */ 
/*      */     
/* 5327 */     updateObject(findColumn(paramString), paramObject, Integer.valueOf(paramInt), JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5335 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject) throws SQLServerException {
/* 5340 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5341 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject });
/*      */     }
/* 5343 */     checkClosed();
/* 5344 */     updateObject(findColumn(paramString), paramObject, (Integer)null, null, null, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5352 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, SQLType paramSQLType) throws SQLServerException {
/* 5357 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 5359 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5360 */       loggerExternal.entering(getClassNameLogging(), "updateObject", new Object[] { paramString, paramObject, paramSQLType });
/*      */     }
/* 5362 */     checkClosed();
/*      */ 
/*      */     
/* 5365 */     updateObject(findColumn(paramString), paramObject, (Integer)null, JDBCType.of(paramSQLType.getVendorTypeNumber().intValue()), null, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5373 */     loggerExternal.exiting(getClassNameLogging(), "updateObject");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRowId(int paramInt, RowId paramRowId) throws SQLException {
/* 5378 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 5381 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateRowId(String paramString, RowId paramRowId) throws SQLException {
/* 5386 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/* 5389 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSQLXML(int paramInt, SQLXML paramSQLXML) throws SQLException {
/* 5394 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5395 */     if (loggerExternal.isLoggable(Level.FINER))
/* 5396 */       loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { Integer.valueOf(paramInt), paramSQLXML }); 
/* 5397 */     updateSQLXMLInternal(paramInt, paramSQLXML);
/* 5398 */     loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateSQLXML(String paramString, SQLXML paramSQLXML) throws SQLException {
/* 5403 */     if (loggerExternal.isLoggable(Level.FINER))
/* 5404 */       loggerExternal.entering(getClassNameLogging(), "updateSQLXML", new Object[] { paramString, paramSQLXML }); 
/* 5405 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5406 */     updateSQLXMLInternal(findColumn(paramString), paramSQLXML);
/* 5407 */     loggerExternal.exiting(getClassNameLogging(), "updateSQLXML");
/*      */   }
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLException {
/* 5412 */     loggerExternal.entering(getClassNameLogging(), "getHoldability");
/*      */     
/* 5414 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5415 */     checkClosed();
/*      */     
/* 5417 */     boolean bool = (0 == this.stmt.getServerCursorId()) ? true : this.stmt.getExecProps().getHoldability();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5428 */     loggerExternal.exiting(getClassNameLogging(), "getHoldability", Integer.valueOf(bool));
/*      */     
/* 5430 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLServerException {
/* 5437 */     loggerExternal.entering(getClassNameLogging(), "insertRow");
/* 5438 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 5440 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     final class InsertRowRPC
/*      */       extends TDSCommand
/*      */     {
/*      */       final String tableName;
/*      */ 
/*      */       
/*      */       InsertRowRPC(String param1String) {
/* 5449 */         super("InsertRowRPC", 0);
/* 5450 */         this.tableName = param1String;
/*      */       }
/*      */ 
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 5455 */         SQLServerResultSet.this.doInsertRowRPC(this, this.tableName);
/* 5456 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 5460 */     if (logger.isLoggable(Level.FINER)) {
/* 5461 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 5463 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5467 */     verifyResultSetIsUpdatable();
/*      */     
/* 5469 */     if (!this.isOnInsertRow)
/*      */     {
/* 5471 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_mustBeOnInsertRow"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5494 */     Column column = null;
/* 5495 */     for (byte b = 0; b < this.columns.length; b++) {
/*      */       
/* 5497 */       if (this.columns[b].hasUpdates()) {
/*      */         
/* 5499 */         column = this.columns[b];
/*      */         
/*      */         break;
/*      */       } 
/* 5503 */       if (null == column && this.columns[b].isUpdatable()) {
/* 5504 */         column = this.columns[b];
/*      */       }
/*      */     } 
/* 5507 */     if (null == column)
/*      */     {
/* 5509 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_noColumnParameterValue"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5517 */     assert column.isUpdatable();
/* 5518 */     assert null != column.getTableName();
/*      */     
/* 5520 */     this.stmt.executeCommand(new InsertRowRPC(column.getTableName().asEscapedString()));
/*      */     
/* 5522 */     if (-3 != this.rowCount)
/* 5523 */       this.rowCount++; 
/* 5524 */     loggerExternal.exiting(getClassNameLogging(), "insertRow");
/*      */   }
/*      */ 
/*      */   
/*      */   private final void doInsertRowRPC(TDSCommand paramTDSCommand, String paramString) throws SQLServerException {
/* 5529 */     assert 0 != this.serverCursorId;
/* 5530 */     assert null != paramString;
/* 5531 */     assert paramString.length() > 0;
/*      */     
/* 5533 */     TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)3);
/* 5534 */     tDSWriter.writeShort((short)-1);
/* 5535 */     tDSWriter.writeShort((short)1);
/* 5536 */     tDSWriter.writeByte((byte)0);
/* 5537 */     tDSWriter.writeByte((byte)0);
/* 5538 */     tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 5539 */     tDSWriter.writeRPCInt(null, new Integer(4), false);
/* 5540 */     tDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
/*      */     
/* 5542 */     if (hasUpdatedColumns()) {
/*      */       
/* 5544 */       tDSWriter.writeRPCStringUnicode(paramString);
/*      */       
/* 5546 */       for (byte b = 0; b < this.columns.length; b++) {
/* 5547 */         this.columns[b].sendByRPC(tDSWriter, this.stmt.connection);
/*      */       }
/*      */     } else {
/*      */       
/* 5551 */       tDSWriter.writeRPCStringUnicode("");
/* 5552 */       tDSWriter.writeRPCStringUnicode("INSERT INTO " + paramString + " DEFAULT VALUES");
/*      */     } 
/*      */     
/* 5555 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLServerException {
/* 5561 */     loggerExternal.entering(getClassNameLogging(), "updateRow");
/* 5562 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 5564 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     final class UpdateRowRPC
/*      */       extends TDSCommand
/*      */     {
/*      */       UpdateRowRPC() {
/* 5570 */         super("UpdateRowRPC", 0);
/*      */       }
/*      */ 
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 5575 */         SQLServerResultSet.this.doUpdateRowRPC(this);
/* 5576 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 5580 */     if (logger.isLoggable(Level.FINER)) {
/* 5581 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 5583 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5587 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5592 */     verifyResultSetIsNotOnInsertRow();
/* 5593 */     verifyResultSetHasCurrentRow();
/*      */ 
/*      */     
/* 5596 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */     
/* 5598 */     if (!hasUpdatedColumns())
/*      */     {
/* 5600 */       SQLServerException.makeFromDriverError(this.stmt.connection, this.stmt, SQLServerException.getErrString("R_noColumnParameterValue"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 5611 */       this.stmt.executeCommand(new UpdateRowRPC());
/*      */     }
/*      */     finally {
/*      */       
/* 5615 */       cancelUpdates();
/*      */     } 
/*      */     
/* 5618 */     this.updatedCurrentRow = true;
/* 5619 */     loggerExternal.exiting(getClassNameLogging(), "updateRow");
/*      */   }
/*      */ 
/*      */   
/*      */   private final void doUpdateRowRPC(TDSCommand paramTDSCommand) throws SQLServerException {
/* 5624 */     assert 0 != this.serverCursorId;
/*      */     
/* 5626 */     TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)3);
/* 5627 */     tDSWriter.writeShort((short)-1);
/* 5628 */     tDSWriter.writeShort((short)1);
/* 5629 */     tDSWriter.writeByte((byte)0);
/* 5630 */     tDSWriter.writeByte((byte)0);
/* 5631 */     tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 5632 */     tDSWriter.writeRPCInt(null, new Integer(33), false);
/* 5633 */     tDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
/* 5634 */     tDSWriter.writeRPCStringUnicode("");
/*      */     
/* 5636 */     assert hasUpdatedColumns();
/*      */     
/* 5638 */     for (byte b = 0; b < this.columns.length; b++) {
/* 5639 */       this.columns[b].sendByRPC(tDSWriter, this.stmt.connection);
/*      */     }
/* 5641 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean hasUpdatedColumns() {
/* 5647 */     for (byte b = 0; b < this.columns.length; b++) {
/* 5648 */       if (this.columns[b].hasUpdates())
/* 5649 */         return true; 
/*      */     } 
/* 5651 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLServerException {
/* 5656 */     loggerExternal.entering(getClassNameLogging(), "deleteRow");
/* 5657 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 5659 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     final class DeleteRowRPC
/*      */       extends TDSCommand
/*      */     {
/*      */       DeleteRowRPC() {
/* 5665 */         super("DeleteRowRPC", 0);
/*      */       }
/*      */ 
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/* 5670 */         SQLServerResultSet.this.doDeleteRowRPC(this);
/* 5671 */         return true;
/*      */       }
/*      */     };
/*      */     
/* 5675 */     if (logger.isLoggable(Level.FINER)) {
/* 5676 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 5678 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5682 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */     
/* 5685 */     verifyResultSetIsNotOnInsertRow();
/* 5686 */     verifyResultSetHasCurrentRow();
/*      */ 
/*      */     
/* 5689 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */ 
/*      */     
/*      */     try {
/* 5693 */       this.stmt.executeCommand(new DeleteRowRPC());
/*      */     }
/*      */     finally {
/*      */       
/* 5697 */       cancelUpdates();
/*      */     } 
/*      */     
/* 5700 */     this.deletedCurrentRow = true;
/* 5701 */     loggerExternal.exiting(getClassNameLogging(), "deleteRow");
/*      */   }
/*      */ 
/*      */   
/*      */   private final void doDeleteRowRPC(TDSCommand paramTDSCommand) throws SQLServerException {
/* 5706 */     assert 0 != this.serverCursorId;
/*      */     
/* 5708 */     TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)3);
/* 5709 */     tDSWriter.writeShort((short)-1);
/* 5710 */     tDSWriter.writeShort((short)1);
/* 5711 */     tDSWriter.writeByte((byte)0);
/* 5712 */     tDSWriter.writeByte((byte)0);
/* 5713 */     tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 5714 */     tDSWriter.writeRPCInt(null, new Integer(34), false);
/* 5715 */     tDSWriter.writeRPCInt(null, new Integer(fetchBufferGetRow()), false);
/* 5716 */     tDSWriter.writeRPCStringUnicode("");
/*      */     
/* 5718 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */   }
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLServerException {
/* 5723 */     loggerExternal.entering(getClassNameLogging(), "refreshRow");
/* 5724 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 5726 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */     
/* 5729 */     if (logger.isLoggable(Level.FINER)) {
/* 5730 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 5732 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5736 */     verifyResultSetIsScrollable();
/*      */ 
/*      */ 
/*      */     
/* 5740 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */     
/* 5744 */     verifyResultSetIsNotOnInsertRow();
/*      */ 
/*      */     
/* 5747 */     verifyResultSetHasCurrentRow();
/* 5748 */     verifyCurrentRowIsNotDeleted("R_cantUpdateDeletedRow");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5755 */     if (1004 == this.stmt.getResultSetType() || 0 == this.serverCursorId) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 5761 */     cancelUpdates();
/*      */     
/* 5763 */     doRefreshRow();
/* 5764 */     loggerExternal.exiting(getClassNameLogging(), "refreshRow");
/*      */   }
/*      */ 
/*      */   
/*      */   private void doRefreshRow() throws SQLServerException {
/* 5769 */     assert hasCurrentRow();
/*      */ 
/*      */ 
/*      */     
/* 5773 */     int i = fetchBufferGetRow();
/*      */ 
/*      */ 
/*      */     
/* 5777 */     doServerFetch(128, 0, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5783 */     byte b = 0;
/* 5784 */     while (b < i && (isForwardOnly() ? fetchBufferNext() : this.scrollWindow.next(this)))
/*      */     {
/*      */       
/* 5787 */       b++;
/*      */     }
/*      */     
/* 5790 */     if (b < i) {
/*      */       
/* 5792 */       this.currentRow = -1;
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5798 */     this.updatedCurrentRow = false;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void cancelUpdates() {
/* 5803 */     if (!this.isOnInsertRow) {
/* 5804 */       clearColumnsValues();
/*      */     }
/*      */   }
/*      */   
/*      */   public void cancelRowUpdates() throws SQLServerException {
/* 5809 */     loggerExternal.entering(getClassNameLogging(), "cancelRowUpdates");
/* 5810 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5815 */     verifyResultSetIsUpdatable();
/* 5816 */     verifyResultSetIsNotOnInsertRow();
/*      */     
/* 5818 */     cancelUpdates();
/* 5819 */     loggerExternal.exiting(getClassNameLogging(), "cancelRowUpdates");
/*      */   }
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLServerException {
/* 5824 */     loggerExternal.entering(getClassNameLogging(), "moveToInsertRow");
/* 5825 */     if (logger.isLoggable(Level.FINER)) {
/* 5826 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 5828 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5832 */     verifyResultSetIsUpdatable();
/*      */     
/* 5834 */     cancelUpdates();
/* 5835 */     this.isOnInsertRow = true;
/* 5836 */     loggerExternal.exiting(getClassNameLogging(), "moveToInsertRow");
/*      */   }
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLServerException {
/* 5841 */     loggerExternal.entering(getClassNameLogging(), "moveToCurrentRow");
/* 5842 */     if (logger.isLoggable(Level.FINER)) {
/* 5843 */       logger.finer(toString() + logCursorState());
/*      */     }
/* 5845 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 5849 */     verifyResultSetIsUpdatable();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5855 */     cancelInsert();
/* 5856 */     loggerExternal.exiting(getClassNameLogging(), "moveToCurrentRow");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLServerException {
/* 5862 */     loggerExternal.entering(getClassNameLogging(), "getStatement");
/* 5863 */     checkClosed();
/* 5864 */     loggerExternal.exiting(getClassNameLogging(), "getStatement", this.stmt);
/* 5865 */     return this.stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Clob paramClob) throws SQLException {
/* 5872 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5873 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramClob });
/*      */     }
/* 5875 */     checkClosed();
/* 5876 */     updateValue(paramInt, JDBCType.CLOB, paramClob, JavaType.CLOB, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5883 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Reader paramReader) throws SQLException {
/* 5888 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5889 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5890 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 5892 */     checkClosed();
/* 5893 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5900 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 5905 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5906 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5907 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 5909 */     checkClosed();
/* 5910 */     updateStream(paramInt, StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5917 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(String paramString, Clob paramClob) throws SQLException {
/* 5922 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5923 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramClob });
/*      */     }
/* 5925 */     checkClosed();
/* 5926 */     updateValue(findColumn(paramString), JDBCType.CLOB, paramClob, JavaType.CLOB, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5933 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(String paramString, Reader paramReader) throws SQLException {
/* 5938 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5939 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5940 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramReader });
/*      */     }
/* 5942 */     checkClosed();
/* 5943 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5950 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 5955 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5956 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5957 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 5959 */     checkClosed();
/* 5960 */     updateStream(findColumn(paramString), StreamType.CHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5967 */     loggerExternal.exiting(getClassNameLogging(), "updateClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, NClob paramNClob) throws SQLException {
/* 5972 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5973 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5974 */       loggerExternal.entering(getClassNameLogging(), "updateClob", new Object[] { Integer.valueOf(paramInt), paramNClob });
/*      */     }
/* 5976 */     checkClosed();
/* 5977 */     updateValue(paramInt, JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5984 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, Reader paramReader) throws SQLException {
/* 5989 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 5990 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 5991 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(paramInt), paramReader });
/*      */     }
/* 5993 */     checkClosed();
/* 5994 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6001 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(int paramInt, Reader paramReader, long paramLong) throws SQLException {
/* 6006 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6007 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6008 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { Integer.valueOf(paramInt), paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 6010 */     checkClosed();
/* 6011 */     updateStream(paramInt, StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6018 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(String paramString, NClob paramNClob) throws SQLException {
/* 6023 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6024 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6025 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramNClob });
/*      */     }
/* 6027 */     checkClosed();
/* 6028 */     updateValue(findColumn(paramString), JDBCType.NCLOB, paramNClob, JavaType.NCLOB, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6035 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(String paramString, Reader paramReader) throws SQLException {
/* 6040 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6041 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6042 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramReader });
/*      */     }
/* 6044 */     checkClosed();
/* 6045 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6052 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNClob(String paramString, Reader paramReader, long paramLong) throws SQLException {
/* 6057 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6058 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6059 */       loggerExternal.entering(getClassNameLogging(), "updateNClob", new Object[] { paramString, paramReader, Long.valueOf(paramLong) });
/*      */     }
/* 6061 */     checkClosed();
/* 6062 */     updateStream(findColumn(paramString), StreamType.NCHARACTER, paramReader, JavaType.READER, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6069 */     loggerExternal.exiting(getClassNameLogging(), "updateNClob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 6074 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6075 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramBlob });
/*      */     }
/* 6077 */     checkClosed();
/* 6078 */     updateValue(paramInt, JDBCType.BLOB, paramBlob, JavaType.BLOB, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6085 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream) throws SQLException {
/* 6090 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6091 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6092 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream });
/*      */     }
/* 6094 */     checkClosed();
/* 6095 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6102 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6107 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6108 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6109 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { Integer.valueOf(paramInt), paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 6111 */     checkClosed();
/* 6112 */     updateStream(paramInt, StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6119 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(String paramString, Blob paramBlob) throws SQLException {
/* 6124 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6125 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramBlob });
/*      */     }
/* 6127 */     checkClosed();
/* 6128 */     updateValue(findColumn(paramString), JDBCType.BLOB, paramBlob, JavaType.BLOB, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6135 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(String paramString, InputStream paramInputStream) throws SQLException {
/* 6140 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6141 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6142 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramInputStream });
/*      */     }
/* 6144 */     checkClosed();
/* 6145 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, -1L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6152 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBlob(String paramString, InputStream paramInputStream, long paramLong) throws SQLException {
/* 6157 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 6158 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 6159 */       loggerExternal.entering(getClassNameLogging(), "updateBlob", new Object[] { paramString, paramInputStream, Long.valueOf(paramLong) });
/*      */     }
/* 6161 */     checkClosed();
/* 6162 */     updateStream(findColumn(paramString), StreamType.BINARY, paramInputStream, JavaType.INPUTSTREAM, paramLong);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6169 */     loggerExternal.exiting(getClassNameLogging(), "updateBlob");
/*      */   }
/*      */   
/*      */   public void updateArray(int paramInt, Array paramArray) throws SQLServerException {
/* 6173 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public void updateArray(String paramString, Array paramArray) throws SQLServerException {
/* 6176 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public void updateRef(int paramInt, Ref paramRef) throws SQLServerException {
/* 6179 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public void updateRef(String paramString, Ref paramRef) throws SQLServerException {
/* 6182 */     this.stmt.NotImplemented();
/*      */   }
/*      */   public URL getURL(int paramInt) throws SQLServerException {
/* 6185 */     this.stmt.NotImplemented();
/* 6186 */     return null;
/*      */   }
/*      */   public URL getURL(String paramString) throws SQLServerException {
/* 6189 */     this.stmt.NotImplemented();
/* 6190 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class FetchBuffer
/*      */   {
/*      */     private final class FetchBufferTokenHandler
/*      */       extends TDSTokenHandler
/*      */     {
/*      */       FetchBufferTokenHandler() {
/* 6223 */         super("FetchBufferTokenHandler");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onColMetaData(TDSReader param2TDSReader) throws SQLServerException {
/* 6231 */         (new StreamColumns(Util.shouldHonorAEForRead(SQLServerResultSet.this.stmt.stmtColumnEncriptionSetting, SQLServerResultSet.this.stmt.connection))).setFromTDS(param2TDSReader);
/* 6232 */         return true;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onRow(TDSReader param2TDSReader) throws SQLServerException {
/* 6237 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/*      */ 
/*      */         
/* 6241 */         if (209 != param2TDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 6242 */         SQLServerResultSet.FetchBuffer.this.fetchBufferCurrentRowType = RowType.ROW;
/* 6243 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onNBCRow(TDSReader param2TDSReader) throws SQLServerException {
/* 6248 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/*      */ 
/*      */         
/* 6252 */         if (210 != param2TDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError();
/*      */         
/* 6254 */         SQLServerResultSet.FetchBuffer.this.fetchBufferCurrentRowType = RowType.NBCROW;
/* 6255 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader param2TDSReader) throws SQLServerException {
/* 6260 */         SQLServerResultSet.FetchBuffer.this.ensureStartMark();
/*      */ 
/*      */         
/* 6263 */         StreamDone streamDone = new StreamDone();
/* 6264 */         streamDone.setFromTDS(param2TDSReader);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6269 */         SQLServerResultSet.FetchBuffer.this.done = true;
/* 6270 */         return (0 != SQLServerResultSet.this.serverCursorId);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetStatus(TDSReader param2TDSReader) throws SQLServerException {
/* 6278 */         StreamRetStatus streamRetStatus = new StreamRetStatus();
/* 6279 */         streamRetStatus.setFromTDS(param2TDSReader);
/* 6280 */         SQLServerResultSet.FetchBuffer.this.needsServerCursorFixup = (2 == streamRetStatus.getStatus());
/* 6281 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       void onEOF(TDSReader param2TDSReader) throws SQLServerException {
/* 6287 */         super.onEOF(param2TDSReader);
/* 6288 */         SQLServerResultSet.FetchBuffer.this.done = true;
/*      */       }
/*      */     }
/*      */     
/* 6292 */     private final FetchBufferTokenHandler fetchBufferTokenHandler = new FetchBufferTokenHandler();
/*      */     private TDSReaderMark startMark;
/*      */     
/*      */     final void clearStartMark() {
/* 6296 */       this.startMark = null;
/*      */     }
/* 6298 */     private RowType fetchBufferCurrentRowType = RowType.UNKNOWN; private boolean done; private boolean needsServerCursorFixup;
/*      */     
/*      */     final boolean needsServerCursorFixup() {
/* 6301 */       return this.needsServerCursorFixup;
/*      */     }
/*      */     
/*      */     FetchBuffer() {
/* 6305 */       init();
/*      */     }
/*      */ 
/*      */     
/*      */     final void ensureStartMark() {
/* 6310 */       if (null == this.startMark && !SQLServerResultSet.this.isForwardOnly()) {
/*      */         
/* 6312 */         if (SQLServerResultSet.logger.isLoggable(Level.FINEST)) {
/* 6313 */           SQLServerResultSet.logger.finest(toString() + " Setting fetch buffer start mark");
/*      */         }
/* 6315 */         this.startMark = SQLServerResultSet.this.tdsReader.mark();
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void reset() {
/* 6324 */       assert null != SQLServerResultSet.this.tdsReader;
/* 6325 */       assert null != this.startMark;
/*      */       
/* 6327 */       SQLServerResultSet.this.tdsReader.reset(this.startMark);
/* 6328 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/* 6329 */       this.done = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void init() {
/* 6339 */       this.startMark = (0 == SQLServerResultSet.this.serverCursorId && !SQLServerResultSet.this.isForwardOnly()) ? SQLServerResultSet.this.tdsReader.mark() : null;
/* 6340 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/* 6341 */       this.done = false;
/* 6342 */       this.needsServerCursorFixup = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final RowType nextRow() throws SQLServerException {
/* 6350 */       this.fetchBufferCurrentRowType = RowType.UNKNOWN;
/*      */       
/* 6352 */       while (null != SQLServerResultSet.this.tdsReader && !this.done && this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN)) {
/* 6353 */         TDSParser.parse(SQLServerResultSet.this.tdsReader, this.fetchBufferTokenHandler);
/*      */       }
/* 6355 */       if (this.fetchBufferCurrentRowType.equals(RowType.UNKNOWN) && null != this.fetchBufferTokenHandler.getDatabaseError())
/*      */       {
/* 6357 */         SQLServerException.makeFromDatabaseError(SQLServerResultSet.this.stmt.connection, (Object)null, this.fetchBufferTokenHandler.getDatabaseError().getMessage(), this.fetchBufferTokenHandler.getDatabaseError(), false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6365 */       return this.fetchBufferCurrentRowType;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final class CursorFetchCommand
/*      */     extends TDSCommand
/*      */   {
/*      */     private final int serverCursorId;
/*      */     
/*      */     private int fetchType;
/*      */     
/*      */     private int startRow;
/*      */     
/*      */     private int numRows;
/*      */     
/*      */     CursorFetchCommand(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
/* 6382 */       super("doServerFetch", SQLServerResultSet.this.stmt.queryTimeout);
/* 6383 */       this.serverCursorId = param1Int1;
/* 6384 */       this.fetchType = param1Int2;
/* 6385 */       this.startRow = param1Int3;
/* 6386 */       this.numRows = param1Int4;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/* 6391 */       TDSWriter tDSWriter = startRequest((byte)3);
/* 6392 */       tDSWriter.writeShort((short)-1);
/* 6393 */       tDSWriter.writeShort((short)7);
/* 6394 */       tDSWriter.writeByte((byte)2);
/* 6395 */       tDSWriter.writeByte((byte)0);
/* 6396 */       tDSWriter.writeRPCInt(null, new Integer(this.serverCursorId), false);
/* 6397 */       tDSWriter.writeRPCInt(null, new Integer(this.fetchType), false);
/* 6398 */       tDSWriter.writeRPCInt(null, new Integer(this.startRow), false);
/* 6399 */       tDSWriter.writeRPCInt(null, new Integer(this.numRows), false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6407 */       SQLServerResultSet.this.tdsReader = startResponse((SQLServerResultSet.this.isForwardOnly() && 1007 != SQLServerResultSet.this.stmt.resultSetConcurrency && SQLServerResultSet.this.stmt.getExecProps().wasResponseBufferingSet() && SQLServerResultSet.this.stmt.getExecProps().isResponseBufferingAdaptive()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6413 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
/* 6418 */       SQLServerResultSet.this.tdsReader = param1TDSReader;
/* 6419 */       SQLServerResultSet.this.discardFetchBuffer();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void doServerFetch(int paramInt1, int paramInt2, int paramInt3) throws SQLServerException {
/* 6433 */     if (logger.isLoggable(Level.FINER)) {
/* 6434 */       logger.finer(toString() + " fetchType:" + paramInt1 + " startRow:" + paramInt2 + " numRows:" + paramInt3);
/*      */     }
/*      */     
/* 6437 */     discardFetchBuffer();
/*      */ 
/*      */     
/* 6440 */     this.fetchBuffer.init();
/*      */ 
/*      */     
/* 6443 */     CursorFetchCommand cursorFetchCommand = new CursorFetchCommand(this.serverCursorId, paramInt1, paramInt2, paramInt3);
/* 6444 */     this.stmt.executeCommand(cursorFetchCommand);
/*      */     
/* 6446 */     this.numFetchedRows = 0;
/* 6447 */     this.resultSetCurrentRowType = RowType.UNKNOWN;
/* 6448 */     this.areNullCompressedColumnsInitialized = false;
/* 6449 */     this.lastColumnIndex = 0;
/*      */ 
/*      */     
/* 6452 */     if (null != this.scrollWindow && 128 != paramInt1) {
/* 6453 */       this.scrollWindow.resize(this.fetchSize);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6462 */     if (paramInt3 < 0 || paramInt2 < 0) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/* 6467 */         while (this.scrollWindow.next(this));
/*      */       
/*      */       }
/* 6470 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6475 */         if (logger.isLoggable(Level.FINER)) {
/* 6476 */           logger.finer(toString() + " Ignored exception from row error during server cursor fixup: " + sQLException.getMessage());
/*      */         }
/*      */       } 
/*      */       
/* 6480 */       if (this.fetchBuffer.needsServerCursorFixup()) {
/*      */         
/* 6482 */         doServerFetch(1, 0, 0);
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 6487 */       this.scrollWindow.reset();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void discardFetchBuffer() {
/* 6508 */     this.fetchBuffer.clearStartMark();
/*      */ 
/*      */     
/* 6511 */     if (null != this.scrollWindow) {
/* 6512 */       this.scrollWindow.clear();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 6518 */       while (fetchBufferNext());
/*      */     
/*      */     }
/* 6521 */     catch (SQLServerException sQLServerException) {
/*      */       
/* 6523 */       if (logger.isLoggable(Level.FINER)) {
/* 6524 */         logger.finer(this + " Encountered exception discarding fetch buffer: " + sQLServerException.getMessage());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void closeServerCursor() {
/* 6535 */     if (0 == this.serverCursorId) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 6540 */     if (this.stmt.connection.isSessionUnAvailable()) {
/*      */       
/* 6542 */       if (logger.isLoggable(Level.FINER)) {
/* 6543 */         logger.finer(this + ": Not closing cursor:" + this.serverCursorId + "; connection is already closed.");
/*      */       }
/*      */     } else {
/*      */       
/* 6547 */       if (logger.isLoggable(Level.FINER)) {
/* 6548 */         logger.finer(toString() + " Closing cursor:" + this.serverCursorId);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 6573 */         this.stmt.executeCommand(new CloseServerCursorCommand());
/*      */       }
/* 6575 */       catch (SQLServerException sQLServerException) {
/*      */         
/* 6577 */         if (logger.isLoggable(Level.FINER)) {
/* 6578 */           logger.finer(toString() + " Ignored error closing cursor:" + this.serverCursorId + " " + sQLServerException.getMessage());
/*      */         }
/*      */       } 
/* 6581 */       if (logger.isLoggable(Level.FINER))
/* 6582 */         logger.finer(toString() + " Closed cursor:" + this.serverCursorId); 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerResultSet.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */