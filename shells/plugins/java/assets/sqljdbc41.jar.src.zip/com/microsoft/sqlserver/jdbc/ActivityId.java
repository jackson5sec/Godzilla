/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.UUID;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ActivityId
/*     */ {
/*  60 */   private final UUID Id = UUID.randomUUID();
/*  61 */   private long Sequence = 0L;
/*     */   
/*     */   private boolean isSentToServer = false;
/*     */ 
/*     */   
/*     */   UUID getId() {
/*  67 */     return this.Id;
/*     */   }
/*     */ 
/*     */   
/*     */   long getSequence() {
/*  72 */     return this.Sequence;
/*     */   }
/*     */ 
/*     */   
/*     */   void Increment() {
/*  77 */     if (this.Sequence < 4294967295L) {
/*     */       
/*  79 */       this.Sequence++;
/*     */     }
/*     */     else {
/*     */       
/*  83 */       this.Sequence = 0L;
/*     */     } 
/*     */     
/*  86 */     this.isSentToServer = false;
/*     */   }
/*     */ 
/*     */   
/*     */   void setSentFlag() {
/*  91 */     this.isSentToServer = true;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean IsSentToServer() {
/*  96 */     return this.isSentToServer;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 101 */     StringBuilder stringBuilder = new StringBuilder();
/* 102 */     stringBuilder.append(this.Id.toString());
/* 103 */     stringBuilder.append("-");
/* 104 */     stringBuilder.append(this.Sequence);
/* 105 */     return stringBuilder.toString();
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\ActivityId.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */