/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ import java.net.IDN;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.util.HashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.security.auth.login.AppConfigurationEntry;
/*     */ import javax.security.auth.login.Configuration;
/*     */ import javax.security.auth.login.LoginException;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.GSSName;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ final class KerbAuthentication extends SSPIAuthentication {
/*  19 */   private static final Logger authLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.KerbAuthentication");
/*     */   
/*     */   private static final String CONFIGNAME = "SQLJDBCDriver";
/*     */   
/*     */   private final SQLServerConnection con;
/*     */   private final String spn;
/*  25 */   private final GSSManager manager = GSSManager.getInstance();
/*  26 */   private LoginContext lc = null;
/*  27 */   private GSSCredential peerCredentials = null;
/*  28 */   private GSSContext peerContext = null;
/*     */ 
/*     */   
/*     */   static {
/*     */     class SQLJDBCDriverConfig
/*     */       extends Configuration
/*     */     {
/*     */       Configuration current;
/*     */       AppConfigurationEntry[] driverConf;
/*     */       
/*     */       SQLJDBCDriverConfig() {
/*     */         AppConfigurationEntry[] arrayOfAppConfigurationEntry;
/*  40 */         this.current = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/*  47 */           this.current = Configuration.getConfiguration();
/*     */         }
/*  49 */         catch (SecurityException securityException) {
/*     */ 
/*     */           
/*  52 */           KerbAuthentication.authLogger.finer(toString() + " No configurations provided, setting driver default");
/*     */         } 
/*  54 */         this$0 = null;
/*     */         
/*  56 */         if (null != this.current)
/*     */         {
/*  58 */           arrayOfAppConfigurationEntry = this.current.getAppConfigurationEntry("SQLJDBCDriver");
/*     */         }
/*     */         
/*  61 */         if (null == arrayOfAppConfigurationEntry) {
/*     */           AppConfigurationEntry appConfigurationEntry;
/*  63 */           if (KerbAuthentication.authLogger.isLoggable(Level.FINER)) {
/*  64 */             KerbAuthentication.authLogger.finer(toString() + " SQLJDBCDriver configuration entry is not provided, setting driver default");
/*     */           }
/*     */           
/*  67 */           if (Util.isIBM()) {
/*     */             
/*  69 */             HashMap<Object, Object> hashMap = new HashMap<>();
/*  70 */             hashMap.put("useDefaultCcache", "true");
/*  71 */             hashMap.put("moduleBanner", "false");
/*  72 */             appConfigurationEntry = new AppConfigurationEntry("com.ibm.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, (Map)hashMap);
/*  73 */             if (KerbAuthentication.authLogger.isLoggable(Level.FINER)) {
/*  74 */               KerbAuthentication.authLogger.finer(toString() + " Setting IBM Krb5LoginModule");
/*     */             }
/*     */           } else {
/*     */             
/*  78 */             HashMap<Object, Object> hashMap = new HashMap<>();
/*  79 */             hashMap.put("useTicketCache", "true");
/*  80 */             hashMap.put("doNotPrompt", "true");
/*  81 */             appConfigurationEntry = new AppConfigurationEntry("com.sun.security.auth.module.Krb5LoginModule", AppConfigurationEntry.LoginModuleControlFlag.REQUIRED, (Map)hashMap);
/*  82 */             if (KerbAuthentication.authLogger.isLoggable(Level.FINER))
/*  83 */               KerbAuthentication.authLogger.finer(toString() + " Setting Sun Krb5LoginModule"); 
/*     */           } 
/*  85 */           this.driverConf = new AppConfigurationEntry[1];
/*  86 */           this.driverConf[0] = appConfigurationEntry;
/*  87 */           Configuration.setConfiguration(this);
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public AppConfigurationEntry[] getAppConfigurationEntry(String param1String) {
/*  96 */         if (param1String.equals("SQLJDBCDriver"))
/*     */         {
/*  98 */           return this.driverConf;
/*     */         }
/*     */ 
/*     */         
/* 102 */         if (null != this.current) {
/* 103 */           return this.current.getAppConfigurationEntry(param1String);
/*     */         }
/* 105 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void refresh() {
/* 111 */         if (null != this.current)
/* 112 */           this.current.refresh(); 
/*     */       }
/*     */     };
/* 115 */     SQLJDBCDriverConfig sQLJDBCDriverConfig = new SQLJDBCDriverConfig();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void intAuthInit() throws SQLServerException {
/*     */     try {
/* 124 */       Oid oid = new Oid("1.2.840.113554.1.2.2");
/* 125 */       Subject subject = null;
/*     */       
/*     */       try {
/* 128 */         AccessControlContext accessControlContext = AccessController.getContext();
/* 129 */         subject = Subject.getSubject(accessControlContext);
/* 130 */         if (null == subject)
/*     */         {
/* 132 */           this.lc = new LoginContext("SQLJDBCDriver");
/* 133 */           this.lc.login();
/*     */           
/* 135 */           subject = this.lc.getSubject();
/*     */         }
/*     */       
/* 138 */       } catch (LoginException loginException) {
/*     */         
/* 140 */         this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), loginException);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 145 */       GSSName gSSName = this.manager.createName(this.spn, (Oid)null);
/* 146 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 148 */         authLogger.finer(toString() + " Getting client credentials");
/*     */       }
/* 150 */       this.peerCredentials = getClientCredential(subject, this.manager, oid);
/* 151 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 153 */         authLogger.finer(toString() + " creating security context");
/*     */       }
/*     */       
/* 156 */       this.peerContext = this.manager.createContext(gSSName, oid, this.peerCredentials, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       this.peerContext.requestCredDeleg(true);
/* 162 */       this.peerContext.requestMutualAuth(true);
/* 163 */       this.peerContext.requestInteg(true);
/*     */     
/*     */     }
/* 166 */     catch (GSSException gSSException) {
/*     */       
/* 168 */       authLogger.finer(toString() + "initAuthInit failed GSSException:-" + gSSException);
/*     */       
/* 170 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), gSSException);
/*     */     }
/* 172 */     catch (PrivilegedActionException privilegedActionException) {
/*     */       
/* 174 */       authLogger.finer(toString() + "initAuthInit failed privileged exception:-" + privilegedActionException);
/*     */       
/* 176 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), privilegedActionException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static GSSCredential getClientCredential(Subject paramSubject, final GSSManager MANAGER, final Oid kerboid) throws PrivilegedActionException {
/* 186 */     PrivilegedExceptionAction<GSSCredential> privilegedExceptionAction = new PrivilegedExceptionAction<GSSCredential>()
/*     */       {
/*     */         public GSSCredential run() throws GSSException {
/* 189 */           return MANAGER.createCredential((GSSName)null, 0, kerboid, 1);
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     GSSCredential gSSCredential = (GSSCredential)Subject.doAs(paramSubject, (PrivilegedExceptionAction)privilegedExceptionAction);
/* 200 */     return gSSCredential;
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] intAuthHandShake(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException {
/*     */     try {
/* 206 */       if (authLogger.isLoggable(Level.FINER))
/*     */       {
/* 208 */         authLogger.finer(toString() + " Sending token to server over secure context");
/*     */       }
/* 210 */       byte[] arrayOfByte = this.peerContext.initSecContext(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */       
/* 212 */       if (this.peerContext.isEstablished()) {
/*     */         
/* 214 */         paramArrayOfboolean[0] = true;
/* 215 */         if (authLogger.isLoggable(Level.FINER)) {
/* 216 */           authLogger.finer(toString() + "Authentication done.");
/*     */         }
/*     */       }
/* 219 */       else if (null == arrayOfByte) {
/*     */ 
/*     */         
/* 222 */         authLogger.info(toString() + "byteToken is null in initSecContext.");
/* 223 */         this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"));
/*     */       } 
/* 225 */       return arrayOfByte;
/*     */     }
/* 227 */     catch (GSSException gSSException) {
/*     */       
/* 229 */       authLogger.finer(toString() + "initSecContext Failed :-" + gSSException);
/*     */       
/* 231 */       this.con.terminate(0, SQLServerException.getErrString("R_integratedAuthenticationFailed"), gSSException);
/*     */ 
/*     */       
/* 234 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String makeSpn(String paramString, int paramInt) throws SQLServerException {
/* 239 */     if (authLogger.isLoggable(Level.FINER))
/*     */     {
/* 241 */       authLogger.finer(toString() + " Server: " + paramString + " port: " + paramInt);
/*     */     }
/* 243 */     StringBuilder stringBuilder = new StringBuilder("MSSQLSvc/");
/*     */ 
/*     */     
/* 246 */     if (this.con.serverNameAsACE()) {
/*     */       
/* 248 */       stringBuilder.append(IDN.toASCII(paramString));
/*     */     }
/*     */     else {
/*     */       
/* 252 */       stringBuilder.append(paramString);
/*     */     } 
/* 254 */     stringBuilder.append(":");
/* 255 */     stringBuilder.append(paramInt);
/* 256 */     String str = stringBuilder.toString();
/* 257 */     if (authLogger.isLoggable(Level.FINER))
/*     */     {
/* 259 */       authLogger.finer(toString() + " SPN: " + str);
/*     */     }
/* 261 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   KerbAuthentication(SQLServerConnection paramSQLServerConnection, String paramString, int paramInt) throws SQLServerException {
/* 267 */     this.con = paramSQLServerConnection;
/*     */     
/* 269 */     String str = paramSQLServerConnection.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.SERVER_SPN.toString());
/*     */ 
/*     */     
/* 272 */     if (null != str) {
/*     */ 
/*     */       
/* 275 */       if (paramSQLServerConnection.serverNameAsACE())
/*     */       {
/* 277 */         int i = str.indexOf("/");
/* 278 */         this.spn = str.substring(0, i + 1) + IDN.toASCII(str.substring(i + 1));
/*     */       
/*     */       }
/*     */       else
/*     */       {
/* 283 */         this.spn = str;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 288 */       this.spn = makeSpn(paramString, paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   byte[] GenerateClientContext(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException {
/* 294 */     if (null == this.peerContext)
/*     */     {
/* 296 */       intAuthInit();
/*     */     }
/* 298 */     return intAuthHandShake(paramArrayOfbyte, paramArrayOfboolean);
/*     */   }
/*     */ 
/*     */   
/*     */   int ReleaseClientContext() throws SQLServerException {
/*     */     try {
/* 304 */       if (null != this.peerCredentials)
/* 305 */         this.peerCredentials.dispose(); 
/* 306 */       if (null != this.peerContext)
/* 307 */         this.peerContext.dispose(); 
/* 308 */       if (null != this.lc) {
/* 309 */         this.lc.logout();
/*     */       }
/* 311 */     } catch (LoginException loginException) {
/*     */ 
/*     */ 
/*     */       
/* 315 */       authLogger.fine(toString() + " Release of the credentials failed LoginException: " + loginException);
/*     */     }
/* 317 */     catch (GSSException gSSException) {
/*     */ 
/*     */ 
/*     */       
/* 321 */       authLogger.fine(toString() + " Release of the credentials failed GSSException: " + gSSException);
/*     */     } 
/* 323 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\KerbAuthentication.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */