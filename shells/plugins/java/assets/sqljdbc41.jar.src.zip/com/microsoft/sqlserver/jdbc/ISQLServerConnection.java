package com.microsoft.sqlserver.jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.UUID;

public interface ISQLServerConnection extends Connection {
  public static final int TRANSACTION_SNAPSHOT = 4096;
  
  UUID getClientConnectionId() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\ISQLServerConnection.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */