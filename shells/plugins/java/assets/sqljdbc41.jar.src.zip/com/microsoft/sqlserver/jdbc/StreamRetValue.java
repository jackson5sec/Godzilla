/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamRetValue
/*    */   extends StreamPacket
/*    */ {
/*    */   private String paramName;
/*    */   private int ordinalOrLength;
/*    */   private int status;
/*    */   
/*    */   final int getOrdinalOrLength() {
/* 17 */     return this.ordinalOrLength;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   StreamRetValue() {
/* 28 */     super(172);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 33 */     if (172 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 34 */     this.ordinalOrLength = paramTDSReader.readUnsignedShort();
/* 35 */     this.paramName = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/* 36 */     this.status = paramTDSReader.readUnsignedByte();
/*    */   }
/*    */ 
/*    */   
/*    */   CryptoMetadata getCryptoMetadata(TDSReader paramTDSReader) throws SQLServerException {
/* 41 */     return (new StreamColumns()).readCryptoMetadata(paramTDSReader);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamRetValue.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */