/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerBulkCSVFileRecord
/*     */   implements ISQLServerBulkRecord, AutoCloseable
/*     */ {
/*     */   private BufferedReader fileReader;
/*     */   private InputStreamReader sr;
/*     */   private FileInputStream fis;
/*     */   private Map<Integer, ColumnMetadata> columnMetadata;
/*     */   
/*     */   private class ColumnMetadata
/*     */   {
/*     */     String columnName;
/*     */     int columnType;
/*     */     int precision;
/*     */     int scale;
/*  35 */     DateTimeFormatter dateTimeFormatter = null;
/*     */ 
/*     */     
/*     */     ColumnMetadata(String param1String, int param1Int1, int param1Int2, int param1Int3, DateTimeFormatter param1DateTimeFormatter) {
/*  39 */       this.columnName = param1String;
/*  40 */       this.columnType = param1Int1;
/*  41 */       this.precision = param1Int2;
/*  42 */       this.scale = param1Int3;
/*  43 */       this.dateTimeFormatter = param1DateTimeFormatter;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private String currentLine = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String delimiter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private String[] columnNames = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private DateTimeFormatter dateTimeFormatter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private DateTimeFormatter timeFormatter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String loggerClassName = "com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(String paramString1, String paramString2, String paramString3, boolean paramBoolean) throws SQLServerException {
/* 107 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "SQLServerBulkCSVFileRecord", new Object[] { paramString1, paramString2, paramString3, Boolean.valueOf(paramBoolean) });
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (null == paramString1) {
/* 112 */       throwInvalidArgument("fileToParse");
/* 113 */     } else if (null == paramString3) {
/* 114 */       throwInvalidArgument("delimiter");
/*     */     } 
/*     */     
/* 117 */     this.delimiter = paramString3;
/*     */ 
/*     */     
/*     */     try {
/* 121 */       this.fis = new FileInputStream(paramString1);
/* 122 */       if (null == paramString2 || 0 == paramString2.length()) {
/*     */         
/* 124 */         this.sr = new InputStreamReader(this.fis);
/*     */       }
/*     */       else {
/*     */         
/* 128 */         this.sr = new InputStreamReader(this.fis, paramString2);
/*     */       } 
/*     */       
/* 131 */       this.fileReader = new BufferedReader(this.sr);
/*     */       
/* 133 */       if (paramBoolean)
/*     */       {
/* 135 */         this.currentLine = this.fileReader.readLine();
/* 136 */         if (null != this.currentLine)
/*     */         {
/* 138 */           this.columnNames = this.currentLine.split(paramString3, -1);
/*     */         }
/*     */       }
/*     */     
/* 142 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 144 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 145 */       throw new SQLServerException(messageFormat.format(new Object[] { paramString2 }, ), null, 0, null);
/*     */     }
/* 147 */     catch (Exception exception) {
/*     */       
/* 149 */       throw new SQLServerException(null, exception.getMessage(), null, 0, false);
/*     */     } 
/* 151 */     this.columnMetadata = new HashMap<>();
/*     */     
/* 153 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "SQLServerBulkCSVFileRecord");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(String paramString1, String paramString2, boolean paramBoolean) throws SQLServerException {
/* 166 */     this(paramString1, paramString2, ",", paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerBulkCSVFileRecord(String paramString, boolean paramBoolean) throws SQLServerException {
/* 178 */     this(paramString, null, ",", paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnMetadata(int paramInt1, String paramString, int paramInt2, int paramInt3, int paramInt4, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
/* 184 */     DriverJDBCVersion.checkSupportsJDBC42();
/* 185 */     addColumnMetadataInternal(paramInt1, paramString, paramInt2, paramInt3, paramInt4, paramDateTimeFormatter);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addColumnMetadata(int paramInt1, String paramString, int paramInt2, int paramInt3, int paramInt4) throws SQLServerException {
/* 190 */     addColumnMetadataInternal(paramInt1, paramString, paramInt2, paramInt3, paramInt4, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addColumnMetadataInternal(int paramInt1, String paramString, int paramInt2, int paramInt3, int paramInt4, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
/* 205 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "addColumnMetadata", new Object[] { Integer.valueOf(paramInt1), paramString, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3), Integer.valueOf(paramInt4) });
/*     */ 
/*     */     
/* 208 */     String str = "";
/*     */     
/* 210 */     if (0 >= paramInt1) {
/*     */       
/* 212 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumnOrdinal"));
/* 213 */       Object[] arrayOfObject = { Integer.valueOf(paramInt1) };
/* 214 */       throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 217 */     if (null != paramString) {
/* 218 */       str = paramString.trim();
/* 219 */     } else if (this.columnNames != null && this.columnNames.length >= paramInt1) {
/* 220 */       str = this.columnNames[paramInt1 - 1];
/*     */     } 
/*     */     
/* 223 */     if (this.columnNames != null && paramInt1 > this.columnNames.length) {
/*     */       
/* 225 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 226 */       Object[] arrayOfObject = { Integer.valueOf(paramInt1) };
/* 227 */       throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */     } 
/*     */     
/* 230 */     checkDuplicateColumnName(paramInt1, paramString);
/* 231 */     switch (paramInt2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -155:
/*     */       case 91:
/*     */       case 92:
/*     */       case 93:
/* 243 */         this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, paramInt2, 50, paramInt4, paramDateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 2009:
/* 249 */         this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, -16, paramInt3, paramInt4, paramDateTimeFormatter));
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 6:
/* 255 */         this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, 8, paramInt3, paramInt4, paramDateTimeFormatter));
/*     */         break;
/*     */ 
/*     */       
/*     */       case 16:
/* 260 */         this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, -7, paramInt3, paramInt4, paramDateTimeFormatter));
/*     */         break;
/*     */       
/*     */       default:
/* 264 */         this.columnMetadata.put(Integer.valueOf(paramInt1), new ColumnMetadata(str, paramInt2, paramInt3, paramInt4, paramDateTimeFormatter));
/*     */         break;
/*     */     } 
/* 267 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "addColumnMetadata");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimestampWithTimezoneFormat(String paramString) {
/* 276 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat", paramString);
/*     */     
/* 278 */     this.dateTimeFormatter = DateTimeFormatter.ofPattern(paramString);
/*     */     
/* 280 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimestampWithTimezoneFormat(DateTimeFormatter paramDateTimeFormatter) {
/* 289 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat", new Object[] { paramDateTimeFormatter });
/*     */ 
/*     */ 
/*     */     
/* 293 */     this.dateTimeFormatter = paramDateTimeFormatter;
/*     */     
/* 295 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimestampWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeWithTimezoneFormat(String paramString) {
/* 304 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat", paramString);
/*     */     
/* 306 */     this.timeFormatter = DateTimeFormatter.ofPattern(paramString);
/*     */     
/* 308 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTimeWithTimezoneFormat(DateTimeFormatter paramDateTimeFormatter) {
/* 317 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat", new Object[] { paramDateTimeFormatter });
/*     */ 
/*     */     
/* 320 */     this.timeFormatter = paramDateTimeFormatter;
/*     */     
/* 322 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "setTimeWithTimezoneFormat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLServerException {
/* 330 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "close");
/*     */ 
/*     */     
/* 333 */     if (this.fileReader != null) try { this.fileReader.close(); } catch (Exception exception) {} 
/* 334 */     if (this.sr != null) try { this.sr.close(); } catch (Exception exception) {} 
/* 335 */     if (this.fis != null) try { this.fis.close(); } catch (Exception exception) {}
/*     */     
/* 337 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCSVFileRecord", "close");
/*     */   }
/*     */   
/*     */   public DateTimeFormatter getColumnDateTimeFormatter(int paramInt) {
/* 341 */     DriverJDBCVersion.checkSupportsJDBC42();
/* 342 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).dateTimeFormatter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Set<Integer> getColumnOrdinals() {
/* 347 */     return this.columnMetadata.keySet();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getColumnName(int paramInt) {
/* 352 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).columnName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnType(int paramInt) {
/* 357 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).columnType;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPrecision(int paramInt) {
/* 362 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).precision;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getScale(int paramInt) {
/* 367 */     return ((ColumnMetadata)this.columnMetadata.get(Integer.valueOf(paramInt))).scale;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement(int paramInt) {
/* 372 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object[] getRowData() throws SQLServerException {
/* 379 */     if (null == this.currentLine) {
/* 380 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 387 */     String[] arrayOfString = this.currentLine.split(this.delimiter, -1);
/*     */ 
/*     */     
/* 390 */     Object[] arrayOfObject = new Object[arrayOfString.length];
/*     */     
/* 392 */     Iterator<Map.Entry> iterator = this.columnMetadata.entrySet().iterator();
/* 393 */     while (iterator.hasNext()) {
/*     */       
/* 395 */       Map.Entry entry = iterator.next();
/* 396 */       ColumnMetadata columnMetadata = (ColumnMetadata)entry.getValue();
/*     */ 
/*     */ 
/*     */       
/* 400 */       if (arrayOfString.length < ((Integer)entry.getKey()).intValue() - 1) {
/*     */         
/* 402 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 403 */         Object[] arrayOfObject1 = { entry.getKey() };
/* 404 */         throw new SQLServerException(messageFormat.format(arrayOfObject1), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */       } 
/*     */ 
/*     */       
/* 408 */       if (this.columnNames != null && this.columnNames.length > arrayOfString.length) {
/*     */         
/* 410 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkCSVDataSchemaMismatch"));
/* 411 */         Object[] arrayOfObject1 = new Object[0];
/* 412 */         throw new SQLServerException(messageFormat.format(arrayOfObject1), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*     */       }  try {
/*     */         DecimalFormat decimalFormat; BigDecimal bigDecimal; String str1; OffsetTime offsetTime;
/*     */         OffsetDateTime offsetDateTime;
/*     */         String str2;
/* 417 */         if (0 == arrayOfString[((Integer)entry.getKey()).intValue() - 1].length()) {
/*     */           
/* 419 */           arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = null;
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 424 */         switch (columnMetadata.columnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 4:
/* 433 */             decimalFormat = new DecimalFormat("#");
/* 434 */             str2 = decimalFormat.format(Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
/* 435 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Integer.valueOf(str2);
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case -6:
/*     */           case 5:
/* 443 */             decimalFormat = new DecimalFormat("#");
/* 444 */             str2 = decimalFormat.format(Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
/* 445 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Short.valueOf(str2);
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case -5:
/* 451 */             bigDecimal = new BigDecimal(arrayOfString[((Integer)entry.getKey()).intValue() - 1].trim());
/*     */             
/*     */             try {
/* 454 */               arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Long.valueOf(bigDecimal.setScale(0, 1).longValueExact());
/*     */             }
/* 456 */             catch (ArithmeticException arithmeticException) {
/*     */               
/* 458 */               String str = "'" + arrayOfString[((Integer)entry.getKey()).intValue() - 1] + "'";
/* 459 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 460 */               throw new SQLServerException(messageFormat.format(new Object[] { str, JDBCType.of(columnMetadata.columnType) }, ), null, 0, null);
/*     */             } 
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case 2:
/*     */           case 3:
/* 468 */             bigDecimal = new BigDecimal(arrayOfString[((Integer)entry.getKey()).intValue() - 1].trim());
/*     */             
/* 470 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = bigDecimal.setScale(columnMetadata.scale, RoundingMode.HALF_UP);
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case -7:
/*     */             try {
/* 480 */               arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = (0.0D == Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1])) ? Boolean.FALSE : Boolean.TRUE;
/*     */ 
/*     */             
/*     */             }
/* 484 */             catch (NumberFormatException numberFormatException) {
/*     */               
/* 486 */               arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Boolean.valueOf(Boolean.parseBoolean(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
/*     */             } 
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case 7:
/* 493 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Float.valueOf(Float.parseFloat(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case 8:
/* 499 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = Double.valueOf(Double.parseDouble(arrayOfString[((Integer)entry.getKey()).intValue() - 1]));
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case -4:
/*     */           case -3:
/*     */           case -2:
/*     */           case 2004:
/* 520 */             str1 = arrayOfString[((Integer)entry.getKey()).intValue() - 1].trim();
/* 521 */             if (str1.startsWith("0x") || str1.startsWith("0X")) {
/*     */ 
/*     */               
/* 524 */               arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = str1.substring(2);
/*     */               
/*     */               continue;
/*     */             } 
/* 528 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = str1;
/*     */             continue;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           case 2013:
/* 535 */             DriverJDBCVersion.checkSupportsJDBC42();
/* 536 */             str1 = null;
/*     */ 
/*     */             
/* 539 */             if (null != columnMetadata.dateTimeFormatter) {
/* 540 */               offsetTime = OffsetTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], columnMetadata.dateTimeFormatter);
/* 541 */             } else if (this.timeFormatter != null) {
/* 542 */               offsetTime = OffsetTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], this.timeFormatter);
/*     */             } else {
/* 544 */               offsetTime = OffsetTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1]);
/*     */             } 
/* 546 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = offsetTime;
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case 2014:
/* 552 */             DriverJDBCVersion.checkSupportsJDBC42();
/* 553 */             offsetTime = null;
/*     */ 
/*     */             
/* 556 */             if (null != columnMetadata.dateTimeFormatter) {
/* 557 */               offsetDateTime = OffsetDateTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], columnMetadata.dateTimeFormatter);
/* 558 */             } else if (this.dateTimeFormatter != null) {
/* 559 */               offsetDateTime = OffsetDateTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1], this.dateTimeFormatter);
/*     */             } else {
/* 561 */               offsetDateTime = OffsetDateTime.parse(arrayOfString[((Integer)entry.getKey()).intValue() - 1]);
/*     */             } 
/* 563 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = offsetDateTime;
/*     */             continue;
/*     */ 
/*     */ 
/*     */           
/*     */           case 0:
/* 569 */             arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = null;
/*     */             continue;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 609 */         arrayOfObject[((Integer)entry.getKey()).intValue() - 1] = arrayOfString[((Integer)entry.getKey()).intValue() - 1];
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 614 */       catch (IllegalArgumentException illegalArgumentException) {
/*     */         
/* 616 */         String str = "'" + arrayOfString[((Integer)entry.getKey()).intValue() - 1] + "'";
/* 617 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 618 */         throw new SQLServerException(messageFormat.format(new Object[] { str, JDBCType.of(columnMetadata.columnType) }, ), null, 0, null);
/*     */       }
/* 620 */       catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
/*     */         
/* 622 */         throw new SQLServerException(SQLServerException.getErrString("R_BulkCSVDataSchemaMismatch"), null);
/*     */       } 
/*     */     } 
/*     */     
/* 626 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean next() throws SQLServerException {
/*     */     try {
/* 633 */       this.currentLine = this.fileReader.readLine();
/* 634 */     } catch (IOException iOException) {
/* 635 */       throw new SQLServerException(null, iOException.getMessage(), null, 0, false);
/*     */     } 
/* 637 */     return (null != this.currentLine);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void throwInvalidArgument(String paramString) throws SQLServerException {
/* 645 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 646 */     Object[] arrayOfObject = { paramString };
/* 647 */     SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkDuplicateColumnName(int paramInt, String paramString) throws SQLServerException {
/* 657 */     if (null != paramString && paramString.trim().length() != 0)
/*     */     {
/* 659 */       for (Map.Entry<Integer, ColumnMetadata> entry : this.columnMetadata.entrySet()) {
/*     */ 
/*     */         
/* 662 */         if (null != entry && ((Integer)entry.getKey()).intValue() != paramInt)
/*     */         {
/* 664 */           if (null != entry.getValue() && paramString.trim().equalsIgnoreCase(((ColumnMetadata)entry.getValue()).columnName))
/*     */           {
/*     */             
/* 667 */             throw new SQLServerException(SQLServerException.getErrString("R_BulkCSVDataDuplicateColumn"), null);
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerBulkCSVFileRecord.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */