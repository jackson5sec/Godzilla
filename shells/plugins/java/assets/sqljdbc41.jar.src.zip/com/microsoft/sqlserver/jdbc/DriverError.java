/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum DriverError
/*    */ {
/* 34 */   NOT_SET(0);
/*    */   
/*    */   final int getErrorCode() {
/* 37 */     return this.errorCode;
/*    */   }
/*    */   private final int errorCode;
/*    */   DriverError(int paramInt1) {
/* 41 */     this.errorCode = paramInt1;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\DriverError.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */