package com.microsoft.sqlserver.jdbc;

final class SQLJdbcVersion {
  static final int major = 6;
  
  static final int minor = 0;
  
  static final int MMDD = 8112;
  
  static final int revision = 200;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLJdbcVersion.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */