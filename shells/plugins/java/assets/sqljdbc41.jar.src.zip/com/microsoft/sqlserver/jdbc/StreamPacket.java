/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class StreamPacket
/*    */ {
/*    */   int packetType;
/*    */   
/*    */   final int getTokenType() {
/* 13 */     return this.packetType;
/*    */   }
/*    */   
/*    */   StreamPacket() {
/* 17 */     this.packetType = 0;
/*    */   }
/*    */ 
/*    */   
/*    */   StreamPacket(int paramInt) {
/* 22 */     this.packetType = paramInt;
/*    */   }
/*    */   
/*    */   abstract void setFromTDS(TDSReader paramTDSReader) throws SQLServerException;
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\StreamPacket.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */