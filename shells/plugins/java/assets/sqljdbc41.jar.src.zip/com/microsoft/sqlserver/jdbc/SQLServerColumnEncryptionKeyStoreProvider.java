package com.microsoft.sqlserver.jdbc;

public abstract class SQLServerColumnEncryptionKeyStoreProvider {
  public abstract void setName(String paramString);
  
  public abstract String getName();
  
  public abstract byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException;
  
  public abstract byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerColumnEncryptionKeyStoreProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */