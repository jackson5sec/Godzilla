/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLFeatureNotSupportedException;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Properties;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class SQLServerDriver
/*      */   implements Driver
/*      */ {
/*      */   static final String PRODUCT_NAME = "Microsoft JDBC Driver 6.0 for SQL Server";
/*      */   static final String DEFAULT_APP_NAME = "Microsoft JDBC Driver for SQL Server";
/*  936 */   private static final String[] TRUE_FALSE = new String[] { "true", "false" };
/*  937 */   private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES = new SQLServerDriverPropertyInfo[] { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue(), false, new String[] { ApplicationIntent.READ_ONLY.toString(), ApplicationIntent.READ_WRITE.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue(), false, new String[] { ColumnEncryptionSetting.Disabled.toString(), ColumnEncryptionSetting.Enabled.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.DATABASE_NAME.toString(), SQLServerDriverStringProperty.DATABASE_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.toString(), Boolean.toString(SQLServerDriverBooleanProperty.DISABLE_STATEMENT_POOLING.getDefaultValue()), false, new String[] { "true" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.ENCRYPT.toString(), Boolean.toString(SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), SQLServerDriverStringProperty.FAILOVER_PARTNER.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.INSTANCE_NAME.toString(), SQLServerDriverStringProperty.INSTANCE_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), Boolean.toString(SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.getDefaultValue(), false, new String[] { KeyStoreAuthentication.JavaKeyStorePassword.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_SECRET.toString(), SQLServerDriverStringProperty.KEY_STORE_SECRET.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), SQLServerDriverStringProperty.KEY_STORE_LOCATION.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), Boolean.toString(SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), Integer.toString(SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), Integer.toString(SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), Boolean.toString(SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PACKET_SIZE.toString(), Integer.toString(SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.PASSWORD.toString(), SQLServerDriverStringProperty.PASSWORD.getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverIntProperty.PORT_NUMBER.toString(), Integer.toString(SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue()), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue(), false, new String[] { "adaptive", "full" }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue(), false, new String[] { "direct", "cursor" }), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_NAME.toString(), SQLServerDriverStringProperty.SERVER_NAME.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.SERVER_SPN.toString(), SQLServerDriverStringProperty.SERVER_SPN.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), Boolean.toString(SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), Boolean.toString(SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE.toString(), SQLServerDriverStringProperty.TRUST_STORE.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), Boolean.toString(SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.USER.toString(), SQLServerDriverStringProperty.USER.getDefaultValue(), true, null), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.WORKSTATION_ID.toString(), SQLServerDriverStringProperty.WORKSTATION_ID.getDefaultValue(), false, null), new SQLServerDriverPropertyInfo(SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), Boolean.toString(SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue()), false, TRUE_FALSE), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.getDefaultValue(), false, new String[] { AuthenticationScheme.javaKerberos.toString(), AuthenticationScheme.nativeAuthentication.toString() }), new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.AUTHENTICATION.toString(), SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue(), false, new String[] { SqlAuthentication.NotSpecified.toString(), SqlAuthentication.SqlPassword.toString(), SqlAuthentication.ActiveDirectoryPassword.toString(), SqlAuthentication.ActiveDirectoryIntegrated.toString() }) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  981 */   private static final SQLServerDriverPropertyInfo[] DRIVER_PROPERTIES_PROPERTY_ONLY = new SQLServerDriverPropertyInfo[] { new SQLServerDriverPropertyInfo(SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), SQLServerDriverStringProperty.ACCESS_TOKEN.getDefaultValue(), false, null) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  988 */   private static final String[][] driverPropertiesSynonyms = new String[][] { { "database", SQLServerDriverStringProperty.DATABASE_NAME.toString() }, { "userName", SQLServerDriverStringProperty.USER.toString() }, { "server", SQLServerDriverStringProperty.SERVER_NAME.toString() }, { "port", SQLServerDriverIntProperty.PORT_NUMBER.toString() } };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  994 */   private static int baseID = 0;
/*      */   
/*      */   private final int instanceID;
/*      */   
/*      */   private final String traceID;
/*      */   
/*      */   private static synchronized int nextInstanceID() {
/* 1001 */     baseID++;
/* 1002 */     return baseID;
/*      */   }
/*      */   
/*      */   public final String toString() {
/* 1006 */     return this.traceID;
/*      */   }
/* 1008 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Driver");
/*      */   
/*      */   private final String loggingClassName;
/*      */   
/*      */   String getClassNameLogging() {
/* 1013 */     return this.loggingClassName;
/*      */   }
/*      */   
/* 1016 */   private static final Logger drLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDriver");
/*      */   
/*      */   static {
/*      */     try {
/* 1020 */       DriverManager.registerDriver(new SQLServerDriver());
/*      */     }
/* 1022 */     catch (SQLException sQLException) {
/* 1023 */       sQLException.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public SQLServerDriver() {
/* 1029 */     this.instanceID = nextInstanceID();
/* 1030 */     this.traceID = "SQLServerDriver:" + this.instanceID;
/* 1031 */     this.loggingClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver:" + this.instanceID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Properties fixupProperties(Properties paramProperties) throws SQLServerException {
/* 1039 */     Properties properties = new Properties();
/* 1040 */     Enumeration<String> enumeration = paramProperties.keys();
/* 1041 */     while (enumeration.hasMoreElements()) {
/*      */       
/* 1043 */       String str1 = enumeration.nextElement();
/* 1044 */       String str2 = getNormalizedPropertyName(str1, drLogger);
/*      */       
/* 1046 */       if (null == str2) {
/* 1047 */         str2 = getPropertyOnlyName(str1, drLogger);
/*      */       }
/*      */       
/* 1050 */       if (null != str2) {
/*      */         
/* 1052 */         String str = paramProperties.getProperty(str1);
/* 1053 */         if (null != str) {
/*      */ 
/*      */           
/* 1056 */           properties.setProperty(str2, str);
/*      */           
/*      */           continue;
/*      */         } 
/* 1060 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidpropertyValue"));
/* 1061 */         Object[] arrayOfObject = { str1 };
/* 1062 */         throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1067 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Properties mergeURLAndSuppliedProperties(Properties paramProperties1, Properties paramProperties2) throws SQLServerException {
/* 1074 */     if (null == paramProperties2) return paramProperties1; 
/* 1075 */     if (paramProperties2.isEmpty()) return paramProperties1;
/*      */     
/* 1077 */     Properties properties = fixupProperties(paramProperties2);
/*      */     
/*      */     byte b;
/* 1080 */     for (b = 0; b < DRIVER_PROPERTIES.length; b++) {
/*      */       
/* 1082 */       String str1 = DRIVER_PROPERTIES[b].getName();
/* 1083 */       String str2 = properties.getProperty(str1);
/* 1084 */       if (null != str2)
/*      */       {
/*      */         
/* 1087 */         paramProperties1.put(str1, str2);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1092 */     for (b = 0; b < DRIVER_PROPERTIES_PROPERTY_ONLY.length; b++) {
/*      */       
/* 1094 */       String str1 = DRIVER_PROPERTIES_PROPERTY_ONLY[b].getName();
/* 1095 */       String str2 = properties.getProperty(str1);
/* 1096 */       if (null != str2)
/*      */       {
/*      */         
/* 1099 */         paramProperties1.put(str1, str2);
/*      */       }
/*      */     } 
/*      */     
/* 1103 */     return paramProperties1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String getNormalizedPropertyName(String paramString, Logger paramLogger) {
/* 1113 */     if (null == paramString)
/* 1114 */       return paramString; 
/*      */     byte b;
/* 1116 */     for (b = 0; b < driverPropertiesSynonyms.length; b++) {
/*      */       
/* 1118 */       if (driverPropertiesSynonyms[b][0].equalsIgnoreCase(paramString))
/*      */       {
/* 1120 */         return driverPropertiesSynonyms[b][1];
/*      */       }
/*      */     } 
/* 1123 */     for (b = 0; b < DRIVER_PROPERTIES.length; b++) {
/*      */       
/* 1125 */       if (DRIVER_PROPERTIES[b].getName().equalsIgnoreCase(paramString))
/*      */       {
/* 1127 */         return DRIVER_PROPERTIES[b].getName();
/*      */       }
/*      */     } 
/*      */     
/* 1131 */     if (paramLogger.isLoggable(Level.FINER))
/* 1132 */       paramLogger.finer("Unknown property" + paramString); 
/* 1133 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String getPropertyOnlyName(String paramString, Logger paramLogger) {
/* 1143 */     if (null == paramString) {
/* 1144 */       return paramString;
/*      */     }
/* 1146 */     for (byte b = 0; b < DRIVER_PROPERTIES_PROPERTY_ONLY.length; b++) {
/*      */       
/* 1148 */       if (DRIVER_PROPERTIES_PROPERTY_ONLY[b].getName().equalsIgnoreCase(paramString)) {
/* 1149 */         return DRIVER_PROPERTIES_PROPERTY_ONLY[b].getName();
/*      */       }
/*      */     } 
/*      */     
/* 1153 */     if (paramLogger.isLoggable(Level.FINER))
/* 1154 */       paramLogger.finer("Unknown property" + paramString); 
/* 1155 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public Connection connect(String paramString, Properties paramProperties) throws SQLServerException {
/* 1160 */     loggerExternal.entering(getClassNameLogging(), "connect", "Arguments not traced.");
/* 1161 */     SQLServerConnection sQLServerConnection = null;
/*      */ 
/*      */     
/* 1164 */     Properties properties = parseAndMergeProperties(paramString, paramProperties);
/* 1165 */     if (properties != null) {
/*      */       
/* 1167 */       sQLServerConnection = new SQLServerConnection(toString());
/* 1168 */       sQLServerConnection.connect(properties, null);
/*      */     } 
/* 1170 */     loggerExternal.exiting(getClassNameLogging(), "connect", sQLServerConnection);
/* 1171 */     return sQLServerConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final Properties parseAndMergeProperties(String paramString, Properties paramProperties) throws SQLServerException {
/* 1177 */     if (paramString == null)
/*      */     {
/* 1179 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*      */     }
/*      */     
/* 1182 */     Properties properties = Util.parseUrl(paramString, drLogger);
/* 1183 */     if (properties == null) {
/* 1184 */       return null;
/*      */     }
/*      */     
/* 1187 */     int i = DriverManager.getLoginTimeout();
/* 1188 */     if (i > 0)
/*      */     {
/* 1190 */       properties.put(SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), (new Integer(i)).toString());
/*      */     }
/*      */ 
/*      */     
/* 1194 */     properties = mergeURLAndSuppliedProperties(properties, paramProperties);
/* 1195 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean acceptsURL(String paramString) throws SQLServerException {
/* 1201 */     loggerExternal.entering(getClassNameLogging(), "acceptsURL", "Arguments not traced.");
/*      */     
/* 1203 */     if (null == paramString)
/*      */     {
/* 1205 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*      */     }
/*      */     
/* 1208 */     boolean bool = false;
/*      */     
/*      */     try {
/* 1211 */       bool = (Util.parseUrl(paramString, drLogger) != null) ? true : false;
/*      */     }
/* 1213 */     catch (SQLServerException sQLServerException) {
/*      */ 
/*      */       
/* 1216 */       bool = false;
/*      */     } 
/* 1218 */     loggerExternal.exiting(getClassNameLogging(), "acceptsURL", Boolean.valueOf(bool));
/* 1219 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLServerException {
/* 1224 */     loggerExternal.entering(getClassNameLogging(), "getPropertyInfo", "Arguments not traced.");
/*      */ 
/*      */     
/* 1227 */     Properties properties = parseAndMergeProperties(paramString, paramProperties);
/*      */     
/* 1229 */     if (null == properties)
/* 1230 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false); 
/* 1231 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = getPropertyInfoFromProperties(properties);
/* 1232 */     loggerExternal.exiting(getClassNameLogging(), "getPropertyInfo");
/*      */     
/* 1234 */     return arrayOfDriverPropertyInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   static final DriverPropertyInfo[] getPropertyInfoFromProperties(Properties paramProperties) {
/* 1239 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[DRIVER_PROPERTIES.length];
/*      */     
/* 1241 */     for (byte b = 0; b < DRIVER_PROPERTIES.length; b++)
/* 1242 */       arrayOfDriverPropertyInfo[b] = DRIVER_PROPERTIES[b].build(paramProperties); 
/* 1243 */     return arrayOfDriverPropertyInfo;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMajorVersion() {
/* 1248 */     loggerExternal.entering(getClassNameLogging(), "getMajorVersion");
/* 1249 */     loggerExternal.exiting(getClassNameLogging(), "getMajorVersion", new Integer(6));
/* 1250 */     return 6;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMinorVersion() {
/* 1255 */     loggerExternal.entering(getClassNameLogging(), "getMinorVersion");
/* 1256 */     loggerExternal.exiting(getClassNameLogging(), "getMinorVersion", new Integer(0));
/* 1257 */     return 0;
/*      */   }
/*      */   
/*      */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/* 1261 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */ 
/*      */     
/* 1264 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*      */   }
/*      */   
/*      */   public boolean jdbcCompliant() {
/* 1268 */     loggerExternal.entering(getClassNameLogging(), "jdbcCompliant");
/* 1269 */     loggerExternal.exiting(getClassNameLogging(), "jdbcCompliant", Boolean.valueOf(true));
/* 1270 */     return true;
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\sqljdbc41.jar!\com\microsoft\sqlserver\jdbc\SQLServerDriver.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */