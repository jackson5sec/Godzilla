/*    */ package com.sun.jna.platform.win32;
/*    */ 
/*    */ import com.sun.jna.Native;
/*    */ import com.sun.jna.Pointer;
/*    */ import com.sun.jna.ptr.IntByReference;
/*    */ import com.sun.jna.ptr.LongByReference;
/*    */ import com.sun.jna.ptr.PointerByReference;
/*    */ import com.sun.jna.win32.W32APIOptions;
/*    */ import java.nio.Buffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Kernel32
/*    */   extends WinNT
/*    */ {
/* 31 */   public static final Kernel32 INSTANCE = (Kernel32)Native.loadLibrary("kernel32", Kernel32.class, W32APIOptions.UNICODE_OPTIONS);
/*    */   
/*    */   int FormatMessage(int paramInt1, Pointer paramPointer1, int paramInt2, int paramInt3, Buffer paramBuffer, int paramInt4, Pointer paramPointer2);
/*    */   
/*    */   boolean ReadFile(WinNT.HANDLE paramHANDLE, Buffer paramBuffer, int paramInt, IntByReference paramIntByReference, WinBase.OVERLAPPED paramOVERLAPPED);
/*    */   
/*    */   Pointer LocalFree(Pointer paramPointer);
/*    */   
/*    */   Pointer GlobalFree(Pointer paramPointer);
/*    */   
/*    */   WinDef.HMODULE GetModuleHandle(String paramString);
/*    */   
/*    */   void GetSystemTime(WinBase.SYSTEMTIME paramSYSTEMTIME);
/*    */   
/*    */   void GetLocalTime(WinBase.SYSTEMTIME paramSYSTEMTIME);
/*    */   
/*    */   int GetTickCount();
/*    */   
/*    */   int GetCurrentThreadId();
/*    */   
/*    */   WinNT.HANDLE GetCurrentThread();
/*    */   
/*    */   int GetCurrentProcessId();
/*    */   
/*    */   WinNT.HANDLE GetCurrentProcess();
/*    */   
/*    */   int GetProcessId(WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   int GetProcessVersion(int paramInt);
/*    */   
/*    */   boolean GetExitCodeProcess(WinNT.HANDLE paramHANDLE, IntByReference paramIntByReference);
/*    */   
/*    */   boolean TerminateProcess(WinNT.HANDLE paramHANDLE, int paramInt);
/*    */   
/*    */   int GetLastError();
/*    */   
/*    */   void SetLastError(int paramInt);
/*    */   
/*    */   int GetDriveType(String paramString);
/*    */   
/*    */   int FormatMessage(int paramInt1, Pointer paramPointer1, int paramInt2, int paramInt3, Pointer paramPointer2, int paramInt4, Pointer paramPointer3);
/*    */   
/*    */   int FormatMessage(int paramInt1, Pointer paramPointer1, int paramInt2, int paramInt3, PointerByReference paramPointerByReference, int paramInt4, Pointer paramPointer2);
/*    */   
/*    */   WinNT.HANDLE CreateFile(String paramString, int paramInt1, int paramInt2, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, int paramInt3, int paramInt4, WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   boolean CopyFile(String paramString1, String paramString2, boolean paramBoolean);
/*    */   
/*    */   boolean MoveFile(String paramString1, String paramString2);
/*    */   
/*    */   boolean MoveFileEx(String paramString1, String paramString2, WinDef.DWORD paramDWORD);
/*    */   
/*    */   boolean CreateDirectory(String paramString, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES);
/*    */   
/*    */   boolean ReadFile(WinNT.HANDLE paramHANDLE, Pointer paramPointer, int paramInt, IntByReference paramIntByReference, WinBase.OVERLAPPED paramOVERLAPPED);
/*    */   
/*    */   WinNT.HANDLE CreateIoCompletionPort(WinNT.HANDLE paramHANDLE1, WinNT.HANDLE paramHANDLE2, Pointer paramPointer, int paramInt);
/*    */   
/*    */   boolean GetQueuedCompletionStatus(WinNT.HANDLE paramHANDLE, IntByReference paramIntByReference, BaseTSD.ULONG_PTRByReference paramULONG_PTRByReference, PointerByReference paramPointerByReference, int paramInt);
/*    */   
/*    */   boolean PostQueuedCompletionStatus(WinNT.HANDLE paramHANDLE, int paramInt, Pointer paramPointer, WinBase.OVERLAPPED paramOVERLAPPED);
/*    */   
/*    */   int WaitForSingleObject(WinNT.HANDLE paramHANDLE, int paramInt);
/*    */   
/*    */   int WaitForMultipleObjects(int paramInt1, WinNT.HANDLE[] paramArrayOfHANDLE, boolean paramBoolean, int paramInt2);
/*    */   
/*    */   boolean DuplicateHandle(WinNT.HANDLE paramHANDLE1, WinNT.HANDLE paramHANDLE2, WinNT.HANDLE paramHANDLE3, WinNT.HANDLEByReference paramHANDLEByReference, int paramInt1, boolean paramBoolean, int paramInt2);
/*    */   
/*    */   boolean CloseHandle(WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   boolean ReadDirectoryChangesW(WinNT.HANDLE paramHANDLE, WinNT.FILE_NOTIFY_INFORMATION paramFILE_NOTIFY_INFORMATION, int paramInt1, boolean paramBoolean, int paramInt2, IntByReference paramIntByReference, WinBase.OVERLAPPED paramOVERLAPPED, WinNT.OVERLAPPED_COMPLETION_ROUTINE paramOVERLAPPED_COMPLETION_ROUTINE);
/*    */   
/*    */   int GetShortPathName(String paramString, char[] paramArrayOfchar, int paramInt);
/*    */   
/*    */   Pointer LocalAlloc(int paramInt1, int paramInt2);
/*    */   
/*    */   boolean WriteFile(WinNT.HANDLE paramHANDLE, byte[] paramArrayOfbyte, int paramInt, IntByReference paramIntByReference, WinBase.OVERLAPPED paramOVERLAPPED);
/*    */   
/*    */   WinNT.HANDLE CreateEvent(WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, boolean paramBoolean1, boolean paramBoolean2, String paramString);
/*    */   
/*    */   boolean SetEvent(WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   boolean ResetEvent(WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   boolean PulseEvent(WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   WinNT.HANDLE CreateFileMapping(WinNT.HANDLE paramHANDLE, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, int paramInt1, int paramInt2, int paramInt3, String paramString);
/*    */   
/*    */   Pointer MapViewOfFile(WinNT.HANDLE paramHANDLE, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*    */   
/*    */   boolean UnmapViewOfFile(Pointer paramPointer);
/*    */   
/*    */   boolean GetComputerName(char[] paramArrayOfchar, IntByReference paramIntByReference);
/*    */   
/*    */   WinNT.HANDLE OpenThread(int paramInt1, boolean paramBoolean, int paramInt2);
/*    */   
/*    */   boolean CreateProcess(String paramString1, String paramString2, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES1, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES2, boolean paramBoolean, WinDef.DWORD paramDWORD, Pointer paramPointer, String paramString3, WinBase.STARTUPINFO paramSTARTUPINFO, WinBase.PROCESS_INFORMATION paramPROCESS_INFORMATION);
/*    */   
/*    */   boolean CreateProcessW(String paramString1, char[] paramArrayOfchar, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES1, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES2, boolean paramBoolean, WinDef.DWORD paramDWORD, Pointer paramPointer, String paramString2, WinBase.STARTUPINFO paramSTARTUPINFO, WinBase.PROCESS_INFORMATION paramPROCESS_INFORMATION);
/*    */   
/*    */   WinNT.HANDLE OpenProcess(int paramInt1, boolean paramBoolean, int paramInt2);
/*    */   
/*    */   WinDef.DWORD GetTempPath(WinDef.DWORD paramDWORD, char[] paramArrayOfchar);
/*    */   
/*    */   WinDef.DWORD GetVersion();
/*    */   
/*    */   boolean GetVersionEx(WinNT.OSVERSIONINFO paramOSVERSIONINFO);
/*    */   
/*    */   boolean GetVersionEx(WinNT.OSVERSIONINFOEX paramOSVERSIONINFOEX);
/*    */   
/*    */   void GetSystemInfo(WinBase.SYSTEM_INFO paramSYSTEM_INFO);
/*    */   
/*    */   void GetNativeSystemInfo(WinBase.SYSTEM_INFO paramSYSTEM_INFO);
/*    */   
/*    */   boolean IsWow64Process(WinNT.HANDLE paramHANDLE, IntByReference paramIntByReference);
/*    */   
/*    */   boolean GetLogicalProcessorInformation(Pointer paramPointer, WinDef.DWORDByReference paramDWORDByReference);
/*    */   
/*    */   boolean GlobalMemoryStatusEx(WinBase.MEMORYSTATUSEX paramMEMORYSTATUSEX);
/*    */   
/*    */   boolean GetFileTime(WinNT.HANDLE paramHANDLE, WinBase.FILETIME paramFILETIME1, WinBase.FILETIME paramFILETIME2, WinBase.FILETIME paramFILETIME3);
/*    */   
/*    */   int SetFileTime(WinNT.HANDLE paramHANDLE, WinBase.FILETIME paramFILETIME1, WinBase.FILETIME paramFILETIME2, WinBase.FILETIME paramFILETIME3);
/*    */   
/*    */   boolean SetFileAttributes(String paramString, WinDef.DWORD paramDWORD);
/*    */   
/*    */   WinDef.DWORD GetLogicalDriveStrings(WinDef.DWORD paramDWORD, char[] paramArrayOfchar);
/*    */   
/*    */   boolean GetDiskFreeSpaceEx(String paramString, WinNT.LARGE_INTEGER paramLARGE_INTEGER1, WinNT.LARGE_INTEGER paramLARGE_INTEGER2, WinNT.LARGE_INTEGER paramLARGE_INTEGER3);
/*    */   
/*    */   boolean DeleteFile(String paramString);
/*    */   
/*    */   boolean CreatePipe(WinNT.HANDLEByReference paramHANDLEByReference1, WinNT.HANDLEByReference paramHANDLEByReference2, WinBase.SECURITY_ATTRIBUTES paramSECURITY_ATTRIBUTES, int paramInt);
/*    */   
/*    */   boolean SetHandleInformation(WinNT.HANDLE paramHANDLE, int paramInt1, int paramInt2);
/*    */   
/*    */   int GetFileAttributes(String paramString);
/*    */   
/*    */   int GetFileType(WinNT.HANDLE paramHANDLE);
/*    */   
/*    */   boolean DeviceIoControl(WinNT.HANDLE paramHANDLE, int paramInt1, Pointer paramPointer1, int paramInt2, Pointer paramPointer2, int paramInt3, IntByReference paramIntByReference, Pointer paramPointer3);
/*    */   
/*    */   boolean GetDiskFreeSpaceEx(String paramString, LongByReference paramLongByReference1, LongByReference paramLongByReference2, LongByReference paramLongByReference3);
/*    */   
/*    */   WinNT.HANDLE CreateToolhelp32Snapshot(WinDef.DWORD paramDWORD1, WinDef.DWORD paramDWORD2);
/*    */   
/*    */   boolean Process32First(WinNT.HANDLE paramHANDLE, Tlhelp32.PROCESSENTRY32 paramPROCESSENTRY32);
/*    */   
/*    */   boolean Process32Next(WinNT.HANDLE paramHANDLE, Tlhelp32.PROCESSENTRY32 paramPROCESSENTRY32);
/*    */   
/*    */   boolean SetEnvironmentVariable(String paramString1, String paramString2);
/*    */   
/*    */   int GetEnvironmentVariable(String paramString, char[] paramArrayOfchar, int paramInt);
/*    */   
/*    */   WinDef.LCID GetSystemDefaultLCID();
/*    */   
/*    */   WinDef.LCID GetUserDefaultLCID();
/*    */   
/*    */   int GetPrivateProfileInt(String paramString1, String paramString2, int paramInt, String paramString3);
/*    */   
/*    */   WinDef.DWORD GetPrivateProfileString(String paramString1, String paramString2, String paramString3, char[] paramArrayOfchar, WinDef.DWORD paramDWORD, String paramString4);
/*    */   
/*    */   boolean WritePrivateProfileString(String paramString1, String paramString2, String paramString3, String paramString4);
/*    */   
/*    */   WinDef.DWORD GetPrivateProfileSection(String paramString1, char[] paramArrayOfchar, WinDef.DWORD paramDWORD, String paramString2);
/*    */   
/*    */   WinDef.DWORD GetPrivateProfileSectionNames(char[] paramArrayOfchar, WinDef.DWORD paramDWORD, String paramString);
/*    */   
/*    */   boolean WritePrivateProfileSection(String paramString1, String paramString2, String paramString3);
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\Kernel32.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */