package com.sun.jna;

public interface AltCallingConvention {}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\AltCallingConvention.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */