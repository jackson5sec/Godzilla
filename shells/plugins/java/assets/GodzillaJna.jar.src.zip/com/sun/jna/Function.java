/*     */ package com.sun.jna;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Function
/*     */   extends Pointer
/*     */ {
/*     */   public static final int MAX_NARGS = 256;
/*     */   public static final int C_CONVENTION = 0;
/*     */   public static final int ALT_CONVENTION = 1;
/*     */   private static final int MASK_CC = 3;
/*     */   public static final int THROW_LAST_ERROR = 4;
/*  64 */   static final Integer INTEGER_TRUE = new Integer(-1);
/*  65 */   static final Integer INTEGER_FALSE = new Integer(0);
/*     */ 
/*     */   
/*     */   private NativeLibrary library;
/*     */ 
/*     */   
/*     */   private final String functionName;
/*     */   
/*     */   final String encoding;
/*     */   
/*     */   final int callFlags;
/*     */   
/*     */   final Map options;
/*     */   
/*     */   static final String OPTION_INVOKING_METHOD = "invoking-method";
/*     */ 
/*     */   
/*     */   public static Function getFunction(String libraryName, String functionName) {
/*  83 */     return NativeLibrary.getInstance(libraryName).getFunction(functionName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(String libraryName, String functionName, int callFlags) {
/* 104 */     return NativeLibrary.getInstance(libraryName).getFunction(functionName, callFlags, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(String libraryName, String functionName, int callFlags, String encoding) {
/* 128 */     return NativeLibrary.getInstance(libraryName).getFunction(functionName, callFlags, encoding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(Pointer p) {
/* 143 */     return getFunction(p, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Function getFunction(Pointer p, int callFlags) {
/* 161 */     return new Function(p, callFlags, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function(NativeLibrary library, String functionName, int callFlags, String encoding) {
/* 195 */     checkCallingConvention(callFlags & 0x3);
/* 196 */     if (functionName == null)
/* 197 */       throw new NullPointerException("Function name must not be null"); 
/* 198 */     this.library = library;
/* 199 */     this.functionName = functionName;
/* 200 */     this.callFlags = callFlags;
/* 201 */     this.options = library.options;
/* 202 */     this.encoding = (encoding != null) ? encoding : Native.getDefaultStringEncoding();
/*     */     
/*     */     try {
/* 205 */       this.peer = library.getSymbolAddress(functionName);
/*     */     }
/* 207 */     catch (UnsatisfiedLinkError e) {
/* 208 */       throw new UnsatisfiedLinkError("Error looking up function '" + functionName + "': " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Function(Pointer functionAddress, int callFlags, String encoding) {
/* 230 */     checkCallingConvention(callFlags & 0x3);
/* 231 */     if (functionAddress == null || functionAddress.peer == 0L)
/*     */     {
/* 233 */       throw new NullPointerException("Function address may not be null");
/*     */     }
/* 235 */     this.functionName = functionAddress.toString();
/* 236 */     this.callFlags = callFlags;
/* 237 */     this.peer = functionAddress.peer;
/* 238 */     this.options = Collections.EMPTY_MAP;
/* 239 */     this.encoding = (encoding != null) ? encoding : Native.getDefaultStringEncoding();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkCallingConvention(int convention) throws IllegalArgumentException {
/* 245 */     switch (convention) {
/*     */       case 0:
/*     */       case 1:
/*     */         return;
/*     */     } 
/* 250 */     throw new IllegalArgumentException("Unrecognized calling convention: " + convention);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 256 */     return this.functionName;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getCallingConvention() {
/* 261 */     return this.callFlags & 0x3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Class returnType, Object[] inArgs) {
/* 268 */     return invoke(returnType, inArgs, this.options);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(Class<?> returnType, Object[] inArgs, Map options) {
/* 277 */     Object[] args = new Object[0];
/* 278 */     if (inArgs != null) {
/* 279 */       if (inArgs.length > 256) {
/* 280 */         throw new UnsupportedOperationException("Maximum argument count is 256");
/*     */       }
/* 282 */       args = new Object[inArgs.length];
/* 283 */       System.arraycopy(inArgs, 0, args, 0, args.length);
/*     */     } 
/*     */     
/* 286 */     TypeMapper mapper = (TypeMapper)options.get("type-mapper");
/*     */     
/* 288 */     Method invokingMethod = (Method)options.get("invoking-method");
/* 289 */     Class[] paramTypes = (invokingMethod != null) ? invokingMethod.getParameterTypes() : null;
/* 290 */     boolean allowObjects = Boolean.TRUE.equals(options.get("allow-objects"));
/* 291 */     for (int i = 0; i < args.length; i++) {
/* 292 */       Class<?> paramType = (invokingMethod != null) ? ((isVarArgs(invokingMethod) && i >= paramTypes.length - 1) ? paramTypes[paramTypes.length - 1].getComponentType() : paramTypes[i]) : null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 297 */       args[i] = convertArgument(args, i, invokingMethod, mapper, allowObjects, paramType);
/*     */     } 
/*     */ 
/*     */     
/* 301 */     Class<?> nativeType = returnType;
/* 302 */     FromNativeConverter resultConverter = null;
/* 303 */     if (NativeMapped.class.isAssignableFrom(returnType)) {
/* 304 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(returnType);
/* 305 */       resultConverter = tc;
/* 306 */       nativeType = tc.nativeType();
/*     */     }
/* 308 */     else if (mapper != null) {
/* 309 */       resultConverter = mapper.getFromNativeConverter(returnType);
/* 310 */       if (resultConverter != null) {
/* 311 */         nativeType = resultConverter.nativeType();
/*     */       }
/*     */     } 
/*     */     
/* 315 */     Object result = invoke(args, nativeType, allowObjects);
/*     */ 
/*     */     
/* 318 */     if (resultConverter != null) {
/*     */       FromNativeContext context;
/*     */       
/* 321 */       if (invokingMethod != null) {
/* 322 */         context = new MethodResultContext(returnType, this, inArgs, invokingMethod);
/*     */       } else {
/* 324 */         context = new FunctionResultContext(returnType, this, inArgs);
/*     */       } 
/* 326 */       result = resultConverter.fromNative(result, context);
/*     */     } 
/*     */ 
/*     */     
/* 330 */     if (inArgs != null) {
/* 331 */       for (int j = 0; j < inArgs.length; j++) {
/* 332 */         Object inArg = inArgs[j];
/* 333 */         if (inArg != null)
/*     */         {
/* 335 */           if (inArg instanceof Structure) {
/* 336 */             if (!(inArg instanceof Structure.ByValue)) {
/* 337 */               ((Structure)inArg).autoRead();
/*     */             }
/*     */           }
/* 340 */           else if (args[j] instanceof PostCallRead) {
/* 341 */             ((PostCallRead)args[j]).read();
/* 342 */             if (args[j] instanceof PointerArray) {
/* 343 */               PointerArray array = (PointerArray)args[j];
/* 344 */               if (Structure.ByReference[].class.isAssignableFrom(inArg.getClass())) {
/* 345 */                 Class<?> type = inArg.getClass().getComponentType();
/* 346 */                 Structure[] ss = (Structure[])inArg;
/* 347 */                 for (int si = 0; si < ss.length; si++) {
/* 348 */                   Pointer p = array.getPointer((Pointer.SIZE * si));
/* 349 */                   ss[si] = Structure.updateStructureByReference(type, ss[si], p);
/*     */                 }
/*     */               
/*     */               } 
/*     */             } 
/* 354 */           } else if (Structure[].class.isAssignableFrom(inArg.getClass())) {
/* 355 */             Structure.autoRead((Structure[])inArg);
/*     */           } 
/*     */         }
/*     */       } 
/*     */     }
/* 360 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   Object invoke(Object[] args, Class<void> returnType, boolean allowObjects) {
/* 365 */     Object result = null;
/* 366 */     if (returnType == null || returnType == void.class || returnType == Void.class) {
/* 367 */       Native.invokeVoid(this.peer, this.callFlags, args);
/* 368 */       result = null;
/*     */     }
/* 370 */     else if (returnType == boolean.class || returnType == Boolean.class) {
/* 371 */       result = valueOf((Native.invokeInt(this.peer, this.callFlags, args) != 0));
/*     */     }
/* 373 */     else if (returnType == byte.class || returnType == Byte.class) {
/* 374 */       result = new Byte((byte)Native.invokeInt(this.peer, this.callFlags, args));
/*     */     }
/* 376 */     else if (returnType == short.class || returnType == Short.class) {
/* 377 */       result = new Short((short)Native.invokeInt(this.peer, this.callFlags, args));
/*     */     }
/* 379 */     else if (returnType == char.class || returnType == Character.class) {
/* 380 */       result = new Character((char)Native.invokeInt(this.peer, this.callFlags, args));
/*     */     }
/* 382 */     else if (returnType == int.class || returnType == Integer.class) {
/* 383 */       result = new Integer(Native.invokeInt(this.peer, this.callFlags, args));
/*     */     }
/* 385 */     else if (returnType == long.class || returnType == Long.class) {
/* 386 */       result = new Long(Native.invokeLong(this.peer, this.callFlags, args));
/*     */     }
/* 388 */     else if (returnType == float.class || returnType == Float.class) {
/* 389 */       result = new Float(Native.invokeFloat(this.peer, this.callFlags, args));
/*     */     }
/* 391 */     else if (returnType == double.class || returnType == Double.class) {
/* 392 */       result = new Double(Native.invokeDouble(this.peer, this.callFlags, args));
/*     */     }
/* 394 */     else if (returnType == String.class) {
/* 395 */       result = invokeString(this.callFlags, args, false);
/*     */     }
/* 397 */     else if (returnType == WString.class) {
/* 398 */       String s = invokeString(this.callFlags, args, true);
/* 399 */       if (s != null) {
/* 400 */         result = new WString(s);
/*     */       }
/*     */     } else {
/* 403 */       if (Pointer.class.isAssignableFrom(returnType)) {
/* 404 */         return invokePointer(this.callFlags, args);
/*     */       }
/* 406 */       if (Structure.class.isAssignableFrom(returnType)) {
/* 407 */         if (Structure.ByValue.class.isAssignableFrom(returnType)) {
/* 408 */           Structure s = Native.invokeStructure(this.peer, this.callFlags, args, Structure.newInstance(returnType));
/*     */ 
/*     */           
/* 411 */           s.autoRead();
/* 412 */           result = s;
/*     */         } else {
/*     */           
/* 415 */           result = invokePointer(this.callFlags, args);
/* 416 */           if (result != null) {
/* 417 */             Structure s = Structure.newInstance(returnType, (Pointer)result);
/* 418 */             s.conditionalAutoRead();
/* 419 */             result = s;
/*     */           }
/*     */         
/*     */         } 
/* 423 */       } else if (Callback.class.isAssignableFrom(returnType)) {
/* 424 */         result = invokePointer(this.callFlags, args);
/* 425 */         if (result != null) {
/* 426 */           result = CallbackReference.getCallback(returnType, (Pointer)result);
/*     */         }
/*     */       }
/* 429 */       else if (returnType == String[].class) {
/* 430 */         Pointer p = invokePointer(this.callFlags, args);
/* 431 */         if (p != null) {
/* 432 */           result = p.getStringArray(0L, this.encoding);
/*     */         }
/*     */       }
/* 435 */       else if (returnType == WString[].class) {
/* 436 */         Pointer p = invokePointer(this.callFlags, args);
/* 437 */         if (p != null) {
/* 438 */           String[] arr = p.getWideStringArray(0L);
/* 439 */           WString[] warr = new WString[arr.length];
/* 440 */           for (int i = 0; i < arr.length; i++) {
/* 441 */             warr[i] = new WString(arr[i]);
/*     */           }
/* 443 */           result = warr;
/*     */         }
/*     */       
/* 446 */       } else if (returnType == Pointer[].class) {
/* 447 */         Pointer p = invokePointer(this.callFlags, args);
/* 448 */         if (p != null) {
/* 449 */           result = p.getPointerArray(0L);
/*     */         }
/*     */       }
/* 452 */       else if (allowObjects) {
/* 453 */         result = Native.invokeObject(this.peer, this.callFlags, args);
/* 454 */         if (result != null && !returnType.isAssignableFrom(result.getClass()))
/*     */         {
/* 456 */           throw new ClassCastException("Return type " + returnType + " does not match result " + result.getClass());
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 462 */         throw new IllegalArgumentException("Unsupported return type " + returnType + " in function " + getName());
/*     */       } 
/*     */     } 
/*     */     
/* 466 */     return result;
/*     */   }
/*     */   
/*     */   private Pointer invokePointer(int callFlags, Object[] args) {
/* 470 */     long ptr = Native.invokePointer(this.peer, callFlags, args);
/* 471 */     return (ptr == 0L) ? null : new Pointer(ptr);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object convertArgument(Object[] args, int index, Method invokingMethod, TypeMapper mapper, boolean allowObjects, Class<?> expectedType) {
/* 477 */     Object arg = args[index];
/* 478 */     if (arg != null) {
/* 479 */       Class<?> type = arg.getClass();
/* 480 */       ToNativeConverter converter = null;
/* 481 */       if (NativeMapped.class.isAssignableFrom(type)) {
/* 482 */         converter = NativeMappedConverter.getInstance(type);
/*     */       }
/* 484 */       else if (mapper != null) {
/* 485 */         converter = mapper.getToNativeConverter(type);
/*     */       } 
/* 487 */       if (converter != null) {
/*     */         ToNativeContext context;
/* 489 */         if (invokingMethod != null) {
/* 490 */           context = new MethodParameterContext(this, args, index, invokingMethod);
/*     */         } else {
/*     */           
/* 493 */           context = new FunctionParameterContext(this, args, index);
/*     */         } 
/* 495 */         arg = converter.toNative(arg, context);
/*     */       } 
/*     */     } 
/* 498 */     if (arg == null || isPrimitiveArray(arg.getClass())) {
/* 499 */       return arg;
/*     */     }
/* 501 */     Class<?> argClass = arg.getClass();
/*     */     
/* 503 */     if (arg instanceof Structure) {
/* 504 */       Structure struct = (Structure)arg;
/* 505 */       struct.autoWrite();
/* 506 */       if (struct instanceof Structure.ByValue) {
/*     */         
/* 508 */         Class<?> ptype = struct.getClass();
/* 509 */         if (invokingMethod != null) {
/* 510 */           Class[] ptypes = invokingMethod.getParameterTypes();
/* 511 */           if (isVarArgs(invokingMethod)) {
/* 512 */             if (index < ptypes.length - 1) {
/* 513 */               ptype = ptypes[index];
/*     */             } else {
/*     */               
/* 516 */               Class<?> etype = ptypes[ptypes.length - 1].getComponentType();
/* 517 */               if (etype != Object.class) {
/* 518 */                 ptype = etype;
/*     */               }
/*     */             } 
/*     */           } else {
/*     */             
/* 523 */             ptype = ptypes[index];
/*     */           } 
/*     */         } 
/* 526 */         if (Structure.ByValue.class.isAssignableFrom(ptype)) {
/* 527 */           return struct;
/*     */         }
/*     */       } 
/* 530 */       return struct.getPointer();
/*     */     } 
/*     */     
/* 533 */     if (arg instanceof Callback) {
/* 534 */       return CallbackReference.getFunctionPointer((Callback)arg);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 540 */     if (arg instanceof String) {
/* 541 */       return (new NativeString((String)arg, false)).getPointer();
/*     */     }
/*     */     
/* 544 */     if (arg instanceof WString) {
/* 545 */       return (new NativeString(arg.toString(), true)).getPointer();
/*     */     }
/*     */ 
/*     */     
/* 549 */     if (arg instanceof Boolean) {
/* 550 */       return Boolean.TRUE.equals(arg) ? INTEGER_TRUE : INTEGER_FALSE;
/*     */     }
/* 552 */     if (String[].class == argClass) {
/* 553 */       return new StringArray((String[])arg, this.encoding);
/*     */     }
/* 555 */     if (WString[].class == argClass) {
/* 556 */       return new StringArray((WString[])arg);
/*     */     }
/* 558 */     if (Pointer[].class == argClass) {
/* 559 */       return new PointerArray((Pointer[])arg);
/*     */     }
/* 561 */     if (NativeMapped[].class.isAssignableFrom(argClass)) {
/* 562 */       return new NativeMappedArray((NativeMapped[])arg);
/*     */     }
/* 564 */     if (Structure[].class.isAssignableFrom(argClass)) {
/*     */ 
/*     */       
/* 567 */       Structure[] ss = (Structure[])arg;
/* 568 */       Class<?> type = argClass.getComponentType();
/* 569 */       boolean byRef = Structure.ByReference.class.isAssignableFrom(type);
/* 570 */       if (expectedType != null && 
/* 571 */         !Structure.ByReference[].class.isAssignableFrom(expectedType)) {
/* 572 */         if (byRef) {
/* 573 */           throw new IllegalArgumentException("Function " + getName() + " declared Structure[] at parameter " + index + " but array of " + type + " was passed");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 578 */         for (int i = 0; i < ss.length; i++) {
/* 579 */           if (ss[i] instanceof Structure.ByReference) {
/* 580 */             throw new IllegalArgumentException("Function " + getName() + " declared Structure[] at parameter " + index + " but element " + i + " is of Structure.ByReference type");
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 588 */       if (byRef) {
/* 589 */         Structure.autoWrite(ss);
/* 590 */         Pointer[] pointers = new Pointer[ss.length + 1];
/* 591 */         for (int i = 0; i < ss.length; i++) {
/* 592 */           pointers[i] = (ss[i] != null) ? ss[i].getPointer() : null;
/*     */         }
/* 594 */         return new PointerArray(pointers);
/*     */       } 
/* 596 */       if (ss.length == 0) {
/* 597 */         throw new IllegalArgumentException("Structure array must have non-zero length");
/*     */       }
/* 599 */       if (ss[0] == null) {
/* 600 */         Structure.newInstance(type).toArray(ss);
/* 601 */         return ss[0].getPointer();
/*     */       } 
/*     */       
/* 604 */       Structure.autoWrite(ss);
/* 605 */       return ss[0].getPointer();
/*     */     } 
/*     */     
/* 608 */     if (argClass.isArray()) {
/* 609 */       throw new IllegalArgumentException("Unsupported array argument type: " + argClass.getComponentType());
/*     */     }
/*     */     
/* 612 */     if (allowObjects) {
/* 613 */       return arg;
/*     */     }
/* 615 */     if (!Native.isSupportedNativeType(arg.getClass())) {
/* 616 */       throw new IllegalArgumentException("Unsupported argument type " + arg.getClass().getName() + " at parameter " + index + " of function " + getName());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 621 */     return arg;
/*     */   }
/*     */   
/*     */   private boolean isPrimitiveArray(Class argClass) {
/* 625 */     return (argClass.isArray() && argClass.getComponentType().isPrimitive());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void invoke(Object[] args) {
/* 636 */     invoke(Void.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String invokeString(int callFlags, Object[] args, boolean wide) {
/* 651 */     Pointer ptr = invokePointer(callFlags, args);
/* 652 */     String s = null;
/* 653 */     if (ptr != null) {
/* 654 */       if (wide) {
/* 655 */         s = ptr.getWideString(0L);
/*     */       } else {
/*     */         
/* 658 */         s = ptr.getString(0L, this.encoding);
/*     */       } 
/*     */     }
/* 661 */     return s;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 666 */     if (this.library != null) {
/* 667 */       return "native function " + this.functionName + "(" + this.library.getName() + ")@0x" + Long.toHexString(this.peer);
/*     */     }
/*     */     
/* 670 */     return "native function@0x" + Long.toHexString(this.peer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invokeObject(Object[] args) {
/* 677 */     return invoke(Object.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Pointer invokePointer(Object[] args) {
/* 684 */     return (Pointer)invoke(Pointer.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String invokeString(Object[] args, boolean wide) {
/* 695 */     Object o = invoke(wide ? WString.class : String.class, args);
/* 696 */     return (o != null) ? o.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int invokeInt(Object[] args) {
/* 703 */     return ((Integer)invoke(Integer.class, args)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public long invokeLong(Object[] args) {
/* 709 */     return ((Long)invoke(Long.class, args)).longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public float invokeFloat(Object[] args) {
/* 715 */     return ((Float)invoke(Float.class, args)).floatValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public double invokeDouble(Object[] args) {
/* 721 */     return ((Double)invoke(Double.class, args)).doubleValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void invokeVoid(Object[] args) {
/* 727 */     invoke(Void.class, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 734 */     if (o == this) return true; 
/* 735 */     if (o == null) return false; 
/* 736 */     if (o.getClass() == getClass()) {
/* 737 */       Function other = (Function)o;
/* 738 */       return (other.callFlags == this.callFlags && other.options.equals(this.options) && other.peer == this.peer);
/*     */     } 
/*     */ 
/*     */     
/* 742 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 749 */     return this.callFlags + this.options.hashCode() + super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public static interface PostCallRead
/*     */   {
/*     */     void read();
/*     */   }
/*     */   
/*     */   static Object[] concatenateVarArgs(Object[] inArgs) {
/* 759 */     if (inArgs != null && inArgs.length > 0) {
/* 760 */       Object lastArg = inArgs[inArgs.length - 1];
/* 761 */       Class<?> argType = (lastArg != null) ? lastArg.getClass() : null;
/* 762 */       if (argType != null && argType.isArray()) {
/* 763 */         Object[] varArgs = (Object[])lastArg;
/* 764 */         Object[] fullArgs = new Object[inArgs.length + varArgs.length];
/* 765 */         System.arraycopy(inArgs, 0, fullArgs, 0, inArgs.length - 1);
/* 766 */         System.arraycopy(varArgs, 0, fullArgs, inArgs.length - 1, varArgs.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 772 */         fullArgs[fullArgs.length - 1] = null;
/* 773 */         inArgs = fullArgs;
/*     */       } 
/*     */     } 
/* 776 */     return inArgs;
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isVarArgs(Method m) {
/*     */     try {
/* 782 */       Method v = m.getClass().getMethod("isVarArgs", new Class[0]);
/* 783 */       return Boolean.TRUE.equals(v.invoke(m, new Object[0]));
/*     */     }
/* 785 */     catch (SecurityException e) {
/*     */     
/* 787 */     } catch (NoSuchMethodException e) {
/*     */     
/* 789 */     } catch (IllegalArgumentException e) {
/*     */     
/* 791 */     } catch (IllegalAccessException e) {
/*     */     
/* 793 */     } catch (InvocationTargetException e) {}
/*     */     
/* 795 */     return false;
/*     */   }
/*     */   
/*     */   private static class NativeMappedArray extends Memory implements PostCallRead { private final NativeMapped[] original;
/*     */     
/*     */     public NativeMappedArray(NativeMapped[] arg) {
/* 801 */       super(Native.getNativeSize(arg.getClass(), arg));
/* 802 */       this.original = arg;
/* 803 */       setValue(0L, this.original, this.original.getClass());
/*     */     }
/*     */     public void read() {
/* 806 */       getValue(0L, this.original.getClass(), this.original);
/*     */     } }
/*     */   
/*     */   private static class PointerArray extends Memory implements PostCallRead {
/*     */     private final Pointer[] original;
/*     */     
/*     */     public PointerArray(Pointer[] arg) {
/* 813 */       super((Pointer.SIZE * (arg.length + 1)));
/* 814 */       this.original = arg;
/* 815 */       for (int i = 0; i < arg.length; i++) {
/* 816 */         setPointer((i * Pointer.SIZE), arg[i]);
/*     */       }
/* 818 */       setPointer((Pointer.SIZE * arg.length), (Pointer)null);
/*     */     }
/*     */     public void read() {
/* 821 */       read(0L, this.original, 0, this.original.length);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   static Boolean valueOf(boolean b) {
/* 827 */     return b ? Boolean.TRUE : Boolean.FALSE;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\Function.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */