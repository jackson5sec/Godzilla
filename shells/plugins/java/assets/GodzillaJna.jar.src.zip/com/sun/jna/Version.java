package com.sun.jna;

interface Version {
  public static final String VERSION = "4.1.0";
  
  public static final String VERSION_NATIVE = "4.0.0";
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\Version.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */