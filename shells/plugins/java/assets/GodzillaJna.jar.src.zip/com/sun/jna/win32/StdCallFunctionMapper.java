/*    */ package com.sun.jna.win32;
/*    */ 
/*    */ import com.sun.jna.FunctionMapper;
/*    */ import com.sun.jna.Native;
/*    */ import com.sun.jna.NativeLibrary;
/*    */ import com.sun.jna.NativeMapped;
/*    */ import com.sun.jna.NativeMappedConverter;
/*    */ import com.sun.jna.Pointer;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class StdCallFunctionMapper
/*    */   implements FunctionMapper
/*    */ {
/*    */   protected int getArgumentNativeStackSize(Class<?> cls) {
/* 33 */     if (NativeMapped.class.isAssignableFrom(cls)) {
/* 34 */       cls = NativeMappedConverter.getInstance(cls).nativeType();
/*    */     }
/* 36 */     if (cls.isArray()) {
/* 37 */       return Pointer.SIZE;
/*    */     }
/*    */     try {
/* 40 */       return Native.getNativeSize(cls);
/*    */     }
/* 42 */     catch (IllegalArgumentException e) {
/* 43 */       throw new IllegalArgumentException("Unknown native stack allocation size for " + cls);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String getFunctionName(NativeLibrary library, Method method) {
/* 50 */     String name = method.getName();
/* 51 */     int pop = 0;
/* 52 */     Class[] argTypes = method.getParameterTypes();
/* 53 */     for (int i = 0; i < argTypes.length; i++) {
/* 54 */       pop += getArgumentNativeStackSize(argTypes[i]);
/*    */     }
/* 56 */     String decorated = name + "@" + pop;
/* 57 */     int conv = 1;
/*    */     try {
/* 59 */       name = library.getFunction(decorated, conv).getName();
/*    */     
/*    */     }
/* 62 */     catch (UnsatisfiedLinkError e) {
/*    */       
/*    */       try {
/* 65 */         name = library.getFunction("_" + decorated, conv).getName();
/*    */       }
/* 67 */       catch (UnsatisfiedLinkError e2) {}
/*    */     } 
/*    */ 
/*    */     
/* 71 */     return name;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\win32\StdCallFunctionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */