/*     */ package com.sun.jna;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PointerType
/*     */   implements NativeMapped
/*     */ {
/*     */   private Pointer pointer;
/*     */   
/*     */   protected PointerType() {
/*  25 */     this.pointer = Pointer.NULL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PointerType(Pointer p) {
/*  32 */     this.pointer = p;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Class nativeType() {
/*  38 */     return Pointer.class;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object toNative() {
/*  43 */     return getPointer();
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointer getPointer() {
/*  48 */     return this.pointer;
/*     */   }
/*     */   
/*     */   public void setPointer(Pointer p) {
/*  52 */     this.pointer = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object fromNative(Object nativeValue, FromNativeContext context) {
/*  63 */     if (nativeValue == null) {
/*  64 */       return null;
/*     */     }
/*     */     try {
/*  67 */       PointerType pt = (PointerType)getClass().newInstance();
/*  68 */       pt.pointer = (Pointer)nativeValue;
/*  69 */       return pt;
/*     */     }
/*  71 */     catch (InstantiationException e) {
/*  72 */       throw new IllegalArgumentException("Can't instantiate " + getClass());
/*     */     }
/*  74 */     catch (IllegalAccessException e) {
/*  75 */       throw new IllegalArgumentException("Not allowed to instantiate " + getClass());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  83 */     return (this.pointer != null) ? this.pointer.hashCode() : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  90 */     if (o == this) return true; 
/*  91 */     if (o instanceof PointerType) {
/*  92 */       Pointer p = ((PointerType)o).getPointer();
/*  93 */       if (this.pointer == null)
/*  94 */         return (p == null); 
/*  95 */       return this.pointer.equals(p);
/*     */     } 
/*  97 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 101 */     return (this.pointer == null) ? "NULL" : (this.pointer.toString() + " (" + super.toString() + ")");
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\PointerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */