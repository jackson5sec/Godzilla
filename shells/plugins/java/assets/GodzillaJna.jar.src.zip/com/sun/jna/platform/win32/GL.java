package com.sun.jna.platform.win32;

import com.sun.jna.win32.StdCallLibrary;

public interface GL extends StdCallLibrary {
  public static final int GL_VENDOR = 7936;
  
  public static final int GL_RENDERER = 7937;
  
  public static final int GL_VERSION = 7938;
  
  public static final int GL_EXTENSIONS = 7939;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\GL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */