/*    */ package com.sun.jna.platform.win32.COM.tlb.imp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TlbParameterNotFoundException
/*    */   extends RuntimeException
/*    */ {
/*    */   public TlbParameterNotFoundException() {}
/*    */   
/*    */   public TlbParameterNotFoundException(String msg) {
/* 21 */     super(msg);
/*    */   }
/*    */   
/*    */   public TlbParameterNotFoundException(Throwable cause) {
/* 25 */     super(cause);
/*    */   }
/*    */   
/*    */   public TlbParameterNotFoundException(String msg, Throwable cause) {
/* 29 */     super(msg, cause);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\COM\tlb\imp\TlbParameterNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */