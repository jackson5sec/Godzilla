/*     */ package com.sun.jna;
/*     */ 
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Union
/*     */   extends Structure
/*     */ {
/*     */   private Structure.StructField activeField;
/*     */   
/*     */   protected Union() {}
/*     */   
/*     */   protected Union(Pointer p) {
/*  39 */     super(p);
/*     */   }
/*     */   
/*     */   protected Union(Pointer p, int alignType) {
/*  43 */     super(p, alignType);
/*     */   }
/*     */   
/*     */   protected Union(TypeMapper mapper) {
/*  47 */     super(mapper);
/*     */   }
/*     */   
/*     */   protected Union(Pointer p, int alignType, TypeMapper mapper) {
/*  51 */     super(p, alignType, mapper);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List getFieldOrder() {
/*  58 */     List flist = getFieldList();
/*  59 */     ArrayList<String> list = new ArrayList();
/*  60 */     for (Iterator<Field> i = flist.iterator(); i.hasNext(); ) {
/*  61 */       Field f = i.next();
/*  62 */       list.add(f.getName());
/*     */     } 
/*  64 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(Class type) {
/*  74 */     ensureAllocated();
/*  75 */     for (Iterator<Structure.StructField> i = fields().values().iterator(); i.hasNext(); ) {
/*  76 */       Structure.StructField f = i.next();
/*  77 */       if (f.type == type) {
/*  78 */         this.activeField = f;
/*     */         return;
/*     */       } 
/*     */     } 
/*  82 */     throw new IllegalArgumentException("No field of type " + type + " in " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setType(String fieldName) {
/*  91 */     ensureAllocated();
/*  92 */     Structure.StructField f = (Structure.StructField)fields().get(fieldName);
/*  93 */     if (f != null) {
/*  94 */       this.activeField = f;
/*     */     } else {
/*     */       
/*  97 */       throw new IllegalArgumentException("No field named " + fieldName + " in " + this);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object readField(String fieldName) {
/* 107 */     ensureAllocated();
/* 108 */     setType(fieldName);
/* 109 */     return super.readField(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeField(String fieldName) {
/* 117 */     ensureAllocated();
/* 118 */     setType(fieldName);
/* 119 */     super.writeField(fieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeField(String fieldName, Object value) {
/* 127 */     ensureAllocated();
/* 128 */     setType(fieldName);
/* 129 */     super.writeField(fieldName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getTypedValue(Class type) {
/* 145 */     ensureAllocated();
/* 146 */     for (Iterator<Structure.StructField> i = fields().values().iterator(); i.hasNext(); ) {
/* 147 */       Structure.StructField f = i.next();
/* 148 */       if (f.type == type) {
/* 149 */         this.activeField = f;
/* 150 */         read();
/* 151 */         return getFieldValue(this.activeField.field);
/*     */       } 
/*     */     } 
/* 154 */     throw new IllegalArgumentException("No field of type " + type + " in " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object setTypedValue(Object object) {
/* 168 */     Structure.StructField f = findField(object.getClass());
/* 169 */     if (f != null) {
/* 170 */       this.activeField = f;
/* 171 */       setFieldValue(f.field, object);
/* 172 */       return this;
/*     */     } 
/* 174 */     throw new IllegalArgumentException("No field of type " + object.getClass() + " in " + this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Structure.StructField findField(Class<?> type) {
/* 183 */     ensureAllocated();
/* 184 */     for (Iterator<Structure.StructField> i = fields().values().iterator(); i.hasNext(); ) {
/* 185 */       Structure.StructField f = i.next();
/* 186 */       if (f.type.isAssignableFrom(type)) {
/* 187 */         return f;
/*     */       }
/*     */     } 
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void writeField(Structure.StructField field) {
/* 195 */     if (field == this.activeField) {
/* 196 */       super.writeField(field);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object readField(Structure.StructField field) {
/* 205 */     if (field == this.activeField || (!Structure.class.isAssignableFrom(field.type) && !String.class.isAssignableFrom(field.type) && !WString.class.isAssignableFrom(field.type)))
/*     */     {
/*     */ 
/*     */       
/* 209 */       return super.readField(field);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getNativeAlignment(Class type, Object value, boolean isFirstElement) {
/* 220 */     return super.getNativeAlignment(type, value, true);
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\Union.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */