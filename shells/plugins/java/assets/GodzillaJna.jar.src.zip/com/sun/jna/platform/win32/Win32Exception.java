/*    */ package com.sun.jna.platform.win32;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Win32Exception
/*    */   extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private WinNT.HRESULT _hr;
/*    */   
/*    */   public WinNT.HRESULT getHR() {
/* 33 */     return this._hr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Win32Exception(WinNT.HRESULT hr) {
/* 42 */     super(Kernel32Util.formatMessage(hr));
/* 43 */     this._hr = hr;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Win32Exception(int code) {
/* 52 */     this(W32Errors.HRESULT_FROM_WIN32(code));
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\Win32Exception.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */