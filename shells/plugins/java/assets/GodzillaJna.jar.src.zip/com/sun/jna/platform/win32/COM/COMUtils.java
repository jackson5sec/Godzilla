/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.platform.win32.Advapi32;
/*     */ import com.sun.jna.platform.win32.Advapi32Util;
/*     */ import com.sun.jna.platform.win32.Kernel32Util;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.platform.win32.WinReg;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class COMUtils
/*     */ {
/*     */   public static final int S_OK = 0;
/*     */   
/*     */   public static boolean SUCCEEDED(WinNT.HRESULT hr) {
/*  50 */     return SUCCEEDED(hr.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean SUCCEEDED(int hr) {
/*  61 */     if (hr == 0) {
/*  62 */       return true;
/*     */     }
/*  64 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean FAILED(WinNT.HRESULT hr) {
/*  75 */     return FAILED(hr.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean FAILED(int hr) {
/*  86 */     if (hr != 0) {
/*  87 */       return true;
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkRC(WinNT.HRESULT hr) {
/*  99 */     checkRC(hr, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkRC(WinNT.HRESULT hr, OaIdl.EXCEPINFO pExcepInfo, IntByReference puArgErr) {
/* 114 */     if (FAILED(hr)) {
/* 115 */       String formatMessageFromHR = Kernel32Util.formatMessage(hr);
/* 116 */       throw new COMException(formatMessageFromHR, pExcepInfo, puArgErr);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<COMInfo> getAllCOMInfoOnSystem() {
/* 126 */     WinReg.HKEYByReference phkResult = new WinReg.HKEYByReference();
/* 127 */     WinReg.HKEYByReference phkResult2 = new WinReg.HKEYByReference();
/*     */     
/* 129 */     ArrayList<COMInfo> comInfos = new ArrayList<COMInfo>();
/*     */ 
/*     */     
/*     */     try {
/* 133 */       phkResult = Advapi32Util.registryGetKey(WinReg.HKEY_CLASSES_ROOT, "CLSID", 2031679);
/*     */ 
/*     */       
/* 136 */       Advapi32Util.InfoKey infoKey = Advapi32Util.registryQueryInfoKey(phkResult.getValue(), 2031679);
/*     */ 
/*     */       
/* 139 */       for (int i = 0; i < infoKey.lpcSubKeys.getValue(); i++) {
/* 140 */         Advapi32Util.EnumKey enumKey = Advapi32Util.registryRegEnumKey(phkResult.getValue(), i);
/*     */         
/* 142 */         String subKey = Native.toString(enumKey.lpName);
/*     */         
/* 144 */         COMInfo comInfo = new COMInfo(subKey);
/*     */         
/* 146 */         phkResult2 = Advapi32Util.registryGetKey(phkResult.getValue(), subKey, 2031679);
/*     */         
/* 148 */         Advapi32Util.InfoKey infoKey2 = Advapi32Util.registryQueryInfoKey(phkResult2.getValue(), 2031679);
/*     */ 
/*     */         
/* 151 */         for (int y = 0; y < infoKey2.lpcSubKeys.getValue(); y++) {
/* 152 */           Advapi32Util.EnumKey enumKey2 = Advapi32Util.registryRegEnumKey(phkResult2.getValue(), y);
/*     */           
/* 154 */           String subKey2 = Native.toString(enumKey2.lpName);
/*     */           
/* 156 */           if (subKey2.equals("InprocHandler32")) {
/* 157 */             comInfo.inprocHandler32 = (String)Advapi32Util.registryGetValue(phkResult2.getValue(), subKey2, null);
/*     */           
/*     */           }
/* 160 */           else if (subKey2.equals("InprocServer32")) {
/* 161 */             comInfo.inprocServer32 = (String)Advapi32Util.registryGetValue(phkResult2.getValue(), subKey2, null);
/*     */           
/*     */           }
/* 164 */           else if (subKey2.equals("LocalServer32")) {
/* 165 */             comInfo.localServer32 = (String)Advapi32Util.registryGetValue(phkResult2.getValue(), subKey2, null);
/*     */           
/*     */           }
/* 168 */           else if (subKey2.equals("ProgID")) {
/* 169 */             comInfo.progID = (String)Advapi32Util.registryGetValue(phkResult2.getValue(), subKey2, null);
/*     */           
/*     */           }
/* 172 */           else if (subKey2.equals("TypeLib")) {
/* 173 */             comInfo.typeLib = (String)Advapi32Util.registryGetValue(phkResult2.getValue(), subKey2, null);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 179 */         Advapi32.INSTANCE.RegCloseKey(phkResult2.getValue());
/* 180 */         comInfos.add(comInfo);
/*     */       } 
/*     */     } finally {
/* 183 */       Advapi32.INSTANCE.RegCloseKey(phkResult.getValue());
/* 184 */       Advapi32.INSTANCE.RegCloseKey(phkResult2.getValue());
/*     */     } 
/*     */     
/* 187 */     return comInfos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class COMInfo
/*     */   {
/*     */     public String clsid;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String inprocHandler32;
/*     */ 
/*     */ 
/*     */     
/*     */     public String inprocServer32;
/*     */ 
/*     */ 
/*     */     
/*     */     public String localServer32;
/*     */ 
/*     */ 
/*     */     
/*     */     public String progID;
/*     */ 
/*     */ 
/*     */     
/*     */     public String typeLib;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public COMInfo() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public COMInfo(String clsid) {
/* 228 */       this.clsid = clsid;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\COM\COMUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */