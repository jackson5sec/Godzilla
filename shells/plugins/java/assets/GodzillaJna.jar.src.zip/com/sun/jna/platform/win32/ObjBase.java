package com.sun.jna.platform.win32;

public interface ObjBase {
  public static final int CLSCTX_INPROC = 3;
  
  public static final int CLSCTX_ALL = 23;
  
  public static final int CLSCTX_SERVER = 21;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\ObjBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */