/*    */ package com.sun.jna.win32;
/*    */ 
/*    */ import com.sun.jna.FunctionMapper;
/*    */ import com.sun.jna.NativeLibrary;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class W32APIFunctionMapper
/*    */   implements FunctionMapper
/*    */ {
/* 22 */   public static final FunctionMapper UNICODE = new W32APIFunctionMapper(true);
/* 23 */   public static final FunctionMapper ASCII = new W32APIFunctionMapper(false);
/*    */   
/*    */   protected W32APIFunctionMapper(boolean unicode) {
/* 26 */     this.suffix = unicode ? "W" : "A";
/*    */   }
/*    */   private final String suffix;
/*    */   
/*    */   public String getFunctionName(NativeLibrary library, Method method) {
/* 31 */     String name = method.getName();
/* 32 */     if (!name.endsWith("W") && !name.endsWith("A")) {
/*    */       try {
/* 34 */         name = library.getFunction(name + this.suffix, 1).getName();
/*    */       }
/* 36 */       catch (UnsatisfiedLinkError e) {}
/*    */     }
/*    */ 
/*    */     
/* 40 */     return name;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\win32\W32APIFunctionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */