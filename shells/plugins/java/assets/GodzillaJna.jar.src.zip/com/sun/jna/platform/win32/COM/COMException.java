/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class COMException
/*     */   extends RuntimeException
/*     */ {
/*     */   private OaIdl.EXCEPINFO pExcepInfo;
/*     */   private IntByReference puArgErr;
/*     */   private int uArgErr;
/*     */   
/*     */   public COMException() {}
/*     */   
/*     */   public COMException(String message, Throwable cause) {
/*  50 */     super(message, cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public COMException(String message) {
/*  60 */     super(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public COMException(String message, OaIdl.EXCEPINFO pExcepInfo, IntByReference puArgErr) {
/*  75 */     super(message + " (puArgErr=" + puArgErr.getValue() + ")");
/*  76 */     this.pExcepInfo = pExcepInfo;
/*  77 */     this.puArgErr = puArgErr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public COMException(Throwable cause) {
/*  87 */     super(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OaIdl.EXCEPINFO getExcepInfo() {
/*  96 */     return this.pExcepInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IntByReference getArgErr() {
/* 105 */     return this.puArgErr;
/*     */   }
/*     */   
/*     */   public int getuArgErr() {
/* 109 */     return this.uArgErr;
/*     */   }
/*     */   
/*     */   public void setuArgErr(int uArgErr) {
/* 113 */     this.uArgErr = uArgErr;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\COM\COMException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */