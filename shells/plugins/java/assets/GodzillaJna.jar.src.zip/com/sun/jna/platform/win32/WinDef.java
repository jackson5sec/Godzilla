/*      */ package com.sun.jna.platform.win32;
/*      */ 
/*      */ import com.sun.jna.IntegerType;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.PointerType;
/*      */ import com.sun.jna.Structure;
/*      */ import com.sun.jna.win32.StdCallLibrary;
/*      */ import java.awt.Rectangle;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface WinDef
/*      */   extends StdCallLibrary
/*      */ {
/*      */   public static final int MAX_PATH = 260;
/*      */   
/*      */   public static class WORD
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 2;
/*      */     
/*      */     public WORD() {
/*   54 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WORD(long value) {
/*   64 */       super(2, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class WORDByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public WORDByReference() {
/*   77 */       this(new WinDef.WORD(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WORDByReference(WinDef.WORD value) {
/*   86 */       super(2);
/*   87 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.WORD value) {
/*   96 */       getPointer().setShort(0L, value.shortValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.WORD getValue() {
/*  105 */       return new WinDef.WORD(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DWORD
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORD() {
/*  121 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORD(long value) {
/*  131 */       super(4, value, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.WORD getLow() {
/*  140 */       return new WinDef.WORD(longValue() & 0xFFL);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.WORD getHigh() {
/*  149 */       return new WinDef.WORD(longValue() >> 16L & 0xFFL);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DWORDByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public DWORDByReference() {
/*  162 */       this(new WinDef.DWORD(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORDByReference(WinDef.DWORD value) {
/*  171 */       super(4);
/*  172 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.DWORD value) {
/*  181 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.DWORD getValue() {
/*  190 */       return new WinDef.DWORD(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONG
/*      */     extends IntegerType
/*      */   {
/*  200 */     public static final int SIZE = Native.LONG_SIZE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONG() {
/*  206 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONG(long value) {
/*  215 */       super(SIZE, value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public LONGByReference() {
/*  228 */       this(new WinDef.LONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGByReference(WinDef.LONG value) {
/*  237 */       super(WinDef.LONG.SIZE);
/*  238 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.LONG value) {
/*  247 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.LONG getValue() {
/*  256 */       return new WinDef.LONG(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONGLONG
/*      */     extends IntegerType
/*      */   {
/*  266 */     public static final int SIZE = Native.LONG_SIZE * 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGLONG() {
/*  272 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGLONG(long value) {
/*  281 */       super(8, value, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LONGLONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public LONGLONGByReference() {
/*  294 */       this(new WinDef.LONGLONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LONGLONGByReference(WinDef.LONGLONG value) {
/*  303 */       super(WinDef.LONGLONG.SIZE);
/*  304 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.LONGLONG value) {
/*  313 */       getPointer().setLong(0L, value.longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.LONGLONG getValue() {
/*  322 */       return new WinDef.LONGLONG(getPointer().getLong(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HDC
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HDC() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HDC(Pointer p) {
/*  345 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HICON
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HICON() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HICON(Pointer p) {
/*  368 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HCURSOR
/*      */     extends HICON
/*      */   {
/*      */     public HCURSOR() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HCURSOR(Pointer p) {
/*  391 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HMENU
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HMENU() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HMENU(Pointer p) {
/*  414 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HPEN
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HPEN() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HPEN(Pointer p) {
/*  437 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HRSRC
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HRSRC() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HRSRC(Pointer p) {
/*  460 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HPALETTE
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HPALETTE() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HPALETTE(Pointer p) {
/*  483 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HBITMAP
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HBITMAP() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HBITMAP(Pointer p) {
/*  506 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HRGN
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HRGN() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HRGN(Pointer p) {
/*  529 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HWND
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HWND() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HWND(Pointer p) {
/*  552 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HINSTANCE
/*      */     extends WinNT.HANDLE {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HMODULE
/*      */     extends HINSTANCE {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HFONT
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HFONT() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HFONT(Pointer p) {
/*  589 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LPARAM
/*      */     extends BaseTSD.LONG_PTR
/*      */   {
/*      */     public LPARAM() {
/*  602 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LPARAM(long value) {
/*  612 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LRESULT
/*      */     extends BaseTSD.LONG_PTR
/*      */   {
/*      */     public LRESULT() {
/*  625 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LRESULT(long value) {
/*  635 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class INT_PTR
/*      */     extends IntegerType
/*      */   {
/*      */     public INT_PTR() {
/*  646 */       super(Pointer.SIZE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public INT_PTR(long value) {
/*  656 */       super(Pointer.SIZE, value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer toPointer() {
/*  665 */       return Pointer.createConstant(longValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UINT_PTR
/*      */     extends IntegerType
/*      */   {
/*      */     public UINT_PTR() {
/*  678 */       super(Pointer.SIZE);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINT_PTR(long value) {
/*  688 */       super(Pointer.SIZE, value, true);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Pointer toPointer() {
/*  697 */       return Pointer.createConstant(longValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class WPARAM
/*      */     extends UINT_PTR
/*      */   {
/*      */     public WPARAM() {
/*  710 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WPARAM(long value) {
/*  720 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class RECT
/*      */     extends Structure
/*      */   {
/*      */     public int left;
/*      */ 
/*      */ 
/*      */     
/*      */     public int top;
/*      */ 
/*      */ 
/*      */     
/*      */     public int right;
/*      */ 
/*      */ 
/*      */     
/*      */     public int bottom;
/*      */ 
/*      */ 
/*      */     
/*      */     protected List getFieldOrder() {
/*  747 */       return Arrays.asList(new String[] { "left", "top", "right", "bottom" });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Rectangle toRectangle() {
/*  757 */       return new Rectangle(this.left, this.top, this.right - this.left, this.bottom - this.top);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toString() {
/*  766 */       return "[(" + this.left + "," + this.top + ")(" + this.right + "," + this.bottom + ")]";
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONG
/*      */     extends IntegerType
/*      */   {
/*  776 */     public static final int SIZE = Native.LONG_SIZE;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONG() {
/*  782 */       this(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONG(int value) {
/*  792 */       super(SIZE, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public ULONGByReference() {
/*  805 */       this(new WinDef.ULONG(0));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGByReference(WinDef.ULONG value) {
/*  814 */       super(WinDef.ULONG.SIZE);
/*  815 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.ULONG value) {
/*  824 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.ULONG getValue() {
/*  833 */       return new WinDef.ULONG(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONGLONG
/*      */     extends IntegerType
/*      */   {
/*  843 */     public static final int SIZE = Native.LONG_SIZE * 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGLONG() {
/*  849 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGLONG(long value) {
/*  858 */       super(SIZE, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ULONGLONGByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public ULONGLONGByReference() {
/*  871 */       this(new WinDef.ULONGLONG(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ULONGLONGByReference(WinDef.ULONGLONG value) {
/*  880 */       super(WinDef.ULONGLONG.SIZE);
/*  881 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.ULONGLONG value) {
/*  890 */       getPointer().setLong(0L, value.longValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.ULONGLONG getValue() {
/*  899 */       return new WinDef.ULONGLONG(getPointer().getLong(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class DWORDLONG
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORDLONG() {
/*  915 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public DWORDLONG(long value) {
/*  925 */       super(8, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HBRUSH
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HBRUSH() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HBRUSH(Pointer p) {
/*  948 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class ATOM
/*      */     extends WORD
/*      */   {
/*      */     public ATOM() {
/*  961 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ATOM(long value) {
/*  971 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class PVOID
/*      */     extends PointerType
/*      */   {
/*      */     public PVOID() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public PVOID(Pointer pointer) {
/*  990 */       super(pointer);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LPVOID
/*      */     extends BaseTSD.LONG_PTR
/*      */   {
/*      */     public LPVOID() {
/* 1003 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LPVOID(long value) {
/* 1013 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class POINT
/*      */     extends Structure
/*      */   {
/*      */     public int x;
/*      */ 
/*      */ 
/*      */     
/*      */     public int y;
/*      */ 
/*      */ 
/*      */     
/*      */     public static class ByReference
/*      */       extends POINT
/*      */       implements Structure.ByReference {}
/*      */ 
/*      */ 
/*      */     
/*      */     public POINT() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public POINT(Pointer memory) {
/* 1042 */       super(memory);
/* 1043 */       read();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public POINT(int x, int y) {
/* 1058 */       this.x = x;
/* 1059 */       this.y = y;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected List getFieldOrder() {
/* 1068 */       return Arrays.asList(new String[] { "x", "y" });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class USHORT
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORT() {
/* 1084 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORT(long value) {
/* 1094 */       super(2, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class USHORTByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public USHORTByReference() {
/* 1107 */       this(new WinDef.USHORT(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORTByReference(WinDef.USHORT value) {
/* 1116 */       super(2);
/* 1117 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public USHORTByReference(short value) {
/* 1126 */       super(2);
/* 1127 */       setValue(new WinDef.USHORT(value));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.USHORT value) {
/* 1136 */       getPointer().setShort(0L, value.shortValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.USHORT getValue() {
/* 1145 */       return new WinDef.USHORT(getPointer().getShort(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SHORT
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SHORT() {
/* 1161 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SHORT(long value) {
/* 1171 */       super(2, value, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UINT
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINT() {
/* 1187 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINT(long value) {
/* 1197 */       super(4, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UINTByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public UINTByReference() {
/* 1210 */       this(new WinDef.UINT(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UINTByReference(WinDef.UINT value) {
/* 1219 */       super(4);
/* 1220 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.UINT value) {
/* 1229 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.UINT getValue() {
/* 1238 */       return new WinDef.UINT(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SCODE
/*      */     extends ULONG
/*      */   {
/*      */     public SCODE() {
/* 1251 */       this(0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SCODE(int value) {
/* 1261 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class SCODEByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public SCODEByReference() {
/* 1274 */       this(new WinDef.SCODE(0));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public SCODEByReference(WinDef.SCODE value) {
/* 1283 */       super(WinDef.SCODE.SIZE);
/* 1284 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.SCODE value) {
/* 1293 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.SCODE getValue() {
/* 1302 */       return new WinDef.SCODE(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class LCID
/*      */     extends DWORD
/*      */   {
/*      */     public LCID() {
/* 1315 */       super(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LCID(long value) {
/* 1324 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BOOL
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOL() {
/* 1340 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOL(long value) {
/* 1349 */       super(4, value, false);
/*      */     }
/*      */     
/*      */     public boolean booleanValue() {
/* 1353 */       if (intValue() > 0) {
/* 1354 */         return true;
/*      */       }
/* 1356 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BOOLByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public BOOLByReference() {
/* 1369 */       this(new WinDef.BOOL(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BOOLByReference(WinDef.BOOL value) {
/* 1378 */       super(4);
/* 1379 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.BOOL value) {
/* 1388 */       getPointer().setInt(0L, value.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.BOOL getValue() {
/* 1397 */       return new WinDef.BOOL(getPointer().getInt(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class UCHAR
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UCHAR() {
/* 1413 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UCHAR(long value) {
/* 1422 */       super(1, value, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class BYTE
/*      */     extends UCHAR
/*      */   {
/*      */     public BYTE() {
/* 1435 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public BYTE(long value) {
/* 1444 */       super(value);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CHAR
/*      */     extends IntegerType
/*      */   {
/*      */     public static final int SIZE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CHAR() {
/* 1460 */       this(0L);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CHAR(long value) {
/* 1469 */       super(1, value, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CHARByReference
/*      */     extends com.sun.jna.ptr.ByReference
/*      */   {
/*      */     public CHARByReference() {
/* 1482 */       this(new WinDef.CHAR(0L));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CHARByReference(WinDef.CHAR value) {
/* 1491 */       super(1);
/* 1492 */       setValue(value);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setValue(WinDef.CHAR value) {
/* 1501 */       getPointer().setByte(0L, value.byteValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public WinDef.CHAR getValue() {
/* 1510 */       return new WinDef.CHAR(getPointer().getChar(0L));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HGLRC
/*      */     extends WinNT.HANDLE
/*      */   {
/*      */     public HGLRC() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HGLRC(Pointer p) {
/* 1533 */       super(p);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class HGLRCByReference
/*      */     extends WinNT.HANDLEByReference
/*      */   {
/*      */     public HGLRCByReference() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HGLRCByReference(WinDef.HGLRC h) {
/* 1556 */       super(h);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\WinDef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */