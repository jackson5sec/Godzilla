/*     */ package com.sun.jna.platform.win32.COM.tlb.imp;
/*     */ 
/*     */ import com.sun.jna.platform.win32.COM.TypeInfoUtil;
/*     */ import com.sun.jna.platform.win32.COM.TypeLibUtil;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TlbBase
/*     */ {
/*     */   public static final String CR = "\n";
/*     */   public static final String CRCR = "\n\n";
/*     */   public static final String TAB = "\t";
/*     */   public static final String TABTAB = "\t\t";
/*     */   protected TypeLibUtil typeLibUtil;
/*     */   protected TypeInfoUtil typeInfoUtil;
/*     */   protected int index;
/*     */   protected StringBuffer templateBuffer;
/*     */   protected StringBuffer classBuffer;
/*  62 */   protected String content = "";
/*     */   
/*  64 */   protected String filename = "DefaultFilename";
/*     */   
/*  66 */   protected String name = "DefaultName";
/*     */ 
/*     */   
/*  69 */   public static String[] IUNKNOWN_METHODS = new String[] { "QueryInterface", "AddRef", "Release" };
/*     */ 
/*     */ 
/*     */   
/*  73 */   public static String[] IDISPATCH_METHODS = new String[] { "GetTypeInfoCount", "GetTypeInfo", "GetIDsOfNames", "Invoke" };
/*     */ 
/*     */   
/*  76 */   protected String bindingMode = "dispid";
/*     */   
/*     */   public TlbBase(int index, TypeLibUtil typeLibUtil, TypeInfoUtil typeInfoUtil) {
/*  79 */     this(index, typeLibUtil, typeInfoUtil, "dispid");
/*     */   }
/*     */   
/*     */   public TlbBase(int index, TypeLibUtil typeLibUtil, TypeInfoUtil typeInfoUtil, String bindingMode) {
/*  83 */     this.index = index;
/*  84 */     this.typeLibUtil = typeLibUtil;
/*  85 */     this.typeInfoUtil = typeInfoUtil;
/*  86 */     this.bindingMode = bindingMode;
/*     */     
/*  88 */     String filename = getClassTemplate();
/*     */     try {
/*  90 */       readTemplateFile(filename);
/*  91 */       this.classBuffer = this.templateBuffer;
/*  92 */     } catch (IOException e) {
/*  93 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logError(String msg) {
/* 104 */     log("ERROR", msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logInfo(String msg) {
/* 114 */     log("INFO", msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StringBuffer getClassBuffer() {
/* 123 */     return this.classBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void createContent(String content) {
/* 133 */     replaceVariable("content", content);
/*     */   }
/*     */   
/*     */   public void setFilename(String filename) {
/* 137 */     if (!filename.endsWith("java"))
/* 138 */       filename = filename + ".java"; 
/* 139 */     this.filename = filename;
/*     */   }
/*     */   
/*     */   public String getFilename() {
/* 143 */     return this.filename;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 147 */     return this.name;
/*     */   }
/*     */   
/*     */   public void setName(String name) {
/* 151 */     this.name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void log(String level, String msg) {
/* 163 */     String _msg = level + " " + getTime() + " : " + msg;
/* 164 */     System.out.println(_msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getTime() {
/* 173 */     SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
/* 174 */     return sdf.format(new Date());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String getClassTemplate();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void readTemplateFile(String filename) throws IOException {
/* 193 */     this.templateBuffer = new StringBuffer();
/* 194 */     BufferedReader reader = null;
/*     */     try {
/* 196 */       InputStream is = getClass().getClassLoader().getResourceAsStream(filename);
/*     */       
/* 198 */       reader = new BufferedReader(new InputStreamReader(is));
/* 199 */       String line = null;
/* 200 */       while ((line = reader.readLine()) != null)
/* 201 */         this.templateBuffer.append(line + "\n"); 
/*     */     } finally {
/* 203 */       if (reader != null) {
/* 204 */         reader.close();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void replaceVariable(String name, String value) {
/* 217 */     if (value == null) {
/* 218 */       value = "";
/*     */     }
/* 220 */     Pattern pattern = Pattern.compile("\\$\\{" + name + "\\}");
/* 221 */     Matcher matcher = pattern.matcher(this.classBuffer);
/* 222 */     String replacement = value;
/* 223 */     String result = "";
/*     */     
/* 225 */     while (matcher.find()) {
/* 226 */       result = matcher.replaceAll(replacement);
/*     */     }
/*     */     
/* 229 */     if (result.length() > 0)
/* 230 */       this.classBuffer = new StringBuffer(result); 
/*     */   }
/*     */   
/*     */   protected void createPackageName(String packagename) {
/* 234 */     replaceVariable("packagename", packagename);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createClassName(String name) {
/* 244 */     replaceVariable("classname", name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isReservedMethod(String method) {
/*     */     int i;
/* 255 */     for (i = 0; i < IUNKNOWN_METHODS.length; i++) {
/* 256 */       if (IUNKNOWN_METHODS[i].equalsIgnoreCase(method)) {
/* 257 */         return true;
/*     */       }
/*     */     } 
/* 260 */     for (i = 0; i < IDISPATCH_METHODS.length; i++) {
/* 261 */       if (IDISPATCH_METHODS[i].equalsIgnoreCase(method)) {
/* 262 */         return true;
/*     */       }
/*     */     } 
/* 265 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isVTableMode() {
/* 269 */     if (this.bindingMode.equalsIgnoreCase("vtable")) {
/* 270 */       return true;
/*     */     }
/* 272 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean isDispIdMode() {
/* 276 */     if (this.bindingMode.equalsIgnoreCase("dispid")) {
/* 277 */       return true;
/*     */     }
/* 279 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\COM\tlb\imp\TlbBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */