/*    */ package com.sun.jna.platform.win32;
/*    */ 
/*    */ import com.sun.jna.ptr.IntByReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WinspoolUtil
/*    */ {
/*    */   public static Winspool.PRINTER_INFO_1[] getPrinterInfo1() {
/* 27 */     IntByReference pcbNeeded = new IntByReference();
/* 28 */     IntByReference pcReturned = new IntByReference();
/* 29 */     Winspool.INSTANCE.EnumPrinters(2, null, 1, null, 0, pcbNeeded, pcReturned);
/*    */     
/* 31 */     if (pcbNeeded.getValue() <= 0) {
/* 32 */       return new Winspool.PRINTER_INFO_1[0];
/*    */     }
/*    */     
/* 35 */     Winspool.PRINTER_INFO_1 pPrinterEnum = new Winspool.PRINTER_INFO_1(pcbNeeded.getValue());
/* 36 */     if (!Winspool.INSTANCE.EnumPrinters(2, null, 1, pPrinterEnum.getPointer(), pcbNeeded.getValue(), pcbNeeded, pcReturned))
/*    */     {
/* 38 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*    */     }
/*    */     
/* 41 */     pPrinterEnum.read();
/*    */     
/* 43 */     return (Winspool.PRINTER_INFO_1[])pPrinterEnum.toArray(pcReturned.getValue());
/*    */   }
/*    */   
/*    */   public static Winspool.PRINTER_INFO_4[] getPrinterInfo4() {
/* 47 */     IntByReference pcbNeeded = new IntByReference();
/* 48 */     IntByReference pcReturned = new IntByReference();
/* 49 */     Winspool.INSTANCE.EnumPrinters(2, null, 4, null, 0, pcbNeeded, pcReturned);
/*    */     
/* 51 */     if (pcbNeeded.getValue() <= 0) {
/* 52 */       return new Winspool.PRINTER_INFO_4[0];
/*    */     }
/*    */     
/* 55 */     Winspool.PRINTER_INFO_4 pPrinterEnum = new Winspool.PRINTER_INFO_4(pcbNeeded.getValue());
/* 56 */     if (!Winspool.INSTANCE.EnumPrinters(2, null, 4, pPrinterEnum.getPointer(), pcbNeeded.getValue(), pcbNeeded, pcReturned))
/*    */     {
/* 58 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*    */     }
/*    */     
/* 61 */     pPrinterEnum.read();
/*    */     
/* 63 */     return (Winspool.PRINTER_INFO_4[])pPrinterEnum.toArray(pcReturned.getValue());
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\platform\win32\WinspoolUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */