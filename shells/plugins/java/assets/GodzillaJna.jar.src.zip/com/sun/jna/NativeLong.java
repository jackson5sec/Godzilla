/*    */ package com.sun.jna;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NativeLong
/*    */   extends IntegerType
/*    */ {
/* 23 */   public static final int SIZE = Native.LONG_SIZE;
/*    */ 
/*    */   
/*    */   public NativeLong() {
/* 27 */     this(0L);
/*    */   }
/*    */ 
/*    */   
/*    */   public NativeLong(long value) {
/* 32 */     super(SIZE, value);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\com\sun\jna\NativeLong.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */