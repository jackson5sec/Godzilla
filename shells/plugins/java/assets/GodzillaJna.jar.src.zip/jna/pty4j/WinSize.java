/*     */ package jna.pty4j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WinSize
/*     */ {
/*     */   private final int myColumns;
/*     */   private final int myRows;
/*     */   @Deprecated
/*     */   public short ws_col;
/*     */   @Deprecated
/*     */   public short ws_row;
/*     */   @Deprecated
/*     */   public short ws_xpixel;
/*     */   @Deprecated
/*     */   public short ws_ypixel;
/*     */   
/*     */   public WinSize() {
/*  60 */     this(0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WinSize(int columns, int rows) {
/*  67 */     this.myColumns = columns;
/*  68 */     this.myRows = rows;
/*  69 */     this.ws_col = (short)columns;
/*  70 */     this.ws_row = (short)rows;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public WinSize(int columns, int rows, int width, int height) {
/*  78 */     this(columns, rows);
/*     */   }
/*     */   
/*     */   public int getColumns() {
/*  82 */     return this.myColumns;
/*     */   }
/*     */   
/*     */   public int getRows() {
/*  86 */     return this.myRows;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  91 */     if (this == o) return true; 
/*  92 */     if (o == null || getClass() != o.getClass()) return false; 
/*  93 */     WinSize winSize = (WinSize)o;
/*  94 */     return (this.myColumns == winSize.myColumns && this.myRows == winSize.myRows && this.ws_row == winSize.ws_row && this.ws_col == winSize.ws_col);
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*  99 */     return super.hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 104 */     return "columns=" + this.myColumns + ", rows=" + this.myRows + ", ws_col=" + this.ws_col + ", ws_row=" + this.ws_row;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\jna\pty4j\WinSize.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */