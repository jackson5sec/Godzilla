/*    */ package jna.pty4j;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PtyProcessOptions
/*    */ {
/*    */   private final String[] myCommand;
/*    */   private final Map<String, String> myEnvironment;
/*    */   private final String myDirectory;
/*    */   private final boolean myRedirectErrorStream;
/*    */   private final Integer myInitialColumns;
/*    */   private final Integer myInitialRows;
/*    */   private final boolean myWindowsAnsiColorEnabled;
/*    */   private final boolean myUnixOpenTtyToPreserveOutputAfterTermination;
/*    */   
/*    */   PtyProcessOptions(String[] command, Map<String, String> environment, String directory, boolean redirectErrorStream, Integer initialColumns, Integer initialRows, boolean windowsAnsiColorEnabled, boolean unixOpenTtyToPreserveOutputAfterTermination) {
/* 25 */     this.myCommand = command;
/* 26 */     this.myEnvironment = environment;
/* 27 */     this.myDirectory = directory;
/* 28 */     this.myRedirectErrorStream = redirectErrorStream;
/* 29 */     this.myInitialColumns = initialColumns;
/* 30 */     this.myInitialRows = initialRows;
/* 31 */     this.myWindowsAnsiColorEnabled = windowsAnsiColorEnabled;
/* 32 */     this.myUnixOpenTtyToPreserveOutputAfterTermination = unixOpenTtyToPreserveOutputAfterTermination;
/*    */   }
/*    */ 
/*    */   
/*    */   public String[] getCommand() {
/* 37 */     return this.myCommand;
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, String> getEnvironment() {
/* 42 */     return this.myEnvironment;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getDirectory() {
/* 47 */     return this.myDirectory;
/*    */   }
/*    */   
/*    */   public boolean isRedirectErrorStream() {
/* 51 */     return this.myRedirectErrorStream;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getInitialColumns() {
/* 56 */     return this.myInitialColumns;
/*    */   }
/*    */ 
/*    */   
/*    */   public Integer getInitialRows() {
/* 61 */     return this.myInitialRows;
/*    */   }
/*    */   
/*    */   public boolean isWindowsAnsiColorEnabled() {
/* 65 */     return this.myWindowsAnsiColorEnabled;
/*    */   }
/*    */   
/*    */   public boolean isUnixOpenTtyToPreserveOutputAfterTermination() {
/* 69 */     return this.myUnixOpenTtyToPreserveOutputAfterTermination;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\jna\pty4j\PtyProcessOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */