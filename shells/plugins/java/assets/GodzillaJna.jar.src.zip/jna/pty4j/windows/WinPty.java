/*     */ package jna.pty4j.windows;
/*     */ 
/*     */ import com.sun.jna.Library;
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.Kernel32;
/*     */ import com.sun.jna.platform.win32.WinBase;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import jna.pty4j.WinSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WinPty
/*     */ {
/*  23 */   private static final boolean DEFAULT_MIN_INITIAL_TERMINAL_WINDOW_HEIGHT = !Boolean.getBoolean("disable.minimal.initial.terminal.window.height");
/*     */   
/*     */   private Pointer myWinpty;
/*     */   
/*     */   private WinNT.HANDLE myProcess;
/*     */   
/*     */   private NamedPipe myConinPipe;
/*     */   private NamedPipe myConoutPipe;
/*     */   private NamedPipe myConerrPipe;
/*     */   private boolean myChildExited = false;
/*  33 */   private int myStatus = -1;
/*     */   
/*     */   private boolean myClosed = false;
/*     */   private WinSize myLastWinSize;
/*  37 */   private int openInputStreamCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   WinPty(String cmdline, String cwd, String env, boolean consoleMode, Integer initialColumns, Integer initialRows, boolean enableAnsiColor) throws WinPtyException, IOException {
/*  46 */     int cols = ((initialColumns != null) ? initialColumns : Integer.getInteger("win.pty.cols", 80)).intValue();
/*  47 */     int rows = getInitialRows(initialRows);
/*  48 */     IntByReference errCode = new IntByReference();
/*  49 */     PointerByReference errPtr = new PointerByReference(null);
/*  50 */     Pointer agentCfg = null;
/*  51 */     Pointer spawnCfg = null;
/*  52 */     Pointer winpty = null;
/*  53 */     WinNT.HANDLEByReference processHandle = new WinNT.HANDLEByReference();
/*  54 */     NamedPipe coninPipe = null;
/*  55 */     NamedPipe conoutPipe = null;
/*  56 */     NamedPipe conerrPipe = null;
/*     */ 
/*     */     
/*     */     try {
/*  60 */       long agentFlags = 0L;
/*  61 */       if (consoleMode) {
/*  62 */         agentFlags = 3L;
/*  63 */         if (enableAnsiColor) {
/*  64 */           agentFlags |= 0x4L;
/*     */         }
/*     */       } 
/*  67 */       agentCfg = getINSTANCE().winpty_config_new(agentFlags, null);
/*  68 */       if (agentCfg == null) {
/*  69 */         throw new WinPtyException("winpty agent cfg is null");
/*     */       }
/*  71 */       getINSTANCE().winpty_config_set_initial_size(agentCfg, cols, rows);
/*  72 */       this.myLastWinSize = new WinSize(cols, rows);
/*     */ 
/*     */       
/*  75 */       winpty = getINSTANCE().winpty_open(agentCfg, errPtr);
/*  76 */       if (winpty == null) {
/*  77 */         WString errMsg = getINSTANCE().winpty_error_msg(errPtr.getValue());
/*  78 */         String errorMessage = errMsg.toString();
/*  79 */         if ("ConnectNamedPipe failed: Windows error 232".equals(errorMessage)) {
/*  80 */           errorMessage = errorMessage + "\n" + suggestFixForError232();
/*     */         }
/*  82 */         throw new WinPtyException("Error starting winpty: " + errorMessage);
/*     */       } 
/*     */ 
/*     */       
/*  86 */       coninPipe = NamedPipe.connectToServer(getINSTANCE().winpty_conin_name(winpty).toString(), 1073741824);
/*  87 */       conoutPipe = NamedPipe.connectToServer(getINSTANCE().winpty_conout_name(winpty).toString(), -2147483648);
/*  88 */       if (consoleMode) {
/*  89 */         conerrPipe = NamedPipe.connectToServer(getINSTANCE().winpty_conerr_name(winpty).toString(), -2147483648);
/*     */       }
/*     */       
/*  92 */       for (int i = 0; i < 5; i++) {
/*  93 */         boolean result = getINSTANCE().winpty_set_size(winpty, cols, rows, null);
/*  94 */         if (!result) {
/*     */           break;
/*     */         }
/*     */         try {
/*  98 */           Thread.sleep(10L);
/*     */         }
/* 100 */         catch (InterruptedException e) {
/* 101 */           e.printStackTrace();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 106 */       spawnCfg = getINSTANCE().winpty_spawn_config_new(3L, null, 
/*     */ 
/*     */ 
/*     */           
/* 110 */           toWString(cmdline), 
/* 111 */           toWString(cwd), 
/* 112 */           toWString(env), null);
/*     */       
/* 114 */       if (spawnCfg == null) {
/* 115 */         throw new WinPtyException("winpty spawn cfg is null");
/*     */       }
/* 117 */       if (!getINSTANCE().winpty_spawn(winpty, spawnCfg, processHandle, null, errCode, errPtr)) {
/* 118 */         WString errMsg = getINSTANCE().winpty_error_msg(errPtr.getValue());
/* 119 */         throw new WinPtyException("Error running process: " + errMsg.toString() + ". Code " + errCode.getValue());
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 124 */       this.myWinpty = winpty;
/* 125 */       this.myProcess = processHandle.getValue();
/* 126 */       this.myConinPipe = coninPipe;
/* 127 */       this.myConoutPipe = conoutPipe;
/* 128 */       this.myConerrPipe = conerrPipe;
/* 129 */       this.openInputStreamCount = consoleMode ? 2 : 1;
/*     */ 
/*     */       
/* 132 */       Thread waitForExit = new WaitForExitThread();
/* 133 */       waitForExit.setDaemon(true);
/* 134 */       waitForExit.start();
/*     */       
/* 136 */       winpty = null;
/* 137 */       processHandle.setValue(null);
/* 138 */       coninPipe = conoutPipe = conerrPipe = null;
/*     */     } finally {
/*     */       
/* 141 */       getINSTANCE().winpty_error_free(errPtr.getValue());
/* 142 */       getINSTANCE().winpty_config_free(agentCfg);
/* 143 */       getINSTANCE().winpty_spawn_config_free(spawnCfg);
/* 144 */       getINSTANCE().winpty_free(winpty);
/* 145 */       if (processHandle.getValue() != null) {
/* 146 */         Kernel32.INSTANCE.CloseHandle(processHandle.getValue());
/*     */       }
/* 148 */       closeNamedPipeQuietly(coninPipe);
/* 149 */       closeNamedPipeQuietly(conoutPipe);
/* 150 */       closeNamedPipeQuietly(conerrPipe);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String suggestFixForError232() {
/*     */     try {
/* 157 */       File dllFile = new File(getLibraryPath());
/* 158 */       File exeFile = new File(dllFile.getParentFile(), "winpty-agent.exe");
/* 159 */       return "This error can occur due to antivirus blocking winpty from creating a pty. Please exclude the following files in your antivirus:\n - " + exeFile
/* 160 */         .getAbsolutePath() + "\n - " + dllFile
/* 161 */         .getAbsolutePath();
/*     */     }
/* 163 */     catch (Exception e) {
/* 164 */       return e.getMessage();
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getInitialRows(Integer initialRows) {
/* 169 */     if (initialRows != null) {
/* 170 */       return initialRows.intValue();
/*     */     }
/* 172 */     Integer rows = Integer.getInteger("win.pty.rows");
/* 173 */     if (rows != null) {
/* 174 */       return rows.intValue();
/*     */     }
/*     */     
/*     */     try {
/* 178 */       return DEFAULT_MIN_INITIAL_TERMINAL_WINDOW_HEIGHT ? 1 : 25;
/*     */     }
/* 180 */     catch (Exception e) {
/* 181 */       e.printStackTrace();
/* 182 */       return 25;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void closeNamedPipeQuietly(NamedPipe pipe) {
/*     */     try {
/* 188 */       if (pipe != null) {
/* 189 */         pipe.close();
/*     */       }
/* 191 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private static WString toWString(String string) {
/* 196 */     return (string == null) ? null : new WString(string);
/*     */   }
/*     */   
/*     */   synchronized void setWinSize(WinSize winSize) throws IOException {
/* 200 */     if (this.myClosed) {
/* 201 */       throw new IOException("Unable to set window size: closed=" + this.myClosed + ", winSize=" + winSize);
/*     */     }
/* 203 */     boolean result = getINSTANCE().winpty_set_size(this.myWinpty, winSize.getColumns(), winSize.getRows(), null);
/* 204 */     if (result) {
/* 205 */       this.myLastWinSize = new WinSize(winSize.getColumns(), winSize.getRows());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized WinSize getWinSize() throws IOException {
/* 211 */     WinSize lastWinSize = this.myLastWinSize;
/* 212 */     if (this.myClosed || lastWinSize == null) {
/* 213 */       throw new IOException("Unable to get window size: closed=" + this.myClosed + ", lastWinSize=" + lastWinSize);
/*     */     }
/* 215 */     return new WinSize(lastWinSize.getColumns(), lastWinSize.getRows());
/*     */   }
/*     */   
/*     */   synchronized void decrementOpenInputStreamCount() {
/* 219 */     this.openInputStreamCount--;
/* 220 */     if (this.openInputStreamCount == 0) {
/* 221 */       close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void close() {
/* 233 */     if (this.myClosed) {
/*     */       return;
/*     */     }
/* 236 */     getINSTANCE().winpty_free(this.myWinpty);
/* 237 */     this.myWinpty = null;
/* 238 */     this.myClosed = true;
/* 239 */     closeUnusedProcessHandle();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void closeUnusedProcessHandle() {
/* 250 */     if (this.myClosed && this.myChildExited && this.myProcess != null) {
/* 251 */       Kernel32.INSTANCE.CloseHandle(this.myProcess);
/* 252 */       this.myProcess = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized boolean isRunning() {
/* 260 */     return !this.myChildExited;
/*     */   }
/*     */ 
/*     */   
/*     */   synchronized int waitFor() throws InterruptedException {
/* 265 */     while (!this.myChildExited) {
/* 266 */       wait();
/*     */     }
/* 268 */     return this.myStatus;
/*     */   }
/*     */   
/*     */   synchronized int getChildProcessId() {
/* 272 */     if (this.myClosed) {
/* 273 */       return -1;
/*     */     }
/* 275 */     return Kernel32.INSTANCE.GetProcessId(this.myProcess);
/*     */   }
/*     */   
/*     */   synchronized int exitValue() {
/* 279 */     if (!this.myChildExited) {
/* 280 */       throw new IllegalThreadStateException("Process not Terminated");
/*     */     }
/* 282 */     return this.myStatus;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() throws Throwable {
/* 287 */     close();
/* 288 */     super.finalize();
/*     */   }
/*     */   
/*     */   NamedPipe getInputPipe() {
/* 292 */     return this.myConoutPipe;
/*     */   }
/*     */   
/*     */   NamedPipe getOutputPipe() {
/* 296 */     return this.myConinPipe;
/*     */   }
/*     */   
/*     */   NamedPipe getErrorPipe() {
/* 300 */     return this.myConerrPipe;
/*     */   }
/*     */ 
/*     */   
/*     */   String getWorkingDirectory() throws IOException {
/* 305 */     if (this.myClosed) {
/* 306 */       return null;
/*     */     }
/* 308 */     int bufferLength = 1024;
/* 309 */     Memory memory = new Memory((Native.WCHAR_SIZE * bufferLength));
/* 310 */     PointerByReference errPtr = new PointerByReference();
/*     */     try {
/* 312 */       int result = getINSTANCE().winpty_get_current_directory(this.myWinpty, bufferLength, (Pointer)memory, errPtr);
/* 313 */       if (result > 0) {
/* 314 */         return memory.getWideString(0L);
/*     */       }
/* 316 */       WString message = getINSTANCE().winpty_error_msg(errPtr.getValue());
/* 317 */       int code = getINSTANCE().winpty_error_code(errPtr.getValue());
/* 318 */       throw new IOException("winpty_get_current_directory failed, code: " + code + ", message: " + message);
/*     */     } finally {
/*     */       
/* 321 */       getINSTANCE().winpty_error_free(errPtr.getValue());
/*     */     } 
/*     */   } private static interface WinPtyLib extends Library {
/*     */     public static final long WINPTY_FLAG_CONERR = 1L; public static final long WINPTY_FLAG_PLAIN_OUTPUT = 2L; public static final long WINPTY_FLAG_COLOR_ESCAPES = 4L; public static final long WINPTY_SPAWN_FLAG_AUTO_SHUTDOWN = 1L; public static final long WINPTY_SPAWN_FLAG_EXIT_AFTER_SHUTDOWN = 2L; int winpty_error_code(Pointer param1Pointer); WString winpty_error_msg(Pointer param1Pointer); void winpty_error_free(Pointer param1Pointer); Pointer winpty_config_new(long param1Long, PointerByReference param1PointerByReference); void winpty_config_free(Pointer param1Pointer); void winpty_config_set_initial_size(Pointer param1Pointer, int param1Int1, int param1Int2); Pointer winpty_open(Pointer param1Pointer, PointerByReference param1PointerByReference); WString winpty_conin_name(Pointer param1Pointer); WString winpty_conout_name(Pointer param1Pointer); WString winpty_conerr_name(Pointer param1Pointer); Pointer winpty_spawn_config_new(long param1Long, WString param1WString1, WString param1WString2, WString param1WString3, WString param1WString4, PointerByReference param1PointerByReference); void winpty_spawn_config_free(Pointer param1Pointer); boolean winpty_spawn(Pointer param1Pointer1, Pointer param1Pointer2, WinNT.HANDLEByReference param1HANDLEByReference1, WinNT.HANDLEByReference param1HANDLEByReference2, IntByReference param1IntByReference, PointerByReference param1PointerByReference); boolean winpty_set_size(Pointer param1Pointer, int param1Int1, int param1Int2, PointerByReference param1PointerByReference); int winpty_get_console_process_list(Pointer param1Pointer1, Pointer param1Pointer2, int param1Int, PointerByReference param1PointerByReference); int winpty_get_current_directory(Pointer param1Pointer1, int param1Int, Pointer param1Pointer2, PointerByReference param1PointerByReference); void winpty_free(Pointer param1Pointer); }
/*     */   int getConsoleProcessList() throws IOException {
/* 326 */     if (this.myClosed) {
/* 327 */       return 0;
/*     */     }
/* 329 */     int MAX_COUNT = 64;
/* 330 */     Memory memory = new Memory((Native.LONG_SIZE * MAX_COUNT));
/* 331 */     PointerByReference errPtr = new PointerByReference();
/*     */     try {
/* 333 */       int actualProcessCount = getINSTANCE().winpty_get_console_process_list(this.myWinpty, (Pointer)memory, MAX_COUNT, errPtr);
/* 334 */       if (actualProcessCount == 0) {
/* 335 */         WString message = getINSTANCE().winpty_error_msg(errPtr.getValue());
/* 336 */         int code = getINSTANCE().winpty_error_code(errPtr.getValue());
/* 337 */         throw new IOException("winpty_get_console_process_list failed, code: " + code + ", message: " + message);
/*     */       } 
/*     */       
/* 340 */       return actualProcessCount;
/*     */     } finally {
/*     */       
/* 343 */       getINSTANCE().winpty_error_free(errPtr.getValue());
/*     */     } 
/*     */   } static interface Kern32 extends Library {
/*     */     boolean PeekNamedPipe(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2, IntByReference param1IntByReference3); boolean ReadFile(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, int param1Int, IntByReference param1IntByReference, Pointer param1Pointer2); boolean WriteFile(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, int param1Int, IntByReference param1IntByReference, Pointer param1Pointer2); boolean GetOverlappedResult(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, IntByReference param1IntByReference, boolean param1Boolean);
/*     */     WinNT.HANDLE CreateNamedPipeA(String param1String, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5, int param1Int6, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES);
/*     */     boolean ConnectNamedPipe(WinNT.HANDLE param1HANDLE, WinBase.OVERLAPPED param1OVERLAPPED);
/*     */     boolean CloseHandle(WinNT.HANDLE param1HANDLE);
/*     */     WinNT.HANDLE CreateEventA(WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, boolean param1Boolean1, boolean param1Boolean2, String param1String);
/*     */     int GetLastError();
/*     */     int WaitForSingleObject(WinNT.HANDLE param1HANDLE, int param1Int);
/*     */     boolean CancelIo(WinNT.HANDLE param1HANDLE);
/*     */     int GetCurrentProcessId(); }
/* 355 */   private class WaitForExitThread extends Thread { private IntByReference myStatusByRef = new IntByReference(-1);
/*     */ 
/*     */     
/*     */     public void run() {
/* 359 */       Kernel32.INSTANCE.WaitForSingleObject(WinPty.this.myProcess, -1);
/* 360 */       Kernel32.INSTANCE.GetExitCodeProcess(WinPty.this.myProcess, this.myStatusByRef);
/* 361 */       synchronized (WinPty.this) {
/* 362 */         WinPty.this.myChildExited = true;
/* 363 */         WinPty.this.myStatus = this.myStatusByRef.getValue();
/* 364 */         WinPty.this.closeUnusedProcessHandle();
/* 365 */         WinPty.this.notifyAll();
/*     */       } 
/*     */     }
/*     */     
/*     */     private WaitForExitThread() {} }
/* 370 */   static final Kern32 KERNEL32 = (Kern32)Native.loadLibrary("kernel32", Kern32.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 410 */   private static WinPtyLib INSTANCE = null;
/* 411 */   private static Object INSTANCE_LOCK = new Object();
/*     */   
/*     */   private static WinPtyLib getINSTANCE() {
/* 414 */     synchronized (INSTANCE_LOCK) {
/* 415 */       if (INSTANCE == null) {
/* 416 */         INSTANCE = (WinPtyLib)Native.loadLibrary(getLibraryPath(), WinPtyLib.class);
/*     */       }
/* 418 */       return INSTANCE;
/*     */     } 
/*     */   }
/*     */   private static String getLibraryPath() {
/*     */     try {
/* 423 */       String tmpdir = System.getProperty("java.io.tmpdir");
/* 424 */       char lastChar = tmpdir.charAt(tmpdir.length() - 1);
/* 425 */       if (lastChar != '\\' && lastChar != '/') {
/* 426 */         tmpdir = tmpdir + File.separator;
/*     */       }
/*     */       
/* 429 */       return String.format("%swinpty_x%s.dll", new Object[] { tmpdir, System.getProperty("sun.arch.data.model") });
/*     */     }
/* 431 */     catch (Exception e) {
/* 432 */       throw new IllegalStateException("Couldn't detect jar containing folder", e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\jna\pty4j\windows\WinPty.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */