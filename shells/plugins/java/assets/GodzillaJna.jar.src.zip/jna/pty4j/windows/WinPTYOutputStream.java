/*    */ package jna.pty4j.windows;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WinPTYOutputStream
/*    */   extends OutputStream
/*    */ {
/*    */   private final WinPty myWinPty;
/*    */   private final NamedPipe myNamedPipe;
/*    */   private final boolean myPatchNewline;
/*    */   private final boolean mySendEOF;
/*    */   
/*    */   public WinPTYOutputStream(WinPty winPty, NamedPipe namedPipe, boolean patchNewline, boolean sendEOF) {
/* 22 */     this.myWinPty = winPty;
/* 23 */     this.myNamedPipe = namedPipe;
/* 24 */     this.myPatchNewline = patchNewline;
/* 25 */     this.mySendEOF = sendEOF;
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(byte[] b, int off, int len) throws IOException {
/* 30 */     if (b == null) {
/* 31 */       throw new NullPointerException();
/*    */     }
/* 33 */     if (off < 0 || len < 0 || len > b.length - off) {
/* 34 */       throw new IndexOutOfBoundsException();
/*    */     }
/*    */     
/* 37 */     if (this.myPatchNewline) {
/* 38 */       byte[] newBuf = new byte[len];
/* 39 */       int newPos = 0;
/* 40 */       for (int i = off; i < off + len; i++) {
/* 41 */         if (b[i] == 10) {
/* 42 */           newBuf[newPos++] = 13;
/*    */         } else {
/* 44 */           newBuf[newPos++] = b[i];
/*    */         } 
/*    */       } 
/* 47 */       b = newBuf;
/* 48 */       off = 0;
/* 49 */       len = newPos;
/*    */     } 
/*    */     
/* 52 */     this.myNamedPipe.write(b, off, len);
/*    */   }
/*    */ 
/*    */   
/*    */   public void write(int b) throws IOException {
/* 57 */     byte[] buf = new byte[1];
/* 58 */     buf[0] = (byte)b;
/* 59 */     write(buf, 0, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 64 */     if (this.mySendEOF)
/*    */     {
/* 66 */       write(new byte[] { 94, 90, 10 });
/*    */     }
/* 68 */     this.myNamedPipe.close();
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\GodzillaJna.jar!\jna\pty4j\windows\WinPTYOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */