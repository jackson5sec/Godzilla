package oracle.jdbc;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public interface AdditionalDatabaseMetaData extends DatabaseMetaData {
  OracleTypeMetaData getOracleTypeMetaData(String paramString) throws SQLException;
  
  long getLobMaxLength() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\AdditionalDatabaseMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */