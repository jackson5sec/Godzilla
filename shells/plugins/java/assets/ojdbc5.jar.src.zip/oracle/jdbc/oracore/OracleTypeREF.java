/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.REF;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeREF
/*     */   extends OracleNamedType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 3186448715463064573L;
/*     */   
/*     */   protected OracleTypeREF() {}
/*     */   
/*     */   public OracleTypeREF(String paramString, OracleConnection paramOracleConnection) throws SQLException {
/*  41 */     super(paramString, paramOracleConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeREF(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) {
/*  48 */     super(paramOracleTypeADT, paramInt, paramOracleConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  63 */     REF rEF = null;
/*     */     
/*  65 */     if (paramObject != null)
/*     */     {
/*  67 */       if (paramObject instanceof REF) {
/*  68 */         rEF = (REF)paramObject;
/*     */       } else {
/*     */         
/*  71 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  72 */         sQLException.fillInStackTrace();
/*  73 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */     
/*  77 */     return (Datum)rEF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/*  91 */     return 2006;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 112 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 113 */       return null;
/*     */     }
/* 115 */     if (paramInt == 1 || paramInt == 2) {
/*     */       
/* 117 */       StructDescriptor structDescriptor = createStructDescriptor();
/*     */       
/* 119 */       return new REF(structDescriptor, (Connection)this.connection, paramArrayOfbyte);
/*     */     } 
/* 121 */     if (paramInt == 3)
/*     */     {
/* 123 */       return paramArrayOfbyte;
/*     */     }
/*     */ 
/*     */     
/* 127 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 128 */     sQLException.fillInStackTrace();
/* 129 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StructDescriptor createStructDescriptor() throws SQLException {
/* 138 */     if (this.descriptor == null)
/*     */     {
/* 140 */       if (this.sqlName == null && getFullName(false) == null) {
/*     */         
/* 142 */         OracleTypeADT oracleTypeADT = new OracleTypeADT(getParent(), getOrder(), (Connection)this.connection);
/*     */         
/* 144 */         this.descriptor = (TypeDescriptor)new StructDescriptor(oracleTypeADT, (Connection)this.connection);
/*     */       }
/*     */       else {
/*     */         
/* 148 */         this.descriptor = (TypeDescriptor)StructDescriptor.createDescriptor(this.sqlName, (Connection)this.connection);
/*     */       } 
/*     */     }
/* 151 */     return (StructDescriptor)this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 208 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\oracore\OracleTypeREF.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */