/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.BINARY_FLOAT;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeBINARY_FLOAT
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  47 */     BINARY_FLOAT bINARY_FLOAT = null;
/*     */     
/*  49 */     if (paramObject != null)
/*     */     {
/*  51 */       if (paramObject instanceof BINARY_FLOAT) {
/*  52 */         bINARY_FLOAT = (BINARY_FLOAT)paramObject;
/*  53 */       } else if (paramObject instanceof Float) {
/*  54 */         bINARY_FLOAT = new BINARY_FLOAT((Float)paramObject);
/*  55 */       } else if (paramObject instanceof byte[]) {
/*  56 */         bINARY_FLOAT = new BINARY_FLOAT((byte[])paramObject);
/*     */       } else {
/*     */         
/*  59 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  60 */         sQLException.fillInStackTrace();
/*  61 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */     
/*  65 */     return (Datum)bINARY_FLOAT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/*  79 */     Datum[] arrayOfDatum = null;
/*     */     
/*  81 */     if (paramObject != null)
/*     */     {
/*  83 */       if (paramObject instanceof Object[]) {
/*     */         
/*  85 */         Object[] arrayOfObject = (Object[])paramObject;
/*     */         
/*  87 */         int i = (int)((paramInt == -1) ? arrayOfObject.length : Math.min(arrayOfObject.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/*  90 */         arrayOfDatum = new Datum[i];
/*     */         
/*  92 */         for (byte b = 0; b < i; b++) {
/*     */           
/*  94 */           Object object = arrayOfObject[(int)paramLong + b - 1];
/*     */           
/*  96 */           if (object != null) {
/*     */             
/*  98 */             if (object instanceof Float) {
/*  99 */               arrayOfDatum[b] = (Datum)new BINARY_FLOAT(((Float)object).floatValue());
/*     */             }
/* 101 */             else if (object instanceof BINARY_FLOAT) {
/* 102 */               arrayOfDatum[b] = (Datum)object;
/*     */             } else {
/*     */               
/* 105 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 106 */               sQLException.fillInStackTrace();
/* 107 */               throw sQLException;
/*     */             }
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 113 */             arrayOfDatum[b] = null;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 119 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/* 129 */     return 100;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 155 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 156 */       return null;
/*     */     }
/* 158 */     if (paramInt == 1)
/* 159 */       return new BINARY_FLOAT(paramArrayOfbyte); 
/* 160 */     if (paramInt == 2)
/* 161 */       return (new BINARY_FLOAT(paramArrayOfbyte)).toJdbc(); 
/* 162 */     if (paramInt == 3) {
/* 163 */       return paramArrayOfbyte;
/*     */     }
/*     */     
/* 166 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 167 */     sQLException.fillInStackTrace();
/* 168 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 173 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\oracore\OracleTypeBINARY_FLOAT.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */