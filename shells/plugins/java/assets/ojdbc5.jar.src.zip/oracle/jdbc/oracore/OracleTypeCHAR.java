/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CHAR;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.converter.CharacterSetMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeCHAR
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -6899444518695804629L;
/*     */   int form;
/*     */   int charset;
/*     */   int length;
/*     */   int characterSemantic;
/*     */   private transient OracleConnection connection;
/*     */   private short pickleCharaterSetId;
/*     */   private transient CharacterSet pickleCharacterSet;
/*     */   private short pickleNcharCharacterSet;
/*     */   static final int SQLCS_IMPLICIT = 1;
/*     */   static final int SQLCS_NCHAR = 2;
/*     */   static final int SQLCS_EXPLICIT = 3;
/*     */   static final int SQLCS_FLEXIBLE = 4;
/*     */   static final int SQLCS_LIT_NULL = 5;
/*     */   
/*     */   protected OracleTypeCHAR() {}
/*     */   
/*     */   public OracleTypeCHAR(OracleConnection paramOracleConnection) {
/*  71 */     this.form = 0;
/*  72 */     this.charset = 0;
/*  73 */     this.length = 0;
/*  74 */     this.connection = paramOracleConnection;
/*  75 */     this.pickleCharaterSetId = 0;
/*  76 */     this.pickleNcharCharacterSet = 0;
/*  77 */     this.pickleCharacterSet = null;
/*     */ 
/*     */     
/*     */     try {
/*  81 */       this.pickleCharaterSetId = this.connection.getStructAttrCsId();
/*     */     }
/*  83 */     catch (SQLException sQLException) {
/*     */ 
/*     */       
/*  86 */       this.pickleCharaterSetId = -1;
/*     */     } 
/*     */     
/*  89 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleTypeCHAR(OracleConnection paramOracleConnection, int paramInt) {
/*  95 */     super(paramInt);
/*     */     
/*  97 */     this.form = 0;
/*  98 */     this.charset = 0;
/*  99 */     this.length = 0;
/* 100 */     this.connection = paramOracleConnection;
/* 101 */     this.pickleCharaterSetId = 0;
/* 102 */     this.pickleNcharCharacterSet = 0;
/* 103 */     this.pickleCharacterSet = null;
/*     */ 
/*     */     
/*     */     try {
/* 107 */       this.pickleCharaterSetId = this.connection.getStructAttrCsId();
/*     */     }
/* 109 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 113 */       this.pickleCharaterSetId = -1;
/*     */     } 
/*     */     
/* 116 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*     */     CHAR cHAR;
/* 142 */     if (paramObject == null) {
/* 143 */       return null;
/*     */     }
/* 145 */     if (paramObject instanceof CHAR) {
/* 146 */       return (Datum)paramObject;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (this.typeCode == 1 && paramObject instanceof String) {
/*     */       
/* 153 */       if (this.characterSemantic != 0) {
/*     */         
/* 155 */         int i = CharacterSetMetaData.getRatio(this.pickleCharaterSetId, 1);
/*     */         
/* 157 */         String str = (String)paramObject;
/* 158 */         for (int j = str.length(); j < this.length / i; ) { str = str + " "; j++; }
/* 159 */          paramObject = str;
/* 160 */         cHAR = new CHAR(paramObject, this.pickleCharacterSet);
/*     */       }
/*     */       else {
/*     */         
/* 164 */         cHAR = new CHAR((String)paramObject, this.pickleCharacterSet, this.length);
/*     */       } 
/*     */     } else {
/* 167 */       cHAR = new CHAR(paramObject, this.pickleCharacterSet);
/* 168 */     }  return (Datum)cHAR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum[] toDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/* 191 */     Datum[] arrayOfDatum = null;
/*     */     
/* 193 */     if (paramObject != null) {
/*     */       
/* 195 */       if (paramObject instanceof Object[] && !(paramObject instanceof char[][])) {
/* 196 */         return super.toDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */       }
/* 198 */       arrayOfDatum = cArrayToDatumArray(paramObject, paramOracleConnection, paramLong, paramInt);
/*     */     } 
/*     */     
/* 201 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/* 216 */     super.parseTDSrec(paramTDSReader);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 221 */       this.length = paramTDSReader.readUB2();
/* 222 */       this.form = paramTDSReader.readByte();
/* 223 */       this.characterSemantic = this.form & 0x80;
/* 224 */       this.form &= 0x7F;
/* 225 */       this.charset = paramTDSReader.readUB2();
/*     */     }
/* 227 */     catch (SQLException sQLException1) {
/*     */ 
/*     */       
/* 230 */       SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 47, "parseTDS");
/* 231 */       sQLException2.fillInStackTrace();
/* 232 */       throw sQLException2;
/*     */     } 
/*     */ 
/*     */     
/* 236 */     if (this.form != 2 || this.pickleNcharCharacterSet != 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 245 */       this.pickleNcharCharacterSet = this.connection.getStructAttrNCsId();
/*     */     }
/* 247 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 251 */       this.pickleNcharCharacterSet = 2000;
/*     */     } 
/*     */     
/* 254 */     this.pickleCharaterSetId = this.pickleNcharCharacterSet;
/* 255 */     this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
/* 281 */     CHAR cHAR = getDbCHAR(paramDatum);
/*     */     
/* 283 */     if (this.characterSemantic != 0 && this.form != 2) {
/*     */ 
/*     */ 
/*     */       
/* 287 */       if (cHAR.getStringWithReplacement().length() > this.length)
/*     */       {
/* 289 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + cHAR.getStringWithReplacement() + "\"");
/* 290 */         sQLException.fillInStackTrace();
/* 291 */         throw sQLException;
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 298 */     else if (cHAR.getLength() > this.length) {
/*     */       
/* 300 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 72, "\"" + cHAR.getStringWithReplacement() + "\"");
/* 301 */       sQLException.fillInStackTrace();
/* 302 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 306 */     return super.pickle81(paramPickleContext, (Datum)cHAR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 318 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 319 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 323 */     CHAR cHAR = null;
/*     */     
/* 325 */     switch (this.form) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 333 */         cHAR = new CHAR(paramArrayOfbyte, this.pickleCharacterSet);
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/* 342 */         cHAR = new CHAR(paramArrayOfbyte, null);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 347 */     if (paramInt == 1)
/* 348 */       return cHAR; 
/* 349 */     if (paramInt == 2)
/* 350 */       return cHAR.stringValue(); 
/* 351 */     if (paramInt == 3) {
/* 352 */       return paramArrayOfbyte;
/*     */     }
/*     */     
/* 355 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 356 */     sQLException.fillInStackTrace();
/* 357 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CHAR getDbCHAR(Datum paramDatum) {
/* 371 */     CHAR cHAR1 = (CHAR)paramDatum;
/* 372 */     CHAR cHAR2 = null;
/*     */     
/* 374 */     if (cHAR1.getCharacterSet().getOracleId() == this.pickleCharaterSetId) {
/*     */       
/* 376 */       cHAR2 = cHAR1;
/*     */     } else {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 382 */         cHAR2 = new CHAR(cHAR1.toString(), this.pickleCharacterSet);
/*     */       }
/* 384 */       catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */         
/* 388 */         cHAR2 = cHAR1;
/*     */       } 
/*     */     } 
/* 391 */     return cHAR2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Datum[] cArrayToDatumArray(Object paramObject, OracleConnection paramOracleConnection, long paramLong, int paramInt) throws SQLException {
/* 420 */     Datum[] arrayOfDatum = null;
/*     */     
/* 422 */     if (paramObject != null)
/*     */     {
/* 424 */       if (paramObject instanceof char[][]) {
/*     */         
/* 426 */         char[][] arrayOfChar = (char[][])paramObject;
/* 427 */         int i = (int)((paramInt == -1) ? arrayOfChar.length : Math.min(arrayOfChar.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 430 */         arrayOfDatum = new Datum[i];
/*     */         
/* 432 */         for (byte b = 0; b < i; b++) {
/* 433 */           arrayOfDatum[b] = (Datum)new CHAR(new String(arrayOfChar[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 436 */       else if (paramObject instanceof boolean[]) {
/*     */         
/* 438 */         boolean[] arrayOfBoolean = (boolean[])paramObject;
/* 439 */         int i = (int)((paramInt == -1) ? arrayOfBoolean.length : Math.min(arrayOfBoolean.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 442 */         arrayOfDatum = new Datum[i];
/*     */         
/* 444 */         for (byte b = 0; b < i; b++) {
/* 445 */           arrayOfDatum[b] = (Datum)new CHAR(Boolean.valueOf(arrayOfBoolean[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 448 */       else if (paramObject instanceof short[]) {
/*     */         
/* 450 */         short[] arrayOfShort = (short[])paramObject;
/* 451 */         int i = (int)((paramInt == -1) ? arrayOfShort.length : Math.min(arrayOfShort.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 454 */         arrayOfDatum = new Datum[i];
/*     */ 
/*     */ 
/*     */         
/* 458 */         for (byte b = 0; b < i; b++) {
/* 459 */           arrayOfDatum[b] = (Datum)new CHAR(Integer.valueOf(arrayOfShort[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         
/*     */         }
/*     */       }
/* 463 */       else if (paramObject instanceof int[]) {
/*     */         
/* 465 */         int[] arrayOfInt = (int[])paramObject;
/* 466 */         int i = (int)((paramInt == -1) ? arrayOfInt.length : Math.min(arrayOfInt.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 469 */         arrayOfDatum = new Datum[i];
/*     */         
/* 471 */         for (byte b = 0; b < i; b++) {
/* 472 */           arrayOfDatum[b] = (Datum)new CHAR(Integer.valueOf(arrayOfInt[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 475 */       else if (paramObject instanceof long[]) {
/*     */         
/* 477 */         long[] arrayOfLong = (long[])paramObject;
/* 478 */         int i = (int)((paramInt == -1) ? arrayOfLong.length : Math.min(arrayOfLong.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 481 */         arrayOfDatum = new Datum[i];
/*     */         
/* 483 */         for (byte b = 0; b < i; b++) {
/* 484 */           arrayOfDatum[b] = (Datum)new CHAR(new Long(arrayOfLong[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 487 */       else if (paramObject instanceof float[]) {
/*     */         
/* 489 */         float[] arrayOfFloat = (float[])paramObject;
/* 490 */         int i = (int)((paramInt == -1) ? arrayOfFloat.length : Math.min(arrayOfFloat.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 493 */         arrayOfDatum = new Datum[i];
/*     */         
/* 495 */         for (byte b = 0; b < i; b++) {
/* 496 */           arrayOfDatum[b] = (Datum)new CHAR(new Float(arrayOfFloat[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         }
/*     */       }
/* 499 */       else if (paramObject instanceof double[]) {
/*     */         
/* 501 */         double[] arrayOfDouble = (double[])paramObject;
/* 502 */         int i = (int)((paramInt == -1) ? arrayOfDouble.length : Math.min(arrayOfDouble.length - paramLong + 1L, paramInt));
/*     */ 
/*     */         
/* 505 */         arrayOfDatum = new Datum[i];
/*     */         
/* 507 */         for (byte b = 0; b < i; b++) {
/* 508 */           arrayOfDatum[b] = (Datum)new CHAR(new Double(arrayOfDouble[(int)paramLong + b - 1]), this.pickleCharacterSet);
/*     */         
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 514 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 515 */         sQLException.fillInStackTrace();
/* 516 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 521 */     return arrayOfDatum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLength() {
/* 528 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 539 */     paramObjectOutputStream.writeInt(this.form);
/* 540 */     paramObjectOutputStream.writeInt(this.charset);
/* 541 */     paramObjectOutputStream.writeInt(this.length);
/* 542 */     paramObjectOutputStream.writeInt(this.characterSemantic);
/* 543 */     paramObjectOutputStream.writeShort(this.pickleCharaterSetId);
/* 544 */     paramObjectOutputStream.writeShort(this.pickleNcharCharacterSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 552 */     this.form = paramObjectInputStream.readInt();
/* 553 */     this.charset = paramObjectInputStream.readInt();
/* 554 */     this.length = paramObjectInputStream.readInt();
/* 555 */     this.characterSemantic = paramObjectInputStream.readInt();
/* 556 */     this.pickleCharaterSetId = paramObjectInputStream.readShort();
/* 557 */     this.pickleNcharCharacterSet = paramObjectInputStream.readShort();
/*     */     
/* 559 */     if (this.pickleNcharCharacterSet != 0) {
/* 560 */       this.pickleCharacterSet = CharacterSet.make(this.pickleNcharCharacterSet);
/*     */     } else {
/* 562 */       this.pickleCharacterSet = CharacterSet.make(this.pickleCharaterSetId);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 569 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNCHAR() throws SQLException {
/* 583 */     return (this.form == 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 598 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 645 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\oracore\OracleTypeCHAR.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */