/*     */ package oracle.jdbc.diagnostics;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.logging.FileHandler;
/*     */ import java.util.logging.Handler;
/*     */ import java.util.logging.LogManager;
/*     */ import java.util.logging.LogRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DemultiplexingLogHandler
/*     */   extends FileHandler
/*     */ {
/*     */   static final String PROPERTY_PATTERN = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.pattern";
/*     */   static final String PROPERTY_LIMIT = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit";
/*     */   static final String PROPERTY_COUNT = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.count";
/*     */   static final String PROPERTY_APPEND = "oracle.jdbc.diagnostics.DemultiplexingLogHandler.append";
/*     */   static final String DEFAULT_PATTERN = "%h/ojdbc_%s.trc";
/*  51 */   static final String DEFAULT_APPEND = String.valueOf(false);
/*  52 */   static final String DEFAULT_LIMIT = String.valueOf(2147483647);
/*  53 */   static final String DEFAULT_COUNT = String.valueOf(1);
/*     */   
/*     */   String localPattern;
/*     */   boolean localAppend;
/*     */   int localLimit;
/*     */   int localCount;
/*     */   Hashtable<Object, Handler> handlerList;
/*     */   
/*     */   public DemultiplexingLogHandler() throws IOException
/*     */   {
/*  63 */     super(getFilename(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.pattern", "%h/ojdbc_%s.trc"), "MAIN"), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)), Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     this.handlerList = new Hashtable<Object, Handler>(50); } public DemultiplexingLogHandler(String paramString) throws IOException { super(getFilename(paramString, "MAIN"), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)), Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND))); this.handlerList = new Hashtable<Object, Handler>(50); } public DemultiplexingLogHandler(String paramString, boolean paramBoolean) throws IOException { super(getFilename(paramString, "MAIN"), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)), Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)), paramBoolean); this.handlerList = new Hashtable<Object, Handler>(50); } public DemultiplexingLogHandler(String paramString, int paramInt1, int paramInt2) throws IOException { super(getFilename(paramString, "MAIN"), paramInt1, paramInt2, Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND))); this.handlerList = new Hashtable<Object, Handler>(50); } void initValues() { this.localPattern = getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.pattern", "%h/ojdbc_%s.trc"); this.localLimit = Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.limit", DEFAULT_LIMIT)); this.localCount = Integer.parseInt(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.count", DEFAULT_COUNT)); this.localAppend = Boolean.getBoolean(getProperty("oracle.jdbc.diagnostics.DemultiplexingLogHandler.append", DEFAULT_APPEND)); } public DemultiplexingLogHandler(String paramString, int paramInt1, int paramInt2, boolean paramBoolean) throws IOException { super(getFilename(paramString, "MAIN"), paramInt1, paramInt2, paramBoolean); this.handlerList = new Hashtable<Object, Handler>(50); }
/*     */ 
/*     */   
/*     */   public void publish(LogRecord paramLogRecord) {
/* 149 */     Object[] arrayOfObject = paramLogRecord.getParameters();
/* 150 */     if (arrayOfObject != null && arrayOfObject.length > 0) {
/*     */ 
/*     */       
/* 153 */       Handler handler = this.handlerList.get(arrayOfObject[0]);
/* 154 */       if (handler == null) {
/*     */         
/* 156 */         if (this.localPattern == null) {
/* 157 */           initValues();
/*     */         }
/*     */         try {
/* 160 */           handler = new FileHandler(getFilename(this.localPattern, (String)arrayOfObject[0]), this.localLimit, this.localCount, this.localAppend);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 165 */           handler.setFormatter(getFormatter());
/* 166 */           handler.setFilter(getFilter());
/* 167 */           handler.setLevel(getLevel());
/* 168 */           handler.setEncoding(getEncoding());
/* 169 */           handler.setErrorManager(getErrorManager());
/* 170 */         } catch (IOException iOException) {
/*     */ 
/*     */           
/* 173 */           reportError("Unable open FileHandler", iOException, 0);
/*     */         } 
/*     */         
/* 176 */         this.handlerList.put(arrayOfObject[0], handler);
/*     */       } 
/* 178 */       handler.publish(paramLogRecord);
/*     */     } else {
/*     */       
/* 181 */       super.publish(paramLogRecord);
/*     */     }  } static final String getFilename(String paramString1, String paramString2) { if (paramString1 == null)
/*     */       paramString1 = "%h/ojdbc_%s.trc"; 
/*     */     if (paramString1.contains("%s"))
/*     */       return paramString1.replaceAll("%s", paramString2); 
/*     */     return paramString1 + "." + paramString2; }
/* 187 */   public void close() { for (Handler handler : this.handlerList.values()) {
/* 188 */       handler.close();
/*     */     }
/* 190 */     super.close(); }
/*     */ 
/*     */   
/*     */   static String getProperty(String paramString1, String paramString2) {
/*     */     String str = LogManager.getLogManager().getProperty(paramString1);
/*     */     return (str != null) ? str : paramString2;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\diagnostics\DemultiplexingLogHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */