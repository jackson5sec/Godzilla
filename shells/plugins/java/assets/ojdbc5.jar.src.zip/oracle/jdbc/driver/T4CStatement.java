/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CStatement
/*      */   extends OracleStatement
/*      */ {
/*   24 */   static final byte[][][] parameterDatum = (byte[][][])null;
/*   25 */   static final OracleTypeADT[][] parameterOtype = (OracleTypeADT[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   35 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   55 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   56 */       this.oacdefSent = null;
/*      */     }
/*   58 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.doOall8");
/*      */     
/*   60 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   64 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   65 */       sQLException.fillInStackTrace();
/*   66 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   70 */     if (paramBoolean3) {
/*   71 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   73 */     int i = this.numberOfDefinePositions;
/*      */     
/*   75 */     if (this.sqlKind.isDML()) {
/*   76 */       i = 0;
/*      */     }
/*      */     
/*   79 */     if (this.accessors != null)
/*   80 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   81 */         if (this.accessors[b] != null)
/*   82 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   83 */       }   if (this.outBindAccessors != null)
/*   84 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   85 */         if (this.outBindAccessors[b] != null)
/*   86 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*   87 */       }   if (this.returnParamAccessors != null) {
/*   88 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*   89 */         if (this.returnParamAccessors[b] != null) {
/*   90 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*   97 */     if (this.bindIndicators != null) {
/*      */       
/*   99 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  102 */       int k = 0;
/*      */       
/*  104 */       if (this.ibtBindChars != null) {
/*  105 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  107 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  109 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  113 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  117 */         if (n != 0) {
/*      */ 
/*      */           
/*  120 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  124 */           if (i1 == 2) {
/*      */             
/*  126 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  131 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  137 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  139 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  141 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  143 */         this.tmpBindsByteArray = null;
/*  144 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  156 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  161 */     int[] arrayOfInt1 = this.definedColumnType;
/*  162 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  163 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  169 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  174 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  175 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  176 */       arrayOfInt1[0] = -8;
/*  177 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  178 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  179 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  180 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  186 */     allocateTmpByteArray();
/*      */     
/*  188 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  190 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  195 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, parameterDatum, parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  207 */       int j = t4C8Oall.getCursorId();
/*  208 */       if (j != 0) {
/*  209 */         this.cursorId = j;
/*      */       }
/*  211 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  213 */     catch (SQLException sQLException) {
/*      */       
/*  215 */       int j = t4C8Oall.getCursorId();
/*  216 */       if (j != 0) {
/*  217 */         this.cursorId = j;
/*      */       }
/*  219 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  222 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  227 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  237 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  240 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  242 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  246 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  258 */     super.releaseBuffers();
/*  259 */     this.tmpByteArray = null;
/*  260 */     this.tmpBindsByteArray = null;
/*      */     
/*  262 */     this.t4Connection.all8.bindChars = null;
/*  263 */     this.t4Connection.all8.bindBytes = null;
/*  264 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  271 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  284 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  295 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  306 */     if (paramInt1 < 1) {
/*      */       
/*  308 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  309 */       sQLException.fillInStackTrace();
/*  310 */       throw sQLException;
/*      */     } 
/*  312 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  316 */       if (paramInt2 == 1 || paramInt2 == 12)
/*      */       {
/*      */ 
/*      */         
/*  320 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  326 */     else if (paramInt3 < 0) {
/*      */       
/*  328 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  329 */       sQLException.fillInStackTrace();
/*  330 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  334 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  336 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  337 */       sQLException.fillInStackTrace();
/*  338 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  345 */     int i = paramInt1 - 1;
/*      */     
/*  347 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  349 */       if (this.definedColumnType == null) {
/*      */         
/*  351 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  363 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  365 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  368 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  374 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  376 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  378 */       if (this.definedColumnSize == null) {
/*  379 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  382 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  384 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  387 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  391 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  393 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  395 */       if (this.definedColumnFormOfUse == null) {
/*  396 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  399 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  401 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  404 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  408 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  410 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  412 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  417 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  421 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  427 */           this.needToPrepareDefineBuffer = true;
/*  428 */           this.columnsDefinedByUser = true;
/*      */           
/*  430 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  431 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  440 */     synchronized (this.connection) {
/*      */       
/*  442 */       super.clearDefines();
/*  443 */       this.definedColumnType = null;
/*  444 */       this.definedColumnSize = null;
/*  445 */       this.definedColumnFormOfUse = null;
/*  446 */       this.t4Connection.all8.definesAccessors = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  464 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  493 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  502 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  503 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  504 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  506 */       int m = bool ? this.accessors.length : 1;
/*  507 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  508 */         m += bool ? -1 : 1) {
/*      */         
/*  510 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  511 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  512 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  513 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  520 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  521 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  522 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  529 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  536 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  546 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  566 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  568 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  572 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  578 */         if (!paramBoolean) {
/*      */           
/*  580 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  588 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  594 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  600 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  606 */         if (!paramBoolean) {
/*      */           
/*  608 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  616 */         if (paramBoolean && paramString != null) {
/*      */           
/*  618 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  619 */           sQLException1.fillInStackTrace();
/*  620 */           throw sQLException1;
/*      */         } 
/*      */         
/*  623 */         if (paramBoolean) {
/*  624 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  627 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  633 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  639 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  645 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  651 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  655 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  658 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  665 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  671 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  677 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  683 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  689 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  695 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  698 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  703 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  706 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  713 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  719 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  725 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  731 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  737 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  753 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  754 */         sQLException.fillInStackTrace();
/*  755 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  759 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  786 */     if (!this.isOpen) {
/*      */ 
/*      */ 
/*      */       
/*  790 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/*  791 */       sQLException.fillInStackTrace();
/*  792 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  799 */       this.t4Connection.needLine();
/*  800 */       this.t4Connection.sendPiggyBackedMessages();
/*  801 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  802 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  804 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  806 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  807 */         this.accessors[b].initMetadata();
/*      */       }
/*  809 */     } catch (IOException iOException) {
/*      */       
/*  811 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  814 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  815 */       sQLException.fillInStackTrace();
/*  816 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  820 */     this.describedWithNames = true;
/*  821 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  856 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  859 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  865 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  869 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  872 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  875 */       throw sQLException;
/*      */     }
/*  877 */     catch (IOException iOException) {
/*      */       
/*  879 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  881 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  882 */       sQLException.fillInStackTrace();
/*  883 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  888 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  889 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  892 */     this.needToParse = false;
/*      */ 
/*      */     
/*  895 */     if (this.connection.calculateChecksum) {
/*  896 */       if (this.validRows > 0) {
/*  897 */         calculateCheckSum();
/*  898 */       } else if (this.rowsProcessed > 0) {
/*  899 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  901 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  911 */     if (this.definedColumnType == null) {
/*  912 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  914 */     this.aFetchWasDoneDuringDescribe = false;
/*  915 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  917 */       this.aFetchWasDoneDuringDescribe = true;
/*  918 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  922 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  923 */       this.accessors[b].initMetadata();
/*      */     }
/*  925 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  967 */         boolean bool = false;
/*  968 */         if (this.columnsDefinedByUser) {
/*  969 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  989 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  997 */           boolean bool1 = false;
/*  998 */           int[] arrayOfInt1 = new int[this.accessors.length];
/*  999 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1001 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1006 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1007 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1013 */               bool1 = true;
/* 1014 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1015 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1019 */           if (bool1) {
/*      */             
/* 1021 */             this.definedColumnType = arrayOfInt1;
/* 1022 */             this.definedColumnSize = arrayOfInt2;
/* 1023 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1029 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1031 */         this.needToParse = false;
/* 1032 */         if (bool) {
/* 1033 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1037 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1040 */     } catch (SQLException sQLException) {
/*      */       
/* 1042 */       throw sQLException;
/*      */     }
/* 1044 */     catch (IOException iOException) {
/*      */       
/* 1046 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1047 */       calculateCheckSum();
/*      */       
/* 1049 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1050 */       sQLException.fillInStackTrace();
/* 1051 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1078 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1082 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1086 */           this.nextStream.close();
/*      */         }
/* 1088 */         catch (IOException iOException) {
/*      */           
/* 1090 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1092 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1093 */           sQLException.fillInStackTrace();
/* 1094 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1098 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1104 */       doOall8(false, false, true, false, false);
/*      */       
/* 1106 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1108 */     catch (IOException iOException) {
/*      */       
/* 1110 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1112 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1113 */       sQLException.fillInStackTrace();
/* 1114 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1120 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1135 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1137 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1139 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1142 */     } catch (IOException iOException) {
/*      */       
/* 1144 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1146 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1147 */       sQLException.fillInStackTrace();
/* 1148 */       throw sQLException;
/*      */     
/*      */     }
/* 1151 */     catch (SQLException sQLException) {
/*      */       
/* 1153 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1156 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1161 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1185 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.do_close");
/*      */     
/* 1187 */     if (this.cursorId != 0) {
/* 1188 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1191 */     this.tmpByteArray = null;
/* 1192 */     this.tmpBindsByteArray = null;
/* 1193 */     this.definedColumnType = null;
/* 1194 */     this.definedColumnSize = null;
/* 1195 */     this.definedColumnFormOfUse = null;
/* 1196 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1216 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CStatement.closeQuery");
/*      */     
/* 1218 */     if (this.streamList != null)
/*      */     {
/* 1220 */       while (this.nextStream != null) {
/*      */         try {
/* 1222 */           this.nextStream.close();
/*      */         }
/* 1224 */         catch (IOException iOException) {
/* 1225 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1227 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1228 */           sQLException.fillInStackTrace();
/* 1229 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1233 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
/* 1248 */     super(paramPhysicalConnection, 1, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */     
/* 1250 */     this.nbPostPonedColumns = new int[1];
/* 1251 */     this.nbPostPonedColumns[0] = 0;
/* 1252 */     this.indexOfPostPonedColumn = new int[1][3];
/* 1253 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeCursorOnPlainStatement() throws SQLException {
/* 1268 */     if (this.cursorId != 0 && this.t4Connection.isLoggedOn()) {
/* 1269 */       this.t4Connection.closeCursor(this.cursorId);
/* 1270 */       setCursorId(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1276 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */