/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NUMBER;
/*     */ import oracle.sql.RAW;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPLTZ;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CCharAccessor
/*     */   extends CharAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLong = false;
/*     */   final int[] meta;
/*     */   final int[] tmp;
/*     */   
/*     */   T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  63 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this.meta = new int[1];
/* 135 */     this.tmp = new int[1]; this.mare = paramT4CMAREngine; calculateSizeTmpByteArray(); } T4CCharAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, int paramInt9, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1]; this.tmp = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     this.definedColumnType = paramInt8;
/*     */     this.definedColumnSize = paramInt9;
/*     */     calculateSizeTmpByteArray();
/*     */     this.oacmxl = paramInt7;
/*     */     if (this.oacmxl == -1) {
/*     */       this.underlyingLong = true;
/*     */       this.oacmxl = 4000;
/* 144 */     }  } boolean unmarshalOneRow() throws SQLException, IOException { if (this.isUseLess) {
/*     */       
/* 146 */       this.lastRowProcessed++;
/*     */       
/* 148 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 152 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 153 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 157 */     byte[] arrayOfByte = this.statement.tmpByteArray;
/* 158 */     int k = this.columnIndex + this.lastRowProcessed * this.charLength;
/*     */ 
/*     */ 
/*     */     
/* 162 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 166 */       byte[] arrayOfByte1 = new byte[16000];
/*     */       
/* 168 */       this.mare.unmarshalCLR(arrayOfByte1, 0, this.meta);
/* 169 */       processIndicator(this.meta[0]);
/*     */       
/* 171 */       this.lastRowProcessed++;
/*     */       
/* 173 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 178 */     if (this.isNullByDescribe) {
/*     */       
/* 180 */       this.rowSpaceIndicator[i] = -1;
/* 181 */       this.rowSpaceIndicator[j] = 0;
/* 182 */       this.lastRowProcessed++;
/*     */       
/* 184 */       if (this.statement.connection.versionNumber < 9200) {
/* 185 */         processIndicator(0);
/*     */       }
/* 187 */       return false;
/*     */     } 
/*     */     
/* 190 */     if (this.statement.maxFieldSize > 0) {
/* 191 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta, this.statement.maxFieldSize);
/*     */     } else {
/* 193 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/*     */     } 
/* 195 */     this.tmp[0] = this.meta[0];
/*     */     
/* 197 */     int m = 0;
/*     */     
/* 199 */     if (this.formOfUse == 2) {
/* 200 */       m = this.statement.connection.conversion.NCHARBytesToJavaChars(arrayOfByte, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 214 */       m = this.statement.connection.conversion.CHARBytesToJavaChars(arrayOfByte, 0, this.rowSpaceChar, k + 1, this.tmp, this.charLength - 1);
/*     */     } 
/*     */ 
/*     */     
/* 218 */     this.rowSpaceChar[k] = (char)(m * 2);
/*     */ 
/*     */ 
/*     */     
/* 222 */     processIndicator(this.meta[0]);
/*     */     
/* 224 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 228 */       this.rowSpaceIndicator[i] = -1;
/* 229 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 233 */       this.rowSpaceIndicator[j] = (short)(this.meta[0] * 2);
/*     */ 
/*     */ 
/*     */       
/* 237 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 240 */     this.lastRowProcessed++;
/*     */     
/* 242 */     return false; }
/*     */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  } void copyRow() throws SQLException, IOException { int i;
/* 252 */     if (this.lastRowProcessed == 0) {
/* 253 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 255 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 258 */     int j = this.columnIndex + this.lastRowProcessed * this.charLength;
/* 259 */     int k = this.columnIndex + i * this.charLength;
/* 260 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 261 */     int n = this.indicatorIndex + i;
/* 262 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 263 */     int i2 = this.lengthIndex + i;
/* 264 */     short s = this.rowSpaceIndicator[i2];
/* 265 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 267 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 271 */     this.rowSpaceIndicator[i1] = (short)s;
/* 272 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 275 */     if (!this.isNullByDescribe)
/*     */     {
/* 277 */       System.arraycopy(this.rowSpaceChar, k, this.rowSpaceChar, j, this.rowSpaceChar[k] / 2 + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 282 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 285 */     this.lastRowProcessed++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 298 */     int i = this.columnIndex + (paramInt2 - 1) * this.charLength;
/*     */     
/* 300 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.charLength;
/*     */     
/* 302 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 303 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 304 */     int n = this.lengthIndex + paramInt2 - 1;
/* 305 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 306 */     short s = paramArrayOfshort[i1];
/*     */     
/* 308 */     this.rowSpaceIndicator[n] = (short)s;
/* 309 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 312 */     if (s != 0) {
/*     */       
/* 314 */       System.arraycopy(paramArrayOfchar, j, this.rowSpaceChar, i, paramArrayOfchar[j] / 2 + 1);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 319 */       this.rowSpaceChar[i] = Character.MIN_VALUE;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void calculateSizeTmpByteArray() {
/*     */     int i;
/* 342 */     if (this.formOfUse == 2) {
/*     */ 
/*     */ 
/*     */       
/* 346 */       i = (this.charLength - 1) * this.statement.connection.conversion.maxNCharSize;
/*     */     }
/*     */     else {
/*     */       
/* 350 */       i = (this.charLength - 1) * this.statement.connection.conversion.cMaxCharSize;
/*     */     } 
/*     */     
/* 353 */     if (this.statement.sizeTmpByteArray < i) {
/* 354 */       this.statement.sizeTmpByteArray = i;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 367 */     String str = super.getString(paramInt);
/*     */     
/* 369 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 371 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 373 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NUMBER getNUMBER(int paramInt) throws SQLException {
/* 383 */     NUMBER nUMBER = null;
/*     */     
/* 385 */     if (this.definedColumnType == 0) {
/* 386 */       nUMBER = super.getNUMBER(paramInt);
/*     */     } else {
/*     */       
/* 389 */       String str = getString(paramInt);
/* 390 */       if (str != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 399 */         return T4CVarcharAccessor.StringToNUMBER(str);
/*     */       }
/*     */     } 
/*     */     
/* 403 */     return nUMBER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 410 */     DATE dATE = null;
/*     */     
/* 412 */     if (this.definedColumnType == 0) {
/* 413 */       dATE = super.getDATE(paramInt);
/*     */     } else {
/*     */       
/* 416 */       Date date = getDate(paramInt);
/* 417 */       if (date != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 426 */         dATE = new DATE(date);
/*     */       }
/*     */     } 
/*     */     
/* 430 */     return dATE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 438 */     TIMESTAMP tIMESTAMP = null;
/*     */     
/* 440 */     if (this.definedColumnType == 0) {
/* 441 */       tIMESTAMP = super.getTIMESTAMP(paramInt);
/*     */     } else {
/*     */       
/* 444 */       String str = getString(paramInt);
/* 445 */       if (str != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 455 */         int[] arrayOfInt = new int[1];
/* 456 */         Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*     */ 
/*     */         
/* 459 */         Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
/* 460 */         timestamp.setNanos(arrayOfInt[0]);
/* 461 */         tIMESTAMP = new TIMESTAMP(timestamp);
/*     */       } 
/*     */     } 
/*     */     
/* 465 */     return tIMESTAMP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 472 */     TIMESTAMPTZ tIMESTAMPTZ = null;
/*     */     
/* 474 */     if (this.definedColumnType == 0) {
/* 475 */       tIMESTAMPTZ = super.getTIMESTAMPTZ(paramInt);
/*     */     } else {
/*     */       
/* 478 */       String str = getString(paramInt);
/* 479 */       if (str != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 490 */         int[] arrayOfInt = new int[1];
/* 491 */         Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*     */ 
/*     */         
/* 494 */         Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
/* 495 */         timestamp.setNanos(arrayOfInt[0]);
/* 496 */         tIMESTAMPTZ = new TIMESTAMPTZ((Connection)this.statement.connection, timestamp, calendar);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 502 */     return tIMESTAMPTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 509 */     TIMESTAMPLTZ tIMESTAMPLTZ = null;
/*     */     
/* 511 */     if (this.definedColumnType == 0) {
/* 512 */       tIMESTAMPLTZ = super.getTIMESTAMPLTZ(paramInt);
/*     */     } else {
/*     */       
/* 515 */       String str = getString(paramInt);
/* 516 */       if (str != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 527 */         int[] arrayOfInt = new int[1];
/* 528 */         Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*     */ 
/*     */         
/* 531 */         Timestamp timestamp = new Timestamp(calendar.getTimeInMillis());
/* 532 */         timestamp.setNanos(arrayOfInt[0]);
/* 533 */         tIMESTAMPLTZ = new TIMESTAMPLTZ((Connection)this.statement.connection, timestamp, calendar);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 539 */     return tIMESTAMPLTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RAW getRAW(int paramInt) throws SQLException {
/* 546 */     RAW rAW = null;
/*     */     
/* 548 */     if (this.definedColumnType == 0) {
/* 549 */       rAW = super.getRAW(paramInt);
/*     */     } else {
/*     */       
/* 552 */       if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 556 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 557 */         sQLException.fillInStackTrace();
/* 558 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 564 */       if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */       {
/* 566 */         if (this.definedColumnType == -2 || this.definedColumnType == -3 || this.definedColumnType == -4) {
/*     */ 
/*     */           
/* 569 */           rAW = new RAW(getBytesFromHexChars(paramInt));
/*     */         } else {
/* 571 */           rAW = new RAW(super.getBytes(paramInt));
/*     */         } 
/*     */       }
/*     */     } 
/* 575 */     return rAW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 582 */     if (this.definedColumnType == 0) {
/* 583 */       return super.getOracleObject(paramInt);
/*     */     }
/*     */     
/* 586 */     Datum datum = null;
/*     */     
/* 588 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 590 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 591 */       sQLException.fillInStackTrace();
/* 592 */       throw sQLException;
/*     */     } 
/*     */     
/* 595 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 597 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 606 */           return super.getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -7:
/*     */         case -6:
/*     */         case -5:
/*     */         case 2:
/*     */         case 3:
/*     */         case 4:
/*     */         case 5:
/*     */         case 6:
/*     */         case 7:
/*     */         case 8:
/*     */         case 16:
/* 629 */           return (Datum)getNUMBER(paramInt);
/*     */         
/*     */         case 91:
/* 632 */           return (Datum)getDATE(paramInt);
/*     */         
/*     */         case 92:
/* 635 */           return (Datum)getDATE(paramInt);
/*     */         
/*     */         case 93:
/* 638 */           return (Datum)getTIMESTAMP(paramInt);
/*     */         
/*     */         case -101:
/* 641 */           return (Datum)getTIMESTAMPTZ(paramInt);
/*     */         
/*     */         case -102:
/* 644 */           return (Datum)getTIMESTAMPLTZ(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 651 */           return (Datum)getRAW(paramInt);
/*     */         
/*     */         case -8:
/* 654 */           return (Datum)getROWID(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 658 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 659 */       sQLException.fillInStackTrace();
/* 660 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 666 */     return datum;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 675 */     if (this.definedColumnType == 0) {
/* 676 */       return super.getBytes(paramInt);
/*     */     }
/* 678 */     Datum datum = getOracleObject(paramInt);
/* 679 */     if (datum != null) {
/* 680 */       return datum.shareBytes();
/*     */     }
/* 682 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean getBoolean(int paramInt) throws SQLException {
/* 690 */     boolean bool = false;
/*     */     
/* 692 */     if (this.definedColumnType == 0) {
/* 693 */       bool = super.getBoolean(paramInt);
/*     */     } else {
/*     */       
/* 696 */       bool = getNUMBER(paramInt).booleanValue();
/*     */     } 
/*     */     
/* 699 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte getByte(int paramInt) throws SQLException {
/* 707 */     byte b = 0;
/*     */     
/* 709 */     if (this.definedColumnType == 0) {
/* 710 */       b = super.getByte(paramInt);
/*     */     } else {
/*     */       
/* 713 */       NUMBER nUMBER = getNUMBER(paramInt);
/* 714 */       if (nUMBER != null) {
/* 715 */         b = nUMBER.byteValue();
/*     */       }
/*     */     } 
/* 718 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getInt(int paramInt) throws SQLException {
/* 726 */     int i = 0;
/*     */     
/* 728 */     if (this.definedColumnType == 0) {
/* 729 */       i = super.getInt(paramInt);
/*     */     } else {
/*     */       
/* 732 */       NUMBER nUMBER = getNUMBER(paramInt);
/* 733 */       if (nUMBER != null) {
/* 734 */         i = nUMBER.intValue();
/*     */       }
/*     */     } 
/* 737 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short getShort(int paramInt) throws SQLException {
/* 745 */     short s = 0;
/*     */     
/* 747 */     if (this.definedColumnType == 0) {
/* 748 */       s = super.getShort(paramInt);
/*     */     } else {
/*     */       
/* 751 */       NUMBER nUMBER = getNUMBER(paramInt);
/* 752 */       if (nUMBER != null) {
/* 753 */         s = nUMBER.shortValue();
/*     */       }
/*     */     } 
/* 756 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getLong(int paramInt) throws SQLException {
/* 764 */     long l = 0L;
/*     */     
/* 766 */     if (this.definedColumnType == 0) {
/* 767 */       l = super.getLong(paramInt);
/*     */     } else {
/*     */       
/* 770 */       NUMBER nUMBER = getNUMBER(paramInt);
/* 771 */       if (nUMBER != null) {
/* 772 */         l = nUMBER.longValue();
/*     */       }
/*     */     } 
/* 775 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float getFloat(int paramInt) throws SQLException {
/* 783 */     float f = 0.0F;
/*     */     
/* 785 */     if (this.definedColumnType == 0) {
/* 786 */       f = super.getFloat(paramInt);
/*     */     } else {
/*     */       
/* 789 */       NUMBER nUMBER = getNUMBER(paramInt);
/* 790 */       if (nUMBER != null) {
/* 791 */         f = nUMBER.floatValue();
/*     */       }
/*     */     } 
/* 794 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   double getDouble(int paramInt) throws SQLException {
/* 802 */     double d = 0.0D;
/*     */     
/* 804 */     if (this.definedColumnType == 0) {
/* 805 */       d = super.getDouble(paramInt);
/*     */     } else {
/*     */       
/* 808 */       NUMBER nUMBER = getNUMBER(paramInt);
/* 809 */       if (nUMBER != null) {
/* 810 */         d = nUMBER.doubleValue();
/*     */       }
/*     */     } 
/* 813 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 823 */     Date date = null;
/*     */     
/* 825 */     if (this.definedColumnType == 0) {
/* 826 */       date = super.getDate(paramInt);
/*     */     } else {
/*     */       
/* 829 */       String str = getString(paramInt);
/* 830 */       if (str != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 839 */         int[] arrayOfInt = new int[1];
/*     */         
/* 841 */         date = new Date(T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCDATEFM"), arrayOfInt).getTimeInMillis());
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 847 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 855 */     Timestamp timestamp = null;
/*     */     
/* 857 */     if (this.definedColumnType == 0) {
/* 858 */       timestamp = super.getTimestamp(paramInt);
/*     */     } else {
/*     */       
/* 861 */       String str = getString(paramInt);
/* 862 */       if (str != null) {
/*     */         
/* 864 */         int[] arrayOfInt = new int[1];
/* 865 */         Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTMPFM"), arrayOfInt);
/*     */ 
/*     */         
/* 868 */         timestamp = new Timestamp(calendar.getTimeInMillis());
/* 869 */         timestamp.setNanos(arrayOfInt[0]);
/*     */       } 
/*     */     } 
/*     */     
/* 873 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 881 */     Time time = null;
/*     */     
/* 883 */     if (this.definedColumnType == 0) {
/* 884 */       time = super.getTime(paramInt);
/*     */     } else {
/*     */       
/* 887 */       String str = getString(paramInt);
/* 888 */       if (str != null) {
/*     */         
/* 890 */         int[] arrayOfInt = new int[1];
/* 891 */         Calendar calendar = T4CVarcharAccessor.DATEStringToCalendar(str, (String)this.statement.connection.sessionProperties.get("AUTH_NLS_LXCSTZNFM"), arrayOfInt);
/*     */ 
/*     */         
/* 894 */         time = new Time(calendar.getTimeInMillis());
/*     */       } 
/*     */     } 
/*     */     
/* 898 */     return time;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 906 */     if (this.definedColumnType == 0) {
/* 907 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 910 */     Object object = null;
/*     */     
/* 912 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 914 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 915 */       sQLException.fillInStackTrace();
/* 916 */       throw sQLException;
/*     */     } 
/*     */     
/* 919 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 921 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 930 */           return getString(paramInt);
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 3:
/* 935 */           return getBigDecimal(paramInt);
/*     */         
/*     */         case 4:
/* 938 */           return Integer.valueOf(getInt(paramInt));
/*     */         
/*     */         case -6:
/* 941 */           return Byte.valueOf(getByte(paramInt));
/*     */         
/*     */         case 5:
/* 944 */           return Short.valueOf(getShort(paramInt));
/*     */ 
/*     */         
/*     */         case -7:
/*     */         case 16:
/* 949 */           return Boolean.valueOf(getBoolean(paramInt));
/*     */         
/*     */         case -5:
/* 952 */           return Long.valueOf(getLong(paramInt));
/*     */         
/*     */         case 7:
/* 955 */           return Float.valueOf(getFloat(paramInt));
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 8:
/* 960 */           return Double.valueOf(getDouble(paramInt));
/*     */         
/*     */         case 91:
/* 963 */           return getDate(paramInt);
/*     */         
/*     */         case 92:
/* 966 */           return getTime(paramInt);
/*     */         
/*     */         case 93:
/* 969 */           return getTimestamp(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 976 */           return getBytesFromHexChars(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 980 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 981 */       sQLException.fillInStackTrace();
/* 982 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 988 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 993 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CCharAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */