/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleClobWriter
/*     */   extends Writer
/*     */ {
/*     */   DBConversion dbConversion;
/*     */   CLOB clob;
/*     */   long lobOffset;
/*     */   char[] charBuf;
/*     */   byte[] nativeBuf;
/*     */   int pos;
/*     */   int count;
/*     */   int chunkSize;
/*     */   boolean isClosed;
/*     */   
/*     */   public OracleClobWriter(CLOB paramCLOB, int paramInt) throws SQLException {
/*  43 */     this(paramCLOB, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobWriter(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/*  60 */     if (paramCLOB == null || paramInt <= 0 || paramCLOB.getJavaSqlConnection() == null || paramLong < 1L)
/*     */     {
/*     */       
/*  63 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  66 */     this.dbConversion = ((PhysicalConnection)paramCLOB.getInternalConnection()).conversion;
/*     */ 
/*     */     
/*  69 */     this.clob = paramCLOB;
/*  70 */     this.lobOffset = paramLong;
/*     */     
/*  72 */     this.charBuf = new char[paramInt];
/*  73 */     this.nativeBuf = new byte[paramInt * 3];
/*  74 */     this.pos = this.count = 0;
/*  75 */     this.chunkSize = paramInt;
/*     */     
/*  77 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(char[] paramArrayOfchar, int paramInt1, int paramInt2) throws IOException {
/*  94 */     synchronized (this.lock) {
/*     */       
/*  96 */       ensureOpen();
/*     */       
/*  98 */       int i = paramInt1;
/*  99 */       int j = Math.min(paramInt2, paramArrayOfchar.length - paramInt1);
/*     */       
/* 101 */       if (j >= 2 * this.chunkSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 108 */         if (this.count > 0) flushBuffer();
/*     */         
/*     */         try {
/* 111 */           this.lobOffset += this.clob.putChars(this.lobOffset, paramArrayOfchar, paramInt1, j);
/*     */         }
/* 113 */         catch (SQLException sQLException) {
/*     */ 
/*     */           
/* 116 */           IOException iOException = DatabaseError.createIOException(sQLException);
/* 117 */           iOException.fillInStackTrace();
/* 118 */           throw iOException;
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 124 */       int k = i + j;
/*     */       
/* 126 */       while (i < k) {
/*     */         
/* 128 */         int m = Math.min(this.chunkSize - this.count, k - i);
/*     */         
/* 130 */         System.arraycopy(paramArrayOfchar, i, this.charBuf, this.count, m);
/*     */         
/* 132 */         i += m;
/* 133 */         this.count += m;
/*     */         
/* 135 */         if (this.count >= this.chunkSize) {
/* 136 */           flushBuffer();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 155 */     synchronized (this.lock) {
/*     */       
/* 157 */       ensureOpen();
/* 158 */       flushBuffer();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 174 */     synchronized (this.lock) {
/*     */       
/* 176 */       flushBuffer();
/*     */       
/* 178 */       this.isClosed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/* 190 */     synchronized (this.lock) {
/*     */ 
/*     */       
/*     */       try {
/* 194 */         if (this.count > 0)
/*     */         {
/* 196 */           this.lobOffset += this.clob.putChars(this.lobOffset, this.charBuf, 0, this.count);
/* 197 */           this.count = 0;
/*     */         }
/*     */       
/* 200 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 203 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 204 */         iOException.fillInStackTrace();
/* 205 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 223 */       if (this.isClosed)
/*     */       {
/* 225 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 226 */         sQLException.fillInStackTrace();
/* 227 */         throw sQLException;
/*     */       }
/*     */     
/* 230 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 233 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 234 */       iOException.fillInStackTrace();
/* 235 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 255 */       return this.clob.getInternalConnection();
/*     */     }
/* 257 */     catch (Exception exception) {
/*     */       
/* 259 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\OracleClobWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */