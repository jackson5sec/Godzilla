/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.pool.OraclePooledConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ClosedConnection
/*     */   extends PhysicalConnection
/*     */ {
/*     */   void initializePassword(String paramString) throws SQLException {}
/*     */   
/*     */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException {
/*  45 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  46 */     sQLException.fillInStackTrace();
/*  47 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getDefaultStreamChunkSize() {
/*  55 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short doGetVersionNumber() throws SQLException {
/*  63 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  64 */     sQLException.fillInStackTrace();
/*  65 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String doGetDatabaseProductVersion() throws SQLException {
/*  75 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  76 */     sQLException.fillInStackTrace();
/*  77 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doRollback() throws SQLException {
/*  87 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  88 */     sQLException.fillInStackTrace();
/*  89 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doCommit(int paramInt) throws SQLException {
/*  98 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  99 */     sQLException.fillInStackTrace();
/* 100 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doSetAutoCommit(boolean paramBoolean) throws SQLException {
/* 109 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 110 */     sQLException.fillInStackTrace();
/* 111 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void cancelOperationOnServer(boolean paramBoolean) throws SQLException {
/* 120 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 121 */     sQLException.fillInStackTrace();
/* 122 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doAbort() throws SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void open(OracleStatement paramOracleStatement) throws SQLException {
/* 138 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 139 */     sQLException.fillInStackTrace();
/* 140 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void logon() throws SQLException {
/* 149 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 150 */     sQLException.fillInStackTrace();
/* 151 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 161 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 162 */     sQLException.fillInStackTrace();
/* 163 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException {
/* 172 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 173 */     sQLException.fillInStackTrace();
/* 174 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 183 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 184 */     sQLException.fillInStackTrace();
/* 185 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\ClosedConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */