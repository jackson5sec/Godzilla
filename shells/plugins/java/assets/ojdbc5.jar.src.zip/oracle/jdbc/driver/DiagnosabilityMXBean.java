package oracle.jdbc.driver;

public interface DiagnosabilityMXBean {
  boolean stateManageable();
  
  boolean statisticsProvider();
  
  boolean getLoggingEnabled();
  
  void setLoggingEnabled(boolean paramBoolean);
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\DiagnosabilityMXBean.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */