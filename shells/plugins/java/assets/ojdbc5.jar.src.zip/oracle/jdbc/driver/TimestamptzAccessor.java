/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ import oracle.sql.TIMEZONETAB;
/*     */ import oracle.sql.ZONEIDMAP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestamptzAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   static final int maxLength = 13;
/*  32 */   TimestampTzConverter tstzConverter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  38 */     init(paramOracleStatement, 181, 181, paramShort, paramBoolean);
/*  39 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*     */     
/*  41 */     if (this.statement.connection.timestamptzInGmt) {
/*  42 */       this.tstzConverter = new GmtTimestampTzConverter();
/*     */     } else {
/*  44 */       this.tstzConverter = new OldTimestampTzConverter();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestamptzAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  53 */     init(paramOracleStatement, 181, 181, paramShort, false);
/*  54 */     initForDescribe(181, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  56 */     initForDataAccess(0, paramInt1, (String)null);
/*     */     
/*  58 */     if (this.statement.connection.timestamptzInGmt) {
/*  59 */       this.tstzConverter = new GmtTimestampTzConverter();
/*     */     } else {
/*  61 */       this.tstzConverter = new OldTimestampTzConverter();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  69 */     if (paramInt1 != 0) {
/*  70 */       this.externalType = paramInt1;
/*     */     }
/*  72 */     this.internalTypeMaxLength = 13;
/*     */     
/*  74 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  75 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  77 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*     */     String str;
/*  85 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/*  89 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  90 */       sQLException.fillInStackTrace();
/*  91 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] == -1) {
/*  98 */       return null;
/*     */     }
/* 100 */     int i = this.columnIndex + this.byteLength * paramInt;
/*     */ 
/*     */     
/* 103 */     int j = 0;
/*     */     
/* 105 */     if ((oracleTZ1(i) & REGIONIDBIT) != 0) {
/*     */       
/* 107 */       j = getHighOrderbits(oracleTZ1(i));
/* 108 */       j += getLowOrderbits(oracleTZ2(i));
/*     */ 
/*     */       
/* 111 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/* 112 */       if (tIMEZONETAB.checkID(j)) {
/* 113 */         tIMEZONETAB.updateTable((Connection)this.statement.connection, j);
/*     */       }
/* 115 */       str = ZONEIDMAP.getRegion(j);
/*     */     }
/*     */     else {
/*     */       
/* 119 */       int i5 = oracleTZ1(i) - OFFSET_HOUR;
/* 120 */       int i6 = oracleTZ2(i) - OFFSET_MINUTE;
/*     */       
/* 122 */       str = "GMT" + ((i5 < 0) ? "-" : "+") + Math.abs(i5) + ":" + ((i6 < 10) ? "0" : "") + i6;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     Calendar calendar = this.statement.getGMTCalendar();
/*     */     
/* 132 */     int k = oracleYear(i);
/*     */     
/* 134 */     calendar.set(1, k);
/* 135 */     calendar.set(2, oracleMonth(i));
/* 136 */     calendar.set(5, oracleDay(i));
/* 137 */     calendar.set(11, oracleHour(i));
/* 138 */     calendar.set(12, oracleMin(i));
/* 139 */     calendar.set(13, oracleSec(i));
/* 140 */     calendar.set(14, 0);
/*     */     
/* 142 */     if ((oracleTZ1(i) & REGIONIDBIT) != 0) {
/*     */       
/* 144 */       TIMEZONETAB tIMEZONETAB = this.statement.connection.getTIMEZONETAB();
/*     */ 
/*     */       
/* 147 */       int i5 = tIMEZONETAB.getOffset(calendar, j);
/*     */ 
/*     */       
/* 150 */       calendar.add(14, i5);
/*     */     }
/*     */     else {
/*     */       
/* 154 */       calendar.add(10, oracleTZ1(i) - OFFSET_HOUR);
/* 155 */       calendar.add(12, oracleTZ2(i) - OFFSET_MINUTE);
/*     */     } 
/*     */ 
/*     */     
/* 159 */     k = calendar.get(1);
/*     */     
/* 161 */     int m = calendar.get(2) + 1;
/* 162 */     int n = calendar.get(5);
/* 163 */     int i1 = calendar.get(11);
/* 164 */     int i2 = calendar.get(12);
/* 165 */     int i3 = calendar.get(13);
/* 166 */     boolean bool = (i1 < 12) ? true : false;
/* 167 */     if (str.length() > 3 && str.startsWith("GMT")) {
/* 168 */       str = str.substring(3);
/*     */     }
/* 170 */     int i4 = oracleNanos(i);
/*     */     
/* 172 */     return toText(k, m, n, i1, i2, i3, i4, bool, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt) throws SQLException {
/* 179 */     return this.tstzConverter.getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 187 */     return getDate(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt) throws SQLException {
/* 194 */     return this.tstzConverter.getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 202 */     return getTime(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt) throws SQLException {
/* 209 */     return this.tstzConverter.getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 217 */     return getTimestamp(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 222 */     return this.tstzConverter.getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 228 */     return this.tstzConverter.getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   DATE getDATE(int paramInt) throws SQLException {
/* 233 */     TIMESTAMPTZ tIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
/* 234 */     return TIMESTAMPTZ.toDATE((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 239 */     TIMESTAMPTZ tIMESTAMPTZ = this.tstzConverter.getTIMESTAMPTZ(paramInt);
/* 240 */     return TIMESTAMPTZ.toTIMESTAMP((Connection)this.statement.connection, tIMESTAMPTZ.getBytes());
/*     */   }
/*     */ 
/*     */   
/*     */   TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 245 */     return this.tstzConverter.getTIMESTAMPTZ(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   static int OFFSET_HOUR = 20;
/* 252 */   static int OFFSET_MINUTE = 60;
/*     */ 
/*     */   
/* 255 */   static byte REGIONIDBIT = Byte.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int setHighOrderbits(int paramInt) {
/* 265 */     return (paramInt & 0x1FC0) >> 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int setLowOrderbits(int paramInt) {
/* 273 */     return (paramInt & 0x3F) << 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getHighOrderbits(int paramInt) {
/* 281 */     return (paramInt & 0x7F) << 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getLowOrderbits(int paramInt) {
/* 288 */     return (paramInt & 0xFC) >> 2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class OldTimestampTzConverter
/*     */     extends TimestampTzConverter
/*     */   {
/*     */     Date getDate(int param1Int) throws SQLException {
/* 304 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 308 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 309 */         sQLException.fillInStackTrace();
/* 310 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 316 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
/* 317 */         return null;
/*     */       }
/* 319 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/*     */       
/* 321 */       TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 322 */       Calendar calendar = Calendar.getInstance(timeZone);
/*     */       
/* 324 */       int j = TimestamptzAccessor.this.oracleYear(i);
/*     */       
/* 326 */       calendar.set(1, j);
/* 327 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 328 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 329 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 330 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 331 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 332 */       calendar.set(14, 0);
/*     */       
/* 334 */       if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 338 */         int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
/* 339 */         k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
/*     */         
/* 341 */         TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/*     */         
/* 343 */         if (tIMEZONETAB.checkID(k)) {
/* 344 */           tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, k);
/*     */         }
/* 346 */         int m = tIMEZONETAB.getOffset(calendar, k);
/*     */         
/* 348 */         boolean bool1 = timeZone.inDaylightTime(calendar.getTime());
/* 349 */         boolean bool2 = timeZone.inDaylightTime(new Date(calendar.getTimeInMillis() + m));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 356 */         if (!bool1 && bool2) {
/*     */           
/* 358 */           calendar.add(14, -1 * timeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 366 */         else if (bool1 && !bool2) {
/*     */           
/* 368 */           calendar.add(14, timeZone.getDSTSavings());
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 373 */         calendar.add(10, m / 3600000);
/* 374 */         calendar.add(12, m % 3600000 / 60000);
/*     */       }
/*     */       else {
/*     */         
/* 378 */         calendar.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
/* 379 */         calendar.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 384 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 387 */       return new Date(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Time getTime(int param1Int) throws SQLException {
/* 395 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 399 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 400 */         sQLException.fillInStackTrace();
/* 401 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 407 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
/* 408 */         return null;
/*     */       }
/* 410 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/*     */       
/* 412 */       TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 413 */       Calendar calendar = Calendar.getInstance(timeZone);
/*     */       
/* 415 */       int j = TimestamptzAccessor.this.oracleYear(i);
/*     */       
/* 417 */       calendar.set(1, j);
/* 418 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 419 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 420 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 421 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 422 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 423 */       calendar.set(14, 0);
/*     */       
/* 425 */       if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 429 */         int k = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
/* 430 */         k += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
/*     */         
/* 432 */         TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/*     */         
/* 434 */         if (tIMEZONETAB.checkID(k)) {
/* 435 */           tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, k);
/*     */         }
/* 437 */         int m = tIMEZONETAB.getOffset(calendar, k);
/*     */         
/* 439 */         boolean bool1 = timeZone.inDaylightTime(calendar.getTime());
/* 440 */         boolean bool2 = timeZone.inDaylightTime(new Date(calendar.getTimeInMillis() + m));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 447 */         if (!bool1 && bool2) {
/*     */           
/* 449 */           calendar.add(14, -1 * timeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 457 */         else if (bool1 && !bool2) {
/*     */           
/* 459 */           calendar.add(14, timeZone.getDSTSavings());
/*     */         } 
/*     */ 
/*     */         
/* 463 */         calendar.add(10, m / 3600000);
/* 464 */         calendar.add(12, m % 3600000 / 60000);
/*     */       }
/*     */       else {
/*     */         
/* 468 */         calendar.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
/* 469 */         calendar.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       } 
/*     */ 
/*     */       
/* 473 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 476 */       return new Time(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Timestamp getTimestamp(int param1Int) throws SQLException {
/* 484 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 488 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 489 */         sQLException.fillInStackTrace();
/* 490 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 496 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
/* 497 */         return null;
/*     */       }
/* 499 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/*     */       
/* 501 */       TimeZone timeZone = TimestamptzAccessor.this.statement.getDefaultTimeZone();
/* 502 */       Calendar calendar1 = Calendar.getInstance(timeZone);
/* 503 */       Calendar calendar2 = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 505 */       int j = TimestamptzAccessor.this.oracleYear(i);
/*     */       
/* 507 */       calendar1.set(1, j);
/* 508 */       calendar1.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 509 */       calendar1.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 510 */       calendar1.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 511 */       calendar1.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 512 */       calendar1.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 513 */       calendar1.set(14, 0);
/*     */       
/* 515 */       calendar2.set(1, j);
/* 516 */       calendar2.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 517 */       calendar2.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 518 */       calendar2.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 519 */       calendar2.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 520 */       calendar2.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 521 */       calendar2.set(14, 0);
/*     */       
/* 523 */       if ((TimestamptzAccessor.this.oracleTZ1(i) & TimestamptzAccessor.REGIONIDBIT) != 0) {
/*     */ 
/*     */ 
/*     */         
/* 527 */         int m = TimestamptzAccessor.getHighOrderbits(TimestamptzAccessor.this.oracleTZ1(i));
/* 528 */         m += TimestamptzAccessor.getLowOrderbits(TimestamptzAccessor.this.oracleTZ2(i));
/*     */ 
/*     */         
/* 531 */         TIMEZONETAB tIMEZONETAB = TimestamptzAccessor.this.statement.connection.getTIMEZONETAB();
/* 532 */         if (tIMEZONETAB.checkID(m)) {
/* 533 */           tIMEZONETAB.updateTable((Connection)TimestamptzAccessor.this.statement.connection, m);
/*     */         }
/* 535 */         int n = tIMEZONETAB.getOffset(calendar2, m);
/*     */         
/* 537 */         boolean bool1 = timeZone.inDaylightTime(calendar1.getTime());
/* 538 */         boolean bool2 = timeZone.inDaylightTime(new Date(calendar1.getTimeInMillis() + n));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 545 */         if (!bool1 && bool2) {
/*     */ 
/*     */           
/* 548 */           calendar1.add(14, -1 * timeZone.getDSTSavings());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 556 */         else if (bool1 && !bool2) {
/*     */           
/* 558 */           calendar1.add(14, timeZone.getDSTSavings());
/*     */         } 
/*     */ 
/*     */         
/* 562 */         calendar1.add(10, n / 3600000);
/* 563 */         calendar1.add(12, n % 3600000 / 60000);
/*     */       }
/*     */       else {
/*     */         
/* 567 */         calendar1.add(10, TimestamptzAccessor.this.oracleTZ1(i) - TimestamptzAccessor.OFFSET_HOUR);
/* 568 */         calendar1.add(12, TimestamptzAccessor.this.oracleTZ2(i) - TimestamptzAccessor.OFFSET_MINUTE);
/*     */       } 
/*     */ 
/*     */       
/* 572 */       long l = calendar1.getTimeInMillis();
/*     */ 
/*     */       
/* 575 */       Timestamp timestamp = new Timestamp(l);
/*     */ 
/*     */       
/* 578 */       int k = TimestamptzAccessor.this.oracleNanos(i);
/*     */ 
/*     */       
/* 581 */       timestamp.setNanos(k);
/*     */       
/* 583 */       return timestamp;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException {
/* 591 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/*     */       
/* 593 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 597 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 598 */         sQLException.fillInStackTrace();
/* 599 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] != -1) {
/*     */         
/* 607 */         int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/* 608 */         byte[] arrayOfByte = new byte[13];
/*     */         
/* 610 */         System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, i, arrayOfByte, 0, 13);
/*     */         
/* 612 */         tIMESTAMPTZ = new TIMESTAMPTZ(arrayOfByte);
/*     */       } 
/*     */       
/* 615 */       return tIMESTAMPTZ;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class GmtTimestampTzConverter
/*     */     extends TimestampTzConverter
/*     */   {
/*     */     Date getDate(int param1Int) throws SQLException {
/* 633 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 637 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 638 */         sQLException.fillInStackTrace();
/* 639 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 645 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
/* 646 */         return null;
/*     */       }
/* 648 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/*     */       
/* 650 */       Calendar calendar = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 652 */       int j = TimestamptzAccessor.this.oracleYear(i);
/*     */       
/* 654 */       calendar.set(1, j);
/* 655 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 656 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 657 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 658 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 659 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 660 */       calendar.set(14, 0);
/*     */ 
/*     */       
/* 663 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 666 */       return new Date(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Time getTime(int param1Int) throws SQLException {
/* 674 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 678 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 679 */         sQLException.fillInStackTrace();
/* 680 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 686 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
/* 687 */         return null;
/*     */       }
/* 689 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/*     */       
/* 691 */       Calendar calendar = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 693 */       int j = TimestamptzAccessor.this.oracleYear(i);
/*     */       
/* 695 */       calendar.set(1, j);
/* 696 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 697 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 698 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 699 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 700 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 701 */       calendar.set(14, 0);
/*     */       
/* 703 */       return new Time(calendar.getTimeInMillis());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Timestamp getTimestamp(int param1Int) throws SQLException {
/* 711 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 715 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 716 */         sQLException.fillInStackTrace();
/* 717 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 723 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] == -1) {
/* 724 */         return null;
/*     */       }
/* 726 */       int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/*     */       
/* 728 */       Calendar calendar = TimestamptzAccessor.this.statement.getGMTCalendar();
/*     */       
/* 730 */       int j = TimestamptzAccessor.this.oracleYear(i);
/*     */       
/* 732 */       calendar.set(1, j);
/* 733 */       calendar.set(2, TimestamptzAccessor.this.oracleMonth(i));
/* 734 */       calendar.set(5, TimestamptzAccessor.this.oracleDay(i));
/* 735 */       calendar.set(11, TimestamptzAccessor.this.oracleHour(i));
/* 736 */       calendar.set(12, TimestamptzAccessor.this.oracleMin(i));
/* 737 */       calendar.set(13, TimestamptzAccessor.this.oracleSec(i));
/* 738 */       calendar.set(14, 0);
/*     */ 
/*     */       
/* 741 */       long l = calendar.getTimeInMillis();
/*     */ 
/*     */       
/* 744 */       Timestamp timestamp = new Timestamp(l);
/*     */ 
/*     */       
/* 747 */       int k = TimestamptzAccessor.this.oracleNanos(i);
/*     */ 
/*     */       
/* 750 */       timestamp.setNanos(k);
/*     */       
/* 752 */       return timestamp;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException {
/* 760 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/*     */       
/* 762 */       if (TimestamptzAccessor.this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */         
/* 766 */         SQLException sQLException = DatabaseError.createSqlException(TimestamptzAccessor.this.getConnectionDuringExceptionHandling(), 21);
/* 767 */         sQLException.fillInStackTrace();
/* 768 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 774 */       if (TimestamptzAccessor.this.rowSpaceIndicator[TimestamptzAccessor.this.indicatorIndex + param1Int] != -1) {
/*     */         
/* 776 */         int i = TimestamptzAccessor.this.columnIndex + TimestamptzAccessor.this.byteLength * param1Int;
/* 777 */         byte[] arrayOfByte = new byte[13];
/*     */         
/* 779 */         System.arraycopy(TimestamptzAccessor.this.rowSpaceByte, i, arrayOfByte, 0, 13);
/*     */         
/* 781 */         tIMESTAMPTZ = new TIMESTAMPTZ(arrayOfByte);
/*     */       } 
/*     */       
/* 784 */       return tIMESTAMPTZ;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract class TimestampTzConverter
/*     */   {
/*     */     abstract Date getDate(int param1Int) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract Time getTime(int param1Int) throws SQLException;
/*     */ 
/*     */ 
/*     */     
/*     */     abstract Timestamp getTimestamp(int param1Int) throws SQLException;
/*     */ 
/*     */ 
/*     */     
/*     */     Object getObject(int param1Int) throws SQLException {
/* 807 */       return getTIMESTAMPTZ(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Datum getOracleObject(int param1Int) throws SQLException {
/* 815 */       return (Datum)getTIMESTAMPTZ(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Object getObject(int param1Int, Map param1Map) throws SQLException {
/* 823 */       return getTIMESTAMPTZ(param1Int);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     abstract TIMESTAMPTZ getTIMESTAMPTZ(int param1Int) throws SQLException;
/*     */   }
/*     */ 
/*     */   
/* 832 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\TimestamptzAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */