/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.lang.reflect.Array;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BufferCache<T>
/*     */ {
/* 144 */   private static final double ln2 = Math.log(2.0D);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int BUFFERS_PER_BUCKET = 8;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int MIN_INDEX = 12;
/*     */ 
/*     */   
/*     */   private final InternalStatistics stats;
/*     */ 
/*     */   
/*     */   private final int[] bufferSize;
/*     */ 
/*     */   
/*     */   private final SoftReference<T>[][] buckets;
/*     */ 
/*     */   
/*     */   private final int[] top;
/*     */ 
/*     */ 
/*     */   
/*     */   BufferCache(int paramInt) {
/*     */     int i;
/* 170 */     if (paramInt < 31) {
/* 171 */       i = paramInt;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 176 */       i = (int)Math.ceil(Math.log(paramInt) / ln2);
/*     */     } 
/*     */     
/* 179 */     int j = Math.max(0, i - 12 + 1);
/*     */     
/* 181 */     this.buckets = (SoftReference<T>[][])new SoftReference[j][8];
/* 182 */     this.top = new int[j];
/*     */     
/* 184 */     this.bufferSize = new int[j];
/* 185 */     int k = 4096;
/* 186 */     for (byte b = 0; b < this.bufferSize.length; b++) {
/* 187 */       this.bufferSize[b] = k;
/* 188 */       k <<= 1;
/*     */     } 
/* 190 */     this.stats = new InternalStatistics(this.bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T get(Class<?> paramClass, int paramInt) {
/* 208 */     int i = bufferIndex(paramInt);
/*     */     
/* 210 */     if (i >= this.buckets.length) {
/* 211 */       this.stats.requestTooBig();
/* 212 */       return (T)Array.newInstance(paramClass, paramInt);
/*     */     } 
/*     */     
/* 215 */     while (this.top[i] > 0) {
/* 216 */       this.top[i] = this.top[i] - 1; SoftReference<T> softReference = this.buckets[i][this.top[i] - 1];
/* 217 */       this.buckets[i][this.top[i]] = null;
/* 218 */       T t = softReference.get();
/* 219 */       if (t != null) {
/* 220 */         this.stats.cacheHit(i);
/* 221 */         return t;
/*     */       } 
/*     */     } 
/*     */     
/* 225 */     this.stats.cacheMiss(i);
/* 226 */     return (T)Array.newInstance(paramClass, this.bufferSize[i]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(T paramT) {
/* 240 */     int i = Array.getLength(paramT);
/*     */     
/* 242 */     int j = bufferIndex(i);
/*     */ 
/*     */     
/* 245 */     if (j >= this.buckets.length || i != this.bufferSize[j]) {
/* 246 */       this.stats.cacheTooBig();
/*     */       
/*     */       return;
/*     */     } 
/* 250 */     if (this.top[j] < 8) {
/* 251 */       this.stats.bufferCached(j);
/* 252 */       this.top[j] = this.top[j] + 1; this.buckets[j][this.top[j]] = new SoftReference<T>(paramT);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 258 */       for (int k = this.top[j]; k > 0;) {
/* 259 */         if (this.buckets[j][--k].get() == null) {
/*     */           
/* 261 */           this.stats.refCleared(j);
/* 262 */           this.buckets[j][k] = new SoftReference<T>(paramT);
/*     */           return;
/*     */         } 
/*     */       } 
/* 266 */       this.stats.bucketFull(j);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleConnection.BufferCacheStatistics getStatistics() {
/* 274 */     return this.stats;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int bufferIndex(int paramInt) {
/* 282 */     for (byte b = 0; b < this.bufferSize.length; b++) {
/* 283 */       if (paramInt <= this.bufferSize[b]) return b; 
/*     */     } 
/* 285 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   private static final class InternalStatistics
/*     */     implements OracleConnection.BufferCacheStatistics {
/* 290 */     private static int CACHE_COUNT = 0;
/*     */     
/* 292 */     private final int cacheId = ++CACHE_COUNT;
/*     */     
/*     */     private final int[] sizes;
/*     */     
/*     */     private final int[] nCacheHit;
/*     */     
/*     */     private final int[] nCacheMiss;
/*     */     private int nRequestTooBig;
/*     */     private final int[] nBufferCached;
/*     */     private final int[] nBucketFull;
/*     */     private final int[] nRefCleared;
/*     */     private int nCacheTooBig;
/*     */     
/*     */     InternalStatistics(int[] param1ArrayOfint) {
/* 306 */       this.sizes = param1ArrayOfint;
/* 307 */       int i = param1ArrayOfint.length;
/* 308 */       this.nCacheHit = new int[i];
/* 309 */       this.nCacheMiss = new int[i];
/* 310 */       this.nRequestTooBig = 0;
/* 311 */       this.nBufferCached = new int[i];
/* 312 */       this.nBucketFull = new int[i];
/* 313 */       this.nRefCleared = new int[i];
/* 314 */       this.nCacheTooBig = 0;
/*     */     }
/*     */     
/* 317 */     void cacheHit(int param1Int) { this.nCacheHit[param1Int] = this.nCacheHit[param1Int] + 1; }
/* 318 */     void cacheMiss(int param1Int) { this.nCacheMiss[param1Int] = this.nCacheMiss[param1Int] + 1; }
/* 319 */     void requestTooBig() { this.nRequestTooBig++; }
/* 320 */     void bufferCached(int param1Int) { this.nBufferCached[param1Int] = this.nBufferCached[param1Int] + 1; }
/* 321 */     void bucketFull(int param1Int) { this.nBucketFull[param1Int] = this.nBucketFull[param1Int] + 1; }
/* 322 */     void refCleared(int param1Int) { this.nRefCleared[param1Int] = this.nRefCleared[param1Int] + 1; } void cacheTooBig() {
/* 323 */       this.nCacheTooBig++;
/*     */     }
/*     */     public int getId() {
/* 326 */       return this.cacheId;
/*     */     } public int[] getBufferSizes() {
/* 328 */       int[] arrayOfInt = new int[this.sizes.length];
/* 329 */       System.arraycopy(this.sizes, 0, arrayOfInt, 0, this.sizes.length);
/* 330 */       return arrayOfInt;
/*     */     }
/* 332 */     public int getCacheHits(int param1Int) { return this.nCacheHit[param1Int]; }
/* 333 */     public int getCacheMisses(int param1Int) { return this.nCacheMiss[param1Int]; }
/* 334 */     public int getRequestsTooBig() { return this.nRequestTooBig; }
/* 335 */     public int getBuffersCached(int param1Int) { return this.nBufferCached[param1Int]; }
/* 336 */     public int getBucketsFull(int param1Int) { return this.nBucketFull[param1Int]; }
/* 337 */     public int getReferencesCleared(int param1Int) { return this.nRefCleared[param1Int]; } public int getTooBigToCache() {
/* 338 */       return this.nCacheTooBig;
/*     */     }
/*     */     public String toString() {
/* 341 */       int i = 0;
/* 342 */       int j = 0;
/* 343 */       int k = 0;
/* 344 */       int m = 0;
/* 345 */       int n = 0;
/* 346 */       for (byte b = 0; b < this.sizes.length; b++) {
/* 347 */         i += this.nCacheHit[b];
/* 348 */         j += this.nCacheMiss[b];
/* 349 */         k += this.nBufferCached[b];
/* 350 */         m += this.nBucketFull[b];
/* 351 */         n += this.nRefCleared[b];
/*     */       } 
/* 353 */       return "oracle.jdbc.driver.BufferCache<" + this.cacheId + ">\n" + "\tTotal Hits   :\t" + i + "\n" + "\tTotal Misses :\t" + (j + this.nRequestTooBig) + "\n" + "\tTotal Cached :\t" + k + "\n" + "\tTotal Dropped:\t" + (m + this.nCacheTooBig) + "\n" + "\tTotal Cleared:\t" + n + "\n";
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 364 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\BufferCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */