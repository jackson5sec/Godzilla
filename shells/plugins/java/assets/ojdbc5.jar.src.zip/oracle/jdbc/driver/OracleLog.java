/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.logging.Level;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleLog
/*     */ {
/*     */   private static final int maxPrintBytes = 512;
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   public static boolean isDebugZip() {
/*  71 */     boolean bool = true;
/*     */ 
/*     */     
/*  74 */     bool = false;
/*  75 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPrivateLogAvailable() {
/*  90 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnabled() {
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean registerClassNameAndGetCurrentTraceSetting(Class paramClass) {
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setTrace(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initialize() {
/* 139 */     setupFromSystemProperties();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setupFromSystemProperties() {
/* 150 */     boolean bool = false;
/* 151 */     securityExceptionWhileGettingSystemProperties = false;
/*     */     
/*     */     try {
/* 154 */       String str = null;
/* 155 */       str = getSystemProperty("oracle.jdbc.Trace", null);
/* 156 */       if (str != null && str.compareTo("true") == 0) {
/* 157 */         bool = true;
/*     */       }
/* 159 */     } catch (SecurityException securityException) {
/*     */       
/* 161 */       securityExceptionWhileGettingSystemProperties = true;
/*     */     } 
/* 163 */     setTrace(bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSystemProperty(String paramString) {
/* 180 */     return getSystemProperty(paramString, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSystemProperty(String paramString1, String paramString2) {
/* 188 */     if (paramString1 != null) {
/*     */       
/* 190 */       final String fstr = paramString1;
/* 191 */       final String fdefaultValue = paramString2;
/* 192 */       final String[] retStr = { paramString2 };
/* 193 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run()
/*     */             {
/* 197 */               retStr[0] = System.getProperty(fstr, fdefaultValue);
/* 198 */               return null;
/*     */             }
/*     */           });
/* 201 */       return arrayOfString[0];
/*     */     } 
/* 203 */     return paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String argument() {
/* 213 */     return "";
/*     */   }
/*     */   
/*     */   public static String argument(boolean paramBoolean) {
/* 217 */     return Boolean.toString(paramBoolean);
/*     */   }
/*     */   
/*     */   public static String argument(byte paramByte) {
/* 221 */     return Byte.toString(paramByte);
/*     */   }
/*     */   
/*     */   public static String argument(short paramShort) {
/* 225 */     return Short.toString(paramShort);
/*     */   }
/*     */   
/*     */   public static String argument(int paramInt) {
/* 229 */     return Integer.toString(paramInt);
/*     */   }
/*     */   
/*     */   public static String argument(long paramLong) {
/* 233 */     return Long.toString(paramLong);
/*     */   }
/*     */   
/*     */   public static String argument(float paramFloat) {
/* 237 */     return Float.toString(paramFloat);
/*     */   }
/*     */   
/*     */   public static String argument(double paramDouble) {
/* 241 */     return Double.toString(paramDouble);
/*     */   }
/*     */   
/*     */   public static String argument(Object paramObject) {
/* 245 */     if (paramObject == null) return "null"; 
/* 246 */     if (paramObject instanceof String) return "\"" + (String)paramObject + "\""; 
/* 247 */     return paramObject.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String byteToHexString(byte paramByte) {
/* 269 */     StringBuffer stringBuffer = new StringBuffer("");
/* 270 */     int i = 0xFF & paramByte;
/*     */     
/* 272 */     if (i <= 15) {
/* 273 */       stringBuffer.append("0x0");
/*     */     } else {
/* 275 */       stringBuffer.append("0x");
/*     */     } 
/* 277 */     stringBuffer.append(Integer.toHexString(i));
/*     */     
/* 279 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToPrintableForm(String paramString, byte[] paramArrayOfbyte) {
/* 300 */     boolean bool = (paramArrayOfbyte == null) ? false : paramArrayOfbyte.length;
/*     */     
/* 302 */     return bytesToPrintableForm(paramString, paramArrayOfbyte, bool);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToPrintableForm(String paramString, byte[] paramArrayOfbyte, int paramInt) {
/* 326 */     String str = null;
/*     */     
/* 328 */     if (paramArrayOfbyte == null) {
/* 329 */       str = paramString + ": null";
/*     */     } else {
/* 331 */       str = paramString + " (" + paramArrayOfbyte.length + " bytes):\n" + bytesToFormattedStr(paramArrayOfbyte, paramInt, "  ");
/*     */     } 
/*     */     
/* 334 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bytesToFormattedStr(byte[] paramArrayOfbyte, int paramInt, String paramString) {
/* 361 */     StringBuffer stringBuffer = new StringBuffer("");
/*     */     
/* 363 */     if (paramString == null) {
/* 364 */       paramString = new String("");
/*     */     }
/* 366 */     stringBuffer.append(paramString);
/*     */     
/* 368 */     if (paramArrayOfbyte == null) {
/*     */       
/* 370 */       stringBuffer.append("byte [] is null");
/*     */       
/* 372 */       return stringBuffer.toString();
/*     */     } 
/*     */     
/* 375 */     for (byte b = 0; b < paramInt; b++) {
/*     */       
/* 377 */       if (b >= 'Ȁ') {
/*     */         
/* 379 */         stringBuffer.append("\n" + paramString + "... last " + (paramInt - 512) + " bytes were not printed to limit the output size");
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */       
/* 385 */       if (b > 0 && b % 20 == 0) {
/* 386 */         stringBuffer.append("\n" + paramString);
/*     */       }
/* 388 */       if (b % 20 == 10) {
/* 389 */         stringBuffer.append(" ");
/*     */       }
/* 391 */       int i = 0xFF & paramArrayOfbyte[b];
/*     */       
/* 393 */       if (i <= 15) {
/* 394 */         stringBuffer.append("0");
/*     */       }
/* 396 */       stringBuffer.append(Integer.toHexString(i) + " ");
/*     */     } 
/*     */     
/* 399 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] strToUcs2Bytes(String paramString) {
/* 416 */     if (paramString == null) {
/* 417 */       return null;
/*     */     }
/* 419 */     return charsToUcs2Bytes(paramString.toCharArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar) {
/* 436 */     if (paramArrayOfchar == null) {
/* 437 */       return null;
/*     */     }
/* 439 */     return charsToUcs2Bytes(paramArrayOfchar, paramArrayOfchar.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar, int paramInt) {
/* 458 */     if (paramArrayOfchar == null) {
/* 459 */       return null;
/*     */     }
/* 461 */     if (paramInt < 0) {
/* 462 */       return null;
/*     */     }
/* 464 */     return charsToUcs2Bytes(paramArrayOfchar, paramInt, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] charsToUcs2Bytes(char[] paramArrayOfchar, int paramInt1, int paramInt2) {
/* 476 */     if (paramArrayOfchar == null) {
/* 477 */       return null;
/*     */     }
/* 479 */     if (paramInt1 > paramArrayOfchar.length - paramInt2) {
/* 480 */       paramInt1 = paramArrayOfchar.length - paramInt2;
/*     */     }
/* 482 */     if (paramInt1 < 0) {
/* 483 */       return null;
/*     */     }
/* 485 */     byte[] arrayOfByte = new byte[2 * paramInt1]; byte b;
/*     */     int i;
/* 487 */     for (i = paramInt2, b = 0; i < paramInt1; i++) {
/*     */       
/* 489 */       arrayOfByte[b++] = (byte)(paramArrayOfchar[i] >> 8 & 0xFF);
/* 490 */       arrayOfByte[b++] = (byte)(paramArrayOfchar[i] & 0xFF);
/*     */     } 
/*     */     
/* 493 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toPrintableStr(String paramString, int paramInt) {
/* 511 */     if (paramString == null)
/*     */     {
/* 513 */       return "null";
/*     */     }
/*     */     
/* 516 */     if (paramString.length() > paramInt)
/*     */     {
/* 518 */       return paramString.substring(0, paramInt - 1) + "\n ... the actual length was " + paramString.length();
/*     */     }
/*     */ 
/*     */     
/* 522 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 534 */   public static final Level INTERNAL_ERROR = OracleLevel.INTERNAL_ERROR;
/* 535 */   public static final Level TRACE_1 = OracleLevel.TRACE_1;
/* 536 */   public static final Level TRACE_10 = OracleLevel.TRACE_10;
/* 537 */   public static final Level TRACE_16 = OracleLevel.TRACE_16;
/* 538 */   public static final Level TRACE_20 = OracleLevel.TRACE_20;
/* 539 */   public static final Level TRACE_30 = OracleLevel.TRACE_30;
/* 540 */   public static final Level TRACE_32 = OracleLevel.TRACE_32;
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean securityExceptionWhileGettingSystemProperties;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 549 */     initialize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toHex(long paramLong, int paramInt) {
/*     */     String str;
/* 558 */     switch (paramInt) {
/*     */       
/*     */       case 1:
/* 561 */         str = "00" + Long.toString(paramLong & 0xFFL, 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 588 */         return "0x" + str.substring(str.length() - 2 * paramInt);case 2: str = "0000" + Long.toString(paramLong & 0xFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 3: str = "000000" + Long.toString(paramLong & 0xFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 4: str = "00000000" + Long.toString(paramLong & 0xFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 5: str = "0000000000" + Long.toString(paramLong & 0xFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 6: str = "000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);case 7: str = "00000000000000" + Long.toString(paramLong & 0xFFFFFFFFFFFFFFL, 16); return "0x" + str.substring(str.length() - 2 * paramInt);
/*     */       case 8:
/*     */         return toHex(paramLong >> 32L, 4) + toHex(paramLong, 4).substring(2);
/*     */     } 
/*     */     return "more than 8 bytes"; } public static String toHex(byte paramByte) {
/* 593 */     String str = "00" + Integer.toHexString(paramByte & 0xFF);
/* 594 */     return "0x" + str.substring(str.length() - 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(short paramShort) {
/* 599 */     return toHex(paramShort, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(int paramInt) {
/* 604 */     return toHex(paramInt, 4);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(byte[] paramArrayOfbyte, int paramInt) {
/* 609 */     if (paramArrayOfbyte == null)
/* 610 */       return "null"; 
/* 611 */     if (paramInt > paramArrayOfbyte.length)
/* 612 */       return "byte array not long enough"; 
/* 613 */     String str = "[";
/* 614 */     int i = Math.min(64, paramInt);
/* 615 */     for (byte b = 0; b < i; b++)
/*     */     {
/* 617 */       str = str + toHex(paramArrayOfbyte[b]) + " ";
/*     */     }
/* 619 */     if (i < paramInt)
/* 620 */       str = str + "..."; 
/* 621 */     return str + "]";
/*     */   }
/*     */ 
/*     */   
/*     */   public static String toHex(byte[] paramArrayOfbyte) {
/* 626 */     if (paramArrayOfbyte == null)
/* 627 */       return "null"; 
/* 628 */     return toHex(paramArrayOfbyte, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class OracleLevel
/*     */     extends Level
/*     */   {
/* 636 */     static final OracleLevel INTERNAL_ERROR = new OracleLevel("INTERNAL_ERROR", 1100);
/* 637 */     static final OracleLevel TRACE_1 = new OracleLevel("TRACE_1", Level.FINE.intValue());
/* 638 */     static final OracleLevel TRACE_10 = new OracleLevel("TRACE_10", 446);
/* 639 */     static final OracleLevel TRACE_16 = new OracleLevel("TRACE_16", Level.FINER.intValue());
/* 640 */     static final OracleLevel TRACE_20 = new OracleLevel("TRACE_20", 376);
/* 641 */     static final OracleLevel TRACE_30 = new OracleLevel("TRACE_30", 316);
/* 642 */     static final OracleLevel TRACE_32 = new OracleLevel("TRACE_32", Level.FINEST.intValue());
/*     */     
/*     */     OracleLevel(String param1String, int param1Int) {
/* 645 */       super(param1String, param1Int);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\OracleLog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */