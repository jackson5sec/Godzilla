/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValueLong;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxsspo
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private int functionId;
/*     */   private byte[] sessionId;
/*     */   private KeywordValueLong[] inKV;
/*     */   private int inFlags;
/*     */   
/*     */   T4CTTIoxsspo(T4CConnection paramT4CConnection) {
/*  62 */     super(paramT4CConnection, (byte)17);
/*     */     
/*  64 */     setFunCode((short)157);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSSPO(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws IOException, SQLException {
/*  80 */     this.functionId = paramInt1;
/*  81 */     this.sessionId = paramArrayOfbyte;
/*  82 */     this.inKV = paramArrayOfKeywordValueLong;
/*  83 */     this.inFlags = paramInt2;
/*  84 */     if (this.inKV != null)
/*  85 */       for (byte b = 0; b < this.inKV.length; b++)
/*  86 */         ((KeywordValueLongI)this.inKV[b]).doCharConversion(this.meg.conv);  
/*  87 */     doPigRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  94 */     this.meg.marshalUB4(this.functionId);
/*  95 */     boolean bool1 = false;
/*  96 */     if (this.sessionId != null && this.sessionId.length > 0) {
/*     */       
/*  98 */       bool1 = true;
/*  99 */       this.meg.marshalPTR();
/* 100 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     }
/*     */     else {
/*     */       
/* 104 */       this.meg.marshalNULLPTR();
/* 105 */       this.meg.marshalUB4(0L);
/*     */     } 
/*     */     
/* 108 */     boolean bool2 = false;
/* 109 */     if (this.inKV != null && this.inKV.length > 0) {
/*     */       
/* 111 */       bool2 = true;
/* 112 */       this.meg.marshalPTR();
/* 113 */       this.meg.marshalUB4(this.inKV.length);
/*     */     }
/*     */     else {
/*     */       
/* 117 */       this.meg.marshalNULLPTR();
/* 118 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 120 */     this.meg.marshalUB4(this.inFlags);
/*     */ 
/*     */     
/* 123 */     if (bool1)
/* 124 */       this.meg.marshalB1Array(this.sessionId); 
/* 125 */     if (bool2) {
/* 126 */       for (byte b = 0; b < this.inKV.length; b++) {
/* 127 */         ((KeywordValueLongI)this.inKV[b]).marshal(this.meg);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/* 132 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CTTIoxsspo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */