/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.util.LinkedList;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.net.ns.BreakNetException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class T4CTTIfun
/*     */   extends T4CTTIMsg
/*     */ {
/*     */   static final short OOPEN = 2;
/*     */   static final short OFETCH = 5;
/*     */   static final short OCLOSE = 8;
/*     */   static final short OLOGOFF = 9;
/*     */   static final short OCOMON = 12;
/*     */   static final short OCOMOFF = 13;
/*     */   static final short OCOMMIT = 14;
/*     */   static final short OROLLBACK = 15;
/*     */   static final short OCANCEL = 20;
/*     */   static final short ODSCRARR = 43;
/*     */   static final short OVERSION = 59;
/*     */   static final short OK2RPC = 67;
/*     */   static final short OALL7 = 71;
/*     */   static final short OSQL7 = 74;
/*     */   static final short O3LOGON = 81;
/*     */   static final short O3LOGA = 82;
/*     */   static final short OKOD = 92;
/*     */   static final short OALL8 = 94;
/*     */   static final short OLOBOPS = 96;
/*     */   static final short ODNY = 98;
/*     */   static final short OTXSE = 103;
/*     */   static final short OTXEN = 104;
/*     */   static final short OCCA = 105;
/*     */   static final short O80SES = 107;
/*     */   static final short OAUTH = 115;
/*     */   static final short OSESSKEY = 118;
/*     */   static final short OCANA = 120;
/*     */   static final short OKPN = 125;
/*     */   static final short OOTCM = 127;
/*     */   static final short OSCID = 135;
/*     */   static final short OSPFPPUT = 138;
/*     */   static final short OKPFC = 139;
/*     */   static final short OPING = 147;
/*     */   static final short OKEYVAL = 154;
/*     */   static final short OXSSCS = 155;
/*     */   static final short OXSSRO = 156;
/*     */   static final short OXSSPO = 157;
/*     */   static final short OAQEQ = 121;
/*     */   static final short OAQDQ = 122;
/*     */   static final short OAQGPS = 132;
/*     */   static final short OAQLS = 126;
/*     */   static final short OAQXQ = 145;
/*     */   static final short OXSNS = 172;
/*     */   private short funCode;
/*     */   protected final T4CTTIoer oer;
/*     */   int receiveState;
/*     */   static final int IDLE_RECEIVE_STATE = 0;
/*     */   static final int ACTIVE_RECEIVE_STATE = 1;
/*     */   static final int READROW_RECEIVE_STATE = 2;
/*     */   static final int STREAM_RECEIVE_STATE = 3;
/*     */   boolean rpaProcessed;
/*     */   boolean rxhProcessed;
/*     */   boolean iovProcessed;
/*     */   private LinkedList<Short> ttilist;
/*     */   
/*     */   T4CTTIfun(T4CConnection paramT4CConnection, byte paramByte) {
/* 132 */     super(paramT4CConnection, paramByte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 286 */     this.receiveState = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 298 */     this.rpaProcessed = false;
/* 299 */     this.rxhProcessed = false;
/* 300 */     this.iovProcessed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     this.ttilist = new LinkedList<Short>();
/*     */     this.oer = paramT4CConnection.getT4CTTIoer();
/*     */   } final void setFunCode(short paramShort) {
/*     */     this.funCode = paramShort;
/*     */   } final short getFunCode() {
/*     */     return this.funCode;
/*     */   } private final void marshalFunHeader() throws IOException {
/*     */     marshalTTCcode();
/*     */     this.meg.marshalUB1(this.funCode);
/*     */     this.meg.marshalUB1((short)this.connection.getNextSeqNumber());
/*     */   }
/*     */   abstract void marshal() throws IOException;
/* 341 */   private void receive() throws SQLException, IOException { this.receiveState = 1;
/*     */     
/* 343 */     SQLException sQLException = null;
/*     */     while (true) {
/*     */       
/*     */       try { byte b1;
/*     */         int i;
/*     */         byte b2;
/*     */         SQLException sQLException1;
/* 350 */         short s = this.meg.unmarshalUB1();
/* 351 */         this.ttilist.add(new Short(s));
/*     */         
/* 353 */         switch (s)
/*     */         
/*     */         { 
/*     */           
/*     */           case 8:
/* 358 */             if (this.rpaProcessed) {
/*     */               
/* 360 */               SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 361 */               sQLException2.fillInStackTrace();
/* 362 */               throw sQLException2;
/*     */             } 
/* 364 */             readRPA();
/*     */             
/*     */             try {
/* 367 */               processRPA();
/*     */             }
/* 369 */             catch (SQLException sQLException2) {
/*     */ 
/*     */ 
/*     */               
/* 373 */               sQLException = sQLException2;
/*     */             } 
/* 375 */             this.rpaProcessed = true;
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 21:
/* 381 */             readBVC();
/*     */             break;
/*     */           
/*     */           case 11:
/* 385 */             readIOV();
/* 386 */             this.iovProcessed = true;
/*     */             break;
/*     */ 
/*     */           
/*     */           case 6:
/* 391 */             readRXH();
/* 392 */             this.rxhProcessed = true;
/*     */             break;
/*     */           case 12:
/* 395 */             processSLG();
/*     */             break;
/*     */ 
/*     */           
/*     */           case 7:
/* 400 */             this.receiveState = 2;
/*     */ 
/*     */             
/* 403 */             if (readRXD()) {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 408 */               this.receiveState = 3;
/*     */ 
/*     */               
/*     */               return;
/*     */             } 
/*     */ 
/*     */             
/* 415 */             this.receiveState = 1;
/*     */             break;
/*     */ 
/*     */ 
/*     */           
/*     */           case 16:
/* 421 */             readDCB();
/*     */             break;
/*     */           case 14:
/* 424 */             readLOBD();
/*     */             break;
/*     */ 
/*     */           
/*     */           case 23:
/* 429 */             b1 = (byte)this.meg.unmarshalUB1();
/* 430 */             i = this.meg.unmarshalUB2();
/* 431 */             b2 = (byte)this.meg.unmarshalUB1();
/*     */             
/* 433 */             if (b1 == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 445 */               for (byte b = 0; b < i; b++) {
/*     */                 
/* 447 */                 T4CTTIidc t4CTTIidc = new T4CTTIidc(this.connection);
/* 448 */                 t4CTTIidc.unmarshal();
/*     */               }  break;
/*     */             } 
/* 451 */             if (b1 == 2) {
/*     */ 
/*     */               
/* 454 */               for (byte b = 0; b < i; b++)
/*     */               {
/* 456 */                 short s1 = this.meg.unmarshalUB1(); } 
/*     */               break;
/*     */             } 
/* 459 */             if (b1 == 3)
/*     */               break; 
/* 461 */             if (b1 == 4)
/*     */               break; 
/* 463 */             if (b1 == 5) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 470 */               T4CTTIkvarr t4CTTIkvarr = new T4CTTIkvarr(this.connection);
/* 471 */               t4CTTIkvarr.unmarshal(); break;
/* 472 */             }  if (b1 == 6)
/*     */             {
/* 474 */               for (byte b = 0; b < i; b++) {
/*     */                 
/* 476 */                 NTFXSEvent nTFXSEvent = new NTFXSEvent(this.connection);
/* 477 */                 this.connection.notify(nTFXSEvent);
/*     */               } 
/*     */             }
/*     */             break;
/*     */           case 19:
/* 482 */             this.meg.marshalUB1((short)19);
/*     */             break;
/*     */ 
/*     */           
/*     */           case 15:
/* 487 */             this.oer.init();
/* 488 */             this.oer.unmarshalWarning();
/*     */ 
/*     */             
/*     */             try {
/* 492 */               this.oer.processWarning();
/*     */             }
/* 494 */             catch (SQLWarning sQLWarning) {
/*     */               
/* 496 */               this.connection.setWarnings(DatabaseError.addSqlWarning(this.connection.getWarnings(), sQLWarning));
/*     */             } 
/*     */             break;
/*     */           case 9:
/* 500 */             processEOCS();
/* 501 */             if (this.connection.getTTCVersion() >= 3) {
/*     */               
/* 503 */               short s1 = (short)this.meg.unmarshalUB2();
/* 504 */               this.connection.endToEndECIDSequenceNumber = s1;
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 536 */             this.connection.sentCancel = false; break;case 4: processEOCS(); this.oer.init(); this.oer.unmarshal(); try { processError(); } catch (SQLException sQLException2) { sQLException = sQLException2; }  this.connection.sentCancel = false; break;default: sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401, this.ttilist.toString()); sQLException1.fillInStackTrace(); throw sQLException1; }  } catch (BreakNetException breakNetException) {  } finally { this.connection.sentCancel = false; }
/*     */     
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 542 */     this.receiveState = 0;
/*     */     
/* 544 */     if (sQLException != null) {
/* 545 */       throw sQLException;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void processEOCS() throws SQLException, IOException {
/* 557 */     if (this.connection.hasServerCompileTimeCapability(15, 1)) {
/*     */       
/* 559 */       int i = (int)this.meg.unmarshalUB4();
/* 560 */       this.connection.eocs = i;
/* 561 */       if ((i & 0x8) != 0)
/*     */       {
/*     */ 
/*     */         
/* 565 */         long l = this.meg.unmarshalSB8(); } 
/*     */     } 
/*     */   }
/*     */   final void doRPC() throws IOException, SQLException { if (getTTCCode() == 17) {
/*     */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401); sQLException.fillInStackTrace(); throw sQLException;
/*     */     }  for (byte b = 0; b < 5; b++) {
/*     */       init(); marshalFunHeader(); try {
/*     */         this.connection.pipeState = 1; marshal(); this.connection.pipeState = 2; receive();
/*     */         break;
/*     */       } catch (SQLException sQLException) {
/*     */         synchronized (this.connection.cancelInProgressLockForThin) {
/*     */           if (sQLException.getErrorCode() == 1013 || (this.connection.cancelInProgressFlag && sQLException.getMessage() != null && sQLException.getMessage().contains("ORA-01013"))) {
/*     */             this.connection.cancelInProgressFlag = false;
/*     */             this.connection.redoCursorClose();
/*     */             if (this.funCode == 15 || this.funCode == 12 || this.funCode == 13 || this.funCode == 14 || this.funCode == 59)
/*     */               if (this.oer.callNumber != this.connection.currentTTCSeqNumber || this.connection.statementCancel) {
/*     */                 this.connection.pipeState = -1;
/*     */                 continue;
/*     */               }  
/*     */           } 
/*     */         } 
/*     */         throw sQLException;
/*     */       } finally {
/*     */         this.connection.pipeState = -1;
/*     */       } 
/*     */     }  }
/*     */   final void doPigRPC() throws IOException { init();
/*     */     marshalFunHeader();
/*     */     marshal(); }
/*     */   private void init() { this.rpaProcessed = false;
/*     */     this.rxhProcessed = false;
/*     */     this.iovProcessed = false;
/* 597 */     this.ttilist.clear(); } void resumeReceive() throws SQLException, IOException { receive(); } void processRPA() throws SQLException {} void readRPA() throws IOException, SQLException {} void readBVC() throws IOException, SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 598 */     sQLException.fillInStackTrace();
/* 599 */     throw sQLException; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readLOBD() throws IOException, SQLException {
/* 608 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 609 */     sQLException.fillInStackTrace();
/* 610 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readIOV() throws IOException, SQLException {
/* 619 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 620 */     sQLException.fillInStackTrace();
/* 621 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readRXH() throws IOException, SQLException {
/* 630 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 631 */     sQLException.fillInStackTrace();
/* 632 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readRXD() throws IOException, SQLException {
/* 641 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 642 */     sQLException.fillInStackTrace();
/* 643 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readDCB() throws IOException, SQLException {
/* 652 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 653 */     sQLException.fillInStackTrace();
/* 654 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processSLG() throws IOException, SQLException {
/* 663 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 401);
/* 664 */     sQLException.fillInStackTrace();
/* 665 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void processError() throws SQLException {
/* 675 */     this.oer.processError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int getErrorCode() throws SQLException {
/* 682 */     return this.oer.retCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 697 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 702 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CTTIfun.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */