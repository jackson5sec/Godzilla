/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.SQLException;
/*     */ import java.util.BitSet;
/*     */ import java.util.Vector;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CTTIrxd
/*     */   extends T4CTTIMsg
/*     */ {
/*  46 */   static final byte[] NO_BYTES = new byte[0];
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] buffer;
/*     */ 
/*     */   
/*     */   byte[] bufferCHAR;
/*     */ 
/*     */   
/*  56 */   BitSet bvcColSent = null;
/*  57 */   int nbOfColumns = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean bvcFound = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isFirstCol;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final byte TTICMD_UNAUTHORIZED = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CTTIrxd(T4CConnection paramT4CConnection) {
/*  78 */     super(paramT4CConnection, (byte)7);
/*     */     
/*  80 */     this.isFirstCol = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init() {
/*  87 */     this.isFirstCol = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setNumberOfColumns(int paramInt) {
/*  94 */     this.nbOfColumns = paramInt;
/*  95 */     this.bvcFound = false;
/*     */     
/*  97 */     if (this.bvcColSent == null || this.bvcColSent.length() < this.nbOfColumns) {
/*  98 */       this.bvcColSent = new BitSet(this.nbOfColumns);
/*     */     } else {
/* 100 */       this.bvcColSent.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void unmarshalBVC(int paramInt) throws SQLException, IOException {
/* 108 */     byte b1 = 0;
/*     */     
/*     */     int i;
/* 111 */     for (i = 0; i < this.bvcColSent.length(); i++) {
/* 112 */       this.bvcColSent.clear(i);
/*     */     }
/*     */     
/* 115 */     i = this.nbOfColumns / 8 + ((this.nbOfColumns % 8 != 0) ? 1 : 0);
/*     */ 
/*     */     
/* 118 */     for (byte b2 = 0; b2 < i; b2++) {
/*     */       
/* 120 */       byte b = (byte)(this.meg.unmarshalUB1() & 0xFF);
/*     */       
/* 122 */       for (byte b3 = 0; b3 < 8; b3++) {
/*     */         
/* 124 */         if ((b & 1 << b3) != 0) {
/*     */           
/* 126 */           this.bvcColSent.set(b2 * 8 + b3);
/*     */           
/* 128 */           b1++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     if (b1 != paramInt) {
/*     */ 
/*     */       
/* 136 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.unmarshalBVC: bits missing in vector");
/*     */       
/* 138 */       sQLException.fillInStackTrace();
/* 139 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 143 */     this.bvcFound = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readBitVector(byte[] paramArrayOfbyte) throws SQLException, IOException {
/*     */     byte b;
/* 156 */     for (b = 0; b < this.bvcColSent.length(); b++) {
/* 157 */       this.bvcColSent.clear(b);
/*     */     }
/* 159 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 160 */       this.bvcFound = false;
/*     */     } else {
/*     */       
/* 163 */       for (b = 0; b < paramArrayOfbyte.length; b++) {
/* 164 */         byte b1 = paramArrayOfbyte[b];
/* 165 */         for (byte b2 = 0; b2 < 8; b2++) {
/* 166 */           if ((b1 & 1 << b2) != 0)
/* 167 */             this.bvcColSent.set(b * 8 + b2); 
/*     */         } 
/*     */       } 
/* 170 */       this.bvcFound = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Vector<IOException> marshal(byte[] paramArrayOfbyte1, char[] paramArrayOfchar1, short[] paramArrayOfshort1, int paramInt1, byte[] paramArrayOfbyte2, DBConversion paramDBConversion, InputStream[] paramArrayOfInputStream, byte[][] paramArrayOfbyte, OracleTypeADT[] paramArrayOfOracleTypeADT, byte[] paramArrayOfbyte3, char[] paramArrayOfchar2, short[] paramArrayOfshort2, byte[] paramArrayOfbyte4, int paramInt2, int[] paramArrayOfint1, boolean paramBoolean1, int[] paramArrayOfint2, int[] paramArrayOfint3, int[][] paramArrayOfint, boolean paramBoolean2) throws IOException {
/* 198 */     Vector<IOException> vector = null;
/*     */     
/*     */     try {
/*     */       int k;
/*     */       
/* 203 */       marshalTTCcode();
/*     */ 
/*     */       
/* 206 */       int i = paramArrayOfshort1[paramInt1 + 0] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       byte b1 = 0;
/* 229 */       int j = paramArrayOfint3[0];
/* 230 */       int[] arrayOfInt = paramArrayOfint[0];
/*     */       
/* 232 */       byte b2 = 0;
/*     */ 
/*     */ 
/*     */       
/* 236 */       if (paramBoolean2) {
/*     */         
/* 238 */         k = 1;
/* 239 */         assert j > 0 : "No postoned columns in RXD";
/*     */       }
/*     */       else {
/*     */         
/* 243 */         for (byte b = 0; b < i; b++) {
/*     */           
/* 245 */           if (b1 < j && arrayOfInt[b1] == b) {
/*     */ 
/*     */             
/* 248 */             b1++;
/*     */             
/*     */             continue;
/*     */           } 
/* 252 */           boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 257 */           int m = paramInt1 + 5 + 10 * b;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 262 */           int i2 = paramArrayOfshort1[m + 0] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 267 */           if (paramArrayOfbyte4 != null && (paramArrayOfbyte4[b] & 0x20) == 0) {
/*     */ 
/*     */ 
/*     */             
/* 271 */             if (i2 == 998) {
/* 272 */               b2++;
/*     */             }
/*     */             
/*     */             continue;
/*     */           } 
/* 277 */           int n = ((paramArrayOfshort1[m + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 8] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */           
/* 281 */           int i3 = ((paramArrayOfshort1[m + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 6] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 286 */           int i1 = paramArrayOfshort1[n] & 0xFFFF;
/*     */           
/* 288 */           short s = paramArrayOfshort1[i3];
/*     */           
/* 290 */           if (i2 == 116) {
/*     */             
/* 292 */             this.meg.marshalUB1((short)1);
/* 293 */             this.meg.marshalUB1((short)0);
/*     */             
/*     */             continue;
/*     */           } 
/* 297 */           if (i2 == 994) {
/*     */             
/* 299 */             s = -1;
/* 300 */             int i4 = paramArrayOfint2[3 + b * 4 + 0];
/*     */ 
/*     */ 
/*     */             
/* 304 */             if (i4 == 109) {
/* 305 */               bool = true;
/*     */             }
/* 307 */           } else if (i2 == 8 || i2 == 24 || (!paramBoolean1 && paramArrayOfint1 != null && paramArrayOfint1.length > b && paramArrayOfint1[b] > 4000)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 324 */             if (j >= arrayOfInt.length) {
/*     */               
/* 326 */               int[] arrayOfInt1 = new int[arrayOfInt.length << 1];
/*     */ 
/*     */               
/* 329 */               System.arraycopy(arrayOfInt, 0, arrayOfInt1, 0, arrayOfInt.length);
/*     */ 
/*     */ 
/*     */               
/* 333 */               arrayOfInt = arrayOfInt1;
/*     */             } 
/*     */             
/* 336 */             arrayOfInt[j++] = b;
/*     */ 
/*     */ 
/*     */             
/*     */             continue;
/*     */           } 
/*     */ 
/*     */           
/* 344 */           if (s == -1) {
/*     */             
/* 346 */             if (i2 == 109 || bool) {
/*     */ 
/*     */               
/* 349 */               this.meg.marshalDALC(NO_BYTES);
/* 350 */               this.meg.marshalDALC(NO_BYTES);
/* 351 */               this.meg.marshalDALC(NO_BYTES);
/* 352 */               this.meg.marshalUB2(0);
/* 353 */               this.meg.marshalUB4(0L);
/* 354 */               this.meg.marshalUB2(1);
/*     */               
/*     */               continue;
/*     */             } 
/* 358 */             if (i2 == 998) {
/*     */               
/* 360 */               b2++;
/* 361 */               this.meg.marshalUB4(0L);
/*     */               continue;
/*     */             } 
/* 364 */             if (i2 == 112 || i2 == 113 || i2 == 114) {
/*     */               
/* 366 */               this.meg.marshalUB4(0L);
/*     */               continue;
/*     */             } 
/* 369 */             if (i2 != 8 && i2 != 24) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 378 */               this.meg.marshalUB1((short)0);
/*     */               
/*     */               continue;
/*     */             } 
/*     */           } 
/*     */           
/* 384 */           if (i2 == 998) {
/*     */ 
/*     */             
/* 387 */             int i4 = (paramArrayOfshort2[6 + b2 * 8 + 4] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 5] & 0xFFFF;
/*     */ 
/*     */             
/* 390 */             int i5 = (paramArrayOfshort2[6 + b2 * 8 + 6] & 0xFFFF) << 16 & 0xFFFF000 | paramArrayOfshort2[6 + b2 * 8 + 7] & 0xFFFF;
/*     */ 
/*     */             
/* 393 */             int i6 = paramArrayOfshort2[6 + b2 * 8] & 0xFFFF;
/* 394 */             int i7 = paramArrayOfshort2[6 + b2 * 8 + 1] & 0xFFFF;
/*     */             
/* 396 */             this.meg.marshalUB4(i4);
/*     */             
/* 398 */             for (byte b3 = 0; b3 < i4; b3++) {
/*     */               
/* 400 */               int i8 = i5 + b3 * i7;
/*     */               
/* 402 */               if (i6 == 9) {
/*     */                 
/* 404 */                 int i9 = paramArrayOfchar2[i8] / 2;
/* 405 */                 int i10 = 0;
/* 406 */                 i10 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar2, i8 + 1, paramArrayOfbyte2, 0, i9);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 412 */                 this.meg.marshalCLR(paramArrayOfbyte2, i10);
/*     */               }
/*     */               else {
/*     */                 
/* 416 */                 i1 = paramArrayOfbyte3[i8];
/*     */                 
/* 418 */                 if (i1 < 1) {
/* 419 */                   this.meg.marshalUB1((short)0);
/*     */                 } else {
/* 421 */                   this.meg.marshalCLR(paramArrayOfbyte3, i8 + 1, i1);
/*     */                 } 
/*     */               } 
/*     */             } 
/* 425 */             b2++;
/*     */ 
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */ 
/*     */             
/* 434 */             int i4 = paramArrayOfshort1[m + 1] & 0xFFFF;
/*     */ 
/*     */ 
/*     */             
/* 438 */             if (i4 != 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 444 */               int i5 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i4 * paramInt2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 451 */               if (i2 == 6) {
/*     */                 
/* 453 */                 i5++;
/* 454 */                 i1--;
/*     */               }
/* 456 */               else if (i2 == 9) {
/*     */                 
/* 458 */                 i5 += 2;
/*     */                 
/* 460 */                 i1 -= 2;
/*     */               }
/* 462 */               else if (i2 == 114 || i2 == 113 || i2 == 112) {
/*     */ 
/*     */                 
/* 465 */                 this.meg.marshalUB4(i1);
/*     */               } 
/*     */ 
/*     */               
/* 469 */               if (i2 == 109 || i2 == 111) {
/*     */                 
/* 471 */                 if (paramArrayOfbyte == null) {
/*     */ 
/*     */                   
/* 474 */                   SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1, "INTERNAL ERROR: oracle.jdbc.driver.T4CTTIrxd.marshal: parameterDatum is null");
/*     */                   
/* 476 */                   sQLException.fillInStackTrace();
/* 477 */                   throw sQLException;
/*     */                 } 
/*     */ 
/*     */                 
/* 481 */                 byte[] arrayOfByte = paramArrayOfbyte[b];
/*     */                 
/* 483 */                 i1 = (arrayOfByte == null) ? 0 : arrayOfByte.length;
/*     */                 
/* 485 */                 if (i2 == 109) {
/*     */                   
/* 487 */                   this.meg.marshalDALC(NO_BYTES);
/* 488 */                   this.meg.marshalDALC(NO_BYTES);
/* 489 */                   this.meg.marshalDALC(NO_BYTES);
/* 490 */                   this.meg.marshalUB2(0);
/*     */                   
/* 492 */                   this.meg.marshalUB4(i1);
/* 493 */                   this.meg.marshalUB2(1);
/*     */                 } 
/*     */                 
/* 496 */                 if (i1 > 0) {
/* 497 */                   this.meg.marshalCLR(arrayOfByte, 0, i1);
/*     */                 }
/* 499 */               } else if (i2 == 104) {
/*     */ 
/*     */ 
/*     */                 
/* 503 */                 i5 += 2;
/*     */                 
/* 505 */                 long[] arrayOfLong = T4CRowidAccessor.stringToRowid(paramArrayOfbyte1, i5, 18);
/*     */                 
/* 507 */                 byte b3 = 14;
/* 508 */                 long l1 = arrayOfLong[0];
/* 509 */                 int i6 = (int)arrayOfLong[1];
/* 510 */                 boolean bool1 = false;
/* 511 */                 long l2 = arrayOfLong[2];
/* 512 */                 int i7 = (int)arrayOfLong[3];
/*     */ 
/*     */                 
/* 515 */                 if (l1 == 0L && i6 == 0 && l2 == 0L && i7 == 0)
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 521 */                   this.meg.marshalUB1((short)0);
/*     */                 }
/*     */                 else
/*     */                 {
/* 525 */                   this.meg.marshalUB1(b3);
/* 526 */                   this.meg.marshalUB4(l1);
/* 527 */                   this.meg.marshalUB2(i6);
/* 528 */                   this.meg.marshalUB1(bool1);
/* 529 */                   this.meg.marshalUB4(l2);
/* 530 */                   this.meg.marshalUB2(i7);
/*     */                 }
/*     */               
/* 533 */               } else if (i2 == 208) {
/*     */ 
/*     */ 
/*     */                 
/* 537 */                 i5 += 2;
/* 538 */                 i1 -= 2;
/* 539 */                 this.meg.marshalUB4(i1);
/* 540 */                 this.meg.marshalCLR(paramArrayOfbyte1, i5, i1);
/*     */ 
/*     */               
/*     */               }
/* 544 */               else if (i1 < 1) {
/* 545 */                 this.meg.marshalUB1((short)0);
/*     */               } else {
/* 547 */                 this.meg.marshalCLR(paramArrayOfbyte1, i5, i1);
/*     */ 
/*     */               
/*     */               }
/*     */ 
/*     */             
/*     */             }
/*     */             else {
/*     */ 
/*     */               
/* 557 */               int i7 = paramArrayOfshort1[m + 9] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 564 */               int i5 = paramArrayOfshort1[m + 2] & 0xFFFF;
/*     */ 
/*     */               
/* 567 */               int i6 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i5 * paramInt2 + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 572 */               if (i2 == 996) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 581 */                 char c = paramArrayOfchar1[i6 - 1];
/*     */                 
/* 583 */                 if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
/* 584 */                   this.bufferCHAR = new byte[c];
/*     */                 }
/* 586 */                 for (byte b3 = 0; b3 < c; b3++) {
/*     */                   
/* 588 */                   this.bufferCHAR[b3] = (byte)((paramArrayOfchar1[i6 + b3 / 2] & 0xFF00) >> 8 & 0xFF);
/*     */ 
/*     */ 
/*     */                   
/* 592 */                   if (b3 < c - 1) {
/*     */                     
/* 594 */                     this.bufferCHAR[b3 + 1] = (byte)(paramArrayOfchar1[i6 + b3 / 2] & 0xFF & 0xFF);
/*     */ 
/*     */                     
/* 597 */                     b3++;
/*     */                   } 
/*     */                 } 
/*     */                 
/* 601 */                 this.meg.marshalCLR(this.bufferCHAR, c);
/*     */                 
/* 603 */                 if (this.bufferCHAR.length > 4000) {
/* 604 */                   this.bufferCHAR = null;
/*     */                 }
/*     */               } else {
/*     */                 int i8;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 615 */                 if (i2 == 96) {
/*     */ 
/*     */ 
/*     */                   
/* 619 */                   i8 = i1 / 2;
/* 620 */                   i6--;
/*     */                 }
/*     */                 else {
/*     */                   
/* 624 */                   i8 = (i1 - 2) / 2;
/*     */                 } 
/*     */ 
/*     */                 
/* 628 */                 int i9 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 633 */                 if (i7 == 2) {
/*     */                   
/* 635 */                   i9 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i6, paramArrayOfbyte2, 0, i8);
/*     */                 
/*     */                 }
/*     */                 else {
/*     */                   
/* 640 */                   i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i6, paramArrayOfbyte2, 0, i8);
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 646 */                 this.meg.marshalCLR(paramArrayOfbyte2, i9);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 656 */         k = j;
/*     */       } 
/*     */       
/* 659 */       if (j > 0)
/*     */       {
/* 661 */         for (byte b = 0; b < k; b++) {
/*     */           
/* 663 */           int i6 = arrayOfInt[b];
/*     */           
/* 665 */           int m = paramInt1 + 5 + 10 * i6;
/*     */ 
/*     */ 
/*     */           
/* 669 */           int i4 = paramArrayOfshort1[m + 0] & 0xFFFF;
/*     */ 
/*     */ 
/*     */           
/* 673 */           int n = ((paramArrayOfshort1[m + 7] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 8] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */           
/* 677 */           int i5 = ((paramArrayOfshort1[m + 5] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 6] & 0xFFFF) + paramInt2;
/*     */ 
/*     */ 
/*     */           
/* 681 */           short s = paramArrayOfshort1[i5];
/* 682 */           int i1 = paramArrayOfshort1[n] & 0xFFFF;
/*     */           
/* 684 */           int i2 = paramArrayOfshort1[m + 2] & 0xFFFF;
/*     */ 
/*     */           
/* 687 */           int i3 = ((paramArrayOfshort1[m + 3] & 0xFFFF) << 16) + (paramArrayOfshort1[m + 4] & 0xFFFF) + i2 * paramInt2 + 1;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 692 */           if (s == -1) {
/*     */             
/* 694 */             this.meg.marshalUB1((short)0);
/*     */ 
/*     */           
/*     */           }
/* 698 */           else if (i4 == 996) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 707 */             char c = paramArrayOfchar1[i3 - 1];
/*     */             
/* 709 */             if (this.bufferCHAR == null || this.bufferCHAR.length < c) {
/* 710 */               this.bufferCHAR = new byte[c];
/*     */             }
/* 712 */             for (byte b3 = 0; b3 < c; b3++) {
/*     */               
/* 714 */               this.bufferCHAR[b3] = (byte)((paramArrayOfchar1[i3 + b3 / 2] & 0xFF00) >> 8 & 0xFF);
/*     */ 
/*     */ 
/*     */               
/* 718 */               if (b3 < c - 1) {
/*     */                 
/* 720 */                 this.bufferCHAR[b3 + 1] = (byte)(paramArrayOfchar1[i3 + b3 / 2] & 0xFF & 0xFF);
/*     */                 
/* 722 */                 b3++;
/*     */               } 
/*     */             } 
/*     */             
/* 726 */             this.meg.marshalCLR(this.bufferCHAR, c);
/*     */             
/* 728 */             if (this.bufferCHAR.length > 4000) {
/* 729 */               this.bufferCHAR = null;
/*     */             }
/* 731 */           } else if (i4 != 8 && i4 != 24) {
/*     */             int i7;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 738 */             if (i4 == 96) {
/*     */ 
/*     */ 
/*     */               
/* 742 */               i7 = i1 / 2;
/* 743 */               i3--;
/*     */             }
/*     */             else {
/*     */               
/* 747 */               i7 = (i1 - 2) / 2;
/*     */             } 
/*     */             
/* 750 */             int i8 = paramArrayOfshort1[m + 9] & 0xFFFF;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 755 */             int i9 = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 760 */             if (i8 == 2) {
/*     */               
/* 762 */               i9 = paramDBConversion.javaCharsToNCHARBytes(paramArrayOfchar1, i3, paramArrayOfbyte2, 0, i7);
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 767 */               i9 = paramDBConversion.javaCharsToCHARBytes(paramArrayOfchar1, i3, paramArrayOfbyte2, 0, i7);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 773 */             this.meg.marshalCLR(paramArrayOfbyte2, i9);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 778 */             int i7 = i6;
/*     */ 
/*     */             
/* 781 */             if (paramArrayOfInputStream != null) {
/*     */               
/* 783 */               InputStream inputStream = paramArrayOfInputStream[i7];
/*     */               
/* 785 */               if (inputStream != null) {
/*     */ 
/*     */ 
/*     */                 
/* 789 */                 byte b3 = 64;
/*     */                 
/* 791 */                 if (this.buffer == null) {
/* 792 */                   this.buffer = new byte[b3];
/*     */                 }
/* 794 */                 int i8 = 0;
/*     */ 
/*     */                 
/* 797 */                 this.meg.marshalUB1((short)254);
/*     */                 
/* 799 */                 boolean bool = false;
/*     */                 
/* 801 */                 while (!bool && !this.connection.sentCancel) {
/*     */                   
/*     */                   try {
/* 804 */                     i8 = inputStream.read(this.buffer, 0, b3);
/* 805 */                   } catch (IOException iOException) {
/* 806 */                     i8 = -1;
/* 807 */                     if (vector == null)
/* 808 */                       vector = new Vector(); 
/* 809 */                     vector.add(iOException);
/*     */                   } 
/*     */                   
/* 812 */                   if (i8 == -1) {
/* 813 */                     bool = true;
/*     */                   }
/* 815 */                   if (i8 > 0) {
/*     */ 
/*     */ 
/*     */                     
/* 819 */                     this.meg.marshalUB1((short)(i8 & 0xFF));
/*     */ 
/*     */                     
/* 822 */                     this.meg.marshalB1Array(this.buffer, 0, i8);
/*     */                   } 
/*     */                 } 
/*     */ 
/*     */                 
/* 827 */                 this.meg.marshalUB1((short)0);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 844 */       paramArrayOfint3[0] = j;
/* 845 */       paramArrayOfint[0] = arrayOfInt;
/*     */     }
/* 847 */     catch (SQLException sQLException) {
/*     */       
/* 849 */       IOException iOException = new IOException();
/* 850 */       iOException.initCause(sQLException);
/* 851 */       throw iOException;
/*     */     } 
/*     */     
/* 854 */     return vector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt) throws SQLException, IOException {
/* 865 */     return unmarshal(paramArrayOfAccessor, 0, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2) throws SQLException, IOException {
/* 882 */     if (paramInt1 == 0) {
/* 883 */       this.isFirstCol = true;
/*     */     }
/* 885 */     for (int i = paramInt1; i < paramInt2 && i < paramArrayOfAccessor.length; i++) {
/*     */       
/* 887 */       if (paramArrayOfAccessor[i] != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 904 */         if ((paramArrayOfAccessor[i]).physicalColumnIndex < 0) {
/*     */ 
/*     */ 
/*     */           
/* 908 */           byte b1 = 0;
/*     */           
/* 910 */           for (byte b2 = 0; b2 < paramInt2 && b2 < paramArrayOfAccessor.length; b2++) {
/*     */             
/* 912 */             if (paramArrayOfAccessor[b2] != null) {
/*     */               
/* 914 */               (paramArrayOfAccessor[b2]).physicalColumnIndex = b1;
/*     */               
/* 916 */               if (!(paramArrayOfAccessor[b2]).isUseLess) {
/* 917 */                 b1++;
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/* 922 */         if (this.bvcFound && !(paramArrayOfAccessor[i]).isUseLess && !this.bvcColSent.get((paramArrayOfAccessor[i]).physicalColumnIndex)) {
/*     */ 
/*     */ 
/*     */           
/* 926 */           paramArrayOfAccessor[i].copyRow();
/*     */         }
/*     */         else {
/*     */           
/* 930 */           byte b = 0;
/*     */ 
/*     */ 
/*     */           
/* 934 */           if ((paramArrayOfAccessor[i]).statement.statementType != 2 && !(paramArrayOfAccessor[i]).statement.sqlKind.isPlsqlOrCall()) {
/*     */ 
/*     */             
/* 937 */             int j = (paramArrayOfAccessor[i]).metaDataIndex + (paramArrayOfAccessor[i]).lastRowProcessed * 1;
/*     */             
/* 939 */             if ((paramArrayOfAccessor[i]).securityAttribute == OracleResultSetMetaData.SecurityAttribute.ENABLED) {
/* 940 */               b = (byte)this.meg.unmarshalUB1();
/*     */             }
/* 942 */             (paramArrayOfAccessor[i]).rowSpaceMetaData[j] = b;
/*     */           } 
/*     */           
/* 945 */           if (paramArrayOfAccessor[i].unmarshalOneRow()) {
/* 946 */             return true;
/*     */           }
/* 948 */           this.isFirstCol = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 953 */     this.bvcFound = false;
/*     */     
/* 955 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshal(Accessor[] paramArrayOfAccessor, int paramInt1, int paramInt2, int paramInt3) throws SQLException, IOException {
/* 964 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 979 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 984 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CTTIrxd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */