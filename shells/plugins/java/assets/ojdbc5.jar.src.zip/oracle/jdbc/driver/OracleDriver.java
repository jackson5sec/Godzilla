/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.management.InstanceAlreadyExistsException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import oracle.jdbc.OracleDatabaseMetaData;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDriver
/*     */   implements Driver
/*     */ {
/*     */   public static final String oracle_string = "oracle";
/*     */   public static final String jdbc_string = "jdbc";
/*     */   public static final String protocol_string = "protocol";
/*     */   public static final String user_string = "user";
/*     */   public static final String password_string = "password";
/*     */   public static final String database_string = "database";
/*     */   public static final String server_string = "server";
/*     */   public static final String access_string = "access";
/*     */   public static final String protocolFullName_string = "protocolFullName";
/*     */   public static final String logon_as_internal_str = "internal_logon";
/*     */   public static final String proxy_client_name = "oracle.jdbc.proxyClientName";
/*     */   public static final String prefetch_string = "prefetch";
/*     */   public static final String row_prefetch_string = "rowPrefetch";
/*     */   public static final String default_row_prefetch_string = "defaultRowPrefetch";
/*     */   public static final String batch_string = "batch";
/*     */   public static final String execute_batch_string = "executeBatch";
/*     */   public static final String default_execute_batch_string = "defaultExecuteBatch";
/*     */   public static final String process_escapes_string = "processEscapes";
/*     */   public static final String accumulate_batch_result = "AccumulateBatchResult";
/*     */   public static final String j2ee_compliance = "oracle.jdbc.J2EE13Compliant";
/*     */   public static final String v8compatible_string = "V8Compatible";
/*     */   public static final String permit_timestamp_date_mismatch_string = "oracle.jdbc.internal.permitBindDateDefineTimestampMismatch";
/*     */   public static final String StreamChunkSize_string = "oracle.jdbc.StreamChunkSize";
/*     */   public static final String prelim_auth_string = "prelim_auth";
/*     */   public static final String SetFloatAndDoubleUseBinary_string = "SetFloatAndDoubleUseBinary";
/*     */   public static final String xa_trans_loose = "oracle.jdbc.XATransLoose";
/*     */   public static final String tcp_no_delay = "oracle.jdbc.TcpNoDelay";
/*     */   public static final String read_timeout = "oracle.jdbc.ReadTimeout";
/*     */   public static final String defaultnchar_string = "oracle.jdbc.defaultNChar";
/*     */   public static final String defaultncharprop_string = "defaultNChar";
/*     */   public static final String useFetchSizeWithLongColumn_prop_string = "useFetchSizeWithLongColumn";
/*     */   public static final String useFetchSizeWithLongColumn_string = "oracle.jdbc.useFetchSizeWithLongColumn";
/*     */   public static final String remarks_string = "remarks";
/*     */   public static final String report_remarks_string = "remarksReporting";
/*     */   public static final String synonyms_string = "synonyms";
/*     */   public static final String include_synonyms_string = "includeSynonyms";
/*     */   public static final String restrict_getTables_string = "restrictGetTables";
/*     */   public static final String fixed_string_string = "fixedString";
/*     */   public static final String dll_string = "oracle.jdbc.ocinativelibrary";
/*     */   public static final String nls_lang_backdoor = "oracle.jdbc.ociNlsLangBackwardCompatible";
/*     */   public static final String disable_defineColumnType_string = "disableDefineColumnType";
/*     */   public static final String convert_nchar_literals_string = "oracle.jdbc.convertNcharLiterals";
/*     */   public static final String dataSizeUnitsPropertyName = "";
/*     */   public static final String dataSizeBytes = "";
/*     */   public static final String dataSizeChars = "";
/*     */   public static final String set_new_password_string = "OCINewPassword";
/*     */   public static final String retain_v9_bind_behavior_string = "oracle.jdbc.RetainV9LongBindBehavior";
/*     */   public static final String no_caching_buffers = "oracle.jdbc.FreeMemoryOnEnterImplicitCache";
/*     */   static final int EXTENSION_TYPE_ORACLE_ERROR = -3;
/*     */   static final int EXTENSION_TYPE_GEN_ERROR = -2;
/*     */   static final int EXTENSION_TYPE_TYPE4_CLIENT = 0;
/*     */   static final int EXTENSION_TYPE_TYPE4_SERVER = 1;
/*     */   static final int EXTENSION_TYPE_TYPE2_CLIENT = 2;
/*     */   static final int EXTENSION_TYPE_TYPE2_SERVER = 3;
/*     */   private static final int NUMBER_OF_EXTENSION_TYPES = 4;
/* 144 */   private OracleDriverExtension[] driverExtensions = new OracleDriverExtension[4];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DRIVER_PACKAGE_STRING = "driver";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   private static final String[] driverExtensionClassNames = new String[] { "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T4CDriverExtension", "oracle.jdbc.driver.T2CDriverExtension", "oracle.jdbc.driver.T2SDriverExtension" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Properties driverAccess;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   protected static Connection defaultConn = null;
/* 180 */   private static OracleDriver defaultDriver = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 187 */       if (defaultDriver == null) {
/*     */         
/* 189 */         defaultDriver = (OracleDriver)new oracle.jdbc.OracleDriver();
/* 190 */         DriverManager.registerDriver(defaultDriver);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       AccessController.doPrivileged(new PrivilegedAction()
/*     */           {
/*     */             public Object run()
/*     */             {
/* 201 */               OracleDriver.registerMBeans();
/* 202 */               return null;
/*     */             }
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 218 */       Timestamp timestamp = Timestamp.valueOf("2000-01-01 00:00:00.0");
/*     */ 
/*     */     
/*     */     }
/* 222 */     catch (SQLException sQLException) {
/* 223 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "SQLException in static block.", sQLException);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 228 */     catch (RuntimeException runtimeException) {
/* 229 */       Logger.getLogger("oracle.jdbc.driver").log(Level.SEVERE, "RuntimeException in static block.", runtimeException);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 243 */       ClassRef classRef = ClassRef.newInstance("oracle.security.pki.OraclePKIProvider");
/* 244 */       Object object = classRef.get().newInstance();
/*     */     }
/* 246 */     catch (Throwable throwable) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   public static final Map<String, ClassRef> systemTypeMap = new Hashtable<String, ClassRef>(3);
/*     */   
/*     */   private static final String DEFAULT_CONNECTION_PROPERTIES_RESOURCE_NAME = "/oracle/jdbc/defaultConnectionProperties.properties";
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 262 */       systemTypeMap.put("SYS.XMLTYPE", ClassRef.newInstance("oracle.xdb.XMLTypeFactory"));
/*     */     }
/* 264 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 272 */       systemTypeMap.put("SYS.ANYDATA", ClassRef.newInstance("oracle.sql.AnyDataFactory"));
/* 273 */       systemTypeMap.put("SYS.ANYTYPE", ClassRef.newInstance("oracle.sql.TypeDescriptorFactory"));
/*     */     }
/* 275 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 288 */   protected static final Properties DEFAULT_CONNECTION_PROPERTIES = new Properties();
/*     */   static {
/*     */     try {
/* 291 */       InputStream inputStream = PhysicalConnection.class.getResourceAsStream("/oracle/jdbc/defaultConnectionProperties.properties");
/* 292 */       if (inputStream != null) DEFAULT_CONNECTION_PROPERTIES.load(inputStream);
/*     */     
/* 294 */     } catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void registerMBeans() {
/*     */     try {
/* 310 */       MBeanServer mBeanServer = null;
/*     */       
/*     */       try {
/* 313 */         ClassRef classRef = ClassRef.newInstance("oracle.as.jmx.framework.PortableMBeanFactory");
/* 314 */         Constructor<Object> constructor = classRef.get().getConstructor(new Class[0]);
/* 315 */         Object object = constructor.newInstance(new Object[0]);
/* 316 */         Method method = classRef.get().getMethod("getMBeanServer", new Class[0]);
/* 317 */         mBeanServer = (MBeanServer)method.invoke(object, new Object[0]);
/*     */       }
/* 319 */       catch (NoClassDefFoundError noClassDefFoundError) {
/*     */ 
/*     */         
/* 322 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 324 */       catch (ClassNotFoundException classNotFoundException) {
/*     */ 
/*     */         
/* 327 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 329 */       catch (NoSuchMethodException noSuchMethodException) {
/* 330 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but not the getMBeanServer method.", noSuchMethodException);
/*     */ 
/*     */ 
/*     */         
/* 334 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 336 */       catch (InstantiationException instantiationException) {
/* 337 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not create an instance.", instantiationException);
/*     */ 
/*     */ 
/*     */         
/* 341 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 343 */       catch (IllegalAccessException illegalAccessException) {
/* 344 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but could not access the getMBeanServer method.", illegalAccessException);
/*     */ 
/*     */ 
/*     */         
/* 348 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/* 350 */       catch (InvocationTargetException invocationTargetException) {
/* 351 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Found Oracle Apps MBeanServer but the getMBeanServer method threw an exception.", invocationTargetException);
/*     */ 
/*     */ 
/*     */         
/* 355 */         mBeanServer = ManagementFactory.getPlatformMBeanServer();
/*     */       } 
/* 357 */       if (mBeanServer != null) {
/* 358 */         ClassLoader classLoader = OracleDriver.class.getClassLoader();
/* 359 */         String str = (classLoader == null) ? "nullLoader" : classLoader.getClass().getName();
/* 360 */         byte b = 0;
/*     */         while (true) {
/* 362 */           String str1 = str + "@" + Integer.toHexString(((classLoader == null) ? 0 : classLoader.hashCode()) + b++);
/*     */           
/* 364 */           ObjectName objectName = new ObjectName("com.oracle.jdbc:type=diagnosability,name=" + str1);
/*     */           
/*     */           try {
/* 367 */             mBeanServer.registerMBean(new OracleDiagnosabilityMBean(), objectName);
/*     */             
/*     */             break;
/* 370 */           } catch (InstanceAlreadyExistsException instanceAlreadyExistsException) {}
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 375 */         Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Unable to find an MBeanServer so no MBears are registered.");
/*     */       }
/*     */     
/*     */     }
/* 379 */     catch (JMException jMException) {
/* 380 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", jMException);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 385 */     catch (Throwable throwable) {
/* 386 */       Logger.getLogger("oracle.jdbc").log(Level.WARNING, "Error while registering Oracle JDBC Diagnosability MBean.", throwable);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection connect(String paramString, Properties paramProperties) throws SQLException {
/* 420 */     if (paramString.regionMatches(0, "jdbc:default:connection", 0, 23)) {
/*     */       
/* 422 */       String str = "jdbc:oracle:kprb";
/* 423 */       int j = paramString.length();
/*     */       
/* 425 */       if (j > 23) {
/* 426 */         paramString = str.concat(paramString.substring(23, paramString.length()));
/*     */       } else {
/* 428 */         paramString = str.concat(":");
/*     */       } 
/* 430 */       str = null;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 440 */     int i = oracleDriverExtensionTypeFromURL(paramString);
/*     */     
/* 442 */     if (i == -2) {
/* 443 */       return null;
/*     */     }
/* 445 */     if (i == -3) {
/*     */       
/* 447 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
/* 448 */       sQLException.fillInStackTrace();
/* 449 */       throw sQLException;
/*     */     } 
/*     */     
/* 452 */     OracleDriverExtension oracleDriverExtension = null;
/*     */     
/* 454 */     oracleDriverExtension = this.driverExtensions[i];
/*     */     
/* 456 */     if (oracleDriverExtension == null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 461 */         synchronized (this)
/*     */         {
/* 463 */           if (oracleDriverExtension == null)
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 469 */             oracleDriverExtension = (OracleDriverExtension)Class.forName(driverExtensionClassNames[i]).newInstance();
/*     */             
/* 471 */             this.driverExtensions[i] = oracleDriverExtension;
/*     */           }
/*     */           else
/*     */           {
/* 475 */             oracleDriverExtension = this.driverExtensions[i];
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 480 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 483 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
/* 484 */         sQLException.fillInStackTrace();
/* 485 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 492 */     if (paramProperties == null) {
/* 493 */       paramProperties = new Properties();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 504 */     Enumeration<Driver> enumeration = DriverManager.getDrivers();
/*     */ 
/*     */     
/* 507 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 509 */       Driver driver = enumeration.nextElement();
/*     */       
/* 511 */       if (driver instanceof OracleDriver) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 516 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 518 */       Driver driver = enumeration.nextElement();
/*     */       
/* 520 */       if (driver instanceof OracleDriver) {
/* 521 */         DriverManager.deregisterDriver(driver);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 528 */     PhysicalConnection physicalConnection = (PhysicalConnection)oracleDriverExtension.getConnection(paramString, paramProperties);
/*     */ 
/*     */     
/* 531 */     physicalConnection.protocolId = i;
/*     */     
/* 533 */     return (Connection)physicalConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection defaultConnection() throws SQLException {
/* 546 */     if (defaultConn == null || defaultConn.isClosed())
/*     */     {
/* 548 */       synchronized (OracleDriver.class) {
/*     */         
/* 550 */         if (defaultConn == null || defaultConn.isClosed())
/*     */         {
/* 552 */           defaultConn = connect("jdbc:oracle:kprb:", new Properties());
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 557 */     return defaultConn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int oracleDriverExtensionTypeFromURL(String paramString) {
/* 582 */     int i = paramString.indexOf(':');
/*     */     
/* 584 */     if (i == -1) {
/* 585 */       return -2;
/*     */     }
/* 587 */     if (!paramString.regionMatches(true, 0, "jdbc", 0, i)) {
/* 588 */       return -2;
/*     */     }
/* 590 */     i++;
/*     */     
/* 592 */     int j = paramString.indexOf(':', i);
/*     */     
/* 594 */     if (j == -1) {
/* 595 */       return -2;
/*     */     }
/* 597 */     if (!paramString.regionMatches(true, i, "oracle", 0, j - i))
/*     */     {
/* 599 */       return -2;
/*     */     }
/* 601 */     j++;
/*     */     
/* 603 */     int k = paramString.indexOf(':', j);
/*     */     
/* 605 */     String str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 612 */     if (k == -1) {
/* 613 */       return -3;
/*     */     }
/* 615 */     str = paramString.substring(j, k);
/*     */     
/* 617 */     if (str.equals("thin")) {
/* 618 */       return 0;
/*     */     }
/* 620 */     if (str.equals("oci8") || str.equals("oci")) {
/* 621 */       return 2;
/*     */     }
/*     */ 
/*     */     
/* 625 */     return -3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean acceptsURL(String paramString) {
/* 645 */     if (paramString.startsWith("jdbc:oracle:"))
/*     */     {
/* 647 */       return (oracleDriverExtensionTypeFromURL(paramString) > -2);
/*     */     }
/*     */     
/* 650 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DriverPropertyInfo[] getPropertyInfo(String paramString, Properties paramProperties) throws SQLException {
/* 658 */     Class clazz = null;
/*     */     
/*     */     try {
/* 661 */       clazz = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*     */     
/*     */     }
/* 664 */     catch (ClassNotFoundException classNotFoundException) {}
/*     */     
/* 666 */     byte b1 = 0;
/* 667 */     String[] arrayOfString1 = new String[150];
/* 668 */     String[] arrayOfString2 = new String[150];
/*     */     
/* 670 */     Field[] arrayOfField = clazz.getFields();
/* 671 */     for (byte b2 = 0; b2 < arrayOfField.length; b2++) {
/*     */       
/* 673 */       if (arrayOfField[b2].getName().startsWith("CONNECTION_PROPERTY_") && !arrayOfField[b2].getName().endsWith("_DEFAULT") && !arrayOfField[b2].getName().endsWith("_ACCESSMODE")) {
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */           
/* 679 */           String str1 = (String)arrayOfField[b2].get(null);
/* 680 */           Field field = clazz.getField(arrayOfField[b2].getName() + "_DEFAULT");
/* 681 */           String str2 = (String)field.get(null);
/* 682 */           if (b1 == arrayOfString1.length) {
/*     */             
/* 684 */             String[] arrayOfString3 = new String[arrayOfString1.length * 2];
/* 685 */             String[] arrayOfString4 = new String[arrayOfString1.length * 2];
/* 686 */             System.arraycopy(arrayOfString1, 0, arrayOfString3, 0, arrayOfString1.length);
/* 687 */             System.arraycopy(arrayOfString2, 0, arrayOfString4, 0, arrayOfString1.length);
/* 688 */             arrayOfString1 = arrayOfString3;
/* 689 */             arrayOfString2 = arrayOfString4;
/*     */           } 
/* 691 */           arrayOfString1[b1] = str1;
/* 692 */           arrayOfString2[b1] = str2;
/* 693 */           b1++;
/*     */         }
/* 695 */         catch (IllegalAccessException illegalAccessException) {
/*     */         
/* 697 */         } catch (NoSuchFieldException noSuchFieldException) {}
/*     */       }
/*     */     } 
/*     */     
/* 701 */     DriverPropertyInfo[] arrayOfDriverPropertyInfo = new DriverPropertyInfo[b1];
/* 702 */     for (byte b3 = 0; b3 < b1; b3++)
/* 703 */       arrayOfDriverPropertyInfo[b3] = new DriverPropertyInfo(arrayOfString1[b3], arrayOfString2[b3]); 
/* 704 */     return arrayOfDriverPropertyInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMajorVersion() {
/* 711 */     return OracleDatabaseMetaData.getDriverMajorVersionInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinorVersion() {
/* 718 */     return OracleDatabaseMetaData.getDriverMinorVersionInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean jdbcCompliant() {
/* 725 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String processSqlEscapes(String paramString) throws SQLException {
/* 740 */     OracleSql oracleSql = new OracleSql(null);
/*     */ 
/*     */ 
/*     */     
/* 744 */     oracleSql.initialize(paramString);
/*     */     
/* 746 */     return oracleSql.parse(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCompileTime() {
/* 761 */     return BuildInfo.getBuildDate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getSystemPropertyFastConnectionFailover(String paramString) {
/* 768 */     return PhysicalConnection.getSystemPropertyFastConnectionFailover(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 783 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 788 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\OracleDriver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */