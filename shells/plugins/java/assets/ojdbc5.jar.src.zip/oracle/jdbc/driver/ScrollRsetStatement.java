package oracle.jdbc.driver;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

interface ScrollRsetStatement {
  Connection getConnection() throws SQLException;
  
  void notifyCloseRset() throws SQLException;
  
  int copyBinds(Statement paramStatement, int paramInt) throws SQLException;
  
  String getOriginalSql() throws SQLException;
  
  OracleResultSetCache getResultSetCache() throws SQLException;
  
  int getMaxFieldSize() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\ScrollRsetStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */