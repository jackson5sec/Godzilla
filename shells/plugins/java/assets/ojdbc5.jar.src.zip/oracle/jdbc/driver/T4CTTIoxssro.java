/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.KeywordValueLong;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4CTTIoxssro
/*     */   extends T4CTTIfun
/*     */ {
/*     */   private int functionId;
/*     */   private byte[] sessionId;
/*     */   private KeywordValueLong[] inKV;
/*     */   private int inFlags;
/*     */   private KeywordValueLong[] outKV;
/*     */   private int outFlags;
/*     */   
/*     */   T4CTTIoxssro(T4CConnection paramT4CConnection) {
/*  63 */     super(paramT4CConnection, (byte)3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     this.sessionId = null;
/*  70 */     this.inKV = null;
/*     */ 
/*     */     
/*  73 */     this.outKV = null;
/*  74 */     this.outFlags = -1;
/*     */     setFunCode((short)156);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void doOXSSRO(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws IOException, SQLException {
/*  83 */     this.functionId = paramInt1;
/*  84 */     this.sessionId = paramArrayOfbyte;
/*  85 */     this.inKV = paramArrayOfKeywordValueLong;
/*  86 */     this.inFlags = paramInt2;
/*  87 */     this.outKV = null;
/*  88 */     this.outFlags = -1;
/*     */     
/*  90 */     if (this.inKV != null)
/*  91 */       for (byte b = 0; b < this.inKV.length; b++)
/*  92 */         ((KeywordValueLongI)this.inKV[b]).doCharConversion(this.meg.conv);  
/*  93 */     doRPC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void marshal() throws IOException {
/*  99 */     this.meg.marshalUB4(this.functionId);
/* 100 */     boolean bool1 = false;
/* 101 */     if (this.sessionId != null && this.sessionId.length > 0) {
/*     */       
/* 103 */       bool1 = true;
/* 104 */       this.meg.marshalPTR();
/* 105 */       this.meg.marshalUB4(this.sessionId.length);
/*     */     }
/*     */     else {
/*     */       
/* 109 */       this.meg.marshalNULLPTR();
/* 110 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 112 */     boolean bool2 = false;
/* 113 */     if (this.inKV != null && this.inKV.length > 0) {
/*     */       
/* 115 */       bool2 = true;
/* 116 */       this.meg.marshalPTR();
/* 117 */       this.meg.marshalUB4(this.inKV.length);
/*     */     }
/*     */     else {
/*     */       
/* 121 */       this.meg.marshalNULLPTR();
/* 122 */       this.meg.marshalUB4(0L);
/*     */     } 
/* 124 */     this.meg.marshalUB4(this.inFlags);
/* 125 */     this.meg.marshalPTR();
/* 126 */     this.meg.marshalPTR();
/* 127 */     this.meg.marshalPTR();
/*     */     
/* 129 */     if (bool1)
/* 130 */       this.meg.marshalB1Array(this.sessionId); 
/* 131 */     if (bool2) {
/* 132 */       for (byte b = 0; b < this.inKV.length; b++) {
/* 133 */         ((KeywordValueLongI)this.inKV[b]).marshal(this.meg);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   KeywordValueLong[] getOutKV() {
/* 141 */     return this.outKV;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   int getOutFlags() {
/* 147 */     return this.outFlags;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void readRPA() throws SQLException, IOException {
/* 153 */     int i = (int)this.meg.unmarshalUB4();
/* 154 */     this.outKV = new KeywordValueLong[i];
/* 155 */     for (byte b = 0; b < i; b++)
/* 156 */       this.outKV[b] = KeywordValueLongI.unmarshal(this.meg); 
/* 157 */     this.outFlags = (int)this.meg.unmarshalUB4();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 172 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 177 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CTTIoxssro.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */