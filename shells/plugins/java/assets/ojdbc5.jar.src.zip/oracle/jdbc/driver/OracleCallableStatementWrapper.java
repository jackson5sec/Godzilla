/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OraclePreparedStatement;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.jdbc.internal.OraclePreparedStatement;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ class OracleCallableStatementWrapper
/*      */   extends OraclePreparedStatementWrapper
/*      */   implements OracleCallableStatement
/*      */ {
/*   54 */   protected OracleCallableStatement callableStatement = null;
/*      */ 
/*      */   
/*      */   OracleCallableStatementWrapper(OracleCallableStatement paramOracleCallableStatement) throws SQLException {
/*   58 */     super((OraclePreparedStatement)paramOracleCallableStatement);
/*   59 */     this.callableStatement = (OracleCallableStatement)paramOracleCallableStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/*   81 */     this.callableStatement.setArray(paramString, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*   89 */     this.callableStatement.setBigDecimal(paramString, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/*   97 */     this.callableStatement.setBlob(paramString, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/*  105 */     this.callableStatement.setBoolean(paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/*  113 */     this.callableStatement.setByte(paramString, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  121 */     this.callableStatement.setBytes(paramString, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/*  129 */     this.callableStatement.setClob(paramString, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/*  137 */     this.callableStatement.setDate(paramString, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  145 */     this.callableStatement.setDate(paramString, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/*  153 */     this.callableStatement.setDouble(paramString, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/*  161 */     this.callableStatement.setFloat(paramString, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/*  169 */     this.callableStatement.setInt(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/*  177 */     this.callableStatement.setLong(paramString, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/*  185 */     this.callableStatement.setObject(paramString, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  193 */     this.callableStatement.setObject(paramString, paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/*  201 */     this.callableStatement.setRef(paramString, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/*  209 */     this.callableStatement.setShort(paramString, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/*  217 */     this.callableStatement.setString(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/*  225 */     this.callableStatement.setTime(paramString, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  233 */     this.callableStatement.setTime(paramString, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  241 */     this.callableStatement.setTimestamp(paramString, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  249 */     this.callableStatement.setTimestamp(paramString, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/*  257 */     this.callableStatement.setURL(paramString, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/*  265 */     this.callableStatement.setARRAY(paramString, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/*  273 */     this.callableStatement.setBFILE(paramString, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/*  281 */     this.callableStatement.setBfile(paramString, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/*  289 */     this.callableStatement.setBinaryFloat(paramString, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  297 */     this.callableStatement.setBinaryFloat(paramString, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/*  305 */     this.callableStatement.setBinaryDouble(paramString, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  313 */     this.callableStatement.setBinaryDouble(paramString, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/*  321 */     this.callableStatement.setBLOB(paramString, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/*  329 */     this.callableStatement.setCHAR(paramString, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/*  337 */     this.callableStatement.setCLOB(paramString, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/*  345 */     this.callableStatement.setCursor(paramString, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/*  353 */     this.callableStatement.setCustomDatum(paramString, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/*  361 */     this.callableStatement.setDATE(paramString, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/*  369 */     this.callableStatement.setFixedCHAR(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/*  377 */     this.callableStatement.setINTERVALDS(paramString, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/*  385 */     this.callableStatement.setINTERVALYM(paramString, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/*  393 */     this.callableStatement.setNUMBER(paramString, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/*  401 */     this.callableStatement.setOPAQUE(paramString, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/*  409 */     this.callableStatement.setOracleObject(paramString, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/*  417 */     this.callableStatement.setORAData(paramString, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/*  425 */     this.callableStatement.setRAW(paramString, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/*  433 */     this.callableStatement.setREF(paramString, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/*  441 */     this.callableStatement.setRefType(paramString, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/*  449 */     this.callableStatement.setROWID(paramString, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/*  457 */     this.callableStatement.setSTRUCT(paramString, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  465 */     this.callableStatement.setTIMESTAMPLTZ(paramString, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  473 */     this.callableStatement.setTIMESTAMPTZ(paramString, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  481 */     this.callableStatement.setTIMESTAMP(paramString, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  489 */     this.callableStatement.setAsciiStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  497 */     this.callableStatement.setBinaryStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/*  505 */     this.callableStatement.setCharacterStream(paramString, paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  513 */     this.callableStatement.setUnicodeStream(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/*  523 */     this.callableStatement.setNull(paramString1, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/*  532 */     this.callableStatement.setNull(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/*  542 */     return this.callableStatement.getArray(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  550 */     return this.callableStatement.getBigDecimal(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  558 */     return this.callableStatement.getBigDecimal(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/*  566 */     return this.callableStatement.getBlob(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  574 */     return this.callableStatement.getBoolean(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  582 */     return this.callableStatement.getByte(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  590 */     return this.callableStatement.getBytes(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/*  598 */     return this.callableStatement.getClob(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  606 */     return this.callableStatement.getDate(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  614 */     return this.callableStatement.getDate(paramInt, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  622 */     return this.callableStatement.getDouble(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  630 */     return this.callableStatement.getFloat(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  638 */     return this.callableStatement.getInt(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  646 */     return this.callableStatement.getLong(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  654 */     return this.callableStatement.getObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/*  662 */     return this.callableStatement.getObject(paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/*  670 */     return this.callableStatement.getRef(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  678 */     return this.callableStatement.getShort(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  686 */     return this.callableStatement.getString(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  694 */     return this.callableStatement.getTime(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/*  702 */     return this.callableStatement.getTime(paramInt, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  710 */     return this.callableStatement.getTimestamp(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/*  718 */     return this.callableStatement.getTimestamp(paramInt, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/*  726 */     return this.callableStatement.getURL(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  734 */     return this.callableStatement.getARRAY(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/*  742 */     return this.callableStatement.getBFILE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/*  750 */     return this.callableStatement.getBfile(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/*  758 */     return this.callableStatement.getBLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/*  766 */     return this.callableStatement.getCHAR(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/*  774 */     return this.callableStatement.getCLOB(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/*  782 */     return this.callableStatement.getCursor(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/*  790 */     return this.callableStatement.getCustomDatum(paramInt, paramCustomDatumFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  798 */     return this.callableStatement.getDATE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  806 */     return this.callableStatement.getINTERVALDS(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  814 */     return this.callableStatement.getINTERVALYM(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  822 */     return this.callableStatement.getNUMBER(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  830 */     return this.callableStatement.getOPAQUE(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  838 */     return this.callableStatement.getOracleObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/*  846 */     return this.callableStatement.getORAData(paramInt, paramORADataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/*  854 */     return this.callableStatement.getObject(paramInt, paramOracleDataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/*  862 */     return this.callableStatement.getRAW(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/*  870 */     return this.callableStatement.getREF(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  878 */     return this.callableStatement.getROWID(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  886 */     return this.callableStatement.getSTRUCT(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  894 */     return this.callableStatement.getTIMESTAMPLTZ(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  902 */     return this.callableStatement.getTIMESTAMPTZ(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  910 */     return this.callableStatement.getTIMESTAMP(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/*  918 */     return this.callableStatement.getAsciiStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/*  926 */     return this.callableStatement.getBinaryStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/*  934 */     return this.callableStatement.getCharacterStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  942 */     return this.callableStatement.getUnicodeStream(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/*  951 */     return this.callableStatement.getArray(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/*  959 */     return this.callableStatement.getBigDecimal(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/*  967 */     return this.callableStatement.getBigDecimal(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/*  975 */     return this.callableStatement.getBlob(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/*  983 */     return this.callableStatement.getBoolean(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/*  991 */     return this.callableStatement.getByte(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/*  999 */     return this.callableStatement.getBytes(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 1007 */     return this.callableStatement.getClob(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 1015 */     return this.callableStatement.getDate(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 1023 */     return this.callableStatement.getDate(paramString, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 1031 */     return this.callableStatement.getDouble(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 1039 */     return this.callableStatement.getFloat(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 1047 */     return this.callableStatement.getInt(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 1055 */     return this.callableStatement.getLong(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 1063 */     return this.callableStatement.getObject(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 1071 */     return this.callableStatement.getObject(paramString, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 1079 */     return this.callableStatement.getRef(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 1087 */     return this.callableStatement.getShort(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 1095 */     return this.callableStatement.getString(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 1103 */     return this.callableStatement.getTime(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 1111 */     return this.callableStatement.getTime(paramString, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 1119 */     return this.callableStatement.getTimestamp(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 1127 */     return this.callableStatement.getTimestamp(paramString, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 1135 */     return this.callableStatement.getURL(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 1143 */     return this.callableStatement.getAsciiStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 1151 */     return this.callableStatement.getBinaryStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 1159 */     return this.callableStatement.getCharacterStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 1167 */     return this.callableStatement.getUnicodeStream(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 1181 */     this.callableStatement.setObject(paramString, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 1189 */     return this.callableStatement.getAnyDataEmbeddedObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException {
/* 1198 */     this.callableStatement.setStructDescriptor(paramInt, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 1207 */     this.callableStatement.setStructDescriptor(paramString, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1216 */     super.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/* 1223 */     this.callableStatement.closeWithKey(paramString);
/* 1224 */     this.statement = (OracleStatement)(this.preparedStatement = (OraclePreparedStatement)(this.callableStatement = closedStatement));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1237 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1245 */     this.callableStatement.registerOutParameterBytes(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1253 */     this.callableStatement.registerOutParameterChars(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 1261 */     this.callableStatement.registerIndexTableOutParameter(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1269 */     this.callableStatement.registerOutParameter(paramString, paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 1279 */     this.callableStatement.registerOutParameter(paramString1, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 1287 */     return this.callableStatement.sendBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {
/* 1295 */     this.callableStatement.setExecuteBatch(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 1303 */     return this.callableStatement.getPlsqlIndexTable(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 1311 */     return this.callableStatement.getPlsqlIndexTable(paramInt, paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 1319 */     return this.callableStatement.getOraclePlsqlIndexTable(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 1327 */     this.callableStatement.setStringForClob(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 1335 */     this.callableStatement.setBytesForBlob(paramString, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 1343 */     return this.callableStatement.wasNull();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/* 1351 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1359 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 1367 */     this.callableStatement.registerOutParameter(paramInt1, paramInt2, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 1376 */     this.callableStatement.registerOutParameter(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 1384 */     this.callableStatement.registerOutParameter(paramString, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 1392 */     return ((OracleCallableStatement)this.callableStatement).privateGetBytes(paramInt);
/*      */   }
/*      */ 
/*      */   
/* 1396 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\OracleCallableStatementWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */