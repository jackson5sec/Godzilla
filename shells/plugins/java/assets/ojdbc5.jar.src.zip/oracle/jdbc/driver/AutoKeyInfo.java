/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AutoKeyInfo
/*     */   extends OracleResultSetMetaData
/*     */ {
/*     */   String originalSql;
/*     */   String newSql;
/*     */   String tableName;
/*  27 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*     */   
/*     */   int sqlParserParamCount;
/*     */   
/*     */   String[] sqlParserParamList;
/*     */   
/*     */   boolean useNamedParameter;
/*     */   
/*     */   int current_argument;
/*     */   
/*     */   String[] columnNames;
/*     */   
/*     */   int[] columnIndexes;
/*     */   
/*     */   int numColumns;
/*     */   
/*     */   String[] tableColumnNames;
/*     */   
/*     */   int[] tableColumnTypes;
/*     */   
/*     */   int[] tableMaxLengths;
/*     */   
/*     */   boolean[] tableNullables;
/*     */   short[] tableFormOfUses;
/*     */   int[] tablePrecisions;
/*     */   int[] tableScales;
/*     */   String[] tableTypeNames;
/*     */   int autoKeyType;
/*     */   static final int KEYFLAG = 0;
/*     */   static final int COLUMNAME = 1;
/*     */   static final int COLUMNINDEX = 2;
/*     */   static final char QMARK = '?';
/*     */   int[] returnTypes;
/*     */   Accessor[] returnAccessors;
/*     */   
/*     */   AutoKeyInfo(String paramString) {
/*  63 */     this.originalSql = paramString;
/*  64 */     this.autoKeyType = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AutoKeyInfo(String paramString, String[] paramArrayOfString) {
/*  71 */     this.originalSql = paramString;
/*  72 */     this.columnNames = paramArrayOfString;
/*  73 */     this.autoKeyType = 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   AutoKeyInfo(String paramString, int[] paramArrayOfint) {
/*  80 */     this.originalSql = paramString;
/*  81 */     this.columnIndexes = paramArrayOfint;
/*  82 */     this.autoKeyType = 2;
/*     */   }
/*     */ 
/*     */   
/*     */   private void parseSql() throws SQLException {
/*  87 */     if (this.originalSql == null) {
/*     */       
/*  89 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  90 */       sQLException.fillInStackTrace();
/*  91 */       throw sQLException;
/*     */     } 
/*     */     
/*  94 */     OracleSql oracleSql = SQL_PARSER.get();
/*  95 */     oracleSql.initialize(this.originalSql);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.sqlKind = oracleSql.getSqlKind();
/*     */ 
/*     */     
/* 112 */     if (this.sqlKind == OracleStatement.SqlKind.INSERT) {
/*     */       
/* 114 */       this.sqlParserParamCount = oracleSql.getParameterCount();
/* 115 */       this.sqlParserParamList = oracleSql.getParameterList();
/*     */       
/* 117 */       if (this.sqlParserParamList == OracleSql.EMPTY_LIST) {
/* 118 */         this.useNamedParameter = false;
/*     */       } else {
/*     */         
/* 121 */         this.useNamedParameter = true;
/*     */         
/* 123 */         this.current_argument = this.sqlParserParamCount;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String generateUniqueNamedParameter() {
/*     */     boolean bool;
/*     */     String str;
/*     */     do {
/* 135 */       bool = false;
/* 136 */       str = Integer.toString(++this.current_argument).intern();
/*     */       
/* 138 */       for (byte b = 0; b < this.sqlParserParamCount; b++) {
/*     */         
/* 140 */         if (this.sqlParserParamList[b] == str) {
/*     */           
/* 142 */           bool = true;
/*     */           break;
/*     */         } 
/*     */       } 
/* 146 */     } while (bool);
/*     */     
/* 148 */     return ":" + str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getNewSql() throws SQLException {
/*     */     try {
/* 160 */       if (this.newSql != null) return this.newSql;
/*     */       
/* 162 */       if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) parseSql();
/*     */       
/* 164 */       switch (this.autoKeyType) {
/*     */         
/*     */         case 0:
/* 167 */           this.newSql = this.originalSql + " RETURNING ROWID INTO " + (this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?'));
/*     */           
/* 169 */           this.returnTypes = new int[1];
/* 170 */           this.returnTypes[0] = 104;
/*     */           break;
/*     */         case 1:
/* 173 */           getNewSqlByColumnName();
/*     */           break;
/*     */         case 2:
/* 176 */           getNewSqlByColumnIndexes();
/*     */           break;
/*     */       } 
/*     */ 
/*     */       
/* 181 */       this.sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/* 182 */       this.sqlParserParamList = null;
/* 183 */       return this.newSql;
/*     */     }
/* 185 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 188 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), exception);
/* 189 */       sQLException.fillInStackTrace();
/* 190 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getNewSqlByColumnName() throws SQLException {
/* 198 */     this.returnTypes = new int[this.columnNames.length];
/*     */ 
/*     */     
/* 201 */     this.columnIndexes = new int[this.columnNames.length];
/*     */     
/* 203 */     StringBuffer stringBuffer = new StringBuffer(this.originalSql);
/* 204 */     stringBuffer.append(" RETURNING ");
/*     */     
/*     */     byte b;
/* 207 */     for (b = 0; b < this.columnNames.length; b++) {
/*     */       
/* 209 */       int i = getReturnParamTypeCode(b, this.columnNames[b], this.columnIndexes);
/* 210 */       this.returnTypes[b] = i;
/*     */       
/* 212 */       stringBuffer.append(this.columnNames[b]);
/*     */       
/* 214 */       if (b < this.columnNames.length - 1) stringBuffer.append(", ");
/*     */     
/*     */     } 
/* 217 */     stringBuffer.append(" INTO ");
/*     */     
/* 219 */     for (b = 0; b < this.columnNames.length - 1; b++)
/*     */     {
/* 221 */       stringBuffer.append((this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?')) + ", ");
/*     */     }
/*     */     
/* 224 */     stringBuffer.append(this.useNamedParameter ? generateUniqueNamedParameter() : Character.valueOf('?'));
/*     */     
/* 226 */     this.newSql = new String(stringBuffer);
/* 227 */     return this.newSql;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getNewSqlByColumnIndexes() throws SQLException {
/* 232 */     this.returnTypes = new int[this.columnIndexes.length];
/*     */     
/* 234 */     StringBuffer stringBuffer = new StringBuffer(this.originalSql);
/* 235 */     stringBuffer.append(" RETURNING ");
/*     */ 
/*     */     
/*     */     byte b;
/*     */     
/* 240 */     for (b = 0; b < this.columnIndexes.length; b++) {
/*     */       
/* 242 */       int j = this.columnIndexes[b] - 1;
/* 243 */       if (j < 0 || j > this.tableColumnNames.length) {
/*     */ 
/*     */         
/* 246 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 247 */         sQLException.fillInStackTrace();
/* 248 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */       
/* 252 */       int i = this.tableColumnTypes[j];
/* 253 */       String str = this.tableColumnNames[j];
/* 254 */       this.returnTypes[b] = i;
/*     */       
/* 256 */       stringBuffer.append(str);
/*     */       
/* 258 */       if (b < this.columnIndexes.length - 1) stringBuffer.append(", ");
/*     */     
/*     */     } 
/* 261 */     stringBuffer.append(" INTO ");
/*     */     
/* 263 */     for (b = 0; b < this.columnIndexes.length - 1; b++)
/*     */     {
/* 265 */       stringBuffer.append((this.useNamedParameter ? generateUniqueNamedParameter() : (String)Character.valueOf('?')) + ", ");
/*     */     }
/*     */     
/* 268 */     stringBuffer.append(this.useNamedParameter ? generateUniqueNamedParameter() : Character.valueOf('?'));
/*     */     
/* 270 */     this.newSql = new String(stringBuffer);
/* 271 */     return this.newSql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int getReturnParamTypeCode(int paramInt, String paramString, int[] paramArrayOfint) throws SQLException {
/* 279 */     for (byte b = 0; b < this.tableColumnNames.length; b++) {
/*     */       
/* 281 */       if (paramString.equalsIgnoreCase(this.tableColumnNames[b])) {
/*     */         
/* 283 */         paramArrayOfint[paramInt] = b + 1;
/* 284 */         return this.tableColumnTypes[b];
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 290 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 291 */     sQLException.fillInStackTrace();
/* 292 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 297 */   private static final ThreadLocal<OracleSql> SQL_PARSER = new ThreadLocal<OracleSql>() {
/*     */       protected OracleSql initialValue() {
/* 299 */         return new OracleSql(null);
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   final boolean isInsertSqlStmt() throws SQLException {
/* 305 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/* 306 */       parseSql();
/*     */     }
/* 308 */     return (this.sqlKind == OracleStatement.SqlKind.INSERT);
/*     */   }
/*     */ 
/*     */   
/*     */   String getTableName() throws SQLException {
/* 313 */     if (this.tableName != null) return this.tableName;
/*     */     
/* 315 */     String str = this.originalSql.trim().toUpperCase();
/*     */     
/* 317 */     int i = str.indexOf("INSERT");
/* 318 */     i = str.indexOf("INTO", i);
/*     */     
/* 320 */     if (i < 0) {
/*     */       
/* 322 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 323 */       sQLException.fillInStackTrace();
/* 324 */       throw sQLException;
/*     */     } 
/*     */     
/* 327 */     int j = str.length();
/* 328 */     int k = i + 5;
/*     */     
/* 330 */     for (; k < j && str.charAt(k) == ' '; k++);
/*     */     
/* 332 */     if (k >= j) {
/*     */       
/* 334 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 335 */       sQLException.fillInStackTrace();
/* 336 */       throw sQLException;
/*     */     } 
/*     */     
/* 339 */     int m = k + 1;
/*     */ 
/*     */     
/* 342 */     for (; m < j && str.charAt(m) != ' ' && str.charAt(m) != '('; m++);
/*     */     
/* 344 */     if (k == m - 1) {
/*     */       
/* 346 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 347 */       sQLException.fillInStackTrace();
/* 348 */       throw sQLException;
/*     */     } 
/*     */     
/* 351 */     this.tableName = str.substring(k, m);
/*     */     
/* 353 */     return this.tableName;
/*     */   }
/*     */ 
/*     */   
/*     */   void allocateSpaceForDescribedData(int paramInt) throws SQLException {
/* 358 */     this.numColumns = paramInt;
/*     */     
/* 360 */     this.tableColumnNames = new String[paramInt];
/* 361 */     this.tableColumnTypes = new int[paramInt];
/* 362 */     this.tableMaxLengths = new int[paramInt];
/* 363 */     this.tableNullables = new boolean[paramInt];
/* 364 */     this.tableFormOfUses = new short[paramInt];
/* 365 */     this.tablePrecisions = new int[paramInt];
/* 366 */     this.tableScales = new int[paramInt];
/* 367 */     this.tableTypeNames = new String[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void fillDescribedData(int paramInt1, String paramString1, int paramInt2, int paramInt3, boolean paramBoolean, short paramShort, int paramInt4, int paramInt5, String paramString2) throws SQLException {
/* 375 */     this.tableColumnNames[paramInt1] = paramString1;
/* 376 */     this.tableColumnTypes[paramInt1] = paramInt2;
/* 377 */     this.tableMaxLengths[paramInt1] = paramInt3;
/* 378 */     this.tableNullables[paramInt1] = paramBoolean;
/* 379 */     this.tableFormOfUses[paramInt1] = paramShort;
/* 380 */     this.tablePrecisions[paramInt1] = paramInt4;
/* 381 */     this.tableScales[paramInt1] = paramInt5;
/* 382 */     this.tableTypeNames[paramInt1] = paramString2;
/*     */   }
/*     */ 
/*     */   
/*     */   void initMetaData(OracleReturnResultSet paramOracleReturnResultSet) throws SQLException {
/* 387 */     if (this.returnAccessors != null)
/*     */       return; 
/* 389 */     this.returnAccessors = paramOracleReturnResultSet.returnAccessors;
/*     */ 
/*     */     
/* 392 */     switch (this.autoKeyType) {
/*     */       
/*     */       case 0:
/* 395 */         initMetaDataKeyFlag();
/*     */         break;
/*     */       case 1:
/*     */       case 2:
/* 399 */         initMetaDataColumnIndexes();
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initMetaDataKeyFlag() throws SQLException {
/* 407 */     (this.returnAccessors[0]).columnName = "ROWID";
/* 408 */     (this.returnAccessors[0]).describeType = 104;
/* 409 */     (this.returnAccessors[0]).describeMaxLength = 4;
/* 410 */     (this.returnAccessors[0]).nullable = true;
/* 411 */     (this.returnAccessors[0]).precision = 0;
/* 412 */     (this.returnAccessors[0]).scale = 0;
/* 413 */     (this.returnAccessors[0]).formOfUse = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initMetaDataColumnIndexes() throws SQLException {
/* 421 */     for (byte b = 0; b < this.returnAccessors.length; b++) {
/*     */       
/* 423 */       Accessor accessor = this.returnAccessors[b];
/* 424 */       int i = this.columnIndexes[b] - 1;
/*     */       
/* 426 */       accessor.columnName = this.tableColumnNames[i];
/* 427 */       accessor.describeType = this.tableColumnTypes[i];
/* 428 */       accessor.describeMaxLength = this.tableMaxLengths[i];
/* 429 */       accessor.nullable = this.tableNullables[i];
/* 430 */       accessor.precision = this.tablePrecisions[i];
/* 431 */       accessor.scale = this.tablePrecisions[i];
/* 432 */       accessor.formOfUse = this.tableFormOfUses[i];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getValidColumnIndex(int paramInt) throws SQLException {
/* 442 */     if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
/*     */       
/* 444 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 445 */       sQLException.fillInStackTrace();
/* 446 */       throw sQLException;
/*     */     } 
/*     */     
/* 449 */     return paramInt - 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getColumnCount() throws SQLException {
/* 454 */     return this.returnAccessors.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnName(int paramInt) throws SQLException {
/* 460 */     if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
/*     */       
/* 462 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 463 */       sQLException.fillInStackTrace();
/* 464 */       throw sQLException;
/*     */     } 
/*     */     
/* 467 */     return (this.returnAccessors[paramInt - 1]).columnName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName(int paramInt) throws SQLException {
/* 473 */     if (paramInt <= 0 || paramInt > this.returnAccessors.length) {
/*     */       
/* 475 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 476 */       sQLException.fillInStackTrace();
/* 477 */       throw sQLException;
/*     */     } 
/*     */     
/* 480 */     return getTableName();
/*     */   }
/*     */ 
/*     */   
/*     */   Accessor[] getDescription() throws SQLException {
/* 485 */     return this.returnAccessors;
/*     */   }
/*     */ 
/*     */   
/* 489 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\AutoKeyInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */