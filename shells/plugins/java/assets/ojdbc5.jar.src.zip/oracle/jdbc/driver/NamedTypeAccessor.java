/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.OracleDataFactory;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.ArrayDescriptor;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.JAVA_STRUCT;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.OpaqueDescriptor;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.StructDescriptor;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NamedTypeAccessor
/*     */   extends TypeAccessor
/*     */ {
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, String paramString, short paramShort, int paramInt, boolean paramBoolean) throws SQLException {
/*  38 */     init(paramOracleStatement, 109, 109, paramShort, paramBoolean);
/*  39 */     initForDataAccess(paramInt, 0, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString) throws SQLException {
/*  49 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*  50 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */     
/*  52 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   NamedTypeAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, String paramString, OracleType paramOracleType) throws SQLException {
/*  62 */     init(paramOracleStatement, 109, 109, paramShort, false);
/*     */     
/*  64 */     this.describeOtype = paramOracleType;
/*     */     
/*  66 */     initForDescribe(109, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, paramString);
/*     */ 
/*     */     
/*  69 */     this.internalOtype = paramOracleType;
/*     */     
/*  71 */     initForDataAccess(0, paramInt1, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleType otypeFromName(String paramString) throws SQLException {
/*  78 */     if (!this.outBind) {
/*  79 */       return (OracleType)TypeDescriptor.getTypeDescriptor(paramString, (OracleConnection)this.statement.connection).getPickler();
/*     */     }
/*  81 */     if (this.externalType == 2003) {
/*  82 */       return (OracleType)ArrayDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeCOLLECTION();
/*     */     }
/*  84 */     if (this.externalType == 2007)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/*  89 */       return (OracleType)OpaqueDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getPickler();
/*     */     }
/*     */     
/*  92 */     return (OracleType)StructDescriptor.createDescriptor(paramString, (Connection)this.statement.connection).getOracleTypeADT();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 101 */     super.initForDataAccess(paramInt1, paramInt2, paramString);
/*     */     
/* 103 */     this.byteLength = this.statement.connection.namedTypeAccessorByteLen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 119 */     return getObject(paramInt, this.statement.connection.getTypeMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 135 */     return paramOracleDataFactory.create(getObject(paramInt, this.statement.connection.getTypeMap()), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 151 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 153 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 154 */       sQLException.fillInStackTrace();
/* 155 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       Datum datum;
/*     */ 
/*     */       
/* 165 */       if (this.externalType == 0) {
/*     */         
/* 167 */         Datum datum1 = getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */         
/* 171 */         if (datum1 == null) {
/* 172 */           return null;
/*     */         }
/* 174 */         if (datum1 instanceof STRUCT) {
/* 175 */           return ((STRUCT)datum1).toJdbc(paramMap);
/*     */         }
/* 177 */         if (datum1 instanceof OPAQUE) {
/* 178 */           return ((OPAQUE)datum1).toJdbc(paramMap);
/*     */         }
/*     */ 
/*     */         
/* 182 */         return datum1.toJdbc();
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 187 */       switch (this.externalType) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2008:
/* 193 */           paramMap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 2000:
/*     */         case 2002:
/*     */         case 2003:
/*     */         case 2007:
/* 202 */           datum = getOracleObject(paramInt);
/*     */ 
/*     */ 
/*     */           
/* 206 */           if (datum == null) {
/* 207 */             return null;
/*     */           }
/* 209 */           if (datum instanceof STRUCT) {
/* 210 */             return ((STRUCT)datum).toJdbc(paramMap);
/*     */           }
/* 212 */           return datum.toJdbc();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 221 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 222 */       sQLException.fillInStackTrace();
/* 223 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 230 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/*     */     STRUCT sTRUCT;
/*     */     OPAQUE oPAQUE;
/* 246 */     ARRAY aRRAY = null;
/*     */ 
/*     */     
/* 249 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 251 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 252 */       sQLException1.fillInStackTrace();
/* 253 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 260 */     byte[] arrayOfByte = pickledBytes(paramInt);
/*     */     
/* 262 */     if (arrayOfByte == null || arrayOfByte.length == 0)
/*     */     {
/* 264 */       return null;
/*     */     }
/*     */     
/* 267 */     PhysicalConnection physicalConnection = this.statement.connection;
/* 268 */     OracleTypeADT oracleTypeADT = (OracleTypeADT)this.internalOtype;
/* 269 */     TypeDescriptor typeDescriptor = TypeDescriptor.getTypeDescriptor(oracleTypeADT.getFullName(), (OracleConnection)physicalConnection, arrayOfByte, 0L);
/*     */ 
/*     */     
/* 272 */     switch (typeDescriptor.getTypeCode()) {
/*     */ 
/*     */       
/*     */       case 2003:
/* 276 */         aRRAY = new ARRAY((ArrayDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 312 */         return (Datum)aRRAY;
/*     */       case 2002:
/*     */         return (Datum)new STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */       case 2007:
/*     */         return (Datum)new OPAQUE((OpaqueDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */       case 2008:
/*     */         return (Datum)new JAVA_STRUCT((StructDescriptor)typeDescriptor, arrayOfByte, (Connection)physicalConnection);
/*     */     } 
/*     */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*     */     sQLException.fillInStackTrace();
/*     */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   ARRAY getARRAY(int paramInt) throws SQLException {
/* 328 */     return (ARRAY)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 344 */     return (STRUCT)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 360 */     return (OPAQUE)getOracleObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isNull(int paramInt) throws SQLException {
/* 367 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 371 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 372 */       sQLException.fillInStackTrace();
/* 373 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 378 */     byte[] arrayOfByte = pickledBytes(paramInt);
/* 379 */     return (arrayOfByte == null || arrayOfByte.length == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 389 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\NamedTypeAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */