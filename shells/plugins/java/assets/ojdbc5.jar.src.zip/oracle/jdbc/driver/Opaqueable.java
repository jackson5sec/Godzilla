package oracle.jdbc.driver;

import java.sql.SQLException;
import oracle.sql.OPAQUE;

public interface Opaqueable {
  OPAQUE toOpaque() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\Opaqueable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */