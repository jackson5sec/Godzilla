/*      */ package oracle.jdbc.driver;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ class OracleReturnResultSet extends BaseResultSet {
/*      */   OracleReturnResultSet(OracleStatement paramOracleStatement) throws SQLException {
/*   37 */     this.statement = paramOracleStatement;
/*   38 */     this.closed = false;
/*      */     
/*   40 */     this.returnAccessors = new Accessor[paramOracleStatement.numReturnParams];
/*      */     
/*   42 */     byte b1 = 0;
/*   43 */     for (byte b2 = 0; b2 < paramOracleStatement.numberOfBindPositions; b2++) {
/*      */       
/*   45 */       Accessor accessor = paramOracleStatement.returnParamAccessors[b2];
/*      */       
/*   47 */       if (accessor != null)
/*   48 */         this.returnAccessors[b1++] = accessor; 
/*      */     } 
/*      */   }
/*      */   
/*      */   OracleStatement statement;
/*      */   Accessor[] returnAccessors;
/*      */   
/*      */   public boolean next() throws SQLException {
/*   56 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/*   59 */       if (this.closed) return false;
/*      */       
/*   61 */       if (!this.statement.returnParamsFetched) {
/*      */         
/*   63 */         this.statement.fetchDmlReturnParams();
/*   64 */         this.statement.setupReturnParamAccessors();
/*      */       } 
/*      */       
/*   67 */       this.statement.currentRow++;
/*   68 */       this.statement.totalRowsVisited++;
/*      */       
/*   70 */       if (this.statement.currentRow >= this.statement.rowsDmlReturned) {
/*   71 */         return false;
/*      */       }
/*   73 */       return true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*   81 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/*   84 */       super.close();
/*      */       
/*   86 */       this.statement.returnResultSet = null;
/*   87 */       this.statement.numReturnParams = 0;
/*   88 */       this.statement.totalRowsVisited = 0;
/*   89 */       this.statement.currentRow = -1;
/*   90 */       this.statement.returnParamsFetched = false;
/*   91 */       this.statement.rowsDmlReturned = 0;
/*   92 */       this.statement.returnParamBytes = null;
/*   93 */       this.statement.returnParamChars = null;
/*   94 */       this.statement.returnParamIndicators = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  102 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/*  105 */       if (this.closed) {
/*      */         
/*  107 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  108 */         sQLException.fillInStackTrace();
/*  109 */         throw sQLException;
/*      */       } 
/*      */       
/*  112 */       if (this.statement.currentRow == -1 || this.statement.lastIndex == 0) {
/*      */         
/*  114 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/*  115 */         sQLException.fillInStackTrace();
/*  116 */         throw sQLException;
/*      */       } 
/*      */       
/*  119 */       return this.returnAccessors[this.statement.lastIndex - 1].isNull(this.statement.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  127 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/*  130 */       if (!this.statement.isAutoGeneratedKey) {
/*      */         
/*  132 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/*  133 */         sQLException.fillInStackTrace();
/*  134 */         throw sQLException;
/*      */       } 
/*      */       
/*  137 */       if (this.closed) {
/*      */         
/*  139 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  140 */         sQLException.fillInStackTrace();
/*  141 */         throw sQLException;
/*      */       } 
/*      */       
/*  144 */       if (this.statement.closed) {
/*      */         
/*  146 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  147 */         sQLException.fillInStackTrace();
/*  148 */         throw sQLException;
/*      */       } 
/*      */       
/*  151 */       AutoKeyInfo autoKeyInfo = this.statement.autoKeyInfo;
/*  152 */       autoKeyInfo.statement = this.statement;
/*  153 */       autoKeyInfo.connection = this.statement.connection;
/*  154 */       autoKeyInfo.initMetaData(this);
/*  155 */       return (ResultSetMetaData)autoKeyInfo;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  162 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/*  165 */       return (Statement)this.statement;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  177 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  181 */       if (this.closed) {
/*      */         
/*  183 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  184 */         sQLException.fillInStackTrace();
/*  185 */         throw sQLException;
/*      */       } 
/*      */       
/*  188 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  190 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  191 */         sQLException.fillInStackTrace();
/*  192 */         throw sQLException;
/*      */       } 
/*      */       
/*  195 */       int i = this.statement.currentRow;
/*  196 */       if (i < 0) {
/*      */         
/*  198 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  199 */         sQLException.fillInStackTrace();
/*  200 */         throw sQLException;
/*      */       } 
/*      */       
/*  203 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  206 */       return this.returnAccessors[paramInt - 1].getString(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  214 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  218 */       if (this.closed) {
/*      */         
/*  220 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  221 */         sQLException.fillInStackTrace();
/*  222 */         throw sQLException;
/*      */       } 
/*      */       
/*  225 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  227 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  228 */         sQLException.fillInStackTrace();
/*  229 */         throw sQLException;
/*      */       } 
/*      */       
/*  232 */       int i = this.statement.currentRow;
/*  233 */       if (i < 0) {
/*      */         
/*  235 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  236 */         sQLException.fillInStackTrace();
/*  237 */         throw sQLException;
/*      */       } 
/*      */       
/*  240 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  243 */       return this.returnAccessors[paramInt - 1].getBoolean(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  250 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  254 */       if (this.closed) {
/*      */         
/*  256 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  257 */         sQLException.fillInStackTrace();
/*  258 */         throw sQLException;
/*      */       } 
/*      */       
/*  261 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  263 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  264 */         sQLException.fillInStackTrace();
/*  265 */         throw sQLException;
/*      */       } 
/*      */       
/*  268 */       int i = this.statement.currentRow;
/*  269 */       if (i < 0) {
/*      */         
/*  271 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  272 */         sQLException.fillInStackTrace();
/*  273 */         throw sQLException;
/*      */       } 
/*      */       
/*  276 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  279 */       return this.returnAccessors[paramInt - 1].getAuthorizationIndicator(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  286 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  290 */       if (this.closed) {
/*      */         
/*  292 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  293 */         sQLException.fillInStackTrace();
/*  294 */         throw sQLException;
/*      */       } 
/*      */       
/*  297 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  299 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  300 */         sQLException.fillInStackTrace();
/*  301 */         throw sQLException;
/*      */       } 
/*      */       
/*  304 */       int i = this.statement.currentRow;
/*  305 */       if (i < 0) {
/*      */         
/*  307 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  308 */         sQLException.fillInStackTrace();
/*  309 */         throw sQLException;
/*      */       } 
/*      */       
/*  312 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  315 */       return this.returnAccessors[paramInt - 1].getByte(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  323 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  327 */       if (this.closed) {
/*      */         
/*  329 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  330 */         sQLException.fillInStackTrace();
/*  331 */         throw sQLException;
/*      */       } 
/*      */       
/*  334 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  336 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  337 */         sQLException.fillInStackTrace();
/*  338 */         throw sQLException;
/*      */       } 
/*      */       
/*  341 */       int i = this.statement.currentRow;
/*  342 */       if (i < 0) {
/*      */         
/*  344 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  345 */         sQLException.fillInStackTrace();
/*  346 */         throw sQLException;
/*      */       } 
/*      */       
/*  349 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  352 */       return this.returnAccessors[paramInt - 1].getShort(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  361 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  365 */       if (this.closed) {
/*      */         
/*  367 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  368 */         sQLException.fillInStackTrace();
/*  369 */         throw sQLException;
/*      */       } 
/*      */       
/*  372 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  374 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  375 */         sQLException.fillInStackTrace();
/*  376 */         throw sQLException;
/*      */       } 
/*      */       
/*  379 */       int i = this.statement.currentRow;
/*  380 */       if (i < 0) {
/*      */         
/*  382 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  383 */         sQLException.fillInStackTrace();
/*  384 */         throw sQLException;
/*      */       } 
/*      */       
/*  387 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  390 */       return this.returnAccessors[paramInt - 1].getInt(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  398 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  402 */       if (this.closed) {
/*      */         
/*  404 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  405 */         sQLException.fillInStackTrace();
/*  406 */         throw sQLException;
/*      */       } 
/*      */       
/*  409 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  411 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  412 */         sQLException.fillInStackTrace();
/*  413 */         throw sQLException;
/*      */       } 
/*      */       
/*  416 */       int i = this.statement.currentRow;
/*  417 */       if (i < 0) {
/*      */         
/*  419 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  420 */         sQLException.fillInStackTrace();
/*  421 */         throw sQLException;
/*      */       } 
/*      */       
/*  424 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  427 */       return this.returnAccessors[paramInt - 1].getLong(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  435 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  439 */       if (this.closed) {
/*      */         
/*  441 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  442 */         sQLException.fillInStackTrace();
/*  443 */         throw sQLException;
/*      */       } 
/*      */       
/*  446 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  448 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  449 */         sQLException.fillInStackTrace();
/*  450 */         throw sQLException;
/*      */       } 
/*      */       
/*  453 */       int i = this.statement.currentRow;
/*  454 */       if (i < 0) {
/*      */         
/*  456 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  457 */         sQLException.fillInStackTrace();
/*  458 */         throw sQLException;
/*      */       } 
/*      */       
/*  461 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  464 */       return this.returnAccessors[paramInt - 1].getFloat(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  472 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  476 */       if (this.closed) {
/*      */         
/*  478 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  479 */         sQLException.fillInStackTrace();
/*  480 */         throw sQLException;
/*      */       } 
/*      */       
/*  483 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  485 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  486 */         sQLException.fillInStackTrace();
/*  487 */         throw sQLException;
/*      */       } 
/*      */       
/*  490 */       int i = this.statement.currentRow;
/*  491 */       if (i < 0) {
/*      */         
/*  493 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  494 */         sQLException.fillInStackTrace();
/*  495 */         throw sQLException;
/*      */       } 
/*      */       
/*  498 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  501 */       return this.returnAccessors[paramInt - 1].getDouble(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  509 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  513 */       if (this.closed) {
/*      */         
/*  515 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  516 */         sQLException.fillInStackTrace();
/*  517 */         throw sQLException;
/*      */       } 
/*      */       
/*  520 */       if (paramInt1 <= 0 || paramInt1 > this.statement.numReturnParams) {
/*      */         
/*  522 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  523 */         sQLException.fillInStackTrace();
/*  524 */         throw sQLException;
/*      */       } 
/*      */       
/*  527 */       int i = this.statement.currentRow;
/*  528 */       if (i < 0) {
/*      */         
/*  530 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  531 */         sQLException.fillInStackTrace();
/*  532 */         throw sQLException;
/*      */       } 
/*      */       
/*  535 */       this.statement.lastIndex = paramInt1;
/*      */ 
/*      */       
/*  538 */       return this.returnAccessors[paramInt1 - 1].getBigDecimal(i, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  546 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  550 */       if (this.closed) {
/*      */         
/*  552 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  553 */         sQLException.fillInStackTrace();
/*  554 */         throw sQLException;
/*      */       } 
/*      */       
/*  557 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  559 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  560 */         sQLException.fillInStackTrace();
/*  561 */         throw sQLException;
/*      */       } 
/*      */       
/*  564 */       int i = this.statement.currentRow;
/*  565 */       if (i < 0) {
/*      */         
/*  567 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  568 */         sQLException.fillInStackTrace();
/*  569 */         throw sQLException;
/*      */       } 
/*      */       
/*  572 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  575 */       return this.returnAccessors[paramInt - 1].getBytes(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  583 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  587 */       if (this.closed) {
/*      */         
/*  589 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  590 */         sQLException.fillInStackTrace();
/*  591 */         throw sQLException;
/*      */       } 
/*      */       
/*  594 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  596 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  597 */         sQLException.fillInStackTrace();
/*  598 */         throw sQLException;
/*      */       } 
/*      */       
/*  601 */       int i = this.statement.currentRow;
/*  602 */       if (i < 0) {
/*      */         
/*  604 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  605 */         sQLException.fillInStackTrace();
/*  606 */         throw sQLException;
/*      */       } 
/*      */       
/*  609 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  612 */       return this.returnAccessors[paramInt - 1].getDate(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  620 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  624 */       if (this.closed) {
/*      */         
/*  626 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  627 */         sQLException.fillInStackTrace();
/*  628 */         throw sQLException;
/*      */       } 
/*      */       
/*  631 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  633 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  634 */         sQLException.fillInStackTrace();
/*  635 */         throw sQLException;
/*      */       } 
/*      */       
/*  638 */       int i = this.statement.currentRow;
/*  639 */       if (i < 0) {
/*      */         
/*  641 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  642 */         sQLException.fillInStackTrace();
/*  643 */         throw sQLException;
/*      */       } 
/*      */       
/*  646 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  649 */       return this.returnAccessors[paramInt - 1].getTime(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  657 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  661 */       if (this.closed) {
/*      */         
/*  663 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  664 */         sQLException.fillInStackTrace();
/*  665 */         throw sQLException;
/*      */       } 
/*      */       
/*  668 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  670 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  671 */         sQLException.fillInStackTrace();
/*  672 */         throw sQLException;
/*      */       } 
/*      */       
/*  675 */       int i = this.statement.currentRow;
/*  676 */       if (i < 0) {
/*      */         
/*  678 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  679 */         sQLException.fillInStackTrace();
/*  680 */         throw sQLException;
/*      */       } 
/*      */       
/*  683 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  686 */       return this.returnAccessors[paramInt - 1].getTimestamp(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/*  694 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  698 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/*  699 */       sQLException.fillInStackTrace();
/*  700 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/*  710 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  714 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/*  715 */       sQLException.fillInStackTrace();
/*  716 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/*  726 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  730 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/*  731 */       sQLException.fillInStackTrace();
/*  732 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  742 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  746 */       if (this.closed) {
/*      */         
/*  748 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  749 */         sQLException.fillInStackTrace();
/*  750 */         throw sQLException;
/*      */       } 
/*      */       
/*  753 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  755 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  756 */         sQLException.fillInStackTrace();
/*  757 */         throw sQLException;
/*      */       } 
/*      */       
/*  760 */       int i = this.statement.currentRow;
/*  761 */       if (i < 0) {
/*      */         
/*  763 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  764 */         sQLException.fillInStackTrace();
/*  765 */         throw sQLException;
/*      */       } 
/*      */       
/*  768 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  771 */       return this.returnAccessors[paramInt - 1].getObject(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/*  780 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  784 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/*  785 */       sQLException.fillInStackTrace();
/*  786 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  797 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  801 */       if (this.closed) {
/*      */         
/*  803 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  804 */         sQLException.fillInStackTrace();
/*  805 */         throw sQLException;
/*      */       } 
/*      */       
/*  808 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  810 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  811 */         sQLException.fillInStackTrace();
/*  812 */         throw sQLException;
/*      */       } 
/*      */       
/*  815 */       int i = this.statement.currentRow;
/*  816 */       if (i < 0) {
/*      */         
/*  818 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  819 */         sQLException.fillInStackTrace();
/*  820 */         throw sQLException;
/*      */       } 
/*      */       
/*  823 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  826 */       return this.returnAccessors[paramInt - 1].getOracleObject(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  835 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  839 */       if (this.closed) {
/*      */         
/*  841 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  842 */         sQLException.fillInStackTrace();
/*  843 */         throw sQLException;
/*      */       } 
/*      */       
/*  846 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  848 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  849 */         sQLException.fillInStackTrace();
/*  850 */         throw sQLException;
/*      */       } 
/*      */       
/*  853 */       int i = this.statement.currentRow;
/*  854 */       if (i < 0) {
/*      */         
/*  856 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  857 */         sQLException.fillInStackTrace();
/*  858 */         throw sQLException;
/*      */       } 
/*      */       
/*  861 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  864 */       return this.returnAccessors[paramInt - 1].getROWID(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  873 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  877 */       if (this.closed) {
/*      */         
/*  879 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  880 */         sQLException.fillInStackTrace();
/*  881 */         throw sQLException;
/*      */       } 
/*      */       
/*  884 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  886 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  887 */         sQLException.fillInStackTrace();
/*  888 */         throw sQLException;
/*      */       } 
/*      */       
/*  891 */       int i = this.statement.currentRow;
/*  892 */       if (i < 0) {
/*      */         
/*  894 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  895 */         sQLException.fillInStackTrace();
/*  896 */         throw sQLException;
/*      */       } 
/*      */       
/*  899 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  902 */       return this.returnAccessors[paramInt - 1].getNUMBER(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  911 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  915 */       if (this.closed) {
/*      */         
/*  917 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  918 */         sQLException.fillInStackTrace();
/*  919 */         throw sQLException;
/*      */       } 
/*      */       
/*  922 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  924 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  925 */         sQLException.fillInStackTrace();
/*  926 */         throw sQLException;
/*      */       } 
/*      */       
/*  929 */       int i = this.statement.currentRow;
/*  930 */       if (i < 0) {
/*      */         
/*  932 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  933 */         sQLException.fillInStackTrace();
/*  934 */         throw sQLException;
/*      */       } 
/*      */       
/*  937 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  940 */       return this.returnAccessors[paramInt - 1].getDATE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  949 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  953 */       if (this.closed) {
/*      */         
/*  955 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  956 */         sQLException.fillInStackTrace();
/*  957 */         throw sQLException;
/*      */       } 
/*      */       
/*  960 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/*  962 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  963 */         sQLException.fillInStackTrace();
/*  964 */         throw sQLException;
/*      */       } 
/*      */       
/*  967 */       int i = this.statement.currentRow;
/*  968 */       if (i < 0) {
/*      */         
/*  970 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  971 */         sQLException.fillInStackTrace();
/*  972 */         throw sQLException;
/*      */       } 
/*      */       
/*  975 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/*  978 */       return this.returnAccessors[paramInt - 1].getARRAY(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  987 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/*  991 */       if (this.closed) {
/*      */         
/*  993 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  994 */         sQLException.fillInStackTrace();
/*  995 */         throw sQLException;
/*      */       } 
/*      */       
/*  998 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1000 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1001 */         sQLException.fillInStackTrace();
/* 1002 */         throw sQLException;
/*      */       } 
/*      */       
/* 1005 */       int i = this.statement.currentRow;
/* 1006 */       if (i < 0) {
/*      */         
/* 1008 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1009 */         sQLException.fillInStackTrace();
/* 1010 */         throw sQLException;
/*      */       } 
/*      */       
/* 1013 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1016 */       return this.returnAccessors[paramInt - 1].getSTRUCT(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1025 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1029 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException("getOPAQUE");
/* 1030 */       sQLException.fillInStackTrace();
/* 1031 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 1042 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1046 */       if (this.closed) {
/*      */         
/* 1048 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1049 */         sQLException.fillInStackTrace();
/* 1050 */         throw sQLException;
/*      */       } 
/*      */       
/* 1053 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1055 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1056 */         sQLException.fillInStackTrace();
/* 1057 */         throw sQLException;
/*      */       } 
/*      */       
/* 1060 */       int i = this.statement.currentRow;
/* 1061 */       if (i < 0) {
/*      */         
/* 1063 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1064 */         sQLException.fillInStackTrace();
/* 1065 */         throw sQLException;
/*      */       } 
/*      */       
/* 1068 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1071 */       return this.returnAccessors[paramInt - 1].getREF(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1080 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1084 */       if (this.closed) {
/*      */         
/* 1086 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1087 */         sQLException.fillInStackTrace();
/* 1088 */         throw sQLException;
/*      */       } 
/*      */       
/* 1091 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1093 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1094 */         sQLException.fillInStackTrace();
/* 1095 */         throw sQLException;
/*      */       } 
/*      */       
/* 1098 */       int i = this.statement.currentRow;
/* 1099 */       if (i < 0) {
/*      */         
/* 1101 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1102 */         sQLException.fillInStackTrace();
/* 1103 */         throw sQLException;
/*      */       } 
/*      */       
/* 1106 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1109 */       return this.returnAccessors[paramInt - 1].getCHAR(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1118 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1122 */       if (this.closed) {
/*      */         
/* 1124 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1125 */         sQLException.fillInStackTrace();
/* 1126 */         throw sQLException;
/*      */       } 
/*      */       
/* 1129 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1131 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1132 */         sQLException.fillInStackTrace();
/* 1133 */         throw sQLException;
/*      */       } 
/*      */       
/* 1136 */       int i = this.statement.currentRow;
/* 1137 */       if (i < 0) {
/*      */         
/* 1139 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1140 */         sQLException.fillInStackTrace();
/* 1141 */         throw sQLException;
/*      */       } 
/*      */       
/* 1144 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1147 */       return this.returnAccessors[paramInt - 1].getRAW(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1156 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1160 */       if (this.closed) {
/*      */         
/* 1162 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1163 */         sQLException.fillInStackTrace();
/* 1164 */         throw sQLException;
/*      */       } 
/*      */       
/* 1167 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1169 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1170 */         sQLException.fillInStackTrace();
/* 1171 */         throw sQLException;
/*      */       } 
/*      */       
/* 1174 */       int i = this.statement.currentRow;
/* 1175 */       if (i < 0) {
/*      */         
/* 1177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1178 */         sQLException.fillInStackTrace();
/* 1179 */         throw sQLException;
/*      */       } 
/*      */       
/* 1182 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1185 */       return this.returnAccessors[paramInt - 1].getBLOB(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1194 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1198 */       if (this.closed) {
/*      */         
/* 1200 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1201 */         sQLException.fillInStackTrace();
/* 1202 */         throw sQLException;
/*      */       } 
/*      */       
/* 1205 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1207 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1208 */         sQLException.fillInStackTrace();
/* 1209 */         throw sQLException;
/*      */       } 
/*      */       
/* 1212 */       int i = this.statement.currentRow;
/* 1213 */       if (i < 0) {
/*      */         
/* 1215 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1216 */         sQLException.fillInStackTrace();
/* 1217 */         throw sQLException;
/*      */       } 
/*      */       
/* 1220 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1223 */       return this.returnAccessors[paramInt - 1].getCLOB(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1231 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1235 */       if (this.closed) {
/*      */         
/* 1237 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1238 */         sQLException.fillInStackTrace();
/* 1239 */         throw sQLException;
/*      */       } 
/*      */       
/* 1242 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1244 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1245 */         sQLException.fillInStackTrace();
/* 1246 */         throw sQLException;
/*      */       } 
/*      */       
/* 1249 */       int i = this.statement.currentRow;
/* 1250 */       if (i < 0) {
/*      */         
/* 1252 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1253 */         sQLException.fillInStackTrace();
/* 1254 */         throw sQLException;
/*      */       } 
/*      */       
/* 1257 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1260 */       return this.returnAccessors[paramInt - 1].getBFILE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1268 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/* 1271 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1280 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1284 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1285 */       sQLException.fillInStackTrace();
/* 1286 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1297 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1301 */       if (this.closed) {
/*      */         
/* 1303 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1304 */         sQLException.fillInStackTrace();
/* 1305 */         throw sQLException;
/*      */       } 
/*      */       
/* 1308 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1310 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1311 */         sQLException.fillInStackTrace();
/* 1312 */         throw sQLException;
/*      */       } 
/*      */       
/* 1315 */       int i = this.statement.currentRow;
/* 1316 */       if (i < 0) {
/*      */         
/* 1318 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1319 */         sQLException.fillInStackTrace();
/* 1320 */         throw sQLException;
/*      */       } 
/*      */       
/* 1323 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1326 */       return this.returnAccessors[paramInt - 1].getORAData(i, paramORADataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1335 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1339 */       if (this.closed) {
/*      */         
/* 1341 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1342 */         sQLException.fillInStackTrace();
/* 1343 */         throw sQLException;
/*      */       } 
/*      */       
/* 1346 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1348 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1349 */         sQLException.fillInStackTrace();
/* 1350 */         throw sQLException;
/*      */       } 
/*      */       
/* 1353 */       int i = this.statement.currentRow;
/* 1354 */       if (i < 0) {
/*      */         
/* 1356 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1357 */         sQLException.fillInStackTrace();
/* 1358 */         throw sQLException;
/*      */       } 
/*      */       
/* 1361 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1364 */       return this.returnAccessors[paramInt - 1].getObject(i, paramOracleDataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1373 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1377 */       if (this.closed) {
/*      */         
/* 1379 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1380 */         sQLException.fillInStackTrace();
/* 1381 */         throw sQLException;
/*      */       } 
/*      */       
/* 1384 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1386 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1387 */         sQLException.fillInStackTrace();
/* 1388 */         throw sQLException;
/*      */       } 
/*      */       
/* 1391 */       int i = this.statement.currentRow;
/* 1392 */       if (i < 0) {
/*      */         
/* 1394 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1395 */         sQLException.fillInStackTrace();
/* 1396 */         throw sQLException;
/*      */       } 
/*      */       
/* 1399 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1402 */       return this.returnAccessors[paramInt - 1].getObject(i, paramMap);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1411 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/* 1414 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1423 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/* 1426 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1435 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/* 1438 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1447 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1451 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1452 */       sQLException.fillInStackTrace();
/* 1453 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1464 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1469 */       sQLException.fillInStackTrace();
/* 1470 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1483 */     if (this.closed) {
/*      */       
/* 1485 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1486 */       sQLException.fillInStackTrace();
/* 1487 */       throw sQLException;
/*      */     } 
/*      */     
/* 1490 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1492 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1493 */       sQLException.fillInStackTrace();
/* 1494 */       throw sQLException;
/*      */     } 
/*      */     
/* 1497 */     int i = this.statement.currentRow;
/* 1498 */     if (i < 0) {
/*      */       
/* 1500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1501 */       sQLException.fillInStackTrace();
/* 1502 */       throw sQLException;
/*      */     } 
/*      */     
/* 1505 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1508 */     return this.returnAccessors[paramInt - 1].getBigDecimal(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1519 */     if (this.closed) {
/*      */       
/* 1521 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1522 */       sQLException.fillInStackTrace();
/* 1523 */       throw sQLException;
/*      */     } 
/*      */     
/* 1526 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1528 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1529 */       sQLException.fillInStackTrace();
/* 1530 */       throw sQLException;
/*      */     } 
/*      */     
/* 1533 */     int i = this.statement.currentRow;
/* 1534 */     if (i < 0) {
/*      */       
/* 1536 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1537 */       sQLException.fillInStackTrace();
/* 1538 */       throw sQLException;
/*      */     } 
/*      */     
/* 1541 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1544 */     return this.returnAccessors[paramInt - 1].getDate(i, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1555 */     if (this.closed) {
/*      */       
/* 1557 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1558 */       sQLException.fillInStackTrace();
/* 1559 */       throw sQLException;
/*      */     } 
/*      */     
/* 1562 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1564 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1565 */       sQLException.fillInStackTrace();
/* 1566 */       throw sQLException;
/*      */     } 
/*      */     
/* 1569 */     int i = this.statement.currentRow;
/* 1570 */     if (i < 0) {
/*      */       
/* 1572 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1573 */       sQLException.fillInStackTrace();
/* 1574 */       throw sQLException;
/*      */     } 
/*      */     
/* 1577 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1580 */     return this.returnAccessors[paramInt - 1].getTime(i, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1591 */     if (this.closed) {
/*      */       
/* 1593 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1594 */       sQLException.fillInStackTrace();
/* 1595 */       throw sQLException;
/*      */     } 
/*      */     
/* 1598 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1600 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1601 */       sQLException.fillInStackTrace();
/* 1602 */       throw sQLException;
/*      */     } 
/*      */     
/* 1605 */     int i = this.statement.currentRow;
/* 1606 */     if (i < 0) {
/*      */       
/* 1608 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1609 */       sQLException.fillInStackTrace();
/* 1610 */       throw sQLException;
/*      */     } 
/*      */     
/* 1613 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1616 */     return this.returnAccessors[paramInt - 1].getTimestamp(i, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1627 */     if (this.closed) {
/*      */       
/* 1629 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1630 */       sQLException.fillInStackTrace();
/* 1631 */       throw sQLException;
/*      */     } 
/*      */     
/* 1634 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1636 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1637 */       sQLException.fillInStackTrace();
/* 1638 */       throw sQLException;
/*      */     } 
/*      */     
/* 1641 */     int i = this.statement.currentRow;
/* 1642 */     if (i < 0) {
/*      */       
/* 1644 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1645 */       sQLException.fillInStackTrace();
/* 1646 */       throw sQLException;
/*      */     } 
/*      */     
/* 1649 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1652 */     return this.returnAccessors[paramInt - 1].getINTERVALYM(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1662 */     if (this.closed) {
/*      */       
/* 1664 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1665 */       sQLException.fillInStackTrace();
/* 1666 */       throw sQLException;
/*      */     } 
/*      */     
/* 1669 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1671 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1672 */       sQLException.fillInStackTrace();
/* 1673 */       throw sQLException;
/*      */     } 
/*      */     
/* 1676 */     int i = this.statement.currentRow;
/* 1677 */     if (i < 0) {
/*      */       
/* 1679 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1680 */       sQLException.fillInStackTrace();
/* 1681 */       throw sQLException;
/*      */     } 
/*      */     
/* 1684 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1687 */     return this.returnAccessors[paramInt - 1].getINTERVALDS(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1698 */     if (this.closed) {
/*      */       
/* 1700 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1701 */       sQLException.fillInStackTrace();
/* 1702 */       throw sQLException;
/*      */     } 
/*      */     
/* 1705 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1707 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1708 */       sQLException.fillInStackTrace();
/* 1709 */       throw sQLException;
/*      */     } 
/*      */     
/* 1712 */     int i = this.statement.currentRow;
/* 1713 */     if (i < 0) {
/*      */       
/* 1715 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1716 */       sQLException.fillInStackTrace();
/* 1717 */       throw sQLException;
/*      */     } 
/*      */     
/* 1720 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1723 */     return this.returnAccessors[paramInt - 1].getTIMESTAMP(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1733 */     if (this.closed) {
/*      */       
/* 1735 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1736 */       sQLException.fillInStackTrace();
/* 1737 */       throw sQLException;
/*      */     } 
/*      */     
/* 1740 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1742 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1743 */       sQLException.fillInStackTrace();
/* 1744 */       throw sQLException;
/*      */     } 
/*      */     
/* 1747 */     int i = this.statement.currentRow;
/* 1748 */     if (i < 0) {
/*      */       
/* 1750 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1751 */       sQLException.fillInStackTrace();
/* 1752 */       throw sQLException;
/*      */     } 
/*      */     
/* 1755 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1758 */     return this.returnAccessors[paramInt - 1].getTIMESTAMPTZ(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1768 */     if (this.closed) {
/*      */       
/* 1770 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1771 */       sQLException.fillInStackTrace();
/* 1772 */       throw sQLException;
/*      */     } 
/*      */     
/* 1775 */     if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */       
/* 1777 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1778 */       sQLException.fillInStackTrace();
/* 1779 */       throw sQLException;
/*      */     } 
/*      */     
/* 1782 */     int i = this.statement.currentRow;
/* 1783 */     if (i < 0) {
/*      */       
/* 1785 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1786 */       sQLException.fillInStackTrace();
/* 1787 */       throw sQLException;
/*      */     } 
/*      */     
/* 1790 */     this.statement.lastIndex = paramInt;
/*      */ 
/*      */     
/* 1793 */     return this.returnAccessors[paramInt - 1].getTIMESTAMPLTZ(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1801 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1805 */       if (this.closed) {
/*      */         
/* 1807 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1808 */         sQLException.fillInStackTrace();
/* 1809 */         throw sQLException;
/*      */       } 
/*      */       
/* 1812 */       if (paramInt <= 0 || paramInt > this.statement.numReturnParams) {
/*      */         
/* 1814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1815 */         sQLException.fillInStackTrace();
/* 1816 */         throw sQLException;
/*      */       } 
/*      */       
/* 1819 */       int i = this.statement.currentRow;
/* 1820 */       if (i < 0) {
/*      */         
/* 1822 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1823 */         sQLException.fillInStackTrace();
/* 1824 */         throw sQLException;
/*      */       } 
/*      */       
/* 1827 */       this.statement.lastIndex = paramInt;
/*      */ 
/*      */       
/* 1830 */       return this.returnAccessors[paramInt - 1].getURL(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 1838 */     if (this.closed) {
/*      */       
/* 1840 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1841 */       sQLException.fillInStackTrace();
/* 1842 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1846 */     return (!isEmptyResultSet() && this.statement.currentRow == -1 && !this.closed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 1853 */     if (this.closed) {
/*      */       
/* 1855 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1856 */       sQLException.fillInStackTrace();
/* 1857 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1861 */     return (!isEmptyResultSet() && this.closed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 1869 */     return (getRow() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 1876 */     if (this.closed) {
/*      */       
/* 1878 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1879 */       sQLException.fillInStackTrace();
/* 1880 */       throw sQLException;
/*      */     } 
/*      */     
/* 1883 */     return (getRow() == this.statement.rowsDmlReturned);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 1890 */     if (this.closed) {
/*      */       
/* 1892 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1893 */       sQLException.fillInStackTrace();
/* 1894 */       throw sQLException;
/*      */     } 
/*      */     
/* 1897 */     return this.statement.totalRowsVisited;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 1904 */     synchronized (this.statement.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1908 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1909 */       sQLException.fillInStackTrace();
/* 1910 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 1922 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1923 */     sQLException.fillInStackTrace();
/* 1924 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 1935 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1936 */     sQLException.fillInStackTrace();
/* 1937 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isEmptyResultSet() {
/* 1946 */     return (this.statement.rowsDmlReturned == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 1956 */     synchronized (this.statement.connection) {
/*      */ 
/*      */       
/* 1959 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 1960 */       sQLException.fillInStackTrace();
/* 1961 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1978 */     return this.statement.getConnectionDuringExceptionHandling();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1985 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\OracleReturnResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */