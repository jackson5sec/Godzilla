/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.channels.SelectionKey;
/*     */ import java.nio.channels.Selector;
/*     */ import java.nio.channels.SocketChannel;
/*     */ import java.util.Iterator;
/*     */ import oracle.jdbc.aq.AQNotificationEvent;
/*     */ import oracle.jdbc.dcn.DatabaseChangeEvent;
/*     */ import oracle.sql.CharacterSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NTFConnection
/*     */   extends Thread
/*     */ {
/*     */   private static final int NS_HEADER_SIZE = 10;
/*     */   private SocketChannel channel;
/*  76 */   private ByteBuffer inBuffer = null;
/*  77 */   private ByteBuffer outBuffer = null;
/*     */ 
/*     */   
/*     */   private int currentNSPacketLength;
/*     */ 
/*     */   
/*     */   private int currentNSPacketType;
/*     */ 
/*     */   
/*     */   private ByteBuffer currentNSPacketDataBuffer;
/*     */   
/*     */   private boolean needsToBeClosed = false;
/*     */   
/*     */   private NTFManager ntfManager;
/*     */   
/*  92 */   private Selector selector = null;
/*  93 */   private Iterator iterator = null;
/*  94 */   private SelectionKey aKey = null;
/*     */   
/*     */   int remotePort;
/*     */   
/*     */   String remoteAddress;
/*     */   
/*     */   String remoteName;
/*     */   int localPort;
/*     */   String localAddress;
/*     */   String localName;
/*     */   String connectionDescription;
/* 105 */   CharacterSet charset = null;
/*     */   
/*     */   static final int NSPTCN = 1;
/*     */   
/*     */   static final int NSPTAC = 2;
/*     */   
/*     */   static final int NSPTAK = 3;
/*     */   
/*     */   static final int NSPTRF = 4;
/*     */   
/*     */   static final int NSPTRD = 5;
/*     */   
/*     */   static final int NSPTDA = 6;
/*     */   static final int NSPTNL = 7;
/*     */   static final int NSPTAB = 9;
/*     */   static final int NSPTRS = 11;
/*     */   static final int NSPTMK = 12;
/*     */   static final int NSPTAT = 13;
/*     */   static final int NSPTCNL = 14;
/*     */   static final int NSPTHI = 19;
/*     */   static final short KPDNFY_TIMEOUT = 1;
/*     */   static final short KPDNFY_GROUPING = 2;
/*     */   
/*     */   NTFConnection(NTFManager paramNTFManager, SocketChannel paramSocketChannel) {
/*     */     try {
/* 130 */       this.ntfManager = paramNTFManager;
/* 131 */       this.channel = paramSocketChannel;
/* 132 */       this.channel.configureBlocking(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 148 */       this.inBuffer = ByteBuffer.allocate(4096);
/* 149 */       this.outBuffer = ByteBuffer.allocate(2048);
/* 150 */       Socket socket = this.channel.socket();
/* 151 */       InetAddress inetAddress1 = socket.getInetAddress();
/* 152 */       InetAddress inetAddress2 = socket.getLocalAddress();
/* 153 */       this.remotePort = socket.getPort();
/* 154 */       this.localPort = socket.getLocalPort();
/* 155 */       this.remoteAddress = inetAddress1.getHostAddress();
/* 156 */       this.remoteName = inetAddress1.getHostName();
/* 157 */       this.localAddress = inetAddress2.getHostAddress();
/* 158 */       this.localName = inetAddress2.getHostName();
/* 159 */       this.connectionDescription = "local=" + this.localName + "/" + this.localAddress + ":" + this.localPort + ", remote=" + this.remoteName + "/" + this.remoteAddress + ":" + this.remotePort;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 164 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     
/* 175 */     try { this.selector = Selector.open();
/* 176 */       this.channel.register(this.selector, 1);
/*     */       
/* 178 */       int i = 0;
/*     */ 
/*     */       
/* 181 */       this.inBuffer.limit(0);
/*     */       
/* 183 */       while (!this.needsToBeClosed) {
/*     */ 
/*     */         
/* 186 */         if (!this.inBuffer.hasRemaining()) {
/*     */           do {
/* 188 */             i = readFromNetwork();
/*     */           }
/* 190 */           while (i == 0);
/*     */         }
/* 192 */         unmarshalOneNSPacket();
/*     */       }  }
/* 194 */     catch (IOException iOException)
/*     */     
/*     */     { 
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 202 */         this.selector.close();
/* 203 */         this.channel.close();
/* 204 */       } catch (IOException iOException1) {} } catch (InterruptedException interruptedException) { try { this.selector.close(); this.channel.close(); } catch (IOException iOException) {} } finally { try { this.selector.close(); this.channel.close(); } catch (IOException iOException) {} }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readFromNetwork() throws IOException, InterruptedException {
/* 234 */     this.inBuffer.compact();
/*     */     
/*     */     while (true) {
/* 237 */       if (this.iterator == null || !this.iterator.hasNext()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 244 */         this.selector.select();
/*     */ 
/*     */ 
/*     */         
/* 248 */         if (this.needsToBeClosed)
/*     */         {
/* 250 */           throw new InterruptedException();
/*     */         }
/* 252 */         this.iterator = this.selector.selectedKeys().iterator(); continue;
/*     */       } 
/* 254 */       this.aKey = this.iterator.next();
/*     */       
/* 256 */       if ((this.aKey.readyOps() & 0x1) == 1) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     int i = this.channel.read(this.inBuffer);
/*     */     
/* 269 */     if (i < 0)
/*     */     {
/* 271 */       throw new EOFException(); } 
/* 272 */     if (i > 0)
/*     */     {
/*     */       
/* 275 */       this.inBuffer.flip();
/*     */     }
/*     */ 
/*     */     
/* 279 */     this.iterator.remove();
/*     */     
/* 281 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getNextNSPacket() throws IOException, InterruptedException {
/* 298 */     while (!this.inBuffer.hasRemaining() || this.inBuffer.remaining() < 10) {
/* 299 */       int k = readFromNetwork();
/*     */     }
/*     */     
/* 302 */     this.currentNSPacketLength = this.inBuffer.getShort();
/*     */ 
/*     */     
/* 305 */     if (this.currentNSPacketLength <= 0) {
/* 306 */       throw new IOException("Invalid NS packet length.");
/*     */     }
/*     */ 
/*     */     
/* 310 */     this.inBuffer.position(this.inBuffer.position() + 2);
/*     */     
/* 312 */     this.currentNSPacketType = this.inBuffer.get();
/*     */ 
/*     */     
/* 315 */     validatePacketType();
/*     */     
/* 317 */     this.inBuffer.position(this.inBuffer.position() + 5);
/*     */ 
/*     */ 
/*     */     
/* 321 */     while (this.inBuffer.remaining() < this.currentNSPacketLength - 10)
/*     */     {
/* 323 */       int k = readFromNetwork();
/*     */     }
/*     */ 
/*     */     
/* 327 */     int i = this.inBuffer.limit();
/* 328 */     int j = this.inBuffer.position() + this.currentNSPacketLength - 10;
/*     */ 
/*     */ 
/*     */     
/* 332 */     this.inBuffer.limit(j);
/* 333 */     this.currentNSPacketDataBuffer = this.inBuffer.slice();
/* 334 */     this.inBuffer.limit(i);
/*     */     
/* 336 */     this.inBuffer.position(j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unmarshalOneNSPacket() throws IOException, InterruptedException {
/* 355 */     getNextNSPacket();
/*     */ 
/*     */ 
/*     */     
/* 359 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/*     */       byte[] arrayOfByte;
/* 361 */       switch (this.currentNSPacketType) {
/*     */ 
/*     */         
/*     */         case 1:
/* 365 */           arrayOfByte = new byte[] { 0, 24, 0, 0, 2, 0, 0, 0, 1, 52, 0, 0, 8, 0, Byte.MAX_VALUE, -1, 1, 0, 0, 0, 0, 24, 65, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 373 */           this.outBuffer.clear();
/* 374 */           this.outBuffer.put(arrayOfByte);
/* 375 */           this.outBuffer.limit(24);
/* 376 */           this.outBuffer.rewind();
/* 377 */           this.channel.write(this.outBuffer);
/*     */           break;
/*     */         
/*     */         case 6:
/* 381 */           if (this.currentNSPacketDataBuffer.get(0) == -34 && this.currentNSPacketDataBuffer.get(1) == -83) {
/*     */ 
/*     */             
/* 384 */             byte[] arrayOfByte1 = { 0, Byte.MAX_VALUE, 0, 0, 6, 0, 0, 0, 0, 0, -34, -83, -66, -17, 0, 117, 10, 32, 1, 0, 0, 4, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, 0, 31, 0, 14, 0, 1, -34, -83, -66, -17, 0, 3, 0, 0, 0, 2, 0, 4, 0, 1, 0, 1, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 2, 0, 6, -5, -1, 0, 2, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0, 0, 3, 0, 2, 0, 0, 0, 0, 0, 4, 0, 5, 10, 32, 1, 0, 0, 1, 0, 2, 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 418 */             this.outBuffer.clear();
/* 419 */             this.outBuffer.put(arrayOfByte1);
/* 420 */             this.outBuffer.limit(arrayOfByte1.length);
/* 421 */             this.outBuffer.rewind();
/* 422 */             this.channel.write(this.outBuffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             break;
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 467 */           unmarshalNSDataPacket();
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void unmarshalNSDataPacket() throws IOException, InterruptedException {
/* 547 */     short s1 = readShort();
/*     */ 
/*     */     
/* 550 */     int i = readInt();
/*     */     
/* 552 */     byte b1 = readByte();
/* 553 */     int j = readInt();
/* 554 */     short s2 = readShort();
/* 555 */     if (this.charset == null || this.charset.getOracleId() != s2) {
/* 556 */       this.charset = CharacterSet.make(s2);
/*     */     }
/*     */ 
/*     */     
/* 560 */     byte b2 = readByte();
/* 561 */     int k = readInt();
/* 562 */     short s3 = readShort();
/*     */ 
/*     */     
/* 565 */     byte b3 = readByte();
/* 566 */     int m = readInt();
/* 567 */     short s4 = readShort();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 573 */     int n = (i - 21) / 9;
/* 574 */     int[] arrayOfInt = new int[n];
/*     */     
/* 576 */     for (byte b = 0; b < n; b++) {
/* 577 */       byte b4 = readByte();
/* 578 */       int i2 = readInt();
/* 579 */       byte[] arrayOfByte = new byte[i2];
/* 580 */       readBuffer(arrayOfByte, 0, i2);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 585 */       for (byte b5 = 0; b5 < i2; b5++) {
/* 586 */         if (b5 < 4) {
/* 587 */           arrayOfInt[b] = arrayOfInt[b] | (arrayOfByte[b5] & 0xFF) << 8 * (i2 - b5 - 1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 593 */     NTFDCNEvent nTFDCNEvent = null;
/* 594 */     NTFAQEvent nTFAQEvent = null;
/* 595 */     int i1 = 0;
/* 596 */     short s5 = 0;
/* 597 */     NTFRegistration[] arrayOfNTFRegistration = null;
/*     */ 
/*     */     
/* 600 */     if (s1 >= 2) {
/*     */       
/* 602 */       short s = readShort();
/* 603 */       arrayOfNTFRegistration = new NTFRegistration[arrayOfInt.length];
/* 604 */       for (byte b4 = 0; b4 < arrayOfInt.length; b4++) {
/* 605 */         arrayOfNTFRegistration[b4] = this.ntfManager.getRegistration(arrayOfInt[b4]);
/* 606 */         if (arrayOfNTFRegistration[b4] != null) {
/* 607 */           i1 = arrayOfNTFRegistration[b4].getNamespace();
/* 608 */           s5 = arrayOfNTFRegistration[b4].getDatabaseVersion();
/*     */         } 
/*     */       } 
/*     */       
/* 612 */       if (i1 == 2) {
/*     */         
/* 614 */         nTFDCNEvent = new NTFDCNEvent(this, s5);
/*     */       }
/* 616 */       else if (i1 == 1) {
/*     */         
/* 618 */         nTFAQEvent = new NTFAQEvent(this, s5);
/*     */       }
/* 620 */       else if (i1 == 0) {
/*     */       
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 631 */     short s6 = 0;
/* 632 */     if (s1 >= 3) {
/*     */       
/* 634 */       short s = readShort();
/* 635 */       int i2 = readInt();
/* 636 */       byte b4 = readByte();
/* 637 */       int i3 = readInt();
/* 638 */       s6 = readShort();
/* 639 */       if (i1 == 2 && nTFDCNEvent != null) {
/*     */         
/* 641 */         nTFDCNEvent.setAdditionalEventType(DatabaseChangeEvent.AdditionalEventType.getEventType(s6));
/*     */ 
/*     */         
/* 644 */         if (s6 == 1) {
/* 645 */           nTFDCNEvent.setEventType(DatabaseChangeEvent.EventType.DEREG);
/*     */         
/*     */         }
/*     */       }
/* 649 */       else if (i1 == 1 && nTFAQEvent != null) {
/*     */         
/* 651 */         nTFAQEvent.setAdditionalEventType(AQNotificationEvent.AdditionalEventType.getEventType(s6));
/*     */ 
/*     */         
/* 654 */         if (s6 == 1) {
/* 655 */           nTFAQEvent.setEventType(AQNotificationEvent.EventType.DEREG);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 661 */     if (s1 > 3);
/*     */ 
/*     */ 
/*     */     
/* 665 */     if (arrayOfNTFRegistration != null) {
/* 666 */       if (i1 == 2) {
/* 667 */         for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
/* 668 */           if (arrayOfNTFRegistration[b4] != null && nTFDCNEvent != null) {
/* 669 */             arrayOfNTFRegistration[b4].notify(nTFDCNEvent);
/*     */           }
/*     */         }
/*     */       
/* 673 */       } else if (i1 == 1) {
/* 674 */         for (byte b4 = 0; b4 < arrayOfNTFRegistration.length; b4++) {
/* 675 */           if (arrayOfNTFRegistration[b4] != null && nTFAQEvent != null) {
/* 676 */             arrayOfNTFRegistration[b4].notify(nTFAQEvent);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeThisConnection() {
/* 695 */     this.needsToBeClosed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte readByte() throws IOException, InterruptedException {
/* 707 */     byte b = 0;
/* 708 */     if (this.currentNSPacketDataBuffer.hasRemaining()) {
/* 709 */       b = this.currentNSPacketDataBuffer.get();
/*     */     } else {
/*     */       
/* 712 */       getNextNSPacket();
/* 713 */       b = this.currentNSPacketDataBuffer.get();
/*     */     } 
/* 715 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   short readShort() throws IOException, InterruptedException {
/* 726 */     short s = 0;
/* 727 */     if (this.currentNSPacketDataBuffer.remaining() >= 2) {
/* 728 */       s = this.currentNSPacketDataBuffer.getShort();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 734 */       int i = readByte() & 0xFF;
/* 735 */       int j = readByte() & 0xFF;
/* 736 */       s = (short)(i << 8 | j);
/*     */     } 
/* 738 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readInt() throws IOException, InterruptedException {
/* 749 */     int i = 0;
/* 750 */     if (this.currentNSPacketDataBuffer.remaining() >= 4) {
/* 751 */       i = this.currentNSPacketDataBuffer.getInt();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 757 */       int j = readByte() & 0xFF;
/* 758 */       int k = readByte() & 0xFF;
/* 759 */       int m = readByte() & 0xFF;
/* 760 */       int n = readByte() & 0xFF;
/* 761 */       i = j << 24 | k << 16 | m << 8 | n;
/*     */     } 
/* 763 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long readLong() throws IOException, InterruptedException {
/* 774 */     long l = 0L;
/* 775 */     if (this.currentNSPacketDataBuffer.remaining() >= 8) {
/* 776 */       l = this.currentNSPacketDataBuffer.getLong();
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 782 */       long l1 = (readByte() & 0xFF);
/* 783 */       long l2 = (readByte() & 0xFF);
/* 784 */       long l3 = (readByte() & 0xFF);
/* 785 */       long l4 = (readByte() & 0xFF);
/* 786 */       long l5 = (readByte() & 0xFF);
/* 787 */       long l6 = (readByte() & 0xFF);
/* 788 */       long l7 = (readByte() & 0xFF);
/* 789 */       long l8 = (readByte() & 0xFF);
/* 790 */       l = l1 << 56L | l2 << 48L | l3 << 40L | l4 << 32L | l5 << 24L | l6 << 16L | l7 << 8L | l8;
/*     */     } 
/*     */     
/* 793 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readBuffer(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, InterruptedException {
/* 807 */     if (this.currentNSPacketDataBuffer.remaining() >= paramInt2) {
/* 808 */       this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     } else {
/*     */       
/* 811 */       boolean bool = false;
/* 812 */       int i = 0;
/* 813 */       int j = 0;
/* 814 */       int k = this.currentNSPacketDataBuffer.remaining();
/*     */       
/* 816 */       this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, k);
/*     */       
/* 818 */       paramInt1 += k;
/* 819 */       i += k;
/*     */       
/* 821 */       while (!bool) {
/*     */         
/* 823 */         getNextNSPacket();
/* 824 */         k = this.currentNSPacketDataBuffer.remaining();
/* 825 */         j = Math.min(k, paramInt2 - i);
/*     */ 
/*     */         
/* 828 */         this.currentNSPacketDataBuffer.get(paramArrayOfbyte, paramInt1, j);
/* 829 */         paramInt1 += j;
/* 830 */         i += j;
/* 831 */         if (i == paramInt2) {
/* 832 */           bool = true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String packetToString(ByteBuffer paramByteBuffer) throws IOException {
/* 846 */     byte b = 0;
/*     */     
/* 848 */     char[] arrayOfChar = new char[8];
/* 849 */     StringBuffer stringBuffer = new StringBuffer();
/* 850 */     int i = paramByteBuffer.position();
/*     */     
/* 852 */     while (paramByteBuffer.hasRemaining()) {
/* 853 */       byte b1 = paramByteBuffer.get();
/* 854 */       String str = Integer.toHexString(b1 & 0xFF);
/* 855 */       str = str.toUpperCase();
/* 856 */       if (str.length() == 1) {
/* 857 */         str = "0" + str;
/*     */       }
/* 859 */       stringBuffer.append(str);
/* 860 */       stringBuffer.append(' ');
/* 861 */       if (b1 > 32 && b1 < Byte.MAX_VALUE) {
/* 862 */         arrayOfChar[b] = (char)b1;
/*     */       } else {
/*     */         
/* 865 */         arrayOfChar[b] = '.';
/*     */       } 
/* 867 */       b++;
/* 868 */       if (b == 8) {
/* 869 */         stringBuffer.append('|');
/* 870 */         stringBuffer.append(arrayOfChar);
/* 871 */         stringBuffer.append('|');
/* 872 */         stringBuffer.append('\n');
/* 873 */         b = 0;
/*     */       } 
/*     */     } 
/* 876 */     if (b != 0) {
/* 877 */       int j = 8 - b; byte b1;
/* 878 */       for (b1 = 0; b1 < j * 3; b1++) {
/* 879 */         stringBuffer.append(' ');
/*     */       }
/* 881 */       stringBuffer.append('|');
/* 882 */       stringBuffer.append(arrayOfChar, 0, b);
/* 883 */       for (b1 = 0; b1 < j; b1++) {
/* 884 */         stringBuffer.append(' ');
/*     */       }
/* 886 */       stringBuffer.append('|');
/* 887 */       stringBuffer.append('\n');
/*     */     } 
/* 889 */     stringBuffer.append("\nEnd of Packet\n\n");
/* 890 */     paramByteBuffer.position(i);
/* 891 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validatePacketType() throws IOException {
/* 899 */     if (this.currentNSPacketType < 1 || this.currentNSPacketType > 19)
/*     */     {
/* 901 */       throw new IOException("Invalid NS packet type.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 907 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\NTFConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */