/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CResultSetAccessor
/*     */   extends ResultSetAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*  24 */   OracleStatement[] newstmt = new OracleStatement[10];
/*  25 */   byte[] empty = new byte[] { 0 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean underlyingLongRaw = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int[] meta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException
/*     */   {
/*  49 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CResultSetAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1) {
/*     */       this.underlyingLongRaw = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 148 */     if (this.isUseLess) {
/*     */       
/* 150 */       this.lastRowProcessed++;
/*     */       
/* 152 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 161 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 163 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 164 */       processIndicator(this.meta[0]);
/*     */       
/* 166 */       this.lastRowProcessed++;
/*     */       
/* 168 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 172 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 173 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */     
/* 175 */     if (this.isNullByDescribe) {
/*     */       
/* 177 */       this.rowSpaceIndicator[i] = -1;
/* 178 */       this.rowSpaceIndicator[j] = 0;
/* 179 */       this.lastRowProcessed++;
/*     */       
/* 181 */       processIndicator(0);
/*     */       
/* 183 */       return false;
/*     */     } 
/*     */     
/* 186 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */     
/* 188 */     if (this.newstmt.length <= this.lastRowProcessed) {
/*     */       
/* 190 */       OracleStatement[] arrayOfOracleStatement = new OracleStatement[this.newstmt.length * 4];
/*     */       
/* 192 */       System.arraycopy(this.newstmt, 0, arrayOfOracleStatement, 0, this.newstmt.length);
/*     */       
/* 194 */       this.newstmt = arrayOfOracleStatement;
/*     */     } 
/*     */     
/* 197 */     this.newstmt[this.lastRowProcessed] = this.statement.connection.RefCursorBytesToStatement(this.empty, this.statement);
/*     */     
/* 199 */     (this.newstmt[this.lastRowProcessed]).needToSendOalToFetch = true;
/*     */     
/* 201 */     T4CTTIdcb t4CTTIdcb = new T4CTTIdcb((T4CConnection)this.statement.connection);
/*     */     
/* 203 */     t4CTTIdcb.init(this.newstmt[this.lastRowProcessed], 0);
/*     */     
/* 205 */     (this.newstmt[this.lastRowProcessed]).accessors = t4CTTIdcb.receiveFromRefCursor((this.newstmt[this.lastRowProcessed]).accessors);
/*     */     
/* 207 */     (this.newstmt[this.lastRowProcessed]).numberOfDefinePositions = (this.newstmt[this.lastRowProcessed]).accessors.length;
/*     */     
/* 209 */     (this.newstmt[this.lastRowProcessed]).describedWithNames = true;
/* 210 */     (this.newstmt[this.lastRowProcessed]).described = true;
/*     */     
/* 212 */     int m = (int)this.mare.unmarshalUB4();
/*     */     
/* 214 */     this.newstmt[this.lastRowProcessed].setCursorId(m);
/*     */     
/* 216 */     if (m > 0) {
/*     */       
/* 218 */       this.rowSpaceByte[k] = 1;
/* 219 */       this.rowSpaceByte[k + 1] = (byte)m;
/*     */ 
/*     */ 
/*     */       
/* 223 */       this.meta[0] = 2;
/*     */     }
/*     */     else {
/*     */       
/* 227 */       this.newstmt[this.lastRowProcessed].close();
/*     */       
/* 229 */       this.newstmt[this.lastRowProcessed] = null;
/* 230 */       this.meta[0] = 0;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 235 */     processIndicator(this.meta[0]);
/*     */     
/* 237 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 241 */       this.rowSpaceIndicator[i] = -1;
/* 242 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 246 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/* 247 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 250 */     this.lastRowProcessed++;
/*     */     
/* 252 */     return false; }
/*     */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2(); if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  }
/*     */   String getString(int paramInt) throws SQLException { String str = super.getString(paramInt); if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/* 262 */       str = str.substring(0, this.definedColumnSize);  return str; } void copyRow() throws SQLException, IOException { int i; if (this.lastRowProcessed == 0) {
/* 263 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 265 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 268 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 269 */     int k = this.columnIndex + i * this.byteLength;
/* 270 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 271 */     int n = this.indicatorIndex + i;
/* 272 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 273 */     int i2 = this.lengthIndex + i;
/* 274 */     short s = this.rowSpaceIndicator[i2];
/* 275 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 277 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 281 */     this.rowSpaceIndicator[i1] = (short)s;
/* 282 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */ 
/*     */     
/* 286 */     System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */ 
/*     */ 
/*     */     
/* 290 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */ 
/*     */     
/* 294 */     this.lastRowProcessed++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 307 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 309 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 311 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 312 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 313 */     int n = this.lengthIndex + paramInt2 - 1;
/* 314 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 315 */     short s = paramArrayOfshort[i1];
/*     */     
/* 317 */     this.rowSpaceIndicator[n] = (short)s;
/* 318 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 321 */     if (s != 0)
/*     */     {
/* 323 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ResultSet getCursor(int paramInt) throws SQLException {
/* 334 */     OracleResultSetImpl oracleResultSetImpl = null;
/*     */     
/* 336 */     if (this.newstmt[paramInt] != null) {
/*     */       
/* 338 */       for (byte b = 0; b < (this.newstmt[paramInt]).numberOfDefinePositions; b++) {
/* 339 */         (this.newstmt[paramInt]).accessors[b].initMetadata();
/*     */       }
/* 341 */       this.newstmt[paramInt].prepareAccessors();
/*     */       
/* 343 */       this.newstmt[paramInt].setPrefetchInternal(this.statement.getFetchSize(), false, false);
/*     */       
/* 345 */       OracleResultSetImpl oracleResultSetImpl1 = new OracleResultSetImpl((this.newstmt[paramInt]).connection, this.newstmt[paramInt]);
/*     */ 
/*     */ 
/*     */       
/* 349 */       oracleResultSetImpl1.close_statement_on_close = true;
/* 350 */       (this.newstmt[paramInt]).currentResultSet = oracleResultSetImpl1;
/* 351 */       oracleResultSetImpl = oracleResultSetImpl1;
/*     */     } 
/*     */     
/* 354 */     return (ResultSet)oracleResultSetImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 360 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\T4CResultSetAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */