package oracle.jdbc.driver;

public interface Message {
  String msg(String paramString, Object paramObject);
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\Message.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */