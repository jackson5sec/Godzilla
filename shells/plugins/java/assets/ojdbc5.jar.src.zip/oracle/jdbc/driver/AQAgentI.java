/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.aq.AQAgent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AQAgentI
/*     */   implements AQAgent
/*     */ {
/*  46 */   private String attrAgentName = null;
/*  47 */   private String attrAgentAddress = null;
/*  48 */   private int attrAgentProtocol = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAddress(String paramString) throws SQLException {
/*  56 */     this.attrAgentAddress = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAddress() {
/*  63 */     return this.attrAgentAddress;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String paramString) throws SQLException {
/*  71 */     this.attrAgentName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  78 */     return this.attrAgentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProtocol(int paramInt) throws SQLException {
/*  85 */     this.attrAgentProtocol = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getProtocol() {
/*  92 */     return this.attrAgentProtocol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  99 */     StringBuffer stringBuffer = new StringBuffer();
/* 100 */     stringBuffer.append("Name=\"");
/* 101 */     stringBuffer.append(getName());
/* 102 */     stringBuffer.append("\" ");
/* 103 */     stringBuffer.append("Address=\"");
/* 104 */     stringBuffer.append(getAddress());
/* 105 */     stringBuffer.append("\" ");
/* 106 */     stringBuffer.append("Protocol=\"");
/* 107 */     stringBuffer.append(getProtocol());
/* 108 */     stringBuffer.append("\"");
/* 109 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 114 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\AQAgentI.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */