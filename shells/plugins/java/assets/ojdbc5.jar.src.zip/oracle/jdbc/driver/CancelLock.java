/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CancelLock
/*    */ {
/*    */   private enum State
/*    */   {
/* 56 */     IDLE, EXECUTING, CANCELING;
/*    */   }
/* 58 */   private State state = State.IDLE;
/*    */ 
/*    */   
/*    */   synchronized void enterExecuting() {
/* 62 */     assert this.state == State.IDLE;
/* 63 */     this.state = State.EXECUTING;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized void exitExecuting() {
/* 68 */     while (this.state != State.EXECUTING) {
/*    */       
/* 70 */       assert this.state == State.CANCELING;
/*    */       try {
/* 72 */         wait();
/* 73 */       } catch (InterruptedException interruptedException) {}
/*    */     } 
/* 75 */     this.state = State.IDLE;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized boolean enterCanceling() {
/* 80 */     if (this.state == State.EXECUTING) {
/*    */       
/* 82 */       this.state = State.CANCELING;
/* 83 */       return true;
/*    */     } 
/*    */     
/* 86 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   synchronized void exitCanceling() {
/* 91 */     assert this.state == State.CANCELING;
/* 92 */     this.state = State.EXECUTING;
/* 93 */     notify();
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\CancelLock.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */