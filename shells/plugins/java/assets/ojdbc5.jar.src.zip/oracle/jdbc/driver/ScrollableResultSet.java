/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class ScrollableResultSet
/*      */   extends BaseResultSet
/*      */ {
/*      */   PhysicalConnection connection;
/*      */   OracleResultSetImpl resultSet;
/*      */   ScrollRsetStatement scrollStmt;
/*      */   ResultSetMetaData metadata;
/*      */   private int rsetType;
/*      */   private int rsetConcurency;
/*      */   private int beginColumnIndex;
/*      */   private int columnCount;
/*      */   private int wasNull;
/*      */   OracleResultSetCache rsetCache;
/*      */   int currentRow;
/*      */   private int numRowsCached;
/*      */   private boolean allRowsCached;
/*      */   private int lastRefetchSz;
/*      */   private Vector refetchRowids;
/*      */   private OraclePreparedStatement refetchStmt;
/*      */   private int usrFetchDirection;
/*      */   
/*      */   ScrollableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2) throws SQLException {
/*   77 */     this.connection = ((OracleStatement)paramScrollRsetStatement).connection;
/*   78 */     this.resultSet = paramOracleResultSetImpl;
/*   79 */     this.metadata = null;
/*   80 */     this.scrollStmt = paramScrollRsetStatement;
/*   81 */     this.rsetType = paramInt1;
/*   82 */     this.rsetConcurency = paramInt2;
/*   83 */     this.beginColumnIndex = needIdentifier(paramInt1, paramInt2) ? 1 : 0;
/*   84 */     this.columnCount = 0;
/*   85 */     this.wasNull = -1;
/*   86 */     this.rsetCache = paramScrollRsetStatement.getResultSetCache();
/*      */     
/*   88 */     if (this.rsetCache == null) {
/*      */       
/*   90 */       this.rsetCache = new OracleResultSetCacheImpl();
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*   96 */         this.rsetCache.clear();
/*      */       }
/*   98 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  101 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  102 */         sQLException.fillInStackTrace();
/*  103 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  108 */     this.currentRow = 0;
/*  109 */     this.numRowsCached = 0;
/*  110 */     this.allRowsCached = false;
/*  111 */     this.lastRefetchSz = 0;
/*  112 */     this.refetchRowids = null;
/*  113 */     this.refetchStmt = null;
/*  114 */     this.usrFetchDirection = 1000;
/*  115 */     getInternalMetadata();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  128 */     synchronized (this.connection) {
/*      */       
/*  130 */       if (this.closed)
/*  131 */         return;  super.close();
/*  132 */       if (this.resultSet != null)
/*  133 */         this.resultSet.close(); 
/*  134 */       if (this.refetchStmt != null)
/*  135 */         this.refetchStmt.close(); 
/*  136 */       if (this.scrollStmt != null)
/*  137 */         this.scrollStmt.notifyCloseRset(); 
/*  138 */       if (this.refetchRowids != null) {
/*  139 */         this.refetchRowids.removeAllElements();
/*      */       }
/*  141 */       this.resultSet = null;
/*  142 */       this.scrollStmt = null;
/*  143 */       this.refetchStmt = null;
/*  144 */       this.refetchRowids = null;
/*  145 */       this.metadata = null;
/*      */ 
/*      */       
/*      */       try {
/*  149 */         if (this.rsetCache != null)
/*      */         {
/*  151 */           this.rsetCache.clear();
/*  152 */           this.rsetCache.close();
/*      */         }
/*      */       
/*  155 */       } catch (IOException iOException) {
/*      */ 
/*      */         
/*  158 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  159 */         sQLException.fillInStackTrace();
/*  160 */         throw sQLException;
/*      */       }
/*      */       finally {
/*      */         
/*  164 */         this.rsetCache = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  172 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  175 */       if (this.wasNull == -1) {
/*      */         
/*  177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/*  178 */         sQLException.fillInStackTrace();
/*  179 */         throw sQLException;
/*      */       } 
/*      */       
/*  182 */       return (this.wasNull == 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  190 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  193 */       return (Statement)this.scrollStmt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetBeginColumnIndex() {
/*  203 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  206 */       this.beginColumnIndex = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSet getResultSet() {
/*  216 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  219 */       return (ResultSet)this.resultSet;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int removeRowInCache(int paramInt) throws SQLException {
/*  226 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  229 */       if (!isEmptyResultSet() && isValidRow(paramInt)) {
/*      */         
/*  231 */         removeCachedRowAt(paramInt);
/*      */         
/*  233 */         this.numRowsCached--;
/*      */         
/*  235 */         if (paramInt >= this.currentRow) {
/*  236 */           this.currentRow--;
/*      */         }
/*  238 */         return 1;
/*      */       } 
/*      */       
/*  241 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int refreshRowsInCache(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  252 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  255 */       OracleResultSetImpl oracleResultSetImpl = null;
/*  256 */       int i = 0;
/*      */ 
/*      */       
/*  259 */       i = get_refetch_size(paramInt1, paramInt2, paramInt3);
/*      */ 
/*      */       
/*      */       try {
/*  263 */         if (i > 0)
/*      */         {
/*      */ 
/*      */           
/*  267 */           if (i != this.lastRefetchSz) {
/*      */             
/*  269 */             if (this.refetchStmt != null) {
/*  270 */               this.refetchStmt.close();
/*      */             }
/*  272 */             this.refetchStmt = prepare_refetch_statement(i);
/*  273 */             this.refetchStmt.setQueryTimeout(((OracleStatement)this.scrollStmt).getQueryTimeout());
/*  274 */             this.lastRefetchSz = i;
/*      */           } 
/*      */ 
/*      */           
/*  278 */           prepare_refetch_binds(this.refetchStmt, i);
/*      */ 
/*      */           
/*  281 */           oracleResultSetImpl = (OracleResultSetImpl)this.refetchStmt.executeQuery();
/*      */ 
/*      */           
/*  284 */           save_refetch_results(oracleResultSetImpl, paramInt1, i, paramInt3);
/*      */         }
/*      */       
/*      */       }
/*      */       finally {
/*      */         
/*  290 */         if (oracleResultSetImpl != null) {
/*  291 */           oracleResultSetImpl.close();
/*      */         }
/*      */       } 
/*  294 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  305 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  308 */       if (this.closed) {
/*      */         
/*  310 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  311 */         sQLException.fillInStackTrace();
/*  312 */         throw sQLException;
/*      */       } 
/*      */       
/*  315 */       if (isEmptyResultSet())
/*      */       {
/*  317 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  321 */       if (this.currentRow < 1) {
/*      */         
/*  323 */         this.currentRow = 1;
/*      */       }
/*      */       else {
/*      */         
/*  327 */         this.currentRow++;
/*      */       } 
/*      */       
/*  330 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/*  338 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  341 */       if (this.closed) {
/*      */         
/*  343 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  344 */         sQLException.fillInStackTrace();
/*  345 */         throw sQLException;
/*      */       } 
/*  347 */       return (!isEmptyResultSet() && this.currentRow < 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/*  354 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  357 */       if (this.closed) {
/*      */         
/*  359 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  360 */         sQLException.fillInStackTrace();
/*  361 */         throw sQLException;
/*      */       } 
/*  363 */       return (!isEmptyResultSet() && this.currentRow > 0 && !isValidRow(this.currentRow));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/*  370 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  373 */       if (this.closed) {
/*      */         
/*  375 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  376 */         sQLException.fillInStackTrace();
/*  377 */         throw sQLException;
/*      */       } 
/*  379 */       return (this.currentRow == 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/*  386 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  389 */       if (this.closed) {
/*      */         
/*  391 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  392 */         sQLException.fillInStackTrace();
/*  393 */         throw sQLException;
/*      */       } 
/*  395 */       return (!isEmptyResultSet() && isValidRow(this.currentRow) && !isValidRow(this.currentRow + 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/*  403 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  406 */       if (this.closed) {
/*      */         
/*  408 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  409 */         sQLException.fillInStackTrace();
/*  410 */         throw sQLException;
/*      */       } 
/*  412 */       if (!isEmptyResultSet()) {
/*  413 */         this.currentRow = 0;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/*  420 */     synchronized (this.connection) {
/*  421 */       if (this.closed) {
/*      */         
/*  423 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  424 */         sQLException.fillInStackTrace();
/*  425 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  429 */       if (!isEmptyResultSet()) {
/*  430 */         this.currentRow = getLastRow() + 1;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/*  437 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  440 */       if (this.closed) {
/*      */         
/*  442 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  443 */         sQLException.fillInStackTrace();
/*  444 */         throw sQLException;
/*      */       } 
/*  446 */       if (isEmptyResultSet())
/*      */       {
/*  448 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  452 */       this.currentRow = 1;
/*      */       
/*  454 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/*  462 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  465 */       if (this.closed) {
/*      */         
/*  467 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  468 */         sQLException.fillInStackTrace();
/*  469 */         throw sQLException;
/*      */       } 
/*  471 */       if (isEmptyResultSet())
/*      */       {
/*  473 */         return false;
/*      */       }
/*      */ 
/*      */       
/*  477 */       this.currentRow = getLastRow();
/*      */       
/*  479 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/*  487 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  490 */       if (this.closed) {
/*      */         
/*  492 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  493 */         sQLException.fillInStackTrace();
/*  494 */         throw sQLException;
/*      */       } 
/*  496 */       if (isValidRow(this.currentRow)) {
/*  497 */         return this.currentRow;
/*      */       }
/*  499 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLException {
/*  506 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  509 */       if (this.closed) {
/*      */         
/*  511 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  512 */         sQLException.fillInStackTrace();
/*  513 */         throw sQLException;
/*      */       } 
/*  515 */       if (paramInt == 0) {
/*      */         
/*  517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "absolute(" + paramInt + ")");
/*  518 */         sQLException.fillInStackTrace();
/*  519 */         throw sQLException;
/*      */       } 
/*      */       
/*  522 */       if (isEmptyResultSet())
/*      */       {
/*  524 */         return false;
/*      */       }
/*  526 */       if (paramInt > 0) {
/*      */         
/*  528 */         this.currentRow = paramInt;
/*      */       }
/*  530 */       else if (paramInt < 0) {
/*      */         
/*  532 */         this.currentRow = getLastRow() + 1 + paramInt;
/*      */       } 
/*      */       
/*  535 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLException {
/*  542 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  545 */       if (this.closed) {
/*      */         
/*  547 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  548 */         sQLException1.fillInStackTrace();
/*  549 */         throw sQLException1;
/*      */       } 
/*  551 */       if (isEmptyResultSet())
/*      */       {
/*  553 */         return false;
/*      */       }
/*  555 */       if (isValidRow(this.currentRow)) {
/*      */         
/*  557 */         this.currentRow += paramInt;
/*      */         
/*  559 */         return isValidRow(this.currentRow);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  564 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "relative");
/*  565 */       sQLException.fillInStackTrace();
/*  566 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/*  575 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  578 */       if (this.closed) {
/*      */         
/*  580 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  581 */         sQLException.fillInStackTrace();
/*  582 */         throw sQLException;
/*      */       } 
/*  584 */       if (isEmptyResultSet())
/*      */       {
/*  586 */         return false;
/*      */       }
/*  588 */       if (isAfterLast()) {
/*      */         
/*  590 */         this.currentRow = getLastRow();
/*      */       }
/*      */       else {
/*      */         
/*  594 */         this.currentRow--;
/*      */       } 
/*      */       
/*  597 */       return isValidRow(this.currentRow);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  608 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  611 */       if (this.closed) {
/*      */         
/*  613 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  614 */         sQLException.fillInStackTrace();
/*  615 */         throw sQLException;
/*      */       } 
/*      */       
/*  618 */       this.wasNull = -1;
/*      */       
/*  620 */       if (!isValidRow(this.currentRow)) {
/*      */         
/*  622 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  623 */         sQLException.fillInStackTrace();
/*  624 */         throw sQLException;
/*      */       } 
/*      */       
/*  627 */       if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */         
/*  629 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  630 */         sQLException.fillInStackTrace();
/*  631 */         throw sQLException;
/*      */       } 
/*      */       
/*  634 */       Datum datum = getCachedDatumValueAt(this.currentRow, paramInt + this.beginColumnIndex);
/*      */ 
/*      */       
/*  637 */       this.wasNull = (datum == null) ? 1 : 0;
/*      */       
/*  639 */       return datum;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  646 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  649 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  651 */       if (datum != null) {
/*      */         CLOB cLOB;
/*  653 */         switch (getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 2005:
/*  661 */             cLOB = (CLOB)datum;
/*  662 */             return cLOB.getSubString(1L, (int)cLOB.length());
/*      */ 
/*      */ 
/*      */           
/*      */           case 91:
/*  667 */             if (this.connection.mapDateToTimestamp) {
/*  668 */               return datum.toJdbc().toString();
/*      */             }
/*  670 */             return datum.dateValue().toString();
/*      */ 
/*      */ 
/*      */           
/*      */           case 93:
/*  675 */             if (datum instanceof DATE) {
/*      */               
/*  677 */               if (this.connection.mapDateToTimestamp) {
/*  678 */                 return datum.toJdbc().toString();
/*      */               }
/*  680 */               return datum.dateValue().toString();
/*      */             } 
/*      */ 
/*      */             
/*  684 */             if (this.connection.j2ee13Compliant)
/*      */             {
/*      */               
/*  687 */               return datum.toJdbc().toString();
/*      */             }
/*      */ 
/*      */             
/*  691 */             return datum.stringValue((Connection)this.connection);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  698 */         return datum.stringValue((Connection)this.connection);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  703 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  710 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  713 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  715 */       if (datum != null)
/*      */       {
/*  717 */         return datum.booleanValue();
/*      */       }
/*      */       
/*  720 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/*  727 */     synchronized (this.connection) {
/*      */       
/*  729 */       if (!isValidRow(this.currentRow)) {
/*      */         
/*  731 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  732 */         sQLException.fillInStackTrace();
/*  733 */         throw sQLException;
/*      */       } 
/*      */       
/*  736 */       if (paramInt < 1 || paramInt > getColumnCount()) {
/*      */         
/*  738 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  739 */         sQLException.fillInStackTrace();
/*  740 */         throw sQLException;
/*      */       } 
/*      */       
/*  743 */       CachedRowElement cachedRowElement = null;
/*  744 */       OracleResultSet.AuthorizationIndicator authorizationIndicator = null;
/*      */ 
/*      */       
/*      */       try {
/*  748 */         cachedRowElement = (CachedRowElement)this.rsetCache.get(this.currentRow, paramInt);
/*      */       }
/*  750 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  753 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  754 */         sQLException.fillInStackTrace();
/*  755 */         throw sQLException;
/*      */       } 
/*      */       
/*  758 */       if (cachedRowElement != null) {
/*  759 */         authorizationIndicator = cachedRowElement.getIndicator();
/*      */       }
/*  761 */       return authorizationIndicator;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  768 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  771 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  773 */       if (datum != null) {
/*  774 */         return datum.byteValue();
/*      */       }
/*  776 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/*  783 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  786 */       long l = getLong(paramInt);
/*      */       
/*  788 */       if (l > 65537L || l < -65538L) {
/*      */         
/*  790 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort");
/*  791 */         sQLException.fillInStackTrace();
/*  792 */         throw sQLException;
/*      */       } 
/*      */       
/*  795 */       return (short)(int)l;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  802 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  805 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  807 */       if (datum != null)
/*      */       {
/*  809 */         return datum.intValue();
/*      */       }
/*      */       
/*  812 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  819 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  822 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  824 */       if (datum != null)
/*      */       {
/*  826 */         return datum.longValue();
/*      */       }
/*      */       
/*  829 */       return 0L;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  836 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  839 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  841 */       if (datum != null)
/*      */       {
/*  843 */         return datum.floatValue();
/*      */       }
/*      */       
/*  846 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  853 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  856 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  858 */       if (datum != null)
/*      */       {
/*  860 */         return datum.doubleValue();
/*      */       }
/*      */       
/*  863 */       return 0.0D;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  871 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  874 */       Datum datum = getOracleObject(paramInt1);
/*      */       
/*  876 */       if (datum != null)
/*      */       {
/*  878 */         return datum.bigDecimalValue();
/*      */       }
/*      */       
/*  881 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  888 */     synchronized (this.connection) {
/*      */       
/*  890 */       byte[] arrayOfByte = null;
/*  891 */       Datum datum = getOracleObject(paramInt);
/*      */       
/*  893 */       if (datum != null)
/*      */       {
/*  895 */         if (datum instanceof RAW) {
/*  896 */           arrayOfByte = ((RAW)datum).shareBytes();
/*  897 */         } else if (datum instanceof BLOB) {
/*      */           
/*  899 */           BLOB bLOB = (BLOB)datum;
/*  900 */           long l = bLOB.length();
/*  901 */           if (l > 2147483647L) {
/*      */ 
/*      */             
/*  904 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 151);
/*  905 */             sQLException.fillInStackTrace();
/*  906 */             throw sQLException;
/*      */           } 
/*      */           
/*  909 */           arrayOfByte = bLOB.getBytes(1L, (int)l);
/*  910 */           if (bLOB.isTemporary()) this.resultSet.statement.addToTempLobsToFree(bLOB);
/*      */         
/*      */         } else {
/*      */           
/*  914 */           arrayOfByte = datum.getBytes();
/*      */         } 
/*      */       }
/*  917 */       return arrayOfByte;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  924 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  927 */       Datum datum = getOracleObject(paramInt);
/*  928 */       Date date = null;
/*      */       
/*  930 */       if (datum != null)
/*      */       
/*  932 */       { ResultSetMetaData resultSetMetaData = getInternalMetadata();
/*  933 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { 
/*      */           
/*      */           case -101:
/*  938 */             date = ((TIMESTAMPTZ)datum).dateValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  951 */             return date;case -102: date = ((TIMESTAMPLTZ)datum).dateValue((Connection)this.connection); return date; }  date = datum.dateValue(); }  return date;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/*  958 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  961 */       Datum datum = getOracleObject(paramInt);
/*  962 */       Time time = null;
/*      */       
/*  964 */       if (datum != null)
/*      */       
/*  966 */       { ResultSetMetaData resultSetMetaData = getInternalMetadata();
/*  967 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/*  970 */             time = ((TIMESTAMPTZ)datum).timeValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  984 */             return time;case -102: time = ((TIMESTAMPLTZ)datum).timeValue((Connection)this.connection, this.connection.getDbTzCalendar()); return time; }  time = datum.timeValue(); }  return time;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/*  992 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  995 */       Datum datum = getOracleObject(paramInt);
/*  996 */       Timestamp timestamp = null;
/*      */       
/*  998 */       if (datum != null)
/*      */       
/* 1000 */       { ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1001 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1004 */             timestamp = ((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1018 */             return timestamp;case -102: timestamp = ((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, this.connection.getDbTzCalendar()); return timestamp; }  timestamp = datum.timestampValue(); }  return timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1026 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1029 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1031 */       if (datum != null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1036 */         return datum.asciiStreamValue();
/*      */       }
/*      */       
/* 1039 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1047 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1050 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1052 */       if (datum != null) {
/*      */         
/* 1054 */         DBConversion dBConversion = this.connection.conversion;
/* 1055 */         byte[] arrayOfByte = datum.shareBytes();
/*      */         
/* 1057 */         if (datum instanceof RAW)
/*      */         {
/* 1059 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3);
/*      */         }
/*      */         
/* 1062 */         if (datum instanceof CHAR)
/*      */         {
/* 1064 */           return dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1069 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream");
/* 1070 */         sQLException.fillInStackTrace();
/* 1071 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1075 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1083 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1086 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1088 */       if (datum != null)
/*      */       {
/* 1090 */         return datum.binaryStreamValue();
/*      */       }
/*      */       
/* 1093 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 1103 */     return getObject(paramInt, this.connection.getTypeMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1111 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1114 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1116 */       if (datum != null)
/*      */       {
/* 1118 */         return datum.characterStreamValue();
/*      */       }
/*      */       
/* 1121 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1131 */     return getBigDecimal(paramInt, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1143 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1146 */       Object object = null;
/* 1147 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1149 */       if (datum != null)
/*      */       
/* 1151 */       { int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/*      */         
/* 1153 */         switch (i)
/*      */         
/*      */         { case 2002:
/* 1156 */             object = ((STRUCT)datum).toJdbc(paramMap);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1198 */             return object;case 91: if (this.connection.mapDateToTimestamp) { object = datum.toJdbc(); } else { object = datum.dateValue(); }  return object;case 93: if (datum instanceof DATE) { if (this.connection.mapDateToTimestamp) { object = datum.toJdbc(); } else { object = datum.dateValue(); }  } else if (this.connection.j2ee13Compliant) { object = datum.toJdbc(); } else { object = datum; }  return object;case -102: case -101: object = datum; return object; }  object = datum.toJdbc(); }  return object;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1206 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1209 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1217 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1220 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1228 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1231 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1240 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1243 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1252 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1255 */       Datum datum = getOracleObject(paramInt);
/* 1256 */       Date date = null;
/*      */       
/* 1258 */       if (datum != null)
/*      */       { Calendar calendar;
/* 1260 */         ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1261 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1264 */             date = new Date(((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection).getTime());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1281 */             return date;case -102: calendar = this.connection.getDbTzCalendar(); date = new Date(((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar).getTime()); return date; }  date = new Date(datum.timestampValue(paramCalendar).getTime()); }  return date;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1290 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1293 */       Datum datum = getOracleObject(paramInt);
/* 1294 */       Time time = null;
/*      */       
/* 1296 */       if (datum != null)
/*      */       { Calendar calendar;
/* 1298 */         ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1299 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1302 */             time = new Time(((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection).getTime());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1316 */             return time;case -102: calendar = this.connection.getDbTzCalendar(); time = new Time(((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar).getTime()); return time; }  time = new Time(datum.timestampValue(paramCalendar).getTime()); }  return time;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1325 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1328 */       Datum datum = getOracleObject(paramInt);
/* 1329 */       Timestamp timestamp = null;
/*      */       
/* 1331 */       if (datum != null)
/*      */       { Calendar calendar;
/* 1333 */         ResultSetMetaData resultSetMetaData = getInternalMetadata();
/* 1334 */         switch (resultSetMetaData.getColumnType(paramInt + this.beginColumnIndex))
/*      */         
/*      */         { case -101:
/* 1337 */             timestamp = ((TIMESTAMPTZ)datum).timestampValue((Connection)this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1351 */             return timestamp;case -102: calendar = this.connection.getDbTzCalendar(); timestamp = ((TIMESTAMPLTZ)datum).timestampValue((Connection)this.connection, (calendar == null) ? paramCalendar : calendar); return timestamp; }  timestamp = datum.timestampValue(paramCalendar); }  return timestamp;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1359 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1362 */       URL uRL = null;
/*      */       
/* 1364 */       int i = getInternalMetadata().getColumnType(paramInt + this.beginColumnIndex);
/* 1365 */       int j = SQLUtil.getInternalType(i);
/*      */ 
/*      */       
/* 1368 */       if (j == 96 || j == 1 || j == 8) {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/* 1373 */           String str = getString(paramInt);
/* 1374 */           if (str == null) { uRL = null; }
/* 1375 */           else { uRL = new URL(str); }
/*      */         
/* 1377 */         } catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */           
/* 1380 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 1381 */           sQLException.fillInStackTrace();
/* 1382 */           throw sQLException;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1389 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Conversion to java.net.URL not supported.");
/* 1390 */         sQLException.fillInStackTrace();
/* 1391 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1395 */       return uRL;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 1403 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1407 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor");
/* 1408 */       sQLException.fillInStackTrace();
/* 1409 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 1419 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1422 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1424 */       if (datum != null) {
/*      */         
/* 1426 */         if (datum instanceof ROWID) {
/* 1427 */           return (ROWID)datum;
/*      */         }
/*      */         
/* 1430 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID");
/* 1431 */         sQLException.fillInStackTrace();
/* 1432 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1436 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1444 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1447 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1449 */       if (datum != null) {
/*      */         
/* 1451 */         if (datum instanceof NUMBER) {
/* 1452 */           return (NUMBER)datum;
/*      */         }
/*      */         
/* 1455 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER");
/* 1456 */         sQLException.fillInStackTrace();
/* 1457 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1461 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 1469 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1472 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1474 */       if (datum != null) {
/*      */         
/* 1476 */         if (datum instanceof DATE)
/* 1477 */           return (DATE)datum; 
/* 1478 */         if (datum instanceof TIMESTAMP)
/* 1479 */           return TIMESTAMP.toDATE(datum.getBytes()); 
/* 1480 */         if (datum instanceof TIMESTAMPLTZ)
/* 1481 */           return TIMESTAMPLTZ.toDATE((Connection)this.connection, datum.getBytes()); 
/* 1482 */         if (datum instanceof TIMESTAMPTZ) {
/* 1483 */           return TIMESTAMPTZ.toDATE((Connection)this.connection, datum.getBytes());
/*      */         }
/*      */         
/* 1486 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE");
/* 1487 */         sQLException.fillInStackTrace();
/* 1488 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1492 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 1500 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1503 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1505 */       if (datum != null) {
/*      */         
/* 1507 */         if (datum instanceof TIMESTAMP)
/* 1508 */           return (TIMESTAMP)datum; 
/* 1509 */         if (datum instanceof TIMESTAMPLTZ)
/* 1510 */           return TIMESTAMPLTZ.toTIMESTAMP((Connection)this.connection, datum.getBytes()); 
/* 1511 */         if (datum instanceof TIMESTAMPTZ)
/* 1512 */           return TIMESTAMPTZ.toTIMESTAMP((Connection)this.connection, datum.getBytes()); 
/* 1513 */         if (datum instanceof DATE) {
/* 1514 */           return new TIMESTAMP((DATE)datum);
/*      */         }
/*      */         
/* 1517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP");
/* 1518 */         sQLException.fillInStackTrace();
/* 1519 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1523 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 1531 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1534 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1536 */       if (datum != null) {
/*      */         
/* 1538 */         if (datum instanceof TIMESTAMPTZ)
/* 1539 */           return (TIMESTAMPTZ)datum; 
/* 1540 */         if (datum instanceof TIMESTAMPLTZ) {
/* 1541 */           return TIMESTAMPLTZ.toTIMESTAMPTZ((Connection)this.connection, datum.getBytes());
/*      */         }
/*      */         
/* 1544 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ");
/* 1545 */         sQLException.fillInStackTrace();
/* 1546 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1550 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 1558 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1561 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1563 */       if (datum != null) {
/*      */         
/* 1565 */         if (datum instanceof TIMESTAMPLTZ) {
/* 1566 */           return (TIMESTAMPLTZ)datum;
/*      */         }
/*      */         
/* 1569 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ");
/* 1570 */         sQLException.fillInStackTrace();
/* 1571 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1575 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1583 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1586 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1588 */       if (datum != null) {
/*      */         
/* 1590 */         if (datum instanceof INTERVALDS) {
/* 1591 */           return (INTERVALDS)datum;
/*      */         }
/*      */         
/* 1594 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS");
/* 1595 */         sQLException.fillInStackTrace();
/* 1596 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1600 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1608 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1611 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1613 */       if (datum != null) {
/*      */         
/* 1615 */         if (datum instanceof INTERVALYM) {
/* 1616 */           return (INTERVALYM)datum;
/*      */         }
/*      */         
/* 1619 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM");
/* 1620 */         sQLException.fillInStackTrace();
/* 1621 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1625 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 1633 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1636 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1638 */       if (datum != null) {
/*      */         
/* 1640 */         if (datum instanceof ARRAY) {
/* 1641 */           return (ARRAY)datum;
/*      */         }
/*      */         
/* 1644 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY");
/* 1645 */         sQLException.fillInStackTrace();
/* 1646 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1650 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 1658 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1661 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1663 */       if (datum != null) {
/*      */         
/* 1665 */         if (datum instanceof STRUCT) {
/* 1666 */           return (STRUCT)datum;
/*      */         }
/*      */         
/* 1669 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT");
/* 1670 */         sQLException.fillInStackTrace();
/* 1671 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1675 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1683 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1686 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1688 */       if (datum != null) {
/*      */         
/* 1690 */         if (datum instanceof OPAQUE) {
/* 1691 */           return (OPAQUE)datum;
/*      */         }
/*      */         
/* 1694 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE");
/* 1695 */         sQLException.fillInStackTrace();
/* 1696 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1700 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 1708 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1711 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1713 */       if (datum != null) {
/*      */         
/* 1715 */         if (datum instanceof REF) {
/* 1716 */           return (REF)datum;
/*      */         }
/*      */         
/* 1719 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF");
/* 1720 */         sQLException.fillInStackTrace();
/* 1721 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1725 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1733 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1736 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1738 */       if (datum != null) {
/*      */         
/* 1740 */         if (datum instanceof CHAR) {
/* 1741 */           return (CHAR)datum;
/*      */         }
/*      */         
/* 1744 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR");
/* 1745 */         sQLException.fillInStackTrace();
/* 1746 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1750 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1758 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1761 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1763 */       if (datum != null) {
/*      */         
/* 1765 */         if (datum instanceof RAW) {
/* 1766 */           return (RAW)datum;
/*      */         }
/*      */         
/* 1769 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW");
/* 1770 */         sQLException.fillInStackTrace();
/* 1771 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1775 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1783 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1786 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1788 */       if (datum != null) {
/*      */         
/* 1790 */         if (datum instanceof BLOB) {
/* 1791 */           return (BLOB)datum;
/*      */         }
/*      */         
/* 1794 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB");
/* 1795 */         sQLException.fillInStackTrace();
/* 1796 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1800 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1808 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1811 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1813 */       if (datum != null) {
/*      */         
/* 1815 */         if (datum instanceof CLOB) {
/* 1816 */           return (CLOB)datum;
/*      */         }
/*      */         
/* 1819 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB");
/* 1820 */         sQLException.fillInStackTrace();
/* 1821 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1825 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1837 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1840 */       Datum datum = getOracleObject(paramInt);
/*      */       
/* 1842 */       if (datum != null) {
/*      */         
/* 1844 */         if (datum instanceof BFILE) {
/* 1845 */           return (BFILE)datum;
/*      */         }
/*      */         
/* 1848 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE");
/* 1849 */         sQLException.fillInStackTrace();
/* 1850 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 1854 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1863 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1866 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1875 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1878 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1883 */       return paramCustomDatumFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1892 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1895 */       Datum datum = getOracleObject(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1900 */       return paramORADataFactory.create(datum, 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1908 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1914 */       return paramOracleDataFactory.create(getObject(paramInt), 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 1931 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1934 */       return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, (OracleStatement)this.scrollStmt, this.beginColumnIndex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 1943 */     synchronized (this.connection) {
/*      */       
/* 1945 */       if (this.closed) {
/*      */         
/* 1947 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/* 1948 */         sQLException.fillInStackTrace();
/* 1949 */         throw sQLException;
/*      */       } 
/* 1951 */       return this.resultSet.findColumn(paramString) - this.beginColumnIndex;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 1962 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1965 */       if (paramInt == 1000) {
/*      */         
/* 1967 */         this.usrFetchDirection = paramInt;
/*      */       }
/* 1969 */       else if (paramInt == 1001 || paramInt == 1002) {
/*      */ 
/*      */         
/* 1972 */         this.usrFetchDirection = paramInt;
/*      */         
/* 1974 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1981 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 1982 */         sQLException.fillInStackTrace();
/* 1983 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 1995 */     return 1000;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 2001 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2004 */       this.resultSet.setFetchSize(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2011 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2014 */       return this.resultSet.getFetchSize();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/* 2023 */     return this.rsetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/* 2031 */     return this.rsetConcurency;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 2046 */     if (!needIdentifier(this.rsetType, this.rsetConcurency)) {
/*      */       
/* 2048 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "refreshRow");
/* 2049 */       sQLException.fillInStackTrace();
/* 2050 */       throw sQLException;
/*      */     } 
/*      */     
/* 2053 */     if (isValidRow(this.currentRow)) {
/*      */       
/* 2055 */       int i = getFetchDirection();
/*      */ 
/*      */       
/*      */       try {
/* 2059 */         refreshRowsInCache(this.currentRow, getFetchSize(), i);
/*      */       }
/* 2061 */       catch (SQLException sQLException1) {
/*      */ 
/*      */         
/* 2064 */         SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), sQLException1, 90, "Unsupported syntax for refreshRow()");
/* 2065 */         sQLException2.fillInStackTrace();
/* 2066 */         throw sQLException2;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2072 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82, "refreshRow");
/* 2073 */       sQLException.fillInStackTrace();
/* 2074 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isEmptyResultSet() throws SQLException {
/* 2090 */     if (this.numRowsCached != 0)
/*      */     {
/* 2092 */       return false;
/*      */     }
/* 2094 */     if (this.numRowsCached == 0 && this.allRowsCached)
/*      */     {
/* 2096 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 2100 */     return !isValidRow(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isValidRow(int paramInt) throws SQLException {
/* 2113 */     if (paramInt > 0 && paramInt <= this.numRowsCached)
/*      */     {
/* 2115 */       return true;
/*      */     }
/* 2117 */     if (paramInt <= 0)
/*      */     {
/* 2119 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 2123 */     return cacheRowAt(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cacheCurrentRow(OracleResultSetImpl paramOracleResultSetImpl, int paramInt) throws SQLException {
/* 2134 */     for (byte b = 0; b < getColumnCount(); b++) {
/*      */ 
/*      */       
/* 2137 */       byte[] arrayOfByte = paramOracleResultSetImpl.privateGetBytes(b + 1);
/* 2138 */       OracleResultSet.AuthorizationIndicator authorizationIndicator = paramOracleResultSetImpl.getAuthorizationIndicator(b + 1);
/*      */       
/* 2140 */       CachedRowElement cachedRowElement = new CachedRowElement(paramInt, b + 1, authorizationIndicator, arrayOfByte);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2145 */       int i = (paramOracleResultSetImpl.statement.accessors[b]).internalType;
/*      */       
/* 2147 */       if (i == 112) {
/*      */         
/* 2149 */         CLOB cLOB = paramOracleResultSetImpl.getCLOB(b + 1);
/* 2150 */         cachedRowElement.setData((Datum)cLOB);
/*      */       }
/* 2152 */       else if (i == 113) {
/*      */         
/* 2154 */         BLOB bLOB = paramOracleResultSetImpl.getBLOB(b + 1);
/* 2155 */         cachedRowElement.setData((Datum)bLOB);
/*      */       } 
/*      */       
/* 2158 */       putCachedValueAt(paramInt, b + 1, cachedRowElement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean cacheRowAt(int paramInt) throws SQLException {
/* 2174 */     while (this.numRowsCached < paramInt && this.resultSet.next()) {
/* 2175 */       cacheCurrentRow(this.resultSet, ++this.numRowsCached);
/*      */     }
/* 2177 */     if (this.numRowsCached < paramInt) {
/*      */       
/* 2179 */       this.allRowsCached = true;
/*      */       
/* 2181 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 2185 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int cacheAllRows() throws SQLException {
/* 2197 */     while (this.resultSet.next()) {
/* 2198 */       cacheCurrentRow(this.resultSet, ++this.numRowsCached);
/*      */     }
/* 2200 */     this.allRowsCached = true;
/*      */     
/* 2202 */     return this.numRowsCached;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnCount() throws SQLException {
/* 2213 */     if (this.columnCount == 0) {
/*      */ 
/*      */ 
/*      */       
/* 2217 */       int i = this.resultSet.statement.numberOfDefinePositions;
/*      */       
/* 2219 */       if (this.resultSet.statement.accessors != null && i > 0) {
/* 2220 */         this.columnCount = i;
/*      */       } else {
/* 2222 */         this.columnCount = getInternalMetadata().getColumnCount();
/*      */       } 
/*      */     } 
/* 2225 */     return this.columnCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetMetaData getInternalMetadata() throws SQLException {
/* 2236 */     if (this.metadata == null) {
/* 2237 */       this.metadata = this.resultSet.getMetaData();
/*      */     }
/* 2239 */     return this.metadata;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getLastRow() throws SQLException {
/* 2250 */     if (!this.allRowsCached) {
/* 2251 */       cacheAllRows();
/*      */     }
/* 2253 */     return this.numRowsCached;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_refetch_size(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2266 */     byte b1 = (paramInt3 == 1001) ? -1 : 1;
/*      */ 
/*      */     
/* 2269 */     byte b2 = 0;
/*      */     
/* 2271 */     if (this.refetchRowids == null) {
/* 2272 */       this.refetchRowids = new Vector(10);
/*      */     } else {
/* 2274 */       this.refetchRowids.removeAllElements();
/*      */     } 
/*      */     
/* 2277 */     while (b2 < paramInt2 && isValidRow(paramInt1 + b2 * b1)) {
/*      */       
/* 2279 */       this.refetchRowids.addElement(getCachedDatumValueAt(paramInt1 + b2 * b1, 1));
/*      */ 
/*      */       
/* 2282 */       b2++;
/*      */     } 
/*      */     
/* 2285 */     return b2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private OraclePreparedStatement prepare_refetch_statement(int paramInt) throws SQLException {
/* 2302 */     if (paramInt < 1) {
/*      */       
/* 2304 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2305 */       sQLException.fillInStackTrace();
/* 2306 */       throw sQLException;
/*      */     } 
/*      */     
/* 2309 */     PreparedStatement preparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getRefetchSqlForScrollableResultSet(this, paramInt));
/*      */ 
/*      */     
/* 2312 */     return (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepare_refetch_binds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
/* 2326 */     int i = this.scrollStmt.copyBinds((Statement)paramOraclePreparedStatement, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2346 */     for (byte b = 0; b < paramInt; b++)
/*      */     {
/* 2348 */       paramOraclePreparedStatement.setROWID(i + b + 1, this.refetchRowids.elementAt(b));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void save_refetch_results(OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2363 */     byte b = (paramInt3 == 1001) ? -1 : 1;
/*      */     
/* 2365 */     while (paramOracleResultSetImpl.next()) {
/*      */       
/* 2367 */       ROWID rOWID = paramOracleResultSetImpl.getROWID(1);
/*      */       
/* 2369 */       boolean bool = false;
/* 2370 */       int i = paramInt1;
/*      */       
/* 2372 */       while (!bool && i < paramInt1 + paramInt2 * b) {
/*      */         
/* 2374 */         if (((ROWID)getCachedDatumValueAt(i, 1)).stringValue((Connection)this.connection).equals(rOWID.stringValue((Connection)this.connection))) {
/*      */           
/* 2376 */           bool = true; continue;
/*      */         } 
/* 2378 */         i += b;
/*      */       } 
/*      */       
/* 2381 */       if (bool) {
/* 2382 */         cacheCurrentRow(paramOracleResultSetImpl, i);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Datum getCachedDatumValueAt(int paramInt1, int paramInt2) throws SQLException {
/* 2391 */     CachedRowElement cachedRowElement = null;
/*      */ 
/*      */     
/*      */     try {
/* 2395 */       cachedRowElement = (CachedRowElement)this.rsetCache.get(paramInt1, paramInt2);
/*      */     }
/* 2397 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2400 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2401 */       sQLException.fillInStackTrace();
/* 2402 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2406 */     Datum datum = null;
/*      */     
/* 2408 */     if (cachedRowElement != null) {
/*      */       
/* 2410 */       datum = cachedRowElement.getDataAsDatum();
/* 2411 */       byte[] arrayOfByte = cachedRowElement.getData();
/*      */       
/* 2413 */       if (datum == null && arrayOfByte != null && arrayOfByte.length > 0) {
/*      */ 
/*      */         
/* 2416 */         int i = getInternalMetadata().getColumnType(paramInt2);
/* 2417 */         int j = getInternalMetadata().getColumnDisplaySize(paramInt2);
/*      */         
/* 2419 */         int k = (((OracleResultSetMetaData)getInternalMetadata()).getDescription()[paramInt2 - 1]).internalType;
/*      */ 
/*      */ 
/*      */         
/* 2423 */         int m = this.scrollStmt.getMaxFieldSize();
/*      */         
/* 2425 */         if (m > 0 && m < j) {
/* 2426 */           j = m;
/*      */         }
/* 2428 */         String str = null;
/*      */         
/* 2430 */         if (i == 2006 || i == 2002 || i == 2008 || i == 2007 || i == 2003)
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2437 */           str = getInternalMetadata().getColumnTypeName(paramInt2);
/*      */         }
/*      */         
/* 2440 */         short s = (this.resultSet.statement.accessors[paramInt2 - 1]).formOfUse;
/*      */         
/* 2442 */         if (s == 2 && (k == 96 || k == 1 || k == 8 || k == 112)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2451 */           datum = SQLUtil.makeNDatum(this.connection, arrayOfByte, k, str, s, j);
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 2457 */           datum = SQLUtil.makeDatum(this.connection, arrayOfByte, k, str, j);
/*      */         } 
/*      */ 
/*      */         
/* 2461 */         cachedRowElement.setData(datum);
/*      */       } 
/*      */     } 
/*      */     
/* 2465 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void putCachedValueAt(int paramInt1, int paramInt2, CachedRowElement paramCachedRowElement) throws SQLException {
/*      */     try {
/* 2476 */       this.rsetCache.put(paramInt1, paramInt2, paramCachedRowElement);
/*      */     }
/* 2478 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2481 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2482 */       sQLException.fillInStackTrace();
/* 2483 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void removeCachedRowAt(int paramInt) throws SQLException {
/*      */     try {
/* 2495 */       this.rsetCache.remove(paramInt);
/*      */     }
/* 2497 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2501 */       sQLException.fillInStackTrace();
/* 2502 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean needIdentifier(int paramInt1, int paramInt2) {
/* 2515 */     if ((paramInt1 == 1003 && paramInt2 == 1007) || (paramInt1 == 1004 && paramInt2 == 1007))
/*      */     {
/*      */       
/* 2518 */       return false;
/*      */     }
/* 2520 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean needCache(int paramInt1, int paramInt2) {
/* 2529 */     if (paramInt1 == 1003 || (paramInt1 == 1004 && paramInt2 == 1007))
/*      */     {
/*      */       
/* 2532 */       return false;
/*      */     }
/* 2534 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean supportRefreshRow(int paramInt1, int paramInt2) {
/* 2543 */     if (paramInt1 == 1003 || (paramInt1 == 1004 && paramInt2 == 1007))
/*      */     {
/*      */       
/* 2546 */       return false;
/*      */     }
/* 2548 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getFirstUserColumnIndex() {
/* 2567 */     return this.beginColumnIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 2573 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2576 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 2577 */       sQLException.fillInStackTrace();
/* 2578 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2595 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/* 2606 */     return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2611 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\ScrollableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */