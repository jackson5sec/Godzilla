/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.PrintWriter;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleSql
/*      */ {
/*      */   static final int UNINITIALIZED = -1;
/*   39 */   static final String[] EMPTY_LIST = new String[0];
/*      */   
/*      */   DBConversion conversion;
/*      */   
/*      */   String originalSql;
/*      */   
/*      */   String parameterSql;
/*      */   
/*      */   String utickSql;
/*      */   String processedSql;
/*      */   String rowidSql;
/*      */   String actualSql;
/*      */   byte[] sqlBytes;
/*   52 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*   53 */   byte sqlKindByte = -1;
/*   54 */   int parameterCount = -1;
/*   55 */   int returningIntoParameterCount = -1;
/*      */   boolean currentConvertNcharLiterals = true;
/*      */   boolean currentProcessEscapes = true;
/*      */   boolean includeRowid = false;
/*   59 */   String[] parameterList = EMPTY_LIST;
/*   60 */   char[] currentParameter = null;
/*      */   
/*   62 */   int bindParameterCount = -1;
/*   63 */   String[] bindParameterList = null;
/*   64 */   int cachedBindParameterCount = -1;
/*   65 */   String[] cachedBindParameterList = null;
/*      */   String cachedParameterSql;
/*      */   String cachedUtickSql;
/*      */   String cachedProcessedSql;
/*      */   String cachedRowidSql;
/*      */   String cachedActualSql;
/*      */   byte[] cachedSqlBytes;
/*   72 */   int selectEndIndex = -1;
/*   73 */   int orderByStartIndex = -1;
/*   74 */   int orderByEndIndex = -1;
/*   75 */   int whereStartIndex = -1;
/*   76 */   int whereEndIndex = -1;
/*   77 */   int forUpdateStartIndex = -1;
/*   78 */   int forUpdateEndIndex = -1;
/*      */   
/*   80 */   int[] ncharLiteralLocation = new int[513];
/*   81 */   int lastNcharLiteralLocation = -1;
/*      */   
/*      */   static final String paramPrefix = "rowid";
/*   84 */   int paramSuffix = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   StringBuffer stringBufferForScrollableStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int cMax = 127;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize(String paramString) throws SQLException {
/*  112 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/*  114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  115 */       sQLException.fillInStackTrace();
/*  116 */       throw sQLException;
/*      */     } 
/*      */     
/*  119 */     this.originalSql = paramString;
/*  120 */     this.utickSql = null;
/*  121 */     this.processedSql = null;
/*  122 */     this.rowidSql = null;
/*  123 */     this.actualSql = null;
/*  124 */     this.sqlBytes = null;
/*  125 */     this.sqlKind = OracleStatement.SqlKind.UNINITIALIZED;
/*  126 */     this.parameterCount = -1;
/*  127 */     this.parameterList = EMPTY_LIST;
/*  128 */     this.includeRowid = false;
/*      */     
/*  130 */     this.parameterSql = this.originalSql;
/*  131 */     this.bindParameterCount = -1;
/*  132 */     this.bindParameterList = null;
/*  133 */     this.cachedBindParameterCount = -1;
/*  134 */     this.cachedBindParameterList = null;
/*  135 */     this.cachedParameterSql = null;
/*  136 */     this.cachedActualSql = null;
/*  137 */     this.cachedProcessedSql = null;
/*  138 */     this.cachedRowidSql = null;
/*  139 */     this.cachedSqlBytes = null;
/*  140 */     this.selectEndIndex = -1;
/*  141 */     this.orderByStartIndex = -1;
/*  142 */     this.orderByEndIndex = -1;
/*  143 */     this.whereStartIndex = -1;
/*  144 */     this.whereEndIndex = -1;
/*  145 */     this.forUpdateStartIndex = -1;
/*  146 */     this.forUpdateEndIndex = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getOriginalSql() {
/*  160 */     return this.originalSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean setNamedParameters(int paramInt, String[] paramArrayOfString) throws SQLException {
/*  172 */     boolean bool = false;
/*      */     
/*  174 */     if (paramInt == 0) {
/*      */       
/*  176 */       this.bindParameterCount = -1;
/*  177 */       bool = (this.bindParameterCount != this.cachedBindParameterCount) ? true : false;
/*      */     }
/*      */     else {
/*      */       
/*  181 */       this.bindParameterCount = paramInt;
/*  182 */       this.bindParameterList = paramArrayOfString;
/*  183 */       bool = (this.bindParameterCount != this.cachedBindParameterCount) ? true : false;
/*      */       
/*  185 */       if (!bool) {
/*  186 */         for (byte b = 0; b < paramInt; b++) {
/*  187 */           if (this.bindParameterList[b] != this.cachedBindParameterList[b]) {
/*      */             
/*  189 */             bool = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/*  194 */       if (bool) {
/*      */         
/*  196 */         if (this.bindParameterCount != getParameterCount()) {
/*      */           
/*  198 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 197);
/*  199 */           sQLException.fillInStackTrace();
/*  200 */           throw sQLException;
/*      */         } 
/*      */         
/*  203 */         char[] arrayOfChar = this.originalSql.toCharArray();
/*  204 */         StringBuffer stringBuffer = new StringBuffer();
/*      */         
/*  206 */         byte b1 = 0;
/*      */         
/*  208 */         for (byte b2 = 0; b2 < arrayOfChar.length; b2++) {
/*      */           
/*  210 */           if (arrayOfChar[b2] != '?') {
/*      */             
/*  212 */             stringBuffer.append(arrayOfChar[b2]);
/*      */           }
/*      */           else {
/*      */             
/*  216 */             stringBuffer.append(this.bindParameterList[b1++]);
/*  217 */             stringBuffer.append("=>" + nextArgument());
/*      */           } 
/*      */         } 
/*      */         
/*  221 */         this.parameterSql = stringBuffer.toString();
/*  222 */         this.actualSql = null;
/*  223 */         this.utickSql = null;
/*  224 */         this.processedSql = null;
/*  225 */         this.rowidSql = null;
/*  226 */         this.sqlBytes = null;
/*      */       }
/*      */       else {
/*      */         
/*  230 */         this.parameterSql = this.cachedParameterSql;
/*  231 */         this.actualSql = this.cachedActualSql;
/*  232 */         this.utickSql = this.cachedUtickSql;
/*  233 */         this.processedSql = this.cachedProcessedSql;
/*  234 */         this.rowidSql = this.cachedRowidSql;
/*  235 */         this.sqlBytes = this.cachedSqlBytes;
/*      */       } 
/*      */     } 
/*      */     
/*  239 */     this.cachedBindParameterList = null;
/*  240 */     this.cachedParameterSql = null;
/*  241 */     this.cachedActualSql = null;
/*  242 */     this.cachedUtickSql = null;
/*  243 */     this.cachedProcessedSql = null;
/*  244 */     this.cachedRowidSql = null;
/*  245 */     this.cachedSqlBytes = null;
/*      */     
/*  247 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetNamedParameters() {
/*  257 */     this.cachedBindParameterCount = this.bindParameterCount;
/*      */     
/*  259 */     if (this.bindParameterCount != -1) {
/*      */       
/*  261 */       if (this.cachedBindParameterList == null || this.cachedBindParameterList == this.bindParameterList || this.cachedBindParameterList.length < this.bindParameterCount)
/*      */       {
/*      */         
/*  264 */         this.cachedBindParameterList = new String[this.bindParameterCount];
/*      */       }
/*  266 */       System.arraycopy(this.bindParameterList, 0, this.cachedBindParameterList, 0, this.bindParameterCount);
/*      */ 
/*      */       
/*  269 */       this.cachedParameterSql = this.parameterSql;
/*  270 */       this.cachedActualSql = this.actualSql;
/*  271 */       this.cachedUtickSql = this.utickSql;
/*  272 */       this.cachedProcessedSql = this.processedSql;
/*  273 */       this.cachedRowidSql = this.rowidSql;
/*  274 */       this.cachedSqlBytes = this.sqlBytes;
/*      */       
/*  276 */       this.bindParameterCount = -1;
/*  277 */       this.bindParameterList = null;
/*  278 */       this.parameterSql = this.originalSql;
/*  279 */       this.actualSql = null;
/*  280 */       this.utickSql = null;
/*  281 */       this.processedSql = null;
/*  282 */       this.rowidSql = null;
/*  283 */       this.sqlBytes = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getSql(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/*  302 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*  303 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*      */     
/*  306 */     if (paramBoolean1 != this.currentProcessEscapes || paramBoolean2 != this.currentConvertNcharLiterals) {
/*      */ 
/*      */       
/*  309 */       if (paramBoolean2 != this.currentConvertNcharLiterals) {
/*  310 */         this.utickSql = null;
/*      */       }
/*      */       
/*  313 */       this.processedSql = null;
/*  314 */       this.rowidSql = null;
/*  315 */       this.actualSql = null;
/*  316 */       this.sqlBytes = null;
/*      */     } 
/*      */     
/*  319 */     this.currentConvertNcharLiterals = paramBoolean2;
/*  320 */     this.currentProcessEscapes = paramBoolean1;
/*      */     
/*  322 */     if (this.actualSql == null) {
/*  323 */       if (this.utickSql == null) {
/*  324 */         this.utickSql = this.currentConvertNcharLiterals ? convertNcharLiterals(this.parameterSql) : this.parameterSql;
/*      */       }
/*      */       
/*  327 */       if (this.processedSql == null) {
/*  328 */         this.processedSql = this.currentProcessEscapes ? parse(this.utickSql) : this.utickSql;
/*      */       }
/*  330 */       if (this.rowidSql == null) {
/*  331 */         this.rowidSql = this.includeRowid ? addRowid(this.processedSql) : this.processedSql;
/*      */       }
/*  333 */       this.actualSql = this.rowidSql;
/*      */     } 
/*      */ 
/*      */     
/*  337 */     return this.actualSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getRevisedSql() throws SQLException {
/*  346 */     String str = null;
/*      */     
/*  348 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) computeBasicInfo(this.parameterSql);
/*      */     
/*  350 */     str = removeForUpdate(this.parameterSql);
/*      */     
/*  352 */     return addRowid(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String removeForUpdate(String paramString) throws SQLException {
/*  367 */     if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {
/*      */ 
/*      */ 
/*      */       
/*  371 */       paramString = paramString.substring(0, this.orderByStartIndex);
/*      */     }
/*  373 */     else if (this.forUpdateStartIndex != -1) {
/*      */       
/*  375 */       paramString = paramString.substring(0, this.forUpdateStartIndex);
/*      */     } 
/*      */     
/*  378 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void appendForUpdate(StringBuffer paramStringBuffer) throws SQLException {
/*  396 */     if (this.orderByStartIndex != -1 && (this.forUpdateStartIndex == -1 || this.forUpdateStartIndex > this.orderByStartIndex)) {
/*      */ 
/*      */ 
/*      */       
/*  400 */       paramStringBuffer.append(this.originalSql.substring(this.orderByStartIndex));
/*      */     }
/*  402 */     else if (this.forUpdateStartIndex != -1) {
/*      */       
/*  404 */       paramStringBuffer.append(this.originalSql.substring(this.forUpdateStartIndex));
/*      */     } 
/*      */   }
/*      */   
/*      */   protected OracleSql(DBConversion paramDBConversion) {
/*  409 */     this.stringBufferForScrollableStatement = null;
/*      */     this.conversion = paramDBConversion;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getInsertSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet) throws SQLException {
/*  422 */     String str = getOriginalSql();
/*  423 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  425 */     if (this.stringBufferForScrollableStatement == null) {
/*  426 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  428 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*  430 */     this.stringBufferForScrollableStatement.append("insert into (");
/*      */     
/*  432 */     this.stringBufferForScrollableStatement.append(removeForUpdate(str));
/*  433 */     this.stringBufferForScrollableStatement.append(") values ( ");
/*      */     
/*  435 */     byte b = 1;
/*  436 */     for (; b < paramUpdatableResultSet.getColumnCount(); 
/*  437 */       b++) {
/*      */       
/*  439 */       if (b != 1) {
/*  440 */         this.stringBufferForScrollableStatement.append(", ");
/*      */       }
/*  442 */       if (bool) {
/*  443 */         this.stringBufferForScrollableStatement.append("?");
/*      */       } else {
/*  445 */         this.stringBufferForScrollableStatement.append(":" + generateParameterName());
/*      */       } 
/*      */     } 
/*  448 */     this.stringBufferForScrollableStatement.append(")");
/*      */     
/*  450 */     this.paramSuffix = 0;
/*      */     
/*  452 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getRefetchSqlForScrollableResultSet(ScrollableResultSet paramScrollableResultSet, int paramInt) throws SQLException {
/*  472 */     String str = getRevisedSql();
/*  473 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  475 */     if (this.stringBufferForScrollableStatement == null) {
/*  476 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  478 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*      */     
/*  481 */     this.stringBufferForScrollableStatement.append(str);
/*      */     
/*  483 */     if (this.whereStartIndex == -1) {
/*      */       
/*  485 */       this.stringBufferForScrollableStatement.append(bool ? " WHERE ( ROWID = ?" : (" WHERE ( ROWID = :" + generateParameterName()));
/*      */     } else {
/*      */       
/*  488 */       this.stringBufferForScrollableStatement.append(bool ? " AND ( ROWID = ?" : (" AND ( ROWID = :" + generateParameterName()));
/*      */     } 
/*      */     
/*  491 */     for (byte b = 0; b < paramInt - 1; b++) {
/*  492 */       if (bool) {
/*  493 */         this.stringBufferForScrollableStatement.append(" OR ROWID = ?");
/*      */       } else {
/*      */         
/*  496 */         this.stringBufferForScrollableStatement.append(" OR ROWID = :" + generateParameterName());
/*      */       } 
/*  498 */     }  this.stringBufferForScrollableStatement.append(" ) ");
/*      */ 
/*      */     
/*  501 */     appendForUpdate(this.stringBufferForScrollableStatement);
/*      */     
/*  503 */     this.paramSuffix = 0;
/*      */     
/*  505 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getUpdateSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet, int paramInt, Object[] paramArrayOfObject, int[] paramArrayOfint) throws SQLException {
/*  523 */     String str = getRevisedSql();
/*  524 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  526 */     if (this.stringBufferForScrollableStatement == null) {
/*  527 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  529 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*      */ 
/*      */     
/*  533 */     this.stringBufferForScrollableStatement.append("update (");
/*  534 */     this.stringBufferForScrollableStatement.append(str);
/*  535 */     this.stringBufferForScrollableStatement.append(") set ");
/*      */ 
/*      */     
/*  538 */     if (paramArrayOfObject != null)
/*      */     {
/*  540 */       for (byte b = 0; b < paramInt; b++) {
/*      */         
/*  542 */         if (b > 0) {
/*  543 */           this.stringBufferForScrollableStatement.append(", ");
/*      */         }
/*  545 */         this.stringBufferForScrollableStatement.append(paramUpdatableResultSet.getInternalMetadata().getColumnName(paramArrayOfint[b] + 1));
/*      */ 
/*      */         
/*  548 */         if (bool) {
/*  549 */           this.stringBufferForScrollableStatement.append(" = ?");
/*      */         } else {
/*  551 */           this.stringBufferForScrollableStatement.append(" = :" + generateParameterName());
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  556 */     this.stringBufferForScrollableStatement.append(" WHERE ");
/*  557 */     if (bool) {
/*  558 */       this.stringBufferForScrollableStatement.append(" ROWID = ?");
/*      */     } else {
/*  560 */       this.stringBufferForScrollableStatement.append(" ROWID = :" + generateParameterName());
/*      */     } 
/*      */     
/*  563 */     this.paramSuffix = 0;
/*      */     
/*  565 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getDeleteSqlForUpdatableResultSet(UpdatableResultSet paramUpdatableResultSet) throws SQLException {
/*  581 */     String str = getRevisedSql();
/*  582 */     boolean bool = generatedSqlNeedEscapeProcessing();
/*      */     
/*  584 */     if (this.stringBufferForScrollableStatement == null) {
/*  585 */       this.stringBufferForScrollableStatement = new StringBuffer(str.length() + 100);
/*      */     } else {
/*  587 */       this.stringBufferForScrollableStatement.delete(0, this.stringBufferForScrollableStatement.length());
/*      */     } 
/*      */ 
/*      */     
/*  591 */     this.stringBufferForScrollableStatement.append("delete from (");
/*  592 */     this.stringBufferForScrollableStatement.append(str);
/*  593 */     this.stringBufferForScrollableStatement.append(") where ");
/*      */     
/*  595 */     if (bool) {
/*  596 */       this.stringBufferForScrollableStatement.append(" ROWID = ?");
/*      */     } else {
/*  598 */       this.stringBufferForScrollableStatement.append(" ROWID = :" + generateParameterName());
/*      */     } 
/*      */     
/*  601 */     this.paramSuffix = 0;
/*      */     
/*  603 */     return this.stringBufferForScrollableStatement.substring(0, this.stringBufferForScrollableStatement.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean generatedSqlNeedEscapeProcessing() {
/*  615 */     return (this.parameterCount > 0 && this.parameterList == EMPTY_LIST);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] getSqlBytes(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/*  628 */     if (this.sqlBytes == null || paramBoolean1 != this.currentProcessEscapes)
/*      */     {
/*  630 */       this.sqlBytes = this.conversion.StringToCharBytes(getSql(paramBoolean1, paramBoolean2));
/*      */     }
/*      */ 
/*      */     
/*  634 */     return this.sqlBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement.SqlKind getSqlKind() throws SQLException {
/*  648 */     if (this.parameterSql == null) {
/*  649 */       return OracleStatement.SqlKind.UNINITIALIZED;
/*      */     }
/*  651 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*  652 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*  654 */     return this.sqlKind;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getParameterCount() throws SQLException {
/*  668 */     if (this.parameterCount == -1)
/*      */     {
/*  670 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*      */     
/*  673 */     return this.parameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getParameterList() throws SQLException {
/*  690 */     if (this.parameterCount == -1)
/*      */     {
/*  692 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*      */     
/*  695 */     return this.parameterList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setIncludeRowid(boolean paramBoolean) {
/*  710 */     if (paramBoolean != this.includeRowid) {
/*      */       
/*  712 */       this.includeRowid = paramBoolean;
/*  713 */       this.rowidSql = null;
/*  714 */       this.actualSql = null;
/*  715 */       this.sqlBytes = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  724 */     return (this.parameterSql == null) ? "null" : this.parameterSql;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String hexUnicode(int paramInt) throws SQLException {
/*  740 */     String str = Integer.toHexString(paramInt);
/*  741 */     switch (str.length()) {
/*      */       case 0:
/*  743 */         return "\\0000";
/*  744 */       case 1: return "\\000" + str;
/*  745 */       case 2: return "\\00" + str;
/*  746 */       case 3: return "\\0" + str;
/*  747 */       case 4: return "\\" + str;
/*      */     } 
/*      */     
/*  750 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "Unexpected case in OracleSql.hexUnicode: " + paramInt);
/*  751 */     sQLException.fillInStackTrace();
/*  752 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String convertNcharLiterals(String paramString) throws SQLException {
/*  775 */     if (this.lastNcharLiteralLocation <= 2) return paramString; 
/*  776 */     String str = "";
/*  777 */     byte b = 0;
/*      */     
/*      */     while (true) {
/*  780 */       int i = this.ncharLiteralLocation[b++];
/*  781 */       int j = this.ncharLiteralLocation[b++];
/*      */       
/*  783 */       str = str + paramString.substring(i, j);
/*  784 */       if (b >= this.lastNcharLiteralLocation)
/*  785 */         break;  i = this.ncharLiteralLocation[b];
/*  786 */       str = str + "u'";
/*      */       
/*  788 */       for (int k = j + 2; k < i; k++) {
/*      */         
/*  790 */         char c = paramString.charAt(k);
/*  791 */         if (c == '\\') { str = str + "\\\\"; }
/*  792 */         else if (c < '') { str = str + c; }
/*  793 */         else { str = str + hexUnicode(c); }
/*      */       
/*      */       } 
/*  796 */     }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  804 */   private static final int[][] TRANSITION = OracleSqlReadOnly.TRANSITION;
/*      */ 
/*      */   
/*  807 */   private static final int[][] ACTION = OracleSqlReadOnly.ACTION;
/*      */   
/*      */   private static final int NO_ACTION = 0;
/*      */   
/*      */   private static final int DELETE_ACTION = 1;
/*      */   
/*      */   private static final int INSERT_ACTION = 2;
/*      */   
/*      */   private static final int MERGE_ACTION = 3;
/*      */   
/*      */   private static final int UPDATE_ACTION = 4;
/*      */   
/*      */   private static final int PLSQL_ACTION = 5;
/*      */   
/*      */   private static final int CALL_ACTION = 6;
/*      */   private static final int SELECT_ACTION = 7;
/*      */   private static final int ORDER_ACTION = 10;
/*      */   private static final int ORDER_BY_ACTION = 11;
/*      */   private static final int WHERE_ACTION = 9;
/*      */   private static final int FOR_ACTION = 12;
/*      */   private static final int FOR_UPDATE_ACTION = 13;
/*      */   private static final int OTHER_ACTION = 8;
/*      */   private static final int QUESTION_ACTION = 14;
/*      */   private static final int PARAMETER_ACTION = 15;
/*      */   private static final int END_PARAMETER_ACTION = 16;
/*      */   private static final int START_NCHAR_LITERAL_ACTION = 17;
/*      */   private static final int END_NCHAR_LITERAL_ACTION = 18;
/*      */   private static final int SAVE_DELIMITER_ACTION = 19;
/*      */   private static final int LOOK_FOR_DELIMITER_ACTION = 20;
/*      */   private static final int ALTER_SESSION_ACTION = 21;
/*      */   private static final int RETURNING_ACTION = 22;
/*      */   private static final int INTO_ACTION = 23;
/*      */   private static final int INITIAL_STATE = 0;
/*      */   private static final int RESTART_STATE = 66;
/*  841 */   private static final OracleSqlReadOnly.ODBCAction[][] ODBC_ACTION = OracleSqlReadOnly.ODBC_ACTION;
/*      */ 
/*      */   
/*      */   private static final boolean DEBUG_CBI = false;
/*      */ 
/*      */   
/*      */   int current_argument;
/*      */ 
/*      */   
/*      */   int i;
/*      */ 
/*      */   
/*      */   int length;
/*      */ 
/*      */   
/*      */   char currentChar;
/*      */ 
/*      */   
/*      */   boolean first;
/*      */ 
/*      */   
/*      */   String odbc_sql;
/*      */ 
/*      */   
/*      */   StringBuffer oracle_sql;
/*      */ 
/*      */   
/*      */   StringBuffer token_buffer;
/*      */ 
/*      */   
/*      */   void computeBasicInfo(String paramString) throws SQLException {
/*  872 */     this.parameterCount = 0;
/*  873 */     boolean bool1 = false;
/*  874 */     boolean bool2 = false;
/*  875 */     this.returningIntoParameterCount = 0;
/*      */     
/*  877 */     this.lastNcharLiteralLocation = 0;
/*  878 */     this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = 0;
/*      */     
/*  880 */     byte b1 = 0;
/*      */     
/*  882 */     byte b2 = 0;
/*      */     
/*  884 */     int i = 0;
/*  885 */     int j = paramString.length();
/*  886 */     int k = -1;
/*  887 */     int m = -1;
/*  888 */     int n = j + 1;
/*      */ 
/*      */     
/*  891 */     for (byte b3 = 0; b3 < n; b3++) {
/*      */       
/*  893 */       byte b = (b3 < j) ? paramString.charAt(b3) : 32;
/*  894 */       this.currentChar = b;
/*      */       
/*  896 */       if (b > 127)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  902 */         if (Character.isLetterOrDigit(b)) {
/*  903 */           this.currentChar = 'X';
/*      */         } else {
/*  905 */           this.currentChar = ' ';
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  910 */       switch (ACTION[i][this.currentChar]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 1:
/*  917 */           this.sqlKind = OracleStatement.SqlKind.DELETE;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 2:
/*  922 */           this.sqlKind = OracleStatement.SqlKind.INSERT;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 3:
/*  927 */           this.sqlKind = OracleStatement.SqlKind.MERGE;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 4:
/*  932 */           this.sqlKind = OracleStatement.SqlKind.UPDATE;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 5:
/*  937 */           this.sqlKind = OracleStatement.SqlKind.PLSQL_BLOCK;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 6:
/*  942 */           this.sqlKind = OracleStatement.SqlKind.CALL_BLOCK;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 7:
/*  947 */           this.sqlKind = OracleStatement.SqlKind.SELECT;
/*  948 */           this.selectEndIndex = b3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 8:
/*  953 */           this.sqlKind = OracleStatement.SqlKind.OTHER;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 9:
/*  958 */           this.whereStartIndex = b3 - 5;
/*  959 */           this.whereEndIndex = b3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 10:
/*  964 */           k = b3 - 5;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 11:
/*  969 */           this.orderByStartIndex = k;
/*  970 */           this.orderByEndIndex = b3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 12:
/*  975 */           m = b3 - 3;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 13:
/*  980 */           this.forUpdateStartIndex = m;
/*  981 */           this.forUpdateEndIndex = b3;
/*  982 */           if (this.sqlKind == OracleStatement.SqlKind.SELECT) {
/*  983 */             this.sqlKind = OracleStatement.SqlKind.SELECT_FOR_UPDATE;
/*      */           }
/*      */           break;
/*      */         
/*      */         case 21:
/*  988 */           this.sqlKind = OracleStatement.SqlKind.ALTER_SESSION;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 14:
/*  993 */           this.parameterCount++;
/*  994 */           if (bool2) this.returningIntoParameterCount++;
/*      */           
/*      */           break;
/*      */         
/*      */         case 15:
/*  999 */           if (this.currentParameter == null) {
/* 1000 */             this.currentParameter = new char[32];
/*      */           }
/* 1002 */           if (b2 >= this.currentParameter.length) {
/*      */             
/* 1004 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 134, new String(this.currentParameter));
/* 1005 */             sQLException.fillInStackTrace();
/* 1006 */             throw sQLException;
/*      */           } 
/*      */           
/* 1009 */           this.currentParameter[b2++] = b;
/*      */           break;
/*      */ 
/*      */         
/*      */         case 16:
/* 1014 */           if (b2 > 0) {
/*      */             
/* 1016 */             if (this.parameterList == EMPTY_LIST) {
/*      */               
/* 1018 */               this.parameterList = new String[Math.max(8, this.parameterCount * 4)];
/*      */             }
/* 1020 */             else if (this.parameterList.length <= this.parameterCount) {
/*      */               
/* 1022 */               String[] arrayOfString = new String[this.parameterList.length * 4];
/*      */               
/* 1024 */               System.arraycopy(this.parameterList, 0, arrayOfString, 0, this.parameterList.length);
/*      */ 
/*      */               
/* 1027 */               this.parameterList = arrayOfString;
/*      */             } 
/*      */             
/* 1030 */             this.parameterList[this.parameterCount] = (new String(this.currentParameter, 0, b2)).intern();
/*      */             
/* 1032 */             b2 = 0;
/* 1033 */             this.parameterCount++;
/* 1034 */             if (bool2) this.returningIntoParameterCount++;
/*      */           
/*      */           } 
/*      */           break;
/*      */         
/*      */         case 17:
/* 1040 */           this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = b3 - 1;
/* 1041 */           if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
/* 1042 */             growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
/*      */           }
/*      */           break;
/*      */         case 18:
/* 1046 */           this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = b3;
/* 1047 */           if (this.lastNcharLiteralLocation >= this.ncharLiteralLocation.length) {
/* 1048 */             growNcharLiteralLocation(this.ncharLiteralLocation.length << 2);
/*      */           }
/*      */           break;
/*      */         
/*      */         case 19:
/* 1053 */           if (b == 91) { b1 = 93; break; }
/* 1054 */            if (b == 123) { b1 = 125; break; }
/* 1055 */            if (b == 60) { b1 = 62; break; }
/* 1056 */            if (b == 40) { b1 = 41; break; }
/* 1057 */            b1 = b;
/*      */           break;
/*      */         
/*      */         case 20:
/* 1061 */           if (b == b1)
/*      */           {
/*      */             
/* 1064 */             i++;
/*      */           }
/*      */           break;
/*      */ 
/*      */         
/*      */         case 22:
/* 1070 */           bool1 = true;
/*      */           break;
/*      */         
/*      */         case 23:
/* 1074 */           if (bool1) bool2 = true;
/*      */           
/*      */           break;
/*      */       } 
/* 1078 */       i = TRANSITION[i][this.currentChar];
/*      */     } 
/*      */     
/* 1081 */     if (this.lastNcharLiteralLocation + 2 >= this.ncharLiteralLocation.length)
/* 1082 */       growNcharLiteralLocation(this.lastNcharLiteralLocation + 2); 
/* 1083 */     this.ncharLiteralLocation[this.lastNcharLiteralLocation++] = j;
/* 1084 */     this.ncharLiteralLocation[this.lastNcharLiteralLocation] = j;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void growNcharLiteralLocation(int paramInt) {
/* 1092 */     int[] arrayOfInt = new int[paramInt];
/* 1093 */     System.arraycopy(this.ncharLiteralLocation, 0, arrayOfInt, 0, this.ncharLiteralLocation.length);
/* 1094 */     this.ncharLiteralLocation = null;
/* 1095 */     this.ncharLiteralLocation = arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String addRowid(String paramString) throws SQLException {
/* 1102 */     if (this.selectEndIndex == -1) {
/*      */       
/* 1104 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 88);
/* 1105 */       sQLException.fillInStackTrace();
/* 1106 */       throw sQLException;
/*      */     } 
/*      */     
/* 1109 */     return "select rowid as \"__Oracle_JDBC_interal_ROWID__\"," + paramString.substring(this.selectEndIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum ParseMode
/*      */   {
/* 1124 */     NORMAL, SCALAR, LOCATE_1, LOCATE_2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String parse(String paramString) throws SQLException {
/* 1143 */     this.first = true;
/* 1144 */     this.current_argument = 1;
/* 1145 */     this.i = 0;
/* 1146 */     this.odbc_sql = paramString;
/* 1147 */     this.length = this.odbc_sql.length();
/*      */     
/* 1149 */     if (this.oracle_sql == null) {
/*      */       
/* 1151 */       this.oracle_sql = new StringBuffer(this.length);
/* 1152 */       this.token_buffer = new StringBuffer(32);
/*      */     }
/*      */     else {
/*      */       
/* 1156 */       this.oracle_sql.ensureCapacity(this.length);
/*      */     } 
/*      */     
/* 1159 */     this.oracle_sql.delete(0, this.oracle_sql.length());
/* 1160 */     skipSpace();
/* 1161 */     handleODBC(ParseMode.NORMAL);
/*      */     
/* 1163 */     if (this.i < this.length) {
/*      */       
/* 1165 */       Integer integer = Integer.valueOf(this.i);
/*      */ 
/*      */       
/* 1168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, integer);
/* 1169 */       sQLException.fillInStackTrace();
/* 1170 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1174 */     return this.oracle_sql.substring(0, this.oracle_sql.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleODBC(ParseMode paramParseMode) throws SQLException {
/* 1184 */     int i = (paramParseMode == ParseMode.NORMAL) ? 0 : 66;
/* 1185 */     byte b1 = 0;
/* 1186 */     byte b2 = 0;
/*      */     
/* 1188 */     while (this.i < this.length) {
/*      */       SQLException sQLException;
/* 1190 */       byte b = (this.i < this.length) ? this.odbc_sql.charAt(this.i) : 32;
/* 1191 */       this.currentChar = b;
/*      */       
/* 1193 */       if (b > 127)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1199 */         if (Character.isLetterOrDigit(b)) {
/* 1200 */           this.currentChar = 'X';
/*      */         } else {
/* 1202 */           this.currentChar = ' ';
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/* 1207 */       switch (ODBC_ACTION[i][this.currentChar]) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case COPY:
/* 1214 */           this.oracle_sql.append(b);
/*      */           break;
/*      */         
/*      */         case QUESTION:
/* 1218 */           this.oracle_sql.append(nextArgument());
/* 1219 */           this.oracle_sql.append(' ');
/*      */           break;
/*      */         
/*      */         case SAVE_DELIMITER:
/* 1223 */           if (b == 91) { b1 = 93; }
/* 1224 */           else if (b == 123) { b1 = 125; }
/* 1225 */           else if (b == 60) { b1 = 62; }
/* 1226 */           else if (b == 40) { b1 = 41; }
/* 1227 */           else { b1 = b; }
/* 1228 */            this.oracle_sql.append(b);
/*      */           break;
/*      */         
/*      */         case LOOK_FOR_DELIMITER:
/* 1232 */           if (b == b1)
/*      */           {
/*      */             
/* 1235 */             i++;
/*      */           }
/* 1237 */           this.oracle_sql.append(b);
/*      */           break;
/*      */         
/*      */         case FUNCTION:
/* 1241 */           handleFunction();
/*      */           break;
/*      */         
/*      */         case CALL:
/* 1245 */           handleCall();
/*      */           break;
/*      */         
/*      */         case TIME:
/* 1249 */           handleTime();
/*      */           break;
/*      */         
/*      */         case TIMESTAMP:
/* 1253 */           handleTimestamp();
/*      */           break;
/*      */         
/*      */         case DATE:
/* 1257 */           handleDate();
/*      */           break;
/*      */         
/*      */         case ESCAPE:
/* 1261 */           handleEscape();
/*      */           break;
/*      */         
/*      */         case SCALAR_FUNCTION:
/* 1265 */           handleScalarFunction();
/*      */           break;
/*      */         
/*      */         case OUTER_JOIN:
/* 1269 */           handleOuterJoin();
/*      */           break;
/*      */ 
/*      */         
/*      */         case UNKNOWN_ESCAPE:
/* 1274 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, Integer.valueOf(this.i));
/* 1275 */           sQLException.fillInStackTrace();
/* 1276 */           throw sQLException;
/*      */ 
/*      */         
/*      */         case END_ODBC_ESCAPE:
/* 1280 */           if (paramParseMode == ParseMode.SCALAR) {
/*      */             
/* 1282 */             i = TRANSITION[i][this.currentChar];
/*      */             return;
/*      */           } 
/*      */ 
/*      */ 
/*      */         
/*      */         case COMMA:
/* 1289 */           if (paramParseMode == ParseMode.LOCATE_1 && b2 > 1) {
/* 1290 */             this.oracle_sql.append(b); break;
/*      */           } 
/* 1292 */           if (paramParseMode == ParseMode.LOCATE_1) {
/*      */             
/* 1294 */             i = TRANSITION[i][this.currentChar];
/*      */             return;
/*      */           } 
/* 1297 */           if (paramParseMode == ParseMode.LOCATE_2) {
/*      */             break;
/*      */           }
/*      */ 
/*      */           
/* 1302 */           this.oracle_sql.append(b);
/*      */           break;
/*      */ 
/*      */         
/*      */         case OPEN_PAREN:
/* 1307 */           if (paramParseMode == ParseMode.LOCATE_1) {
/* 1308 */             if (b2 > 0) this.oracle_sql.append(b); 
/* 1309 */             b2++; break;
/*      */           } 
/* 1311 */           if (paramParseMode == ParseMode.LOCATE_2) {
/* 1312 */             b2++;
/* 1313 */             this.oracle_sql.append(b);
/*      */             
/*      */             break;
/*      */           } 
/* 1317 */           this.oracle_sql.append(b);
/*      */           break;
/*      */ 
/*      */         
/*      */         case CLOSE_PAREN:
/* 1322 */           if (paramParseMode == ParseMode.LOCATE_1) {
/* 1323 */             b2--;
/* 1324 */             this.oracle_sql.append(b); break;
/*      */           } 
/* 1326 */           if (paramParseMode == ParseMode.LOCATE_2 && b2 > 1) {
/* 1327 */             b2--;
/* 1328 */             this.oracle_sql.append(b); break;
/*      */           } 
/* 1330 */           if (paramParseMode == ParseMode.LOCATE_2) {
/* 1331 */             this.i++;
/*      */             
/* 1333 */             i = TRANSITION[i][this.currentChar];
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/* 1338 */           this.oracle_sql.append(b);
/*      */           break;
/*      */ 
/*      */         
/*      */         case BEGIN:
/* 1343 */           this.first = false;
/* 1344 */           this.oracle_sql.append(b);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 1349 */       i = TRANSITION[i][this.currentChar];
/* 1350 */       this.i++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleFunction() throws SQLException {
/* 1359 */     boolean bool = this.first;
/* 1360 */     this.first = false;
/*      */     
/* 1362 */     if (bool) {
/* 1363 */       this.oracle_sql.append("BEGIN ");
/*      */     }
/* 1365 */     appendChar(this.oracle_sql, '?');
/* 1366 */     skipSpace();
/*      */     
/* 1368 */     if (this.currentChar != '=') {
/*      */       
/* 1370 */       String str = this.i + ". Expecting \"=\" got \"" + this.currentChar + "\"";
/*      */ 
/*      */       
/* 1373 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, str);
/* 1374 */       sQLException.fillInStackTrace();
/* 1375 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1379 */     this.i++;
/*      */     
/* 1381 */     skipSpace();
/*      */     
/* 1383 */     if (!this.odbc_sql.startsWith("call", this.i)) {
/*      */       
/* 1385 */       String str = this.i + ". Expecting \"call\"";
/*      */ 
/*      */       
/* 1388 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33, str);
/* 1389 */       sQLException.fillInStackTrace();
/* 1390 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1394 */     this.i += 4;
/*      */     
/* 1396 */     this.oracle_sql.append(" := ");
/* 1397 */     skipSpace();
/* 1398 */     handleODBC(ParseMode.SCALAR);
/*      */     
/* 1400 */     if (bool) {
/* 1401 */       this.oracle_sql.append("; END;");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleCall() throws SQLException {
/* 1409 */     boolean bool = this.first;
/* 1410 */     this.first = false;
/*      */     
/* 1412 */     if (bool) {
/* 1413 */       this.oracle_sql.append("BEGIN ");
/*      */     }
/* 1415 */     skipSpace();
/* 1416 */     handleODBC(ParseMode.SCALAR);
/* 1417 */     skipSpace();
/*      */     
/* 1419 */     if (bool) {
/* 1420 */       this.oracle_sql.append("; END;");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleTimestamp() throws SQLException {
/* 1429 */     this.oracle_sql.append("TO_TIMESTAMP (");
/* 1430 */     skipSpace();
/* 1431 */     handleODBC(ParseMode.SCALAR);
/* 1432 */     this.oracle_sql.append(", 'YYYY-MM-DD HH24:MI:SS.FF')");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleTime() throws SQLException {
/* 1439 */     this.oracle_sql.append("TO_DATE (");
/* 1440 */     skipSpace();
/* 1441 */     handleODBC(ParseMode.SCALAR);
/* 1442 */     this.oracle_sql.append(", 'HH24:MI:SS')");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleDate() throws SQLException {
/* 1449 */     this.oracle_sql.append("TO_DATE (");
/* 1450 */     skipSpace();
/* 1451 */     handleODBC(ParseMode.SCALAR);
/* 1452 */     this.oracle_sql.append(", 'YYYY-MM-DD')");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleEscape() throws SQLException {
/* 1459 */     this.oracle_sql.append("ESCAPE ");
/* 1460 */     skipSpace();
/* 1461 */     handleODBC(ParseMode.SCALAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleScalarFunction() throws SQLException {
/* 1468 */     this.token_buffer.delete(0, this.token_buffer.length());
/*      */     
/* 1470 */     this.i++;
/*      */     
/* 1472 */     skipSpace();
/*      */ 
/*      */ 
/*      */     
/* 1476 */     while (this.i < this.length && (Character.isJavaLetterOrDigit(this.currentChar = this.odbc_sql.charAt(this.i)) || this.currentChar == '?')) {
/*      */ 
/*      */       
/* 1479 */       this.token_buffer.append(this.currentChar);
/*      */       
/* 1481 */       this.i++;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1487 */     String str = this.token_buffer.substring(0, this.token_buffer.length()).toUpperCase().intern();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1495 */     if (str == "ABS")
/* 1496 */     { usingFunctionName(str); }
/* 1497 */     else if (str == "ACOS")
/* 1498 */     { usingFunctionName(str); }
/* 1499 */     else if (str == "ASIN")
/* 1500 */     { usingFunctionName(str); }
/* 1501 */     else if (str == "ATAN")
/* 1502 */     { usingFunctionName(str); }
/* 1503 */     else if (str == "ATAN2")
/* 1504 */     { usingFunctionName(str); }
/* 1505 */     else if (str == "CEILING")
/* 1506 */     { usingFunctionName("CEIL"); }
/* 1507 */     else if (str == "COS")
/* 1508 */     { usingFunctionName(str); }
/* 1509 */     else { if (str == "COT") {
/*      */         
/* 1511 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1512 */         sQLException.fillInStackTrace();
/* 1513 */         throw sQLException;
/*      */       } 
/* 1515 */       if (str == "DEGREES") {
/*      */         
/* 1517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1518 */         sQLException.fillInStackTrace();
/* 1519 */         throw sQLException;
/*      */       } 
/* 1521 */       if (str == "EXP")
/* 1522 */       { usingFunctionName(str); }
/* 1523 */       else if (str == "FLOOR")
/* 1524 */       { usingFunctionName(str); }
/* 1525 */       else if (str == "LOG")
/* 1526 */       { usingFunctionName("LN"); }
/* 1527 */       else if (str == "LOG10")
/* 1528 */       { replacingFunctionPrefix("LOG ( 10, "); }
/* 1529 */       else if (str == "MOD")
/* 1530 */       { usingFunctionName(str); }
/* 1531 */       else if (str == "PI")
/* 1532 */       { replacingFunctionPrefix("( 3.141592653589793238462643383279502884197169399375 "); }
/* 1533 */       else if (str == "POWER")
/* 1534 */       { usingFunctionName(str); }
/* 1535 */       else { if (str == "RADIANS") {
/*      */           
/* 1537 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1538 */           sQLException.fillInStackTrace();
/* 1539 */           throw sQLException;
/*      */         } 
/* 1541 */         if (str == "RAND") {
/*      */           
/* 1543 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1544 */           sQLException.fillInStackTrace();
/* 1545 */           throw sQLException;
/*      */         } 
/* 1547 */         if (str == "ROUND")
/* 1548 */         { usingFunctionName(str); }
/* 1549 */         else if (str == "SIGN")
/* 1550 */         { usingFunctionName(str); }
/* 1551 */         else if (str == "SIN")
/* 1552 */         { usingFunctionName(str); }
/* 1553 */         else if (str == "SQRT")
/* 1554 */         { usingFunctionName(str); }
/* 1555 */         else if (str == "TAN")
/* 1556 */         { usingFunctionName(str); }
/* 1557 */         else if (str == "TRUNCATE")
/* 1558 */         { usingFunctionName("TRUNC");
/*      */            }
/*      */         
/* 1561 */         else if (str == "ASCII")
/* 1562 */         { usingFunctionName(str); }
/* 1563 */         else if (str == "CHAR")
/* 1564 */         { usingFunctionName("CHR");
/*      */           
/*      */            }
/*      */         
/* 1568 */         else if (str == "CONCAT")
/* 1569 */         { usingFunctionName(str); }
/* 1570 */         else { if (str == "DIFFERENCE") {
/*      */             
/* 1572 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1573 */             sQLException.fillInStackTrace();
/* 1574 */             throw sQLException;
/*      */           } 
/* 1576 */           if (str == "INSERT") {
/*      */             
/* 1578 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1579 */             sQLException.fillInStackTrace();
/* 1580 */             throw sQLException;
/*      */           } 
/* 1582 */           if (str == "LCASE")
/* 1583 */           { usingFunctionName("LOWER"); }
/* 1584 */           else { if (str == "LEFT") {
/*      */               
/* 1586 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1587 */               sQLException.fillInStackTrace();
/* 1588 */               throw sQLException;
/*      */             } 
/* 1590 */             if (str == "LENGTH") {
/* 1591 */               usingFunctionName(str);
/* 1592 */             } else if (str == "LOCATE") {
/*      */ 
/*      */ 
/*      */               
/* 1596 */               StringBuffer stringBuffer1 = this.oracle_sql;
/* 1597 */               this.oracle_sql = new StringBuffer();
/* 1598 */               handleODBC(ParseMode.LOCATE_1);
/* 1599 */               StringBuffer stringBuffer2 = this.oracle_sql;
/* 1600 */               this.oracle_sql = stringBuffer1;
/* 1601 */               this.oracle_sql.append("INSTR(");
/* 1602 */               handleODBC(ParseMode.LOCATE_2);
/* 1603 */               this.oracle_sql.append(',');
/* 1604 */               this.oracle_sql.append(stringBuffer2);
/* 1605 */               this.oracle_sql.append(')');
/* 1606 */               handleODBC(ParseMode.SCALAR);
/*      */             }
/* 1608 */             else if (str == "LTRIM") {
/* 1609 */               usingFunctionName(str);
/*      */             }
/*      */             else {
/*      */               
/* 1613 */               if (str == "REPEAT") {
/*      */                 
/* 1615 */                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1616 */                 sQLException.fillInStackTrace();
/* 1617 */                 throw sQLException;
/*      */               } 
/* 1619 */               if (str == "REPLACE")
/* 1620 */               { usingFunctionName(str); }
/* 1621 */               else { if (str == "RIGHT") {
/*      */                   
/* 1623 */                   SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1624 */                   sQLException.fillInStackTrace();
/* 1625 */                   throw sQLException;
/*      */                 } 
/* 1627 */                 if (str == "RTRIM")
/* 1628 */                 { usingFunctionName(str); }
/* 1629 */                 else if (str == "SOUNDEX")
/* 1630 */                 { usingFunctionName(str); }
/* 1631 */                 else { if (str == "SPACE") {
/*      */                     
/* 1633 */                     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1634 */                     sQLException.fillInStackTrace();
/* 1635 */                     throw sQLException;
/*      */                   } 
/* 1637 */                   if (str == "SUBSTRING")
/* 1638 */                   { usingFunctionName("SUBSTR"); }
/* 1639 */                   else if (str == "UCASE")
/* 1640 */                   { usingFunctionName("UPPER");
/*      */ 
/*      */ 
/*      */ 
/*      */                     
/*      */                      }
/*      */                   
/* 1647 */                   else if (str == "CURDATE")
/* 1648 */                   { replacingFunctionPrefix("(CURRENT_DATE"); }
/* 1649 */                   else if (str == "CURTIME")
/* 1650 */                   { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
/* 1651 */                   else { if (str == "DAYNAME") {
/*      */                       
/* 1653 */                       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1654 */                       sQLException.fillInStackTrace();
/* 1655 */                       throw sQLException;
/*      */                     } 
/* 1657 */                     if (str == "DAYOFMONTH")
/* 1658 */                     { replacingFunctionPrefix("EXTRACT ( DAY FROM "); }
/* 1659 */                     else { if (str == "DAYOFWEEK") {
/*      */                         
/* 1661 */                         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1662 */                         sQLException.fillInStackTrace();
/* 1663 */                         throw sQLException;
/*      */                       } 
/* 1665 */                       if (str == "DAYOFYEAR") {
/*      */                         
/* 1667 */                         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1668 */                         sQLException.fillInStackTrace();
/* 1669 */                         throw sQLException;
/*      */                       } 
/*      */ 
/*      */ 
/*      */                       
/* 1674 */                       if (str == "HOUR")
/* 1675 */                       { replacingFunctionPrefix("EXTRACT ( HOUR FROM "); }
/* 1676 */                       else if (str == "MINUTE")
/* 1677 */                       { replacingFunctionPrefix("EXTRACT ( MINUTE FROM "); }
/* 1678 */                       else if (str == "MONTH")
/* 1679 */                       { replacingFunctionPrefix("EXTRACT ( MONTH FROM "); }
/* 1680 */                       else { if (str == "MONTHNAME") {
/*      */                           
/* 1682 */                           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1683 */                           sQLException.fillInStackTrace();
/* 1684 */                           throw sQLException;
/*      */                         } 
/* 1686 */                         if (str == "NOW")
/* 1687 */                         { replacingFunctionPrefix("(CURRENT_TIMESTAMP"); }
/* 1688 */                         else { if (str == "QUARTER") {
/*      */                             
/* 1690 */                             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1691 */                             sQLException.fillInStackTrace();
/* 1692 */                             throw sQLException;
/*      */                           } 
/* 1694 */                           if (str == "SECOND")
/* 1695 */                           { replacingFunctionPrefix("EXTRACT ( SECOND FROM "); }
/* 1696 */                           else { if (str == "TIMESTAMPADD") {
/*      */                               
/* 1698 */                               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1699 */                               sQLException.fillInStackTrace();
/* 1700 */                               throw sQLException;
/*      */                             } 
/* 1702 */                             if (str == "TIMESTAMPDIFF") {
/*      */                               
/* 1704 */                               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1705 */                               sQLException.fillInStackTrace();
/* 1706 */                               throw sQLException;
/*      */                             } 
/* 1708 */                             if (str == "WEEK") {
/*      */                               
/* 1710 */                               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1711 */                               sQLException.fillInStackTrace();
/* 1712 */                               throw sQLException;
/*      */                             } 
/* 1714 */                             if (str == "YEAR")
/* 1715 */                             { replacingFunctionPrefix("EXTRACT ( YEAR FROM "); }
/*      */                             else
/*      */                             
/* 1718 */                             { if (str == "DATABASE") {
/*      */                                 
/* 1720 */                                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1721 */                                 sQLException.fillInStackTrace();
/* 1722 */                                 throw sQLException;
/*      */                               } 
/* 1724 */                               if (str == "IFNULL")
/* 1725 */                               { usingFunctionName("NVL"); }
/* 1726 */                               else if (str == "USER")
/* 1727 */                               { replacingFunctionPrefix("(USER"); }
/*      */                               else
/*      */                               
/* 1730 */                               { if (str == "CONVERT") {
/*      */ 
/*      */                                   
/* 1733 */                                   SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1734 */                                   sQLException1.fillInStackTrace();
/* 1735 */                                   throw sQLException1;
/*      */                                 } 
/*      */ 
/*      */ 
/*      */ 
/*      */                                 
/* 1741 */                                 SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 34, str);
/* 1742 */                                 sQLException.fillInStackTrace();
/* 1743 */                                 throw sQLException; }  }  }  }  }  }  }
/*      */                    }
/*      */                  }
/*      */             
/*      */             }  }
/*      */            }
/*      */          }
/*      */        }
/* 1751 */      } void usingFunctionName(String paramString) throws SQLException { this.oracle_sql.append(paramString);
/* 1752 */     skipSpace();
/* 1753 */     handleODBC(ParseMode.SCALAR); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void replacingFunctionPrefix(String paramString) throws SQLException {
/* 1760 */     skipSpace();
/*      */ 
/*      */     
/* 1763 */     if (this.i < this.length && (this.currentChar = this.odbc_sql.charAt(this.i)) == '(') {
/* 1764 */       this.i++;
/*      */     } else {
/*      */       
/* 1767 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 33);
/* 1768 */       sQLException.fillInStackTrace();
/* 1769 */       throw sQLException;
/*      */     } 
/*      */     
/* 1772 */     this.oracle_sql.append(paramString);
/* 1773 */     skipSpace();
/* 1774 */     handleODBC(ParseMode.SCALAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void handleOuterJoin() throws SQLException {
/* 1781 */     this.oracle_sql.append(" ( ");
/* 1782 */     skipSpace();
/* 1783 */     handleODBC(ParseMode.SCALAR);
/* 1784 */     this.oracle_sql.append(" ) ");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String nextArgument() {
/* 1791 */     String str = ":" + this.current_argument;
/*      */     
/* 1793 */     this.current_argument++;
/*      */     
/* 1795 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void appendChar(StringBuffer paramStringBuffer, char paramChar) {
/* 1802 */     if (paramChar == '?') {
/* 1803 */       paramStringBuffer.append(nextArgument());
/*      */     } else {
/* 1805 */       paramStringBuffer.append(paramChar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void skipSpace() {
/* 1812 */     while (this.i < this.length && (this.currentChar = this.odbc_sql.charAt(this.i)) == ' ') {
/* 1813 */       this.i++;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String generateParameterName() {
/*      */     String str;
/* 1824 */     if (this.parameterCount == 0 || this.parameterList == null)
/*      */     {
/* 1826 */       return "rowid" + this.paramSuffix++;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     label13: while (true) {
/* 1832 */       str = "rowid" + this.paramSuffix++;
/* 1833 */       for (byte b = 0; b < this.parameterList.length; b++)
/*      */       
/* 1835 */       { if (str.equals(this.parameterList[b]))
/*      */           continue label13;  }  break;
/* 1837 */     }  return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isValidPlsqlWarning(String paramString) throws SQLException {
/* 1857 */     return paramString.matches("('\\s*([a-zA-Z0-9:,\\(\\)\\s])*')\\s*(,\\s*'([a-zA-Z0-9:,\\(\\)\\s])*')*");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isValidObjectName(String paramString) throws SQLException {
/* 1875 */     if (paramString.matches("([a-zA-Z]{1}\\w*(\\$|\\#)*\\w*)|(\".*)"))
/*      */     {
/* 1877 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1884 */     char[] arrayOfChar = paramString.toCharArray();
/* 1885 */     int i = arrayOfChar.length;
/*      */ 
/*      */     
/* 1888 */     if (!Character.isLetter(arrayOfChar[0]))
/*      */     {
/* 1890 */       return false;
/*      */     }
/*      */     
/* 1893 */     for (byte b = 1; b < i; b++) {
/*      */       
/* 1895 */       if (!Character.isLetterOrDigit(arrayOfChar[b]) && arrayOfChar[b] != '$' && arrayOfChar[b] != '#' && arrayOfChar[b] != '_')
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1900 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1904 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] paramArrayOfString) {
/*      */     String[] arrayOfString;
/* 1929 */     if (paramArrayOfString.length < 2) {
/* 1930 */       System.err.println("ERROR: incorrect usage. OracleSql (-transition <file> | <process_escapes> <convert_nchars> { <sql> } )");
/*      */       return;
/*      */     } 
/* 1933 */     if (paramArrayOfString[0].equals("-dump")) {
/* 1934 */       dumpTransitionMatrix(paramArrayOfString[1]);
/*      */       return;
/*      */     } 
/* 1937 */     boolean bool1 = paramArrayOfString[0].equals("true");
/* 1938 */     boolean bool2 = paramArrayOfString[1].equals("true");
/*      */ 
/*      */     
/* 1941 */     if (paramArrayOfString.length > 2) {
/* 1942 */       arrayOfString = new String[paramArrayOfString.length - 2];
/* 1943 */       System.arraycopy(paramArrayOfString, 2, arrayOfString, 0, arrayOfString.length);
/*      */     } else {
/*      */       
/* 1946 */       arrayOfString = new String[] { "select ? from dual", "insert into dual values (?)", "delete from dual", "update dual set dummy = ?", "merge tab into dual", " select ? from dual where ? = ?", "select ?from dual where?=?for update", "select '?', n'?', q'???', q'{?}', q'{cat's}' from dual", "select'?',n'?',q'???',q'{?}',q'{cat's}'from dual", "select--line\n? from dual", "select --line\n? from dual", "--line\nselect ? from dual", " --line\nselect ? from dual", "--line\n select ? from dual", "begin proc4in4out (:x1, :x2, :x3, :x4); end;", "{CALL tkpjpn01(:pin, :pinout, :pout)}", "select :NumberBindVar as the_number from dual", "select {fn locate(bob(carol(),ted(alice,sue)), 'xfy')} from dual", "CREATE USER vijay6 IDENTIFIED BY \"vjay?\"", "ALTER SESSION SET TIME", "SELECT ename FROM emp WHERE hiredate BETWEEN {ts'1980-12-17'} AND {ts '1981-09-28'} " };
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1975 */     for (String str : arrayOfString) {
/*      */       try {
/* 1977 */         System.out.println("\n\n-----------------------");
/* 1978 */         System.out.println(str);
/* 1979 */         System.out.println();
/* 1980 */         OracleSql oracleSql = new OracleSql(null);
/*      */         
/* 1982 */         oracleSql.initialize(str);
/* 1983 */         String str1 = oracleSql.getSql(bool1, bool2);
/*      */         
/* 1985 */         System.out.println(oracleSql.sqlKind + ", " + oracleSql.parameterCount);
/*      */         
/* 1987 */         String[] arrayOfString1 = oracleSql.getParameterList();
/*      */         
/* 1989 */         if (arrayOfString1 == EMPTY_LIST) {
/* 1990 */           System.out.println("parameterList is empty");
/*      */         } else {
/* 1992 */           for (byte b = 0; b < arrayOfString1.length; b++)
/* 1993 */             System.out.println("parameterList[" + b + "] = " + arrayOfString1[b]); 
/*      */         } 
/* 1995 */         if (oracleSql.getSqlKind().isDML()) {
/* 1996 */           int i = oracleSql.getReturnParameterCount();
/* 1997 */           if (i == -1) { System.out.println("no return parameters"); }
/* 1998 */           else { System.out.println(i + " return parameters"); }
/*      */         
/*      */         } 
/* 2001 */         if (oracleSql.lastNcharLiteralLocation == 2) { System.out.println("No NCHAR literals"); }
/*      */         else
/* 2003 */         { System.out.println("NCHAR Literals");
/* 2004 */           for (byte b = 1; b < oracleSql.lastNcharLiteralLocation - 1;)
/* 2005 */             System.out.println(str1.substring(oracleSql.ncharLiteralLocation[b++], oracleSql.ncharLiteralLocation[b++]));  }
/*      */         
/* 2007 */         System.out.println("Keywords");
/* 2008 */         if (oracleSql.selectEndIndex == -1) { System.out.println("no select"); }
/* 2009 */         else { System.out.println("'" + str1.substring(oracleSql.selectEndIndex - 6, oracleSql.selectEndIndex) + "'"); }
/* 2010 */          if (oracleSql.orderByStartIndex == -1) { System.out.println("no order by"); }
/* 2011 */         else { System.out.println("'" + str1.substring(oracleSql.orderByStartIndex, oracleSql.orderByEndIndex) + "'"); }
/* 2012 */          if (oracleSql.whereStartIndex == -1) { System.out.println("no where"); }
/* 2013 */         else { System.out.println("'" + str1.substring(oracleSql.whereStartIndex, oracleSql.whereEndIndex) + "'"); }
/* 2014 */          if (oracleSql.forUpdateStartIndex == -1) { System.out.println("no for update"); }
/* 2015 */         else { System.out.println("'" + str1.substring(oracleSql.forUpdateStartIndex, oracleSql.forUpdateEndIndex) + "'"); }
/*      */         
/* 2017 */         System.out.println("isPlsqlOrCall(): " + oracleSql.getSqlKind().isPlsqlOrCall());
/* 2018 */         System.out.println("isDML(): " + oracleSql.getSqlKind().isDML());
/* 2019 */         System.out.println("isSELECT(): " + oracleSql.getSqlKind().isSELECT());
/* 2020 */         System.out.println("isOTHER(): " + oracleSql.getSqlKind().isOTHER());
/* 2021 */         System.out.println("\"" + str1 + "\"");
/* 2022 */         System.out.println("\"" + oracleSql.getRevisedSql() + "\"");
/*      */       }
/* 2024 */       catch (Exception exception) {
/* 2025 */         System.out.println(exception);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private static final void dumpTransitionMatrix(String paramString) {
/*      */     try {
/* 2032 */       PrintWriter printWriter = new PrintWriter(paramString);
/* 2033 */       printWriter.print(",");
/* 2034 */       for (byte b1 = 0; b1 < ''; ) { printWriter.print("'" + ((b1 < 32) ? ("0x" + Integer.toHexString(b1)) : Character.toString((char)b1)) + ((b1 < 127) ? "'," : "'")); b1++; }
/* 2035 */        printWriter.println();
/* 2036 */       int[][] arrayOfInt = OracleSqlReadOnly.TRANSITION;
/* 2037 */       String[] arrayOfString = OracleSqlReadOnly.PARSER_STATE_NAME;
/* 2038 */       for (byte b2 = 0; b2 < TRANSITION.length; b2++) {
/* 2039 */         printWriter.print(arrayOfString[b2] + ",");
/* 2040 */         for (byte b = 0; b < (arrayOfInt[b2]).length; ) { printWriter.print(arrayOfString[arrayOfInt[b2][b]] + ((b < 127) ? "," : "")); b++; }
/* 2041 */          printWriter.println();
/*      */       } 
/* 2043 */       printWriter.close();
/*      */     }
/* 2045 */     catch (Throwable throwable) {
/* 2046 */       System.err.println(throwable);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2063 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getReturnParameterCount() throws SQLException {
/* 2076 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/* 2077 */       computeBasicInfo(this.parameterSql);
/*      */     }
/*      */     
/* 2080 */     if (!this.sqlKind.isDML()) return -1; 
/* 2081 */     return this.returningIntoParameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getSubstrPos(String paramString1, String paramString2) throws SQLException {
/* 2089 */     int i = -1;
/* 2090 */     int j = paramString1.indexOf(paramString2);
/*      */     
/* 2092 */     if (j >= 1 && Character.isWhitespace(paramString1.charAt(j - 1))) {
/*      */ 
/*      */       
/* 2095 */       int k = j + paramString2.length();
/*      */       
/* 2097 */       if (k < paramString1.length() && Character.isWhitespace(paramString1.charAt(k)))
/*      */       {
/*      */         
/* 2100 */         i = j;
/*      */       }
/*      */     } 
/* 2103 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2109 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\driver\OracleSql.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */