/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleImplicitConnectionCacheThread
/*     */   extends Thread
/*     */ {
/*  35 */   private OracleImplicitConnectionCache implicitCache = null;
/*     */ 
/*     */   
/*     */   protected boolean timeToLive = true;
/*     */ 
/*     */   
/*     */   protected boolean isSleeping = false;
/*     */ 
/*     */   
/*     */   OracleImplicitConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
/*  45 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  53 */     long l1 = 0L;
/*  54 */     long l2 = 0L;
/*  55 */     long l3 = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     while (this.timeToLive) {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */         
/*  67 */         if (this.timeToLive && (l1 = this.implicitCache.getCacheTimeToLiveTimeout()) > 0L)
/*     */         {
/*     */           
/*  70 */           runTimeToLiveTimeout(l1);
/*     */         }
/*     */ 
/*     */         
/*  74 */         if (this.timeToLive && (l2 = this.implicitCache.getCacheInactivityTimeout()) > 0L)
/*     */         {
/*  76 */           runInactivityTimeout();
/*     */         }
/*     */ 
/*     */         
/*  80 */         if (this.timeToLive && (l3 = this.implicitCache.getCacheAbandonedTimeout()) > 0L)
/*     */         {
/*  82 */           runAbandonedTimeout(l3);
/*     */         }
/*     */ 
/*     */         
/*  86 */         if (this.timeToLive) {
/*     */           
/*  88 */           this.isSleeping = true;
/*     */ 
/*     */ 
/*     */           
/*     */           try {
/*  93 */             sleep((this.implicitCache.getCachePropertyCheckInterval() * 1000));
/*     */           }
/*  95 */           catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 100 */           this.isSleeping = false;
/*     */         } 
/*     */ 
/*     */         
/* 104 */         if (this.implicitCache == null || (l1 <= 0L && l2 <= 0L && l3 <= 0L))
/*     */         {
/*     */           
/* 107 */           this.timeToLive = false;
/*     */         }
/* 109 */       } catch (SQLException sQLException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runTimeToLiveTimeout(long paramLong) throws SQLException {
/* 123 */     long l1 = 0L;
/* 124 */     long l2 = 0L;
/*     */ 
/*     */     
/* 127 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
/*     */       
/* 129 */       OraclePooledConnection oraclePooledConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       synchronized (this.implicitCache) {
/*     */ 
/*     */ 
/*     */         
/* 138 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/* 139 */         int i = this.implicitCache.checkedOutConnectionList.size();
/*     */         
/* 141 */         for (byte b = 0; b < i; b++) {
/*     */           
/* 143 */           oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
/*     */           
/* 145 */           Connection connection = oraclePooledConnection.getLogicalHandle();
/*     */           
/* 147 */           if (connection != null) {
/*     */             
/* 149 */             l2 = ((OracleConnection)connection).getStartTime();
/*     */             
/* 151 */             l1 = System.currentTimeMillis();
/*     */ 
/*     */             
/* 154 */             if (l1 - l2 > paramLong * 1000L) {
/*     */               
/*     */               try {
/*     */ 
/*     */ 
/*     */                 
/* 160 */                 this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
/*     */               }
/* 162 */               catch (SQLException sQLException) {}
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runInactivityTimeout() {
/*     */     try {
/* 182 */       this.implicitCache.doForEveryCachedConnection(4);
/*     */     }
/* 184 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runAbandonedTimeout(long paramLong) throws SQLException {
/* 200 */     if (this.implicitCache.getNumberOfCheckedOutConnections() > 0) {
/*     */       
/* 202 */       OraclePooledConnection oraclePooledConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       synchronized (this.implicitCache) {
/*     */         
/* 209 */         Object[] arrayOfObject = this.implicitCache.checkedOutConnectionList.toArray();
/*     */ 
/*     */         
/* 212 */         for (byte b = 0; b < arrayOfObject.length; b++) {
/*     */           
/* 214 */           oraclePooledConnection = (OraclePooledConnection)arrayOfObject[b];
/*     */           
/* 216 */           OracleConnection oracleConnection = (OracleConnection)oraclePooledConnection.getLogicalHandle();
/*     */           
/* 218 */           if (oracleConnection != null) {
/*     */ 
/*     */ 
/*     */             
/* 222 */             OracleConnectionCacheCallback oracleConnectionCacheCallback = oracleConnection.getConnectionCacheCallbackObj();
/*     */ 
/*     */ 
/*     */             
/* 226 */             if ((oracleConnection.getHeartbeatNoChangeCount() * this.implicitCache.getCachePropertyCheckInterval()) > paramLong) {
/*     */               
/*     */               try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 234 */                 boolean bool = true;
/* 235 */                 if (oracleConnectionCacheCallback != null && (oracleConnection.getConnectionCacheCallbackFlag() == 4 || oracleConnection.getConnectionCacheCallbackFlag() == 1))
/*     */                 {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 246 */                   bool = oracleConnectionCacheCallback.handleAbandonedConnection((OracleConnection)oracleConnection, oracleConnection.getConnectionCacheCallbackPrivObj());
/*     */                 }
/*     */ 
/*     */ 
/*     */                 
/* 251 */                 if (bool) {
/*     */                   
/* 253 */                   this.implicitCache.closeCheckedOutConnection(oraclePooledConnection, true);
/* 254 */                   this.implicitCache.checkedOutConnectionList.remove(oraclePooledConnection);
/* 255 */                   this.implicitCache.storeCacheConnection(oraclePooledConnection.cachedConnectionAttributes, oraclePooledConnection);
/*     */                 } 
/* 257 */               } catch (SQLException sQLException) {}
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 274 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\pool\OracleImplicitConnectionCacheThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */