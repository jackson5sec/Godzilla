/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.sql.SQLException;
/*     */ import oracle.ons.Notification;
/*     */ import oracle.ons.ONSException;
/*     */ import oracle.ons.Subscriber;
/*     */ import oracle.ons.SubscriptionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleFailoverEventHandlerThread
/*     */   extends Thread
/*     */ {
/*  41 */   private Notification event = null;
/*  42 */   private OracleConnectionCacheManager cacheManager = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleFailoverEventHandlerThread() throws SQLException {
/*  48 */     this.cacheManager = OracleConnectionCacheManager.getConnectionCacheManagerInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  57 */     Subscriber subscriber = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     while (this.cacheManager.failoverEnabledCacheExists()) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/*  67 */         subscriber = AccessController.<Subscriber>doPrivileged(new PrivilegedExceptionAction<Subscriber>()
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               public Object run()
/*     */               {
/*     */                 try {
/*  76 */                   return new Subscriber("(%\"eventType=database/event/service\")|(%\"eventType=database/event/host\")", "", 30000L);
/*     */                 }
/*  78 */                 catch (SubscriptionException subscriptionException) {
/*     */ 
/*     */                   
/*  81 */                   return null;
/*     */                 }
/*     */               
/*     */               }
/*     */             });
/*  86 */       } catch (PrivilegedActionException privilegedActionException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  91 */       if (subscriber != null) {
/*     */         
/*     */         try {
/*     */           
/*  95 */           while (this.cacheManager.failoverEnabledCacheExists()) {
/*     */ 
/*     */             
/*  98 */             if ((this.event = subscriber.receive(true)) != null) {
/*  99 */               handleEvent(this.event);
/*     */             }
/*     */           } 
/* 102 */         } catch (ONSException oNSException) {
/*     */           
/* 104 */           subscriber.close();
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 112 */         Thread.currentThread(); Thread.sleep(10000L);
/*     */       }
/* 114 */       catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void handleEvent(Notification paramNotification) {
/*     */     try {
/* 129 */       char c = Character.MIN_VALUE;
/*     */       
/* 131 */       if (paramNotification.type().equalsIgnoreCase("database/event/service")) {
/* 132 */         c = 'Ā';
/* 133 */       } else if (paramNotification.type().equalsIgnoreCase("database/event/host")) {
/* 134 */         c = 'Ȁ';
/*     */       } 
/* 136 */       if (c != '\000') {
/* 137 */         this.cacheManager.verifyAndHandleEvent(c, paramNotification.body());
/*     */       }
/* 139 */     } catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\pool\OracleFailoverEventHandlerThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */