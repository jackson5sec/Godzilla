package oracle.jdbc.pool;

import oracle.jdbc.OracleConnection;

public interface OracleConnectionCacheCallback {
  boolean handleAbandonedConnection(OracleConnection paramOracleConnection, Object paramObject);
  
  void releaseConnection(OracleConnection paramOracleConnection, Object paramObject);
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\pool\OracleConnectionCacheCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */