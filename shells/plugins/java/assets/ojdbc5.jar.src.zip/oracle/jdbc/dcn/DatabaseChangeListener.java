package oracle.jdbc.dcn;

import java.util.EventListener;

public interface DatabaseChangeListener extends EventListener {
  void onDatabaseChangeNotification(DatabaseChangeEvent paramDatabaseChangeEvent);
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\dcn\DatabaseChangeListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */