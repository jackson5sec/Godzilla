/*    */ package oracle.jdbc.dcn;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface QueryChangeDescription
/*    */ {
/*    */   long getQueryId();
/*    */   
/*    */   QueryChangeEventType getQueryChangeEventType();
/*    */   
/*    */   TableChangeDescription[] getTableChangeDescription();
/*    */   
/*    */   public enum QueryChangeEventType
/*    */   {
/* 56 */     DEREG(DatabaseChangeEvent.EventType.DEREG.getCode()),
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 61 */     QUERYCHANGE(DatabaseChangeEvent.EventType.QUERYCHANGE.getCode());
/*    */     private final int code;
/*    */     
/*    */     QueryChangeEventType(int param1Int1) {
/* 65 */       this.code = param1Int1;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public final int getCode() {
/* 73 */       return this.code;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     public static final QueryChangeEventType getQueryChangeEventType(int param1Int) {
/* 80 */       if (param1Int == DEREG.getCode()) {
/* 81 */         return DEREG;
/*    */       }
/* 83 */       return QUERYCHANGE;
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\dcn\QueryChangeDescription.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */