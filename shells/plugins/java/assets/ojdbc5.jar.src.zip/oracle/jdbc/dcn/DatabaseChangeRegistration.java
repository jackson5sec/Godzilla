package oracle.jdbc.dcn;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

public interface DatabaseChangeRegistration extends NotificationRegistration {
  int getRegistrationId();
  
  long getRegId();
  
  String[] getTables();
  
  void addListener(DatabaseChangeListener paramDatabaseChangeListener) throws SQLException;
  
  void addListener(DatabaseChangeListener paramDatabaseChangeListener, Executor paramExecutor) throws SQLException;
  
  void removeListener(DatabaseChangeListener paramDatabaseChangeListener) throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\dcn\DatabaseChangeRegistration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */