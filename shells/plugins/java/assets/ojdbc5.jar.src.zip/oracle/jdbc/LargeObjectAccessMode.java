/*    */ package oracle.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum LargeObjectAccessMode
/*    */ {
/*    */   private final int code;
/* 21 */   MODE_READONLY(0),
/* 22 */   MODE_READWRITE(1);
/*    */   
/*    */   LargeObjectAccessMode(int paramInt1) {
/* 25 */     this.code = paramInt1;
/*    */   }
/*    */   public int getCode() {
/* 28 */     return this.code;
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\LargeObjectAccessMode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */