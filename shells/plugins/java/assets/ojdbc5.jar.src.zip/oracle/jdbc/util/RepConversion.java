/*     */ package oracle.jdbc.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RepConversion
/*     */ {
/*     */   public static void printInHex(byte paramByte) {
/*  36 */     System.out.print((char)nibbleToHex((byte)((paramByte & 0xF0) >> 4)));
/*  37 */     System.out.print((char)nibbleToHex((byte)(paramByte & 0xF)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte nibbleToHex(byte paramByte) {
/*  52 */     paramByte = (byte)(paramByte & 0xF);
/*     */     
/*  54 */     return (byte)((paramByte < 10) ? (paramByte + 48) : (paramByte - 10 + 65));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte asciiHexToNibble(byte paramByte) {
/*     */     byte b;
/*  75 */     if (paramByte >= 97 && paramByte <= 102) {
/*  76 */       b = (byte)(paramByte - 97 + 10);
/*     */     }
/*  78 */     else if (paramByte >= 65 && paramByte <= 70) {
/*  79 */       b = (byte)(paramByte - 65 + 10);
/*     */     }
/*  81 */     else if (paramByte >= 48 && paramByte <= 57) {
/*  82 */       b = (byte)(paramByte - 48);
/*     */     } else {
/*     */       
/*  85 */       b = paramByte;
/*     */     } 
/*  87 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void bArray2Nibbles(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 101 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/*     */       
/* 103 */       paramArrayOfbyte2[b * 2] = nibbleToHex((byte)((paramArrayOfbyte1[b] & 0xF0) >> 4));
/* 104 */       paramArrayOfbyte2[b * 2 + 1] = nibbleToHex((byte)(paramArrayOfbyte1[b] & 0xF));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String bArray2String(byte[] paramArrayOfbyte) {
/* 118 */     StringBuffer stringBuffer = new StringBuffer(paramArrayOfbyte.length * 2);
/*     */     
/* 120 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*     */       
/* 122 */       stringBuffer.append((char)nibbleToHex((byte)((paramArrayOfbyte[b] & 0xF0) >> 4)));
/* 123 */       stringBuffer.append((char)nibbleToHex((byte)(paramArrayOfbyte[b] & 0xF)));
/*     */     } 
/*     */     
/* 126 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] nibbles2bArray(byte[] paramArrayOfbyte) {
/* 141 */     byte[] arrayOfByte = new byte[paramArrayOfbyte.length / 2];
/*     */ 
/*     */     
/* 144 */     for (byte b = 0; b < arrayOfByte.length; b++) {
/*     */       
/* 146 */       arrayOfByte[b] = (byte)(asciiHexToNibble(paramArrayOfbyte[b * 2]) << 4);
/* 147 */       arrayOfByte[b] = (byte)(arrayOfByte[b] | asciiHexToNibble(paramArrayOfbyte[b * 2 + 1]));
/*     */     } 
/*     */     
/* 150 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printInHex(long paramLong) {
/* 156 */     byte[] arrayOfByte = toHex(paramLong);
/*     */     
/* 158 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printInHex(int paramInt) {
/* 164 */     byte[] arrayOfByte = toHex(paramInt);
/*     */     
/* 166 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void printInHex(short paramShort) {
/* 172 */     byte[] arrayOfByte = toHex(paramShort);
/*     */     
/* 174 */     System.out.print(new String(arrayOfByte, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toHex(long paramLong) {
/* 180 */     byte b = 16;
/* 181 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 183 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 185 */       arrayOfByte[i] = nibbleToHex((byte)(int)(paramLong & 0xFL));
/* 186 */       paramLong >>= 4L;
/*     */     } 
/*     */     
/* 189 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toHex(int paramInt) {
/* 195 */     byte b = 8;
/* 196 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 198 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 200 */       arrayOfByte[i] = nibbleToHex((byte)(paramInt & 0xF));
/* 201 */       paramInt >>= 4;
/*     */     } 
/*     */     
/* 204 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] toHex(short paramShort) {
/* 210 */     byte b = 4;
/* 211 */     byte[] arrayOfByte = new byte[b];
/*     */     
/* 213 */     for (int i = b - 1; i >= 0; i--) {
/*     */       
/* 215 */       arrayOfByte[i] = nibbleToHex((byte)(paramShort & 0xF));
/* 216 */       paramShort = (short)(paramShort >> 4);
/*     */     } 
/*     */     
/* 219 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 224 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdb\\util\RepConversion.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */