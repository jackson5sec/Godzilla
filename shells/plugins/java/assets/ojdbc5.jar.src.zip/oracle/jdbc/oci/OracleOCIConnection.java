/*    */ package oracle.jdbc.oci;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import oracle.jdbc.driver.OracleOCIConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OracleOCIConnection
/*    */   extends OracleOCIConnection
/*    */ {
/*    */   public OracleOCIConnection(String paramString, Properties paramProperties, Object paramObject) throws SQLException {
/* 35 */     super(paramString, paramProperties, paramObject);
/*    */   }
/*    */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\oci\OracleOCIConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */