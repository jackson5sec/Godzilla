package oracle.jdbc.aq;

import java.sql.SQLException;
import java.util.concurrent.Executor;
import oracle.jdbc.NotificationRegistration;

public interface AQNotificationRegistration extends NotificationRegistration {
  void addListener(AQNotificationListener paramAQNotificationListener) throws SQLException;
  
  void addListener(AQNotificationListener paramAQNotificationListener, Executor paramExecutor) throws SQLException;
  
  void removeListener(AQNotificationListener paramAQNotificationListener) throws SQLException;
  
  String getQueueName();
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\aq\AQNotificationRegistration.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */