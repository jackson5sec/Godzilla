/*     */ package oracle.jdbc.aq;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface AQMessageProperties
/*     */ {
/*     */   public static final int MESSAGE_NO_DELAY = 0;
/*     */   public static final int MESSAGE_NO_EXPIRATION = -1;
/*     */   
/*     */   int getDequeueAttemptsCount();
/*     */   
/*     */   void setCorrelation(String paramString) throws SQLException;
/*     */   
/*     */   String getCorrelation();
/*     */   
/*     */   void setDelay(int paramInt) throws SQLException;
/*     */   
/*     */   int getDelay();
/*     */   
/*     */   Timestamp getEnqueueTime();
/*     */   
/*     */   void setExceptionQueue(String paramString) throws SQLException;
/*     */   
/*     */   String getExceptionQueue();
/*     */   
/*     */   void setExpiration(int paramInt) throws SQLException;
/*     */   
/*     */   int getExpiration();
/*     */   
/*     */   MessageState getState();
/*     */   
/*     */   void setPriority(int paramInt) throws SQLException;
/*     */   
/*     */   int getPriority();
/*     */   
/*     */   void setRecipientList(AQAgent[] paramArrayOfAQAgent) throws SQLException;
/*     */   
/*     */   AQAgent[] getRecipientList();
/*     */   
/*     */   void setSender(AQAgent paramAQAgent) throws SQLException;
/*     */   
/*     */   AQAgent getSender();
/*     */   
/*     */   String getTransactionGroup();
/*     */   
/*     */   byte[] getPreviousQueueMessageId();
/*     */   
/*     */   DeliveryMode getDeliveryMode();
/*     */   
/*     */   String toString();
/*     */   
/*     */   public enum MessageState
/*     */   {
/*  74 */     WAITING(1),
/*     */ 
/*     */ 
/*     */     
/*  78 */     READY(0),
/*     */ 
/*     */ 
/*     */     
/*  82 */     PROCESSED(2),
/*     */ 
/*     */ 
/*     */     
/*  86 */     EXPIRED(3);
/*     */     private final int code;
/*     */     
/*     */     MessageState(int param1Int1) {
/*  90 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/*  98 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final MessageState getMessageState(int param1Int) {
/* 106 */       if (param1Int == WAITING.getCode())
/* 107 */         return WAITING; 
/* 108 */       if (param1Int == READY.getCode())
/* 109 */         return READY; 
/* 110 */       if (param1Int == PROCESSED.getCode()) {
/* 111 */         return PROCESSED;
/*     */       }
/* 113 */       return EXPIRED;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum DeliveryMode
/*     */   {
/* 123 */     PERSISTENT(1),
/*     */ 
/*     */ 
/*     */     
/* 127 */     BUFFERED(2);
/*     */     private final int code;
/*     */     
/*     */     DeliveryMode(int param1Int1) {
/* 131 */       this.code = param1Int1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int getCode() {
/* 139 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static final DeliveryMode getDeliveryMode(int param1Int) {
/* 147 */       if (param1Int == BUFFERED.getCode()) {
/* 148 */         return BUFFERED;
/*     */       }
/* 150 */       return PERSISTENT;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\aq\AQMessageProperties.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */