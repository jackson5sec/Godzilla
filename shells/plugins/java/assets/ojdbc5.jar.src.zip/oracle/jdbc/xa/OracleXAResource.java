/*      */ package oracle.jdbc.xa;
/*      */ 
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Hashtable;
/*      */ import javax.transaction.xa.XAException;
/*      */ import javax.transaction.xa.XAResource;
/*      */ import javax.transaction.xa.Xid;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class OracleXAResource
/*      */   implements XAResource
/*      */ {
/*      */   public static final int XA_OK = 0;
/*      */   public static final short DEFAULT_XA_TIMEOUT = 60;
/*      */   protected boolean savedConnectionAutoCommit = false;
/*      */   protected boolean savedXAConnectionAutoCommit = false;
/*      */   public static final int TMNOFLAGS = 0;
/*      */   public static final int TMNOMIGRATE = 2;
/*      */   public static final int TMENDRSCAN = 8388608;
/*      */   public static final int TMFAIL = 536870912;
/*      */   public static final int TMMIGRATE = 1048576;
/*      */   public static final int TMJOIN = 2097152;
/*      */   public static final int TMONEPHASE = 1073741824;
/*      */   public static final int TMRESUME = 134217728;
/*      */   public static final int TMSTARTRSCAN = 16777216;
/*      */   public static final int TMSUCCESS = 67108864;
/*      */   public static final int TMSUSPEND = 33554432;
/*      */   public static final int ORATMREADONLY = 256;
/*      */   public static final int ORATMREADWRITE = 512;
/*      */   public static final int ORATMSERIALIZABLE = 1024;
/*      */   public static final int ORAISOLATIONMASK = 65280;
/*      */   public static final int ORATRANSLOOSE = 65536;
/*   81 */   protected Connection connection = null;
/*   82 */   protected OracleXAConnection xaconnection = null;
/*   83 */   protected int timeout = 60;
/*   84 */   protected String dblink = null;
/*      */ 
/*      */   
/*   87 */   private Connection logicalConnection = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   private String synchronizeBeforeRecoverNewCall = "BEGIN sys.dbms_xa.dist_txn_sync \n; END;";
/*      */ 
/*      */   
/*   98 */   private String synchronizeBeforeRecoverOldCall = "BEGIN sys.dbms_system.dist_txn_sync(0) \n; END;";
/*      */ 
/*      */ 
/*      */   
/*  102 */   private String recoverySqlRows = "SELECT formatid, globalid, branchid FROM SYS.DBA_PENDING_TRANSACTIONS";
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean canBeMigratablySuspended = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isTMRScanStarted = false;
/*      */ 
/*      */   
/*  113 */   private static final Xid[] NO_XID = new Xid[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Xid lastActiveXid;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Xid activeXid;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Hashtable<Xid, XidListEntry> xidHash;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnection(Connection paramConnection) throws XAException {
/*  153 */     this.connection = paramConnection;
/*      */     
/*  155 */     if (this.connection == null) {
/*  156 */       throw new XAException(-7);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleXAResource() {
/*  194 */     this.lastActiveXid = null;
/*      */ 
/*      */     
/*  197 */     this.activeXid = null;
/*      */     
/*  199 */     this.xidHash = new Hashtable<Xid, XidListEntry>(50); } public OracleXAResource(Connection paramConnection, OracleXAConnection paramOracleXAConnection) throws XAException { this.lastActiveXid = null; this.activeXid = null; this.xidHash = new Hashtable<Xid, XidListEntry>(50);
/*      */     this.connection = paramConnection;
/*      */     this.xaconnection = paramOracleXAConnection;
/*      */     if (this.connection == null)
/*      */       throw new XAException(-7);  }
/*      */   
/*      */   class XidListEntry { Xid xid;
/*      */     boolean isSuspended;
/*      */     
/*      */     XidListEntry(Xid param1Xid, boolean param1Boolean) {
/*  209 */       this.xid = param1Xid;
/*  210 */       this.isSuspended = param1Boolean;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final synchronized XidListEntry getMatchingXidListEntry(Xid paramXid) {
/*  218 */     return this.xidHash.get(paramXid);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final synchronized boolean removeXidFromList(Xid paramXid) {
/*  228 */     if (isSameXid(this.activeXid, paramXid)) {
/*  229 */       this.activeXid = null;
/*      */     }
/*  231 */     return (this.xidHash.remove(paramXid) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isSameXid(Xid paramXid1, Xid paramXid2) {
/*  240 */     return (paramXid1 == paramXid2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final boolean isOnStack(Xid paramXid) throws XAException {
/*  249 */     return this.xidHash.containsKey(paramXid);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final synchronized boolean isXidListEmpty() {
/*  258 */     return this.xidHash.isEmpty();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void createOrUpdateXid(Xid paramXid, boolean paramBoolean, boolean[] paramArrayOfboolean) {
/*  280 */     XidListEntry xidListEntry = getMatchingXidListEntry(paramXid);
/*      */     
/*  282 */     if (xidListEntry != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  288 */       paramArrayOfboolean[0] = true;
/*      */ 
/*      */ 
/*      */       
/*  292 */       xidListEntry.isSuspended = paramBoolean;
/*      */     }
/*      */     else {
/*      */       
/*  296 */       xidListEntry = new XidListEntry(paramXid, paramBoolean);
/*  297 */       this.xidHash.put(paramXid, xidListEntry);
/*      */     } 
/*      */     
/*  300 */     if (paramBoolean) {
/*      */ 
/*      */       
/*  303 */       this.lastActiveXid = this.activeXid;
/*  304 */       this.activeXid = null;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  309 */       enterGlobalTxnMode();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  314 */       if (this.lastActiveXid != null && isSameXid(paramXid, this.lastActiveXid)) {
/*  315 */         this.lastActiveXid = null;
/*      */       }
/*  317 */       this.activeXid = xidListEntry.xid;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized boolean updateXidList(Xid paramXid, boolean[] paramArrayOfboolean) {
/*  344 */     boolean bool = false;
/*  345 */     XidListEntry xidListEntry = getMatchingXidListEntry(paramXid);
/*  346 */     if (xidListEntry != null) {
/*      */       
/*  348 */       bool = true;
/*  349 */       paramArrayOfboolean[0] = true;
/*  350 */       paramArrayOfboolean[1] = xidListEntry.isSuspended;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  357 */       if (xidListEntry.isSuspended) {
/*      */         
/*  359 */         enterGlobalTxnMode();
/*      */       }
/*      */       else {
/*      */         
/*  363 */         exitGlobalTxnMode();
/*      */       } 
/*      */     } 
/*      */     
/*  367 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isXidSuspended(Xid paramXid) throws XAException {
/*  382 */     boolean bool = false;
/*  383 */     XidListEntry xidListEntry = getMatchingXidListEntry(paramXid);
/*      */     
/*  385 */     if (xidListEntry != null) {
/*  386 */       bool = xidListEntry.isSuspended;
/*      */     }
/*  388 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Xid suspendStacked(Xid paramXid) throws XAException {
/*  414 */     Xid xid = null;
/*      */     
/*  416 */     if (this.activeXid != null && !isSameXid(this.activeXid, paramXid)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  421 */       xid = this.activeXid;
/*      */ 
/*      */ 
/*      */       
/*  425 */       if (!isXidSuspended(this.activeXid)) {
/*      */         
/*  427 */         end(this.activeXid, 33554432);
/*  428 */         this.lastActiveXid = this.activeXid;
/*  429 */         this.activeXid = null;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  434 */     return xid;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void resumeStacked(Xid paramXid) throws XAException {
/*  454 */     if (paramXid != null) {
/*      */ 
/*      */ 
/*      */       
/*  458 */       start(paramXid, 134217728);
/*  459 */       this.activeXid = paramXid;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Xid[] recover(int paramInt) throws XAException {
/*  651 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  654 */       if ((paramInt & 0x1800000) != paramInt)
/*      */       {
/*      */ 
/*      */         
/*  658 */         throw new XAException(-5);
/*      */       }
/*      */       
/*  661 */       if (paramInt == 16777216)
/*  662 */       { this.isTMRScanStarted = true; }
/*  663 */       else { if (this.isTMRScanStarted && paramInt == 8388608) {
/*      */           
/*  665 */           this.isTMRScanStarted = false;
/*  666 */           return NO_XID;
/*      */         } 
/*  668 */         if (this.isTMRScanStarted && paramInt == 0)
/*  669 */           return NO_XID;  }
/*      */       
/*  671 */       Statement statement = null;
/*  672 */       ResultSet resultSet = null;
/*  673 */       ArrayList<OracleXid> arrayList = new ArrayList(50);
/*      */ 
/*      */       
/*      */       try {
/*  677 */         statement = this.connection.createStatement();
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  682 */           statement.execute(this.synchronizeBeforeRecoverNewCall);
/*      */         }
/*  684 */         catch (Exception exception) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  689 */           statement.execute(this.synchronizeBeforeRecoverOldCall);
/*      */         } 
/*      */ 
/*      */         
/*  693 */         resultSet = statement.executeQuery(this.recoverySqlRows);
/*      */         
/*  695 */         while (resultSet.next())
/*      */         {
/*  697 */           arrayList.add(new OracleXid(resultSet.getInt(1), resultSet.getBytes(2), resultSet.getBytes(3)));
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  702 */       catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  709 */         throw new XAException(-3);
/*      */       } finally {
/*      */ 
/*      */         
/*      */         try {
/*      */           
/*  715 */           if (statement != null) {
/*  716 */             statement.close();
/*      */           }
/*  718 */           if (resultSet != null) {
/*  719 */             resultSet.close();
/*      */           }
/*  721 */         } catch (Exception exception) {}
/*      */       } 
/*      */       
/*  724 */       int i = arrayList.size();
/*  725 */       Xid[] arrayOfXid = new Xid[i];
/*  726 */       System.arraycopy(arrayList.toArray(), 0, arrayOfXid, 0, i);
/*      */       
/*  728 */       return arrayOfXid;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void restoreAutoCommitModeForGlobalTransaction() throws XAException {
/*  747 */     if (this.savedConnectionAutoCommit && ((OracleConnection)this.connection).getTxnMode() != 1) {
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */         
/*  753 */         this.connection.setAutoCommit(this.savedConnectionAutoCommit);
/*  754 */         this.xaconnection.setAutoCommit(this.savedXAConnectionAutoCommit);
/*      */       }
/*  756 */       catch (SQLException sQLException) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void saveAndAlterAutoCommitModeForGlobalTransaction() throws XAException {
/*  776 */     if (((OracleConnection)this.connection).getTxnMode() != 1) {
/*      */       
/*      */       try {
/*      */ 
/*      */         
/*  781 */         this.savedConnectionAutoCommit = this.connection.getAutoCommit();
/*  782 */         this.connection.setAutoCommit(false);
/*  783 */         this.savedXAConnectionAutoCommit = this.xaconnection.getAutoCommit();
/*  784 */         this.xaconnection.setAutoCommit(false);
/*      */       }
/*  786 */       catch (SQLException sQLException) {}
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resume(Xid paramXid) throws XAException {
/*  806 */     start(paramXid, 134217728);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void join(Xid paramXid) throws XAException {
/*  823 */     start(paramXid, 2097152);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void suspend(Xid paramXid) throws XAException {
/*  839 */     end(paramXid, 33554432);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void join(Xid paramXid, int paramInt) throws XAException {
/*  857 */     this.timeout = paramInt;
/*      */     
/*  859 */     start(paramXid, 2097152);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resume(Xid paramXid, int paramInt) throws XAException {
/*  877 */     this.timeout = paramInt;
/*      */     
/*  879 */     start(paramXid, 134217728);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() {
/*  894 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTransactionTimeout() throws XAException {
/*  913 */     return this.timeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isSameRM(XAResource paramXAResource) throws XAException {
/*  934 */     Connection connection = null;
/*      */ 
/*      */     
/*  937 */     if (paramXAResource instanceof OracleXAResource) {
/*  938 */       connection = ((OracleXAResource)paramXAResource).getConnection();
/*      */     } else {
/*      */       
/*  941 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  946 */       if (this.connection == null || ((OracleConnection)this.connection).isClosed()) {
/*  947 */         return false;
/*      */       }
/*  949 */       String str1 = ((OracleConnection)this.connection).getURL();
/*  950 */       String str2 = ((OracleConnection)this.connection).getProtocolType();
/*      */       
/*  952 */       if (connection != null)
/*      */       {
/*  954 */         return (connection.equals(this.connection) || ((OracleConnection)connection).getURL().equals(str1) || (((OracleConnection)connection).getProtocolType().equals(str2) && str2.equals("kprb")));
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  963 */     catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  970 */       throw new XAException(-3);
/*      */     } 
/*      */ 
/*      */     
/*  974 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setTransactionTimeout(int paramInt) throws XAException {
/*  997 */     if (paramInt < 0) {
/*  998 */       throw new XAException(-5);
/*      */     }
/* 1000 */     this.timeout = paramInt;
/*      */     
/* 1002 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDBLink() {
/* 1016 */     return this.dblink;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDBLink(String paramString) {
/* 1031 */     this.dblink = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogicalConnection(Connection paramConnection) {
/* 1046 */     this.logicalConnection = paramConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void allowGlobalTxnModeOnly(int paramInt) throws XAException {
/* 1072 */     if (((OracleConnection)this.connection).getTxnMode() != 1)
/*      */     {
/* 1074 */       throw new XAException(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void exitGlobalTxnMode() {
/* 1086 */     ((OracleConnection)this.connection).setTxnMode(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void enterGlobalTxnMode() {
/* 1098 */     ((OracleConnection)this.connection).setTxnMode(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkError(int paramInt) throws XAException {
/* 1107 */     if ((paramInt & 0xFFFF) != 0) {
/*      */       
/* 1109 */       XAException xAException = OracleXAException.newXAException(getConnectionDuringExceptionHandling(), paramInt);
/* 1110 */       xAException.fillInStackTrace();
/* 1111 */       throw xAException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkError(int paramInt1, int paramInt2) throws XAException {
/* 1121 */     if ((paramInt1 & 0xFFFF) != 0) {
/*      */       
/* 1123 */       XAException xAException = OracleXAException.newXAException(getConnectionDuringExceptionHandling(), paramInt1, paramInt2);
/* 1124 */       xAException.fillInStackTrace();
/* 1125 */       throw xAException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkError(SQLException paramSQLException, int paramInt) throws XAException {
/* 1134 */     XAException xAException = OracleXAException.newXAException(getConnectionDuringExceptionHandling(), paramSQLException, paramInt);
/* 1135 */     xAException.fillInStackTrace();
/* 1136 */     throw xAException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1152 */     return (OracleConnection)this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1157 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   public abstract void start(Xid paramXid, int paramInt) throws XAException;
/*      */   
/*      */   public abstract void end(Xid paramXid, int paramInt) throws XAException;
/*      */   
/*      */   public abstract void commit(Xid paramXid, boolean paramBoolean) throws XAException;
/*      */   
/*      */   public abstract int prepare(Xid paramXid) throws XAException;
/*      */   
/*      */   public abstract void forget(Xid paramXid) throws XAException;
/*      */   
/*      */   public abstract void rollback(Xid paramXid) throws XAException;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\xa\OracleXAResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */