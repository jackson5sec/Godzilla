/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Blob;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleSerialBlob
/*     */   implements Blob, Serializable, Cloneable
/*     */ {
/*     */   private byte[] buffer;
/*     */   private long length;
/*     */   private boolean isFreed = false;
/*     */   
/*     */   public OracleSerialBlob(byte[] paramArrayOfbyte) throws SQLException {
/*  41 */     this.length = paramArrayOfbyte.length;
/*  42 */     this.buffer = new byte[(int)this.length];
/*  43 */     for (byte b = 0; b < this.length; b++) {
/*  44 */       this.buffer[b] = paramArrayOfbyte[b];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSerialBlob(Blob paramBlob) throws SQLException {
/*  54 */     this.length = paramBlob.length();
/*  55 */     this.buffer = new byte[(int)this.length];
/*  56 */     BufferedInputStream bufferedInputStream = new BufferedInputStream(paramBlob.getBinaryStream());
/*     */ 
/*     */     
/*     */     try {
/*  60 */       int i = 0;
/*  61 */       int j = 0;
/*     */ 
/*     */ 
/*     */       
/*     */       while (true)
/*  66 */       { i = bufferedInputStream.read(this.buffer, j, (int)(this.length - j));
/*     */         
/*  68 */         j += i;
/*  69 */         if (i <= 0)
/*     */           return;  } 
/*  71 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/*  74 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 346, iOException.getMessage());
/*  75 */       sQLException.fillInStackTrace();
/*  76 */       throw sQLException;
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*  81 */         if (bufferedInputStream != null)
/*  82 */           bufferedInputStream.close(); 
/*  83 */       } catch (IOException iOException) {
/*     */ 
/*     */         
/*  86 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 346, iOException.getMessage());
/*  87 */         sQLException.fillInStackTrace();
/*  88 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/* 101 */     if (this.isFreed) {
/*     */       
/* 103 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 104 */       sQLException.fillInStackTrace();
/* 105 */       throw sQLException;
/*     */     } 
/*     */     
/* 108 */     return new ByteArrayInputStream(this.buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes(long paramLong, int paramInt) throws SQLException {
/* 119 */     if (this.isFreed) {
/*     */       
/* 121 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 122 */       sQLException.fillInStackTrace();
/* 123 */       throw sQLException;
/*     */     } 
/*     */     
/* 126 */     byte[] arrayOfByte = null;
/*     */     
/* 128 */     paramLong--;
/* 129 */     if (paramLong < 0L || paramInt > this.length || paramLong + paramInt > this.length) {
/*     */       
/* 131 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 132 */       sQLException.fillInStackTrace();
/* 133 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/* 137 */     arrayOfByte = new byte[paramInt];
/* 138 */     System.arraycopy(this.buffer, (int)paramLong, arrayOfByte, 0, paramInt);
/*     */ 
/*     */     
/* 141 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/* 150 */     if (this.isFreed) {
/*     */       
/* 152 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 153 */       sQLException.fillInStackTrace();
/* 154 */       throw sQLException;
/*     */     } 
/*     */     
/* 157 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 168 */     if (this.isFreed) {
/*     */       
/* 170 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 171 */       sQLException.fillInStackTrace();
/* 172 */       throw sQLException;
/*     */     } 
/*     */     
/* 175 */     if (paramLong < 1L) {
/*     */       
/* 177 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 178 */       sQLException.fillInStackTrace();
/* 179 */       throw sQLException;
/*     */     } 
/*     */     
/* 182 */     if (paramLong > this.length || paramLong + paramArrayOfbyte.length - 1L > this.length) {
/* 183 */       return -1L;
/*     */     }
/* 185 */     int i = (int)(paramLong - 1L);
/* 186 */     boolean bool = false;
/* 187 */     long l = paramArrayOfbyte.length;
/*     */     
/* 189 */     while (i < this.length) {
/*     */       
/* 191 */       byte b = 0;
/* 192 */       long l1 = (i + 1);
/* 193 */       int j = i;
/* 194 */       while (b < l && j < this.length && paramArrayOfbyte[b] == this.buffer[j]) {
/*     */         
/* 196 */         b++;
/* 197 */         j++;
/* 198 */         if (b == l) {
/* 199 */           return l1;
/*     */         }
/*     */       } 
/* 202 */       i++;
/*     */     } 
/*     */     
/* 205 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(Blob paramBlob, long paramLong) throws SQLException {
/* 214 */     if (this.isFreed) {
/*     */       
/* 216 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 217 */       sQLException.fillInStackTrace();
/* 218 */       throw sQLException;
/*     */     } 
/*     */     
/* 221 */     return position(paramBlob.getBytes(1L, (int)paramBlob.length()), paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setBytes(long paramLong, byte[] paramArrayOfbyte) throws SQLException {
/* 250 */     if (this.isFreed) {
/*     */       
/* 252 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 253 */       sQLException1.fillInStackTrace();
/* 254 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 258 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 259 */     sQLException.fillInStackTrace();
/* 260 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setBytes(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 293 */     if (this.isFreed) {
/*     */       
/* 295 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 296 */       sQLException1.fillInStackTrace();
/* 297 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 301 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 302 */     sQLException.fillInStackTrace();
/* 303 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream(long paramLong) throws SQLException {
/* 329 */     if (this.isFreed) {
/*     */       
/* 331 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 332 */       sQLException1.fillInStackTrace();
/* 333 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 337 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 338 */     sQLException.fillInStackTrace();
/* 339 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void truncate(long paramLong) throws SQLException {
/* 361 */     if (this.isFreed) {
/*     */       
/* 363 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 364 */       sQLException1.fillInStackTrace();
/* 365 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 369 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 370 */     sQLException.fillInStackTrace();
/* 371 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 391 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 396 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleSerialBlob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */