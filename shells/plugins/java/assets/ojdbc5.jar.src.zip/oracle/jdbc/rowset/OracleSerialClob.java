/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.io.StringBufferInputStream;
/*     */ import java.io.Writer;
/*     */ import java.sql.Clob;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleSerialClob
/*     */   implements Clob, Serializable, Cloneable
/*     */ {
/*     */   private static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*     */   private char[] buffer;
/*     */   private long length;
/*     */   private boolean isFreed = false;
/*     */   
/*     */   public OracleSerialClob(char[] paramArrayOfchar) throws SQLException {
/*  52 */     this.length = paramArrayOfchar.length;
/*  53 */     this.buffer = new char[(int)this.length];
/*  54 */     for (byte b = 0; b < this.length; b++) {
/*  55 */       this.buffer[b] = paramArrayOfchar[b];
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSerialClob(Clob paramClob) throws SQLException {
/*  65 */     this.length = paramClob.length();
/*  66 */     this.buffer = new char[(int)this.length];
/*  67 */     BufferedReader bufferedReader = new BufferedReader(paramClob.getCharacterStream());
/*     */ 
/*     */     
/*     */     try {
/*  71 */       int i = 0;
/*  72 */       int j = 0;
/*     */ 
/*     */ 
/*     */       
/*     */       while (true)
/*  77 */       { i = bufferedReader.read(this.buffer, j, (int)(this.length - j));
/*     */         
/*  79 */         j += i;
/*  80 */         if (i <= 0)
/*     */           return;  } 
/*  82 */     } catch (IOException iOException) {
/*     */ 
/*     */       
/*  85 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, iOException.getMessage());
/*  86 */       sQLException.fillInStackTrace();
/*  87 */       throw sQLException;
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*  92 */         if (bufferedReader != null)
/*  93 */           bufferedReader.close(); 
/*  94 */       } catch (IOException iOException) {
/*     */ 
/*     */         
/*  97 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, iOException.getMessage());
/*  98 */         sQLException.fillInStackTrace();
/*  99 */         throw sQLException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSerialClob(Reader paramReader) throws SQLException {
/*     */     try {
/* 114 */       int i = 0;
/* 115 */       char[] arrayOfChar = new char[1024];
/* 116 */       StringBuilder stringBuilder = new StringBuilder(1024);
/*     */ 
/*     */       
/*     */       while (true) {
/* 120 */         i = paramReader.read(arrayOfChar);
/*     */ 
/*     */ 
/*     */         
/* 124 */         if (i == -1) {
/*     */           break;
/*     */         }
/* 127 */         stringBuilder.append(arrayOfChar, 0, i);
/*     */       } 
/*     */       
/* 130 */       paramReader.close();
/*     */       
/* 132 */       this.buffer = stringBuilder.toString().toCharArray();
/* 133 */       this.length = this.buffer.length;
/*     */     }
/* 135 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 138 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, exception.getMessage());
/* 139 */       sQLException.fillInStackTrace();
/* 140 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleSerialClob(Reader paramReader, long paramLong) throws SQLException {
/*     */     try {
/* 154 */       int i = 0;
/* 155 */       long l = paramLong;
/* 156 */       char[] arrayOfChar = new char[1024];
/* 157 */       StringBuilder stringBuilder = new StringBuilder(1024);
/*     */       
/* 159 */       while (l > 0L) {
/*     */         
/* 161 */         i = paramReader.read(arrayOfChar, 0, Math.min(1024, (int)l));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 166 */         if (i == -1) {
/*     */           break;
/*     */         }
/* 169 */         stringBuilder.append(arrayOfChar, 0, i);
/* 170 */         l -= i;
/*     */       } 
/*     */       
/* 173 */       paramReader.close();
/*     */       
/* 175 */       this.buffer = stringBuilder.toString().toCharArray();
/* 176 */       this.length = this.buffer.length;
/*     */     }
/* 178 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 181 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 347, exception.getMessage());
/* 182 */       sQLException.fillInStackTrace();
/* 183 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getAsciiStream() throws SQLException {
/* 195 */     if (this.isFreed) {
/*     */       
/* 197 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 198 */       sQLException.fillInStackTrace();
/* 199 */       throw sQLException;
/*     */     } 
/*     */     
/* 202 */     return new StringBufferInputStream(new String(this.buffer));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/* 211 */     if (this.isFreed) {
/*     */       
/* 213 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 214 */       sQLException.fillInStackTrace();
/* 215 */       throw sQLException;
/*     */     } 
/*     */     
/* 218 */     return new CharArrayReader(this.buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubString(long paramLong, int paramInt) throws SQLException {
/* 229 */     if (this.isFreed) {
/*     */       
/* 231 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 232 */       sQLException.fillInStackTrace();
/* 233 */       throw sQLException;
/*     */     } 
/*     */     
/* 236 */     if (paramLong < 1L || paramInt < 0 || paramInt > this.length || paramLong + paramInt - 1L > this.length) {
/*     */ 
/*     */ 
/*     */       
/* 240 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 241 */       sQLException.fillInStackTrace();
/* 242 */       throw sQLException;
/*     */     } 
/* 244 */     if (paramInt == 0) {
/* 245 */       return new String();
/*     */     }
/* 247 */     return new String(this.buffer, (int)paramLong - 1, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/* 257 */     if (this.isFreed) {
/*     */       
/* 259 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 260 */       sQLException.fillInStackTrace();
/* 261 */       throw sQLException;
/*     */     } 
/*     */     
/* 264 */     return this.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(String paramString, long paramLong) throws SQLException {
/* 275 */     if (this.isFreed) {
/*     */       
/* 277 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 278 */       sQLException.fillInStackTrace();
/* 279 */       throw sQLException;
/*     */     } 
/*     */     
/* 282 */     if (paramLong < 1L) {
/*     */       
/* 284 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 285 */       sQLException.fillInStackTrace();
/* 286 */       throw sQLException;
/*     */     } 
/*     */     
/* 289 */     if (paramLong > this.length || paramLong + paramString.length() - 1L > this.length) {
/* 290 */       return -1L;
/*     */     }
/* 292 */     char[] arrayOfChar = paramString.toCharArray();
/* 293 */     int i = (int)(paramLong - 1L);
/* 294 */     boolean bool = false;
/* 295 */     long l = arrayOfChar.length;
/*     */     
/* 297 */     while (i < this.length) {
/*     */       
/* 299 */       byte b = 0;
/* 300 */       long l1 = (i + 1);
/* 301 */       int j = i;
/* 302 */       while (b < l && j < this.length && arrayOfChar[b] == this.buffer[j]) {
/*     */         
/* 304 */         b++;
/* 305 */         j++;
/* 306 */         if (b == l) {
/* 307 */           return l1;
/*     */         }
/*     */       } 
/* 310 */       i++;
/*     */     } 
/* 312 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(Clob paramClob, long paramLong) throws SQLException {
/* 321 */     if (this.isFreed) {
/*     */       
/* 323 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 324 */       sQLException.fillInStackTrace();
/* 325 */       throw sQLException;
/*     */     } 
/*     */     
/* 328 */     return position(paramClob.getSubString(1L, (int)paramClob.length()), paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setString(long paramLong, String paramString) throws SQLException {
/* 357 */     if (this.isFreed) {
/*     */       
/* 359 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 360 */       sQLException1.fillInStackTrace();
/* 361 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 365 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 366 */     sQLException.fillInStackTrace();
/* 367 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setString(long paramLong, String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 397 */     if (this.isFreed) {
/*     */       
/* 399 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 400 */       sQLException1.fillInStackTrace();
/* 401 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 405 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 406 */     sQLException.fillInStackTrace();
/* 407 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setAsciiStream(long paramLong) throws SQLException {
/* 433 */     if (this.isFreed) {
/*     */       
/* 435 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 436 */       sQLException1.fillInStackTrace();
/* 437 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 441 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 442 */     sQLException.fillInStackTrace();
/* 443 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Writer setCharacterStream(long paramLong) throws SQLException {
/* 470 */     if (this.isFreed) {
/*     */       
/* 472 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 473 */       sQLException1.fillInStackTrace();
/* 474 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 478 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 479 */     sQLException.fillInStackTrace();
/* 480 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void truncate(long paramLong) throws SQLException {
/* 503 */     if (this.isFreed) {
/*     */       
/* 505 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 192);
/* 506 */       sQLException1.fillInStackTrace();
/* 507 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 511 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 512 */     sQLException.fillInStackTrace();
/* 513 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 533 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 538 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleSerialClob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */