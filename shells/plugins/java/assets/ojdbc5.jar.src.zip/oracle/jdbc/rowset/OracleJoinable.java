package oracle.jdbc.rowset;

import java.sql.SQLException;
import javax.sql.rowset.Joinable;

public interface OracleJoinable extends Joinable {
  int[] getMatchColumnIndexes() throws SQLException;
  
  String[] getMatchColumnNames() throws SQLException;
  
  void setMatchColumn(int paramInt) throws SQLException;
  
  void setMatchColumn(int[] paramArrayOfint) throws SQLException;
  
  void setMatchColumn(String paramString) throws SQLException;
  
  void setMatchColumn(String[] paramArrayOfString) throws SQLException;
  
  void unsetMatchColumn(int paramInt) throws SQLException;
  
  void unsetMatchColumn(int[] paramArrayOfint) throws SQLException;
  
  void unsetMatchColumn(String paramString) throws SQLException;
  
  void unsetMatchColumn(String[] paramArrayOfString) throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleJoinable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */