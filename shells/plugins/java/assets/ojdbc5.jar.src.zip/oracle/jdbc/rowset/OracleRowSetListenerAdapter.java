package oracle.jdbc.rowset;

import java.io.Serializable;
import javax.sql.RowSetEvent;
import javax.sql.RowSetListener;

public abstract class OracleRowSetListenerAdapter implements RowSetListener, Serializable {
  public void cursorMoved(RowSetEvent paramRowSetEvent) {}
  
  public void rowChanged(RowSetEvent paramRowSetEvent) {}
  
  public void rowSetChanged(RowSetEvent paramRowSetEvent) {}
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleRowSetListenerAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */