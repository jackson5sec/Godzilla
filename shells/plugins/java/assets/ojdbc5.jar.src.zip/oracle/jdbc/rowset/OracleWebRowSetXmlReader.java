package oracle.jdbc.rowset;

import javax.sql.rowset.spi.XmlReader;

public interface OracleWebRowSetXmlReader extends XmlReader {}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleWebRowSetXmlReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */