/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import javax.sql.RowSet;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleWebRowSetXmlReaderDomHandler
/*     */   extends OracleWebRowSetXmlReaderContHandler
/*     */ {
/*     */   OracleWebRowSetXmlReaderDomHandler(RowSet paramRowSet) {
/*  42 */     super(paramRowSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readXMLDocument(Document paramDocument) throws SAXException {
/*  50 */     Element element = paramDocument.getDocumentElement();
/*  51 */     startElement(null, null, "webRowSet", null);
/*     */ 
/*     */     
/*  54 */     Node node1 = element.getElementsByTagName("properties").item(0);
/*     */     
/*  56 */     startElement(null, null, "properties", null);
/*     */ 
/*     */     
/*  59 */     NodeList nodeList1 = node1.getChildNodes();
/*  60 */     int i = nodeList1.getLength();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     for (byte b1 = 0; b1 < i; b1++) {
/*     */       
/*  67 */       Node node = nodeList1.item(b1);
/*     */ 
/*     */       
/*  70 */       if (!(node instanceof org.w3c.dom.Text)) {
/*     */ 
/*     */ 
/*     */         
/*  74 */         String str1 = node.getNodeName();
/*  75 */         startElement(null, null, str1, null);
/*     */ 
/*     */ 
/*     */         
/*  79 */         if (node.hasChildNodes()) {
/*     */           
/*  81 */           processElement(node.getFirstChild().getNodeValue());
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/*  88 */           processElement("");
/*     */         } 
/*     */         
/*  91 */         endElement(null, null, str1);
/*     */       } 
/*     */     } 
/*  94 */     endElement(null, null, "properties");
/*     */ 
/*     */     
/*  97 */     Node node2 = element.getElementsByTagName("metadata").item(0);
/*     */     
/*  99 */     startElement(null, null, "metadata", null);
/*     */ 
/*     */     
/* 102 */     Node node3 = node2.getFirstChild().getNextSibling();
/*     */     
/* 104 */     String str = node3.getNodeName();
/* 105 */     startElement(null, null, str, null);
/*     */ 
/*     */     
/* 108 */     processElement(node3.getFirstChild().getNodeValue());
/* 109 */     endElement(null, null, str);
/*     */ 
/*     */     
/* 112 */     NodeList nodeList2 = node2.getChildNodes();
/* 113 */     int j = nodeList2.getLength();
/*     */ 
/*     */     
/* 116 */     for (byte b2 = 3; b2 < j; b2++) {
/*     */       
/* 118 */       Node node = nodeList2.item(b2);
/*     */ 
/*     */       
/* 121 */       NodeList nodeList = node.getChildNodes();
/* 122 */       int m = nodeList.getLength();
/*     */       
/* 124 */       for (byte b = 0; b < m; b++) {
/*     */         
/* 126 */         Node node5 = nodeList.item(b);
/*     */ 
/*     */         
/* 129 */         if (!(node5 instanceof org.w3c.dom.Text)) {
/*     */ 
/*     */ 
/*     */           
/* 133 */           String str1 = node5.getNodeName();
/* 134 */           startElement(null, null, str1, null);
/*     */ 
/*     */ 
/*     */           
/* 138 */           if (node5.hasChildNodes()) {
/*     */             
/* 140 */             processElement(node5.getFirstChild().getNodeValue());
/*     */ 
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 147 */             processElement("");
/*     */           } 
/*     */           
/* 150 */           endElement(null, null, str1);
/*     */         } 
/*     */       } 
/*     */     } 
/* 154 */     endElement(null, null, "metadata");
/*     */ 
/*     */     
/* 157 */     Node node4 = element.getElementsByTagName("data").item(0);
/* 158 */     startElement(null, null, "data", null);
/*     */ 
/*     */     
/* 161 */     NodeList nodeList3 = node4.getChildNodes();
/* 162 */     int k = nodeList3.getLength();
/*     */     
/* 164 */     for (byte b3 = 0; b3 < k; b3++) {
/*     */       
/* 166 */       Node node = nodeList3.item(b3);
/*     */ 
/*     */       
/* 169 */       if (!(node instanceof org.w3c.dom.Text)) {
/*     */ 
/*     */ 
/*     */         
/* 173 */         String str1 = node.getNodeName();
/* 174 */         startElement(null, null, str1, null);
/*     */ 
/*     */         
/* 177 */         NodeList nodeList = node.getChildNodes();
/* 178 */         int m = nodeList.getLength();
/*     */         
/* 180 */         for (byte b = 0; b < m; b++) {
/*     */           
/* 182 */           Node node5 = nodeList.item(b);
/*     */ 
/*     */           
/* 185 */           if (!(node5 instanceof org.w3c.dom.Text)) {
/*     */ 
/*     */ 
/*     */             
/* 189 */             String str3, str2 = node5.getNodeName();
/* 190 */             startElement(null, null, str2, null);
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 195 */             if (node5.hasChildNodes()) {
/*     */               
/* 197 */               str3 = node5.getFirstChild().getNodeValue();
/* 198 */               if (str3 == null)
/*     */               {
/* 200 */                 startElement(null, null, "null", null);
/*     */               
/*     */               }
/*     */             
/*     */             }
/*     */             else {
/*     */               
/* 207 */               str3 = "";
/*     */             } 
/*     */             
/* 210 */             processElement(str3);
/*     */             
/* 212 */             endElement(null, null, str2);
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 217 */         endElement(null, null, str1);
/*     */       } 
/*     */     } 
/*     */     
/* 221 */     endElement(null, null, "data");
/*     */     
/* 223 */     endElement(null, null, "webRowSet");
/*     */     
/* 225 */     endDocument();
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleWebRowSetXmlReaderDomHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */