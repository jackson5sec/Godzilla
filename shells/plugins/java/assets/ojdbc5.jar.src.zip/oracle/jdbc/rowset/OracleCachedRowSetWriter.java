/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.sql.RowSet;
/*     */ import javax.sql.RowSetInternal;
/*     */ import javax.sql.RowSetWriter;
/*     */ import oracle.jdbc.OraclePreparedStatement;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleCachedRowSetWriter
/*     */   implements RowSetWriter, Serializable
/*     */ {
/*     */   static final long serialVersionUID = 8932894189919931169L;
/*  61 */   private StringBuffer updateClause = new StringBuffer("");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private StringBuffer deleteClause = new StringBuffer("");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private StringBuffer insertClause = new StringBuffer("");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PreparedStatement insertStmt;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PreparedStatement updateStmt;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PreparedStatement deleteStmt;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResultSetMetaData rsmd;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private transient Connection connection;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int columnCount;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int ASCII_STREAM = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int BINARY_STREAM = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int CHARACTER_STREAM = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int NCHARACTER_STREAM = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getSchemaName(RowSet paramRowSet) throws SQLException {
/* 130 */     return paramRowSet.getUsername();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getTableName(RowSet paramRowSet) throws SQLException {
/* 139 */     String str1 = ((OracleCachedRowSet)paramRowSet).getTableName();
/* 140 */     if (str1 != null) {
/* 141 */       return str1;
/*     */     }
/* 143 */     String str2 = paramRowSet.getCommand().toUpperCase();
/*     */ 
/*     */ 
/*     */     
/* 147 */     int i = str2.indexOf(" FROM ");
/*     */ 
/*     */ 
/*     */     
/* 151 */     if (i == -1) {
/*     */       
/* 153 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 343, (str2.length() != 0) ? str2 : "Please use RowSet.setCommand (String) to set the SQL query string.");
/* 154 */       sQLException.fillInStackTrace();
/* 155 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     String str3 = str2.substring(i + 6).trim();
/*     */ 
/*     */ 
/*     */     
/* 165 */     StringTokenizer stringTokenizer = new StringTokenizer(str3);
/* 166 */     if (stringTokenizer.hasMoreTokens()) {
/* 167 */       str3 = stringTokenizer.nextToken();
/*     */     }
/* 169 */     return str3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initSQLStatement(RowSet paramRowSet) throws SQLException {
/* 181 */     this.insertClause = new StringBuffer("INSERT INTO " + getTableName(paramRowSet) + "(");
/* 182 */     this.updateClause = new StringBuffer("UPDATE " + getTableName(paramRowSet) + " SET ");
/* 183 */     this.deleteClause = new StringBuffer("DELETE FROM " + getTableName(paramRowSet) + " WHERE ");
/*     */ 
/*     */     
/* 186 */     this.rsmd = paramRowSet.getMetaData();
/* 187 */     this.columnCount = this.rsmd.getColumnCount();
/*     */     
/*     */     byte b;
/*     */     
/* 191 */     for (b = 0; b < this.columnCount; b++) {
/*     */       
/* 193 */       if (b != 0) this.insertClause.append(", "); 
/* 194 */       this.insertClause.append(this.rsmd.getColumnName(b + 1));
/*     */       
/* 196 */       if (b != 0) this.updateClause.append(", "); 
/* 197 */       this.updateClause.append(this.rsmd.getColumnName(b + 1) + " = :" + b);
/*     */       
/* 199 */       if (b != 0) this.deleteClause.append(" AND "); 
/* 200 */       this.deleteClause.append(this.rsmd.getColumnName(b + 1) + " = :" + b);
/*     */     } 
/* 202 */     this.insertClause.append(") VALUES (");
/* 203 */     this.updateClause.append(" WHERE ");
/*     */     
/* 205 */     for (b = 0; b < this.columnCount; b++) {
/*     */       
/* 207 */       if (b != 0) this.insertClause.append(", "); 
/* 208 */       this.insertClause.append(":" + b);
/*     */       
/* 210 */       if (b != 0) this.updateClause.append(" AND "); 
/* 211 */       this.updateClause.append(this.rsmd.getColumnName(b + 1) + " = :" + b);
/*     */     } 
/* 213 */     this.insertClause.append(")");
/*     */     
/* 215 */     this.insertStmt = this.connection.prepareStatement(this.insertClause.substring(0, this.insertClause.length()));
/*     */     
/* 217 */     this.updateStmt = this.connection.prepareStatement(this.updateClause.substring(0, this.updateClause.length()));
/*     */     
/* 219 */     this.deleteStmt = this.connection.prepareStatement(this.deleteClause.substring(0, this.deleteClause.length()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean insertRow(OracleRow paramOracleRow) throws SQLException {
/* 235 */     this.insertStmt.clearParameters();
/* 236 */     for (byte b = 1; b <= this.columnCount; b++) {
/*     */       
/* 238 */       Object object = null;
/* 239 */       object = paramOracleRow.isColumnChanged(b) ? paramOracleRow.getModifiedColumn(b) : paramOracleRow.getColumn(b);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 244 */       if (object == null) {
/* 245 */         this.insertStmt.setNull(b, this.rsmd.getColumnType(b));
/* 246 */         paramOracleRow.markOriginalNull(b, true);
/*     */       } else {
/* 248 */         this.insertStmt.setObject(b, object);
/*     */       } 
/*     */     } 
/* 251 */     return (this.insertStmt.executeUpdate() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean updateRow(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
/* 263 */     this.updateStmt.clearParameters(); byte b;
/* 264 */     for (b = 1; b <= this.columnCount; b++) {
/*     */       
/* 266 */       Object object = null;
/* 267 */       object = paramOracleRow.isColumnChanged(b) ? paramOracleRow.getModifiedColumn(b) : paramOracleRow.getColumn(b);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 272 */       if (object == null) {
/* 273 */         this.updateStmt.setNull(b, this.rsmd.getColumnType(b));
/*     */       
/*     */       }
/* 276 */       else if (object instanceof Reader) {
/*     */         
/* 278 */         OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)this.updateStmt;
/* 279 */         if (paramOracleRow.columnTypeInfo[b - 1][1] == 4) {
/* 280 */           oraclePreparedStatement.setFormOfUse(b, (short)2);
/* 281 */         } else if (paramOracleRow.columnTypeInfo[b - 1][1] == 3) {
/* 282 */           oraclePreparedStatement.setFormOfUse(b, (short)1);
/*     */         } 
/* 284 */         this.updateStmt.setCharacterStream(b, (Reader)object, paramOracleRow.columnTypeInfo[b - 1][0]);
/*     */ 
/*     */       
/*     */       }
/* 288 */       else if (object instanceof InputStream) {
/*     */         
/* 290 */         if (paramOracleRow.columnTypeInfo[b - 1][1] == 2) {
/* 291 */           this.updateStmt.setBinaryStream(b, (InputStream)object, paramOracleRow.columnTypeInfo[b - 1][0]);
/*     */         
/*     */         }
/* 294 */         else if (paramOracleRow.columnTypeInfo[b - 1][1] == 1) {
/* 295 */           this.updateStmt.setAsciiStream(b, (InputStream)object, paramOracleRow.columnTypeInfo[b - 1][0]);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 300 */         this.updateStmt.setObject(b, object);
/*     */       } 
/*     */     } 
/* 303 */     for (b = 1; b <= this.columnCount; b++) {
/*     */       
/* 305 */       if (paramOracleRow.isOriginalNull(b)) {
/* 306 */         return updateRowWithNull(paramRowSet, paramOracleRow);
/*     */       }
/* 308 */       this.updateStmt.setObject(b + this.columnCount, paramOracleRow.getColumn(b));
/*     */     } 
/*     */     
/* 311 */     return (this.updateStmt.executeUpdate() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean updateRowWithNull(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
/* 320 */     boolean bool = false;
/* 321 */     StringBuffer stringBuffer = new StringBuffer("UPDATE " + getTableName(paramRowSet) + " SET ");
/*     */     
/*     */     byte b;
/* 324 */     for (b = 1; b <= this.columnCount; b++) {
/*     */       
/* 326 */       if (b != 1) {
/* 327 */         stringBuffer.append(", ");
/*     */       }
/* 329 */       stringBuffer.append(this.rsmd.getColumnName(b) + " = :" + b);
/*     */     } 
/*     */     
/* 332 */     stringBuffer.append(" WHERE ");
/*     */     
/* 334 */     for (b = 1; b <= this.columnCount; b++) {
/*     */       
/* 336 */       if (b != 1)
/* 337 */         stringBuffer.append(" AND "); 
/* 338 */       if (paramOracleRow.isOriginalNull(b)) {
/* 339 */         stringBuffer.append(this.rsmd.getColumnName(b) + " IS NULL ");
/*     */       } else {
/* 341 */         stringBuffer.append(this.rsmd.getColumnName(b) + " = :" + b);
/*     */       } 
/*     */     } 
/* 344 */     PreparedStatement preparedStatement = null;
/*     */     
/*     */     try {
/* 347 */       preparedStatement = this.connection.prepareStatement(stringBuffer.substring(0, stringBuffer.length()));
/*     */       
/*     */       byte b1;
/* 350 */       for (b1 = 1; b1 <= this.columnCount; b1++) {
/*     */         
/* 352 */         Object object = null;
/* 353 */         object = paramOracleRow.isColumnChanged(b1) ? paramOracleRow.getModifiedColumn(b1) : paramOracleRow.getColumn(b1);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 358 */         if (object == null) {
/* 359 */           preparedStatement.setNull(b1, this.rsmd.getColumnType(b1));
/*     */         
/*     */         }
/* 362 */         else if (object instanceof Reader) {
/*     */           
/* 364 */           OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)preparedStatement;
/* 365 */           if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 4) {
/* 366 */             oraclePreparedStatement.setFormOfUse(b1, (short)2);
/* 367 */           } else if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 3) {
/* 368 */             oraclePreparedStatement.setFormOfUse(b1, (short)1);
/*     */           } 
/* 370 */           preparedStatement.setCharacterStream(b1, (Reader)object, paramOracleRow.columnTypeInfo[b1 - 1][0]);
/*     */ 
/*     */         
/*     */         }
/* 374 */         else if (object instanceof InputStream) {
/*     */           
/* 376 */           if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 2) {
/* 377 */             preparedStatement.setBinaryStream(b1, (InputStream)object, paramOracleRow.columnTypeInfo[b1 - 1][0]);
/*     */           
/*     */           }
/* 380 */           else if (paramOracleRow.columnTypeInfo[b1 - 1][1] == 1) {
/* 381 */             preparedStatement.setAsciiStream(b1, (InputStream)object, paramOracleRow.columnTypeInfo[b1 - 1][0]);
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 386 */           preparedStatement.setObject(b1, object);
/*     */         } 
/*     */       } 
/*     */       byte b2;
/* 390 */       for (b1 = 1, b2 = 1; b1 <= this.columnCount; b1++) {
/*     */         
/* 392 */         if (!paramOracleRow.isOriginalNull(b1)) {
/*     */ 
/*     */           
/* 395 */           preparedStatement.setObject(b2 + this.columnCount, paramOracleRow.getColumn(b1));
/*     */           
/* 397 */           b2++;
/*     */         } 
/* 399 */       }  bool = (preparedStatement.executeUpdate() == 1) ? true : false;
/*     */     } finally {
/*     */       
/* 402 */       if (preparedStatement != null) {
/* 403 */         preparedStatement.close();
/*     */       }
/*     */     } 
/* 406 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean deleteRow(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
/* 419 */     this.deleteStmt.clearParameters();
/* 420 */     for (byte b = 1; b <= this.columnCount; b++) {
/*     */       
/* 422 */       if (paramOracleRow.isOriginalNull(b)) {
/* 423 */         return deleteRowWithNull(paramRowSet, paramOracleRow);
/*     */       }
/* 425 */       Object object = paramOracleRow.getColumn(b);
/* 426 */       if (object == null) {
/* 427 */         this.deleteStmt.setNull(b, this.rsmd.getColumnType(b));
/*     */       } else {
/* 429 */         this.deleteStmt.setObject(b, object);
/*     */       } 
/*     */     } 
/* 432 */     return (this.deleteStmt.executeUpdate() == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean deleteRowWithNull(RowSet paramRowSet, OracleRow paramOracleRow) throws SQLException {
/* 442 */     boolean bool = false;
/* 443 */     StringBuffer stringBuffer = new StringBuffer("DELETE FROM " + getTableName(paramRowSet) + " WHERE ");
/*     */ 
/*     */     
/* 446 */     for (byte b = 1; b <= this.columnCount; b++) {
/*     */       
/* 448 */       if (b != 1)
/* 449 */         stringBuffer.append(" AND "); 
/* 450 */       if (paramOracleRow.isOriginalNull(b)) {
/* 451 */         stringBuffer.append(this.rsmd.getColumnName(b) + " IS NULL ");
/*     */       } else {
/* 453 */         stringBuffer.append(this.rsmd.getColumnName(b) + " = :" + b);
/*     */       } 
/*     */     } 
/* 456 */     PreparedStatement preparedStatement = null;
/*     */     
/*     */     try {
/* 459 */       preparedStatement = this.connection.prepareStatement(stringBuffer.substring(0, stringBuffer.length()));
/*     */ 
/*     */ 
/*     */       
/* 463 */       for (byte b1 = 1, b2 = 1; b1 <= this.columnCount; b1++) {
/*     */         
/* 465 */         if (!paramOracleRow.isOriginalNull(b1))
/*     */         {
/*     */           
/* 468 */           preparedStatement.setObject(b2++, paramOracleRow.getColumn(b1)); } 
/*     */       } 
/* 470 */       bool = (preparedStatement.executeUpdate() == 1) ? true : false;
/*     */     } finally {
/*     */       
/* 473 */       if (preparedStatement != null) {
/* 474 */         preparedStatement.close();
/*     */       }
/*     */     } 
/* 477 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean writeData(RowSetInternal paramRowSetInternal) throws SQLException {
/* 486 */     OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)paramRowSetInternal;
/* 487 */     this.connection = ((OracleCachedRowSetReader)oracleCachedRowSet.getReader()).getConnection(paramRowSetInternal);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 492 */     if (this.connection == null) {
/*     */       
/* 494 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 342);
/* 495 */       sQLException.fillInStackTrace();
/* 496 */       throw sQLException;
/*     */     } 
/*     */     
/* 499 */     if (this.connection.getAutoCommit()) {
/* 500 */       this.connection.setAutoCommit(false);
/*     */     }
/*     */     
/*     */     try {
/* 504 */       this.connection.setTransactionIsolation(oracleCachedRowSet.getTransactionIsolation());
/*     */     }
/* 506 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 511 */     initSQLStatement(oracleCachedRowSet);
/* 512 */     if (this.columnCount < 1) {
/*     */       
/* 514 */       this.connection.close();
/* 515 */       return true;
/*     */     } 
/* 517 */     boolean bool = oracleCachedRowSet.getShowDeleted();
/* 518 */     oracleCachedRowSet.setShowDeleted(true);
/* 519 */     oracleCachedRowSet.beforeFirst();
/* 520 */     boolean bool1 = true;
/* 521 */     boolean bool2 = true;
/* 522 */     boolean bool3 = true;
/* 523 */     OracleRow oracleRow = null;
/* 524 */     while (oracleCachedRowSet.next()) {
/*     */       
/* 526 */       if (oracleCachedRowSet.rowInserted()) {
/*     */ 
/*     */         
/* 529 */         if (oracleCachedRowSet.rowDeleted())
/*     */           continue; 
/* 531 */         oracleRow = oracleCachedRowSet.getCurrentRow();
/*     */         
/* 533 */         bool2 = (insertRow(oracleRow) || bool2) ? true : false; continue;
/*     */       } 
/* 535 */       if (oracleCachedRowSet.rowUpdated()) {
/*     */         
/* 537 */         oracleRow = oracleCachedRowSet.getCurrentRow();
/*     */         
/* 539 */         bool1 = (updateRow(oracleCachedRowSet, oracleRow) || bool1) ? true : false; continue;
/*     */       } 
/* 541 */       if (oracleCachedRowSet.rowDeleted()) {
/*     */         
/* 543 */         oracleRow = oracleCachedRowSet.getCurrentRow();
/*     */         
/* 545 */         bool3 = (deleteRow(oracleCachedRowSet, oracleRow) || bool3) ? true : false;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 552 */     if (bool1 && bool2 && bool3) {
/*     */ 
/*     */       
/* 555 */       this.connection.commit();
/*     */       
/* 557 */       oracleCachedRowSet.setOriginal();
/*     */     } else {
/*     */       
/* 560 */       this.connection.rollback();
/*     */     } 
/* 562 */     this.insertStmt.close();
/* 563 */     this.updateStmt.close();
/* 564 */     this.deleteStmt.close();
/*     */ 
/*     */ 
/*     */     
/* 568 */     if (!oracleCachedRowSet.isConnectionStayingOpen())
/*     */     {
/* 570 */       this.connection.close();
/*     */     }
/*     */     
/* 573 */     oracleCachedRowSet.setShowDeleted(bool);
/* 574 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 589 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 594 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleCachedRowSetWriter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */