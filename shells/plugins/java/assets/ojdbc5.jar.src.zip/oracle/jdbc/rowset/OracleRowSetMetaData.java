/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.RowSetMetaData;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleRowSetMetaData
/*     */   implements RowSetMetaData, Serializable
/*     */ {
/*     */   private int columnCount;
/*     */   private int[] nullable;
/*     */   private int[] columnDisplaySize;
/*     */   private int[] precision;
/*     */   private int[] scale;
/*     */   private int[] columnType;
/*     */   private boolean[] searchable;
/*     */   private boolean[] caseSensitive;
/*     */   private boolean[] readOnly;
/*     */   private boolean[] writable;
/*     */   private boolean[] definatelyWritable;
/*     */   private boolean[] currency;
/*     */   private boolean[] autoIncrement;
/*     */   private boolean[] signed;
/*     */   private String[] columnLabel;
/*     */   private String[] schemaName;
/*     */   private String[] columnName;
/*     */   private String[] tableName;
/*     */   private String[] columnTypeName;
/*     */   private String[] catalogName;
/*     */   private String[] columnClassName;
/*     */   
/*     */   OracleRowSetMetaData(int paramInt) throws SQLException {
/* 147 */     this.columnCount = paramInt;
/* 148 */     this.searchable = new boolean[this.columnCount];
/* 149 */     this.caseSensitive = new boolean[this.columnCount];
/* 150 */     this.readOnly = new boolean[this.columnCount];
/* 151 */     this.nullable = new int[this.columnCount];
/* 152 */     this.signed = new boolean[this.columnCount];
/* 153 */     this.columnDisplaySize = new int[this.columnCount];
/* 154 */     this.columnType = new int[this.columnCount];
/* 155 */     this.columnLabel = new String[this.columnCount];
/* 156 */     this.columnName = new String[this.columnCount];
/* 157 */     this.schemaName = new String[this.columnCount];
/* 158 */     this.precision = new int[this.columnCount];
/* 159 */     this.scale = new int[this.columnCount];
/* 160 */     this.tableName = new String[this.columnCount];
/* 161 */     this.columnTypeName = new String[this.columnCount];
/* 162 */     this.writable = new boolean[this.columnCount];
/* 163 */     this.definatelyWritable = new boolean[this.columnCount];
/* 164 */     this.currency = new boolean[this.columnCount];
/* 165 */     this.autoIncrement = new boolean[this.columnCount];
/* 166 */     this.catalogName = new String[this.columnCount];
/* 167 */     this.columnClassName = new String[this.columnCount];
/*     */     
/* 169 */     for (byte b = 0; b < this.columnCount; b++) {
/*     */       
/* 171 */       this.searchable[b] = false;
/* 172 */       this.caseSensitive[b] = false;
/* 173 */       this.readOnly[b] = false;
/* 174 */       this.nullable[b] = 1;
/* 175 */       this.signed[b] = false;
/* 176 */       this.columnDisplaySize[b] = 0;
/* 177 */       this.columnType[b] = 0;
/* 178 */       this.columnLabel[b] = "";
/* 179 */       this.columnName[b] = "";
/* 180 */       this.schemaName[b] = "";
/* 181 */       this.precision[b] = 0;
/* 182 */       this.scale[b] = 0;
/* 183 */       this.tableName[b] = "";
/* 184 */       this.columnTypeName[b] = "";
/* 185 */       this.writable[b] = false;
/* 186 */       this.definatelyWritable[b] = false;
/* 187 */       this.currency[b] = false;
/* 188 */       this.autoIncrement[b] = true;
/* 189 */       this.catalogName[b] = "";
/* 190 */       this.columnClassName[b] = "";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleRowSetMetaData(ResultSetMetaData paramResultSetMetaData) throws SQLException {
/* 201 */     this.columnCount = paramResultSetMetaData.getColumnCount();
/* 202 */     this.searchable = new boolean[this.columnCount];
/* 203 */     this.caseSensitive = new boolean[this.columnCount];
/* 204 */     this.readOnly = new boolean[this.columnCount];
/* 205 */     this.nullable = new int[this.columnCount];
/* 206 */     this.signed = new boolean[this.columnCount];
/* 207 */     this.columnDisplaySize = new int[this.columnCount];
/* 208 */     this.columnType = new int[this.columnCount];
/* 209 */     this.columnLabel = new String[this.columnCount];
/* 210 */     this.columnName = new String[this.columnCount];
/* 211 */     this.schemaName = new String[this.columnCount];
/* 212 */     this.precision = new int[this.columnCount];
/* 213 */     this.scale = new int[this.columnCount];
/* 214 */     this.tableName = new String[this.columnCount];
/* 215 */     this.columnTypeName = new String[this.columnCount];
/* 216 */     this.writable = new boolean[this.columnCount];
/* 217 */     this.definatelyWritable = new boolean[this.columnCount];
/* 218 */     this.currency = new boolean[this.columnCount];
/* 219 */     this.autoIncrement = new boolean[this.columnCount];
/* 220 */     this.catalogName = new String[this.columnCount];
/* 221 */     this.columnClassName = new String[this.columnCount];
/*     */     
/* 223 */     for (byte b = 0; b < this.columnCount; b++) {
/*     */       
/* 225 */       this.searchable[b] = paramResultSetMetaData.isSearchable(b + 1);
/* 226 */       this.caseSensitive[b] = paramResultSetMetaData.isCaseSensitive(b + 1);
/* 227 */       this.readOnly[b] = paramResultSetMetaData.isReadOnly(b + 1);
/* 228 */       this.nullable[b] = paramResultSetMetaData.isNullable(b + 1);
/* 229 */       this.signed[b] = paramResultSetMetaData.isSigned(b + 1);
/* 230 */       this.columnDisplaySize[b] = paramResultSetMetaData.getColumnDisplaySize(b + 1);
/* 231 */       this.columnType[b] = paramResultSetMetaData.getColumnType(b + 1);
/* 232 */       this.columnLabel[b] = paramResultSetMetaData.getColumnLabel(b + 1);
/* 233 */       this.columnName[b] = paramResultSetMetaData.getColumnName(b + 1);
/* 234 */       this.schemaName[b] = paramResultSetMetaData.getSchemaName(b + 1);
/*     */       
/* 236 */       if (this.columnType[b] == 2 || this.columnType[b] == 2 || this.columnType[b] == -5 || this.columnType[b] == 3 || this.columnType[b] == 8 || this.columnType[b] == 6 || this.columnType[b] == 4) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 244 */         this.precision[b] = paramResultSetMetaData.getPrecision(b + 1);
/* 245 */         this.scale[b] = paramResultSetMetaData.getScale(b + 1);
/*     */       }
/*     */       else {
/*     */         
/* 249 */         this.precision[b] = 0;
/* 250 */         this.scale[b] = 0;
/*     */       } 
/*     */       
/* 253 */       this.tableName[b] = paramResultSetMetaData.getTableName(b + 1);
/* 254 */       this.columnTypeName[b] = paramResultSetMetaData.getColumnTypeName(b + 1);
/* 255 */       this.writable[b] = paramResultSetMetaData.isWritable(b + 1);
/* 256 */       this.definatelyWritable[b] = paramResultSetMetaData.isDefinitelyWritable(b + 1);
/* 257 */       this.currency[b] = paramResultSetMetaData.isCurrency(b + 1);
/* 258 */       this.autoIncrement[b] = paramResultSetMetaData.isAutoIncrement(b + 1);
/* 259 */       this.catalogName[b] = paramResultSetMetaData.getCatalogName(b + 1);
/* 260 */       this.columnClassName[b] = paramResultSetMetaData.getColumnClassName(b + 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void validateColumnIndex(int paramInt) throws SQLException {
/* 271 */     if (paramInt < 1 || paramInt > this.columnCount) {
/*     */       
/* 273 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/* 274 */       sQLException.fillInStackTrace();
/* 275 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnCount() throws SQLException {
/* 291 */     return this.columnCount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement(int paramInt) throws SQLException {
/* 307 */     validateColumnIndex(paramInt);
/* 308 */     return this.autoIncrement[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive(int paramInt) throws SQLException {
/* 324 */     validateColumnIndex(paramInt);
/* 325 */     return this.caseSensitive[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSearchable(int paramInt) throws SQLException {
/* 341 */     validateColumnIndex(paramInt);
/* 342 */     return this.searchable[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrency(int paramInt) throws SQLException {
/* 358 */     validateColumnIndex(paramInt);
/* 359 */     return this.currency[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLException {
/* 376 */     validateColumnIndex(paramInt);
/* 377 */     return this.nullable[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSigned(int paramInt) throws SQLException {
/* 392 */     validateColumnIndex(paramInt);
/* 393 */     return this.signed[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnDisplaySize(int paramInt) throws SQLException {
/* 410 */     validateColumnIndex(paramInt);
/* 411 */     return this.columnDisplaySize[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnLabel(int paramInt) throws SQLException {
/* 428 */     validateColumnIndex(paramInt);
/* 429 */     return this.columnLabel[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnName(int paramInt) throws SQLException {
/* 445 */     validateColumnIndex(paramInt);
/* 446 */     return this.columnName[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchemaName(int paramInt) throws SQLException {
/* 462 */     validateColumnIndex(paramInt);
/* 463 */     return this.schemaName[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision(int paramInt) throws SQLException {
/* 479 */     validateColumnIndex(paramInt);
/* 480 */     return this.precision[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale(int paramInt) throws SQLException {
/* 496 */     validateColumnIndex(paramInt);
/* 497 */     return this.scale[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName(int paramInt) throws SQLException {
/* 513 */     validateColumnIndex(paramInt);
/* 514 */     return this.tableName[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalogName(int paramInt) throws SQLException {
/* 530 */     validateColumnIndex(paramInt);
/* 531 */     return this.catalogName[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnType(int paramInt) throws SQLException {
/* 548 */     validateColumnIndex(paramInt);
/* 549 */     return this.columnType[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnTypeName(int paramInt) throws SQLException {
/* 566 */     validateColumnIndex(paramInt);
/* 567 */     return this.columnTypeName[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(int paramInt) throws SQLException {
/* 583 */     validateColumnIndex(paramInt);
/* 584 */     return this.readOnly[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable(int paramInt) throws SQLException {
/* 600 */     validateColumnIndex(paramInt);
/* 601 */     return this.writable[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyWritable(int paramInt) throws SQLException {
/* 617 */     validateColumnIndex(paramInt);
/* 618 */     return this.definatelyWritable[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnClassName(int paramInt) throws SQLException {
/* 644 */     validateColumnIndex(paramInt);
/* 645 */     return this.columnClassName[paramInt - 1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoIncrement(int paramInt, boolean paramBoolean) throws SQLException {
/* 658 */     validateColumnIndex(paramInt);
/* 659 */     this.autoIncrement[paramInt - 1] = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCaseSensitive(int paramInt, boolean paramBoolean) throws SQLException {
/* 669 */     validateColumnIndex(paramInt);
/* 670 */     this.caseSensitive[paramInt - 1] = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCatalogName(int paramInt, String paramString) throws SQLException {
/* 680 */     validateColumnIndex(paramInt);
/* 681 */     this.catalogName[paramInt - 1] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnCount(int paramInt) throws SQLException {
/* 691 */     this.columnCount = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnDisplaySize(int paramInt1, int paramInt2) throws SQLException {
/* 701 */     validateColumnIndex(paramInt1);
/* 702 */     this.columnDisplaySize[paramInt1 - 1] = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnLabel(int paramInt, String paramString) throws SQLException {
/* 712 */     validateColumnIndex(paramInt);
/* 713 */     this.columnLabel[paramInt - 1] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnName(int paramInt, String paramString) throws SQLException {
/* 723 */     validateColumnIndex(paramInt);
/* 724 */     this.columnName[paramInt - 1] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnType(int paramInt1, int paramInt2) throws SQLException {
/* 734 */     validateColumnIndex(paramInt1);
/* 735 */     this.columnType[paramInt1 - 1] = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnTypeName(int paramInt, String paramString) throws SQLException {
/* 745 */     validateColumnIndex(paramInt);
/* 746 */     this.columnTypeName[paramInt - 1] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrency(int paramInt, boolean paramBoolean) throws SQLException {
/* 756 */     validateColumnIndex(paramInt);
/* 757 */     this.currency[paramInt - 1] = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNullable(int paramInt1, int paramInt2) throws SQLException {
/* 767 */     validateColumnIndex(paramInt1);
/* 768 */     this.nullable[paramInt1 - 1] = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPrecision(int paramInt1, int paramInt2) throws SQLException {
/* 778 */     validateColumnIndex(paramInt1);
/* 779 */     this.precision[paramInt1 - 1] = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScale(int paramInt1, int paramInt2) throws SQLException {
/* 789 */     validateColumnIndex(paramInt1);
/* 790 */     this.scale[paramInt1 - 1] = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSchemaName(int paramInt, String paramString) throws SQLException {
/* 800 */     validateColumnIndex(paramInt);
/* 801 */     this.schemaName[paramInt - 1] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSearchable(int paramInt, boolean paramBoolean) throws SQLException {
/* 811 */     validateColumnIndex(paramInt);
/* 812 */     this.searchable[paramInt - 1] = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSigned(int paramInt, boolean paramBoolean) throws SQLException {
/* 822 */     validateColumnIndex(paramInt);
/* 823 */     this.signed[paramInt - 1] = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableName(int paramInt, String paramString) throws SQLException {
/* 833 */     validateColumnIndex(paramInt);
/* 834 */     this.tableName[paramInt - 1] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 854 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 859 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleRowSetMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */