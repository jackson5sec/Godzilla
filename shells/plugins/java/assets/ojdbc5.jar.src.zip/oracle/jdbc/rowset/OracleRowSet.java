/*      */ package oracle.jdbc.rowset;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Vector;
/*      */ import javax.sql.RowSet;
/*      */ import javax.sql.RowSetEvent;
/*      */ import javax.sql.RowSetListener;
/*      */ import javax.sql.rowset.Joinable;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleRowSet
/*      */   implements Serializable, Cloneable, Joinable
/*      */ {
/*      */   protected String dataSource;
/*      */   protected String dataSourceName;
/*      */   protected String url;
/*      */   protected String username;
/*      */   protected String password;
/*      */   protected Map typeMap;
/*      */   protected int maxFieldSize;
/*      */   protected int maxRows;
/*      */   protected int queryTimeout;
/*      */   protected int fetchSize;
/*      */   protected int transactionIsolation;
/*      */   protected boolean escapeProcessing;
/*      */   protected String command;
/*      */   protected int concurrency;
/*      */   protected boolean readOnly;
/*      */   protected int fetchDirection;
/*      */   protected int rowsetType;
/*      */   protected boolean showDeleted;
/*      */   protected Vector listener;
/*      */   protected RowSetEvent rowsetEvent;
/*      */   protected Vector matchColumnIndexes;
/*      */   protected Vector matchColumnNames;
/*      */   protected boolean isClosed;
/*      */   
/*      */   protected OracleRowSet() throws SQLException {
/*  260 */     initializeProperties();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  265 */     this.matchColumnIndexes = new Vector(10);
/*  266 */     this.matchColumnNames = new Vector(10);
/*      */     
/*  268 */     this.listener = new Vector();
/*  269 */     this.rowsetEvent = new RowSetEvent((RowSet)this);
/*      */     
/*  271 */     this.isClosed = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeProperties() {
/*  284 */     this.command = null;
/*  285 */     this.concurrency = 1007;
/*  286 */     this.dataSource = null;
/*  287 */     this.dataSourceName = null;
/*      */     
/*  289 */     this.escapeProcessing = true;
/*  290 */     this.fetchDirection = 1002;
/*  291 */     this.fetchSize = 0;
/*  292 */     this.maxFieldSize = 0;
/*  293 */     this.maxRows = 0;
/*  294 */     this.queryTimeout = 0;
/*  295 */     this.readOnly = false;
/*  296 */     this.showDeleted = false;
/*  297 */     this.transactionIsolation = 2;
/*  298 */     this.rowsetType = 1005;
/*  299 */     this.typeMap = new HashMap<Object, Object>();
/*  300 */     this.username = null;
/*  301 */     this.password = null;
/*  302 */     this.url = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCommand() {
/*  318 */     return this.command;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/*  327 */     return this.concurrency;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataSource() {
/*  338 */     return this.dataSource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataSourceName() {
/*  346 */     return this.dataSourceName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getEscapeProcessing() throws SQLException {
/*  355 */     return this.escapeProcessing;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/*  364 */     return this.fetchDirection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/*  373 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxFieldSize() throws SQLException {
/*  382 */     return this.maxFieldSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() throws SQLException {
/*  391 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getPassword() {
/*  399 */     return this.password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() throws SQLException {
/*  408 */     return this.queryTimeout;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getReadOnly() {
/*  416 */     return isReadOnly();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() {
/*  424 */     return this.readOnly;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getShowDeleted() {
/*  432 */     return this.showDeleted;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTransactionIsolation() {
/*  440 */     return this.transactionIsolation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/*  449 */     return this.rowsetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getTypeMap() throws SQLException {
/*  458 */     return this.typeMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUrl() {
/*  466 */     return this.url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getUsername() {
/*  474 */     return this.username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCommand(String paramString) throws SQLException {
/*  484 */     this.command = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConcurrency(int paramInt) throws SQLException {
/*  494 */     if (paramInt == 1007 || paramInt == 1008) {
/*  495 */       this.concurrency = paramInt;
/*      */     } else {
/*      */       
/*  498 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  499 */       sQLException.fillInStackTrace();
/*  500 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDataSource(String paramString) {
/*  517 */     this.dataSource = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDataSourceName(String paramString) throws SQLException {
/*  527 */     this.dataSourceName = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
/*  537 */     this.escapeProcessing = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/*  553 */     this.fetchDirection = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/*  563 */     this.fetchSize = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxFieldSize(int paramInt) throws SQLException {
/*  574 */     this.maxFieldSize = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int paramInt) throws SQLException {
/*  584 */     this.maxRows = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPassword(String paramString) throws SQLException {
/*  594 */     this.password = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int paramInt) throws SQLException {
/*  604 */     this.queryTimeout = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadOnly(boolean paramBoolean) throws SQLException {
/*  615 */     this.readOnly = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShowDeleted(boolean paramBoolean) throws SQLException {
/*  625 */     this.showDeleted = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionIsolation(int paramInt) throws SQLException {
/*  635 */     this.transactionIsolation = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setType(int paramInt) throws SQLException {
/*  645 */     if (paramInt == 1003 || paramInt == 1004 || paramInt == 1005) {
/*      */ 
/*      */       
/*  648 */       this.rowsetType = paramInt;
/*      */     } else {
/*      */       
/*  651 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  652 */       sQLException.fillInStackTrace();
/*  653 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeMap(Map paramMap) throws SQLException {
/*  664 */     this.typeMap = paramMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUrl(String paramString) {
/*  673 */     this.url = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUsername(String paramString) throws SQLException {
/*  683 */     this.username = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addRowSetListener(RowSetListener paramRowSetListener) {
/*  703 */     for (byte b = 0; b < this.listener.size(); b++) {
/*  704 */       if (this.listener.elementAt(b).equals(paramRowSetListener))
/*      */         return; 
/*  706 */     }  this.listener.add(paramRowSetListener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeRowSetListener(RowSetListener paramRowSetListener) {
/*  715 */     for (byte b = 0; b < this.listener.size(); b++) {
/*  716 */       if (this.listener.elementAt(b).equals(paramRowSetListener)) {
/*  717 */         this.listener.remove(b);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void notifyCursorMoved() {
/*  731 */     int i = this.listener.size();
/*  732 */     if (i > 0) {
/*  733 */       for (byte b = 0; b < i; b++) {
/*  734 */         ((RowSetListener)this.listener.elementAt(b)).cursorMoved(this.rowsetEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyRowChanged() {
/*  747 */     int i = this.listener.size();
/*  748 */     if (i > 0) {
/*  749 */       for (byte b = 0; b < i; b++)
/*      */       {
/*  751 */         ((RowSetListener)this.listener.elementAt(b)).rowChanged(this.rowsetEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void notifyRowSetChanged() {
/*  765 */     int i = this.listener.size();
/*  766 */     if (i > 0) {
/*  767 */       for (byte b = 0; b < i; b++)
/*      */       {
/*  769 */         ((RowSetListener)this.listener.elementAt(b)).rowSetChanged(this.rowsetEvent);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getMatchColumnIndexes() throws SQLException {
/*      */     int[] arrayOfInt;
/*  798 */     if (this.matchColumnIndexes.size() == 0 && this.matchColumnNames.size() == 0) {
/*      */       
/*  800 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
/*  801 */       sQLException.fillInStackTrace();
/*  802 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  808 */     if (this.matchColumnNames.size() > 0) {
/*      */       
/*  810 */       String[] arrayOfString = getMatchColumnNames();
/*  811 */       int i = arrayOfString.length;
/*  812 */       arrayOfInt = new int[i];
/*      */       
/*  814 */       for (byte b = 0; b < i; b++)
/*      */       {
/*  816 */         arrayOfInt[b] = findColumn(arrayOfString[b]);
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  821 */       int i = this.matchColumnIndexes.size();
/*  822 */       arrayOfInt = new int[i];
/*  823 */       int j = -1;
/*      */       
/*  825 */       for (byte b = 0; b < i; b++) {
/*      */ 
/*      */         
/*      */         try {
/*  829 */           j = ((Integer)this.matchColumnIndexes.get(b)).intValue();
/*      */         
/*      */         }
/*  832 */         catch (Exception exception) {
/*      */ 
/*      */           
/*  835 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
/*  836 */           sQLException.fillInStackTrace();
/*  837 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  843 */         if (j <= 0) {
/*      */ 
/*      */           
/*  846 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
/*  847 */           sQLException.fillInStackTrace();
/*  848 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  854 */         arrayOfInt[b] = j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  859 */     return arrayOfInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String[] getMatchColumnNames() throws SQLException {
/*  878 */     checkIfMatchColumnNamesSet();
/*      */     
/*  880 */     int i = this.matchColumnNames.size();
/*  881 */     String[] arrayOfString = new String[i];
/*  882 */     String str = null;
/*      */     
/*  884 */     for (byte b = 0; b < i; b++) {
/*      */ 
/*      */       
/*      */       try {
/*  888 */         str = this.matchColumnNames.get(b);
/*      */       
/*      */       }
/*  891 */       catch (Exception exception) {
/*      */ 
/*      */         
/*  894 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 337);
/*  895 */         sQLException.fillInStackTrace();
/*  896 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  902 */       if (str == null || str.equals("")) {
/*      */ 
/*      */         
/*  905 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 337);
/*  906 */         sQLException.fillInStackTrace();
/*  907 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  913 */       arrayOfString[b] = str;
/*      */     } 
/*      */ 
/*      */     
/*  917 */     return arrayOfString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMatchColumn(int paramInt) throws SQLException {
/*  936 */     if (paramInt <= 0) {
/*      */ 
/*      */       
/*  939 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
/*  940 */       sQLException.fillInStackTrace();
/*  941 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  948 */       this.matchColumnIndexes.clear();
/*  949 */       this.matchColumnNames.clear();
/*      */       
/*  951 */       this.matchColumnIndexes.add(0, Integer.valueOf(paramInt));
/*      */     
/*      */     }
/*  954 */     catch (Exception exception) {
/*      */ 
/*      */       
/*  957 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 338);
/*  958 */       sQLException.fillInStackTrace();
/*  959 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMatchColumn(int[] paramArrayOfint) throws SQLException {
/*  982 */     this.matchColumnIndexes.clear();
/*  983 */     this.matchColumnNames.clear();
/*      */     
/*  985 */     if (paramArrayOfint == null) {
/*      */ 
/*      */       
/*  988 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  989 */       sQLException.fillInStackTrace();
/*  990 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  994 */     for (byte b = 0; b < paramArrayOfint.length; b++) {
/*      */       
/*  996 */       if (paramArrayOfint[b] <= 0) {
/*      */ 
/*      */         
/*  999 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
/* 1000 */         sQLException.fillInStackTrace();
/* 1001 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1007 */         this.matchColumnIndexes.add(b, Integer.valueOf(paramArrayOfint[b]));
/*      */       
/*      */       }
/* 1010 */       catch (Exception exception) {
/*      */ 
/*      */         
/* 1013 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 338);
/* 1014 */         sQLException.fillInStackTrace();
/* 1015 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMatchColumn(String paramString) throws SQLException {
/* 1039 */     if (paramString == null || paramString.equals("")) {
/*      */ 
/*      */       
/* 1042 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1043 */       sQLException.fillInStackTrace();
/* 1044 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1051 */       this.matchColumnIndexes.clear();
/* 1052 */       this.matchColumnNames.clear();
/*      */       
/* 1054 */       this.matchColumnNames.add(0, paramString.trim());
/*      */     
/*      */     }
/* 1057 */     catch (Exception exception) {
/*      */ 
/*      */       
/* 1060 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 339);
/* 1061 */       sQLException.fillInStackTrace();
/* 1062 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMatchColumn(String[] paramArrayOfString) throws SQLException {
/* 1086 */     this.matchColumnIndexes.clear();
/* 1087 */     this.matchColumnNames.clear();
/*      */     
/* 1089 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*      */       
/* 1091 */       if (paramArrayOfString[b] == null || paramArrayOfString[b].equals("")) {
/*      */ 
/*      */         
/* 1094 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1095 */         sQLException.fillInStackTrace();
/* 1096 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1102 */         this.matchColumnNames.add(b, paramArrayOfString[b].trim());
/*      */       
/*      */       }
/* 1105 */       catch (Exception exception) {
/*      */ 
/*      */         
/* 1108 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 339);
/* 1109 */         sQLException.fillInStackTrace();
/* 1110 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMatchColumn(int paramInt) throws SQLException {
/* 1134 */     checkIfMatchColumnIndexesSet();
/*      */     
/* 1136 */     if (paramInt <= 0) {
/*      */ 
/*      */       
/* 1139 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
/* 1140 */       sQLException.fillInStackTrace();
/* 1141 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1145 */     int i = -1;
/*      */ 
/*      */     
/*      */     try {
/* 1149 */       i = ((Integer)this.matchColumnIndexes.get(0)).intValue();
/*      */     
/*      */     }
/* 1152 */     catch (Exception exception) {
/*      */ 
/*      */       
/* 1155 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
/* 1156 */       sQLException.fillInStackTrace();
/* 1157 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1162 */     if (i != paramInt) {
/*      */ 
/*      */       
/* 1165 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 340);
/* 1166 */       sQLException.fillInStackTrace();
/* 1167 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1172 */     this.matchColumnIndexes.clear();
/* 1173 */     this.matchColumnNames.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMatchColumn(int[] paramArrayOfint) throws SQLException {
/* 1192 */     checkIfMatchColumnIndexesSet();
/*      */     
/* 1194 */     if (paramArrayOfint == null) {
/*      */ 
/*      */       
/* 1197 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1198 */       sQLException.fillInStackTrace();
/* 1199 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1203 */     int i = -1;
/*      */     
/* 1205 */     for (byte b = 0; b < paramArrayOfint.length; b++) {
/*      */       
/* 1207 */       if (paramArrayOfint[b] <= 0) {
/*      */ 
/*      */         
/* 1210 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 336);
/* 1211 */         sQLException.fillInStackTrace();
/* 1212 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1218 */         i = ((Integer)this.matchColumnIndexes.get(b)).intValue();
/*      */       
/*      */       }
/* 1221 */       catch (Exception exception) {
/*      */ 
/*      */         
/* 1224 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
/* 1225 */         sQLException.fillInStackTrace();
/* 1226 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1231 */       if (i != paramArrayOfint[b]) {
/*      */ 
/*      */         
/* 1234 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 340);
/* 1235 */         sQLException.fillInStackTrace();
/* 1236 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1242 */     this.matchColumnIndexes.clear();
/* 1243 */     this.matchColumnNames.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMatchColumn(String paramString) throws SQLException {
/* 1263 */     checkIfMatchColumnNamesSet();
/*      */     
/* 1265 */     if (paramString == null || paramString.equals("")) {
/*      */ 
/*      */       
/* 1268 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1269 */       sQLException.fillInStackTrace();
/* 1270 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1274 */     String str = null;
/*      */ 
/*      */     
/*      */     try {
/* 1278 */       str = this.matchColumnNames.get(0);
/*      */     
/*      */     }
/* 1281 */     catch (Exception exception) {
/*      */ 
/*      */       
/* 1284 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 335);
/* 1285 */       sQLException.fillInStackTrace();
/* 1286 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1292 */     if (!str.equals(paramString.trim())) {
/*      */ 
/*      */       
/* 1295 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 341);
/* 1296 */       sQLException.fillInStackTrace();
/* 1297 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1302 */     this.matchColumnIndexes.clear();
/* 1303 */     this.matchColumnNames.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unsetMatchColumn(String[] paramArrayOfString) throws SQLException {
/* 1322 */     checkIfMatchColumnNamesSet();
/*      */     
/* 1324 */     if (paramArrayOfString == null) {
/*      */ 
/*      */       
/* 1327 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1328 */       sQLException.fillInStackTrace();
/* 1329 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1333 */     String str = null;
/*      */     
/* 1335 */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*      */       
/* 1337 */       if (paramArrayOfString[b] == null || paramArrayOfString[b].equals("")) {
/*      */ 
/*      */         
/* 1340 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 1341 */         sQLException.fillInStackTrace();
/* 1342 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1348 */         str = this.matchColumnNames.get(b);
/*      */       
/*      */       }
/* 1351 */       catch (Exception exception) {
/*      */ 
/*      */         
/* 1354 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 335);
/* 1355 */         sQLException.fillInStackTrace();
/* 1356 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1362 */       if (!str.equals(paramArrayOfString[b])) {
/*      */ 
/*      */         
/* 1365 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 341);
/* 1366 */         sQLException.fillInStackTrace();
/* 1367 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1373 */     this.matchColumnIndexes.clear();
/* 1374 */     this.matchColumnNames.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkIfMatchColumnIndexesSet() throws SQLException {
/* 1389 */     if (this.matchColumnIndexes.size() == 0) {
/*      */       
/* 1391 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 334);
/* 1392 */       sQLException.fillInStackTrace();
/* 1393 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkIfMatchColumnNamesSet() throws SQLException {
/* 1405 */     if (this.matchColumnNames.size() == 0) {
/*      */       
/* 1407 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 335);
/* 1408 */       sQLException.fillInStackTrace();
/* 1409 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int findColumn(String paramString) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract ResultSetMetaData getMetaData() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   abstract String getTableName() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1434 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1439 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\rowset\OracleRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */