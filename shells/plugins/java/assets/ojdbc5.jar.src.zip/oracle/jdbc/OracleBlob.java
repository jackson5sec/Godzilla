package oracle.jdbc;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

public interface OracleBlob extends Blob {
  void open(LargeObjectAccessMode paramLargeObjectAccessMode) throws SQLException;
  
  void close() throws SQLException;
  
  boolean isOpen() throws SQLException;
  
  int getBytes(long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
  
  boolean isEmptyLob() throws SQLException;
  
  boolean isSecureFile() throws SQLException;
  
  InputStream getBinaryStream(long paramLong) throws SQLException;
  
  boolean isTemporary() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\OracleBlob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */