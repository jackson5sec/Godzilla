package oracle.jdbc.internal;

public interface ClientDataSupport {
  Object getClientData(Object paramObject);
  
  Object setClientData(Object paramObject1, Object paramObject2);
  
  Object removeClientData(Object paramObject);
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\internal\ClientDataSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */