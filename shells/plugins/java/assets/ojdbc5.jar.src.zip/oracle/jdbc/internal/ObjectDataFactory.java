package oracle.jdbc.internal;

public interface ObjectDataFactory {}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\internal\ObjectDataFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */