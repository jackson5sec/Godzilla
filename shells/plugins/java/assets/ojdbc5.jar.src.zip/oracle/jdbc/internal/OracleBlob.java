package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.SQLException;
import oracle.jdbc.OracleBlob;
import oracle.sql.BlobDBAccess;

public interface OracleBlob extends OracleDatumWithConnection, OracleBlob {
  Object toJdbc() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  int putBytes(long paramLong, byte[] paramArrayOfbyte) throws SQLException;
  
  int putBytes(long paramLong, byte[] paramArrayOfbyte, int paramInt) throws SQLException;
  
  OutputStream getBinaryOutputStream() throws SQLException;
  
  OutputStream getBinaryOutputStream(long paramLong) throws SQLException;
  
  Reader characterStreamValue() throws SQLException;
  
  InputStream asciiStreamValue() throws SQLException;
  
  InputStream binaryStreamValue() throws SQLException;
  
  byte[] getLocator();
  
  void setLocator(byte[] paramArrayOfbyte);
  
  int getChunkSize() throws SQLException;
  
  int getBufferSize() throws SQLException;
  
  void trim(long paramLong) throws SQLException;
  
  Object makeJdbcArray(int paramInt);
  
  BlobDBAccess getDBAccess() throws SQLException;
  
  Connection getJavaSqlConnection() throws SQLException;
  
  void setLength(long paramLong);
  
  void setChunkSize(int paramInt);
  
  void setPrefetchedData(byte[] paramArrayOfbyte);
  
  void setPrefetchedData(byte[] paramArrayOfbyte, int paramInt);
  
  byte[] getPrefetchedData();
  
  int getPrefetchedDataSize();
  
  void setActivePrefetch(boolean paramBoolean);
  
  void clearCachedData();
  
  boolean isActivePrefetch();
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\internal\OracleBlob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */