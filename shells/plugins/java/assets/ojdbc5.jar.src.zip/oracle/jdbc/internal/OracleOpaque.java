package oracle.jdbc.internal;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;
import oracle.jdbc.OracleOpaque;
import oracle.sql.OpaqueDescriptor;

public interface OracleOpaque extends OracleDatumWithConnection, OracleOpaque {
  OpaqueDescriptor getDescriptor() throws SQLException;
  
  void setDescriptor(OpaqueDescriptor paramOpaqueDescriptor);
  
  byte[] toBytes() throws SQLException;
  
  byte[] getBytesValue() throws SQLException;
  
  void setValue(byte[] paramArrayOfbyte) throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Object makeJdbcArray(int paramInt);
  
  Map getMap();
  
  Object toJdbc() throws SQLException;
  
  Object toJdbc(Map paramMap) throws SQLException;
  
  Object toClass(Class paramClass) throws SQLException;
  
  Object toClass(Class paramClass, Map paramMap) throws SQLException;
  
  void setImage(byte[] paramArrayOfbyte, long paramLong1, long paramLong2) throws SQLException;
  
  void setImageLength(long paramLong) throws SQLException;
  
  long getImageOffset();
  
  long getImageLength();
  
  Connection getJavaSqlConnection() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\internal\OracleOpaque.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */