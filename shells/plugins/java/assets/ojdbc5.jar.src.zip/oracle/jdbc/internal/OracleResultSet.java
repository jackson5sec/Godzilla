package oracle.jdbc.internal;

import java.sql.SQLException;
import oracle.jdbc.OracleResultSet;

public interface OracleResultSet extends OracleResultSet {
  void closeStatementOnClose() throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\internal\OracleResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */