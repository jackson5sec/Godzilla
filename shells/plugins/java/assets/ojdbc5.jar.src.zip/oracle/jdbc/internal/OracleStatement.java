/*     */ package oracle.jdbc.internal;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleStatement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface OracleStatement
/*     */   extends OracleStatement
/*     */ {
/*     */   public static final int DEFAULT_RSET_TYPE = 1;
/*     */   public static final int CLOSED = 0;
/*     */   public static final int ACTIVE = 1;
/*     */   public static final int CACHED = 2;
/*     */   public static final int NON_CACHED = 3;
/*     */   
/*     */   void setFixedString(boolean paramBoolean);
/*     */   
/*     */   boolean getFixedString();
/*     */   
/*     */   int sendBatch() throws SQLException;
/*     */   
/*     */   boolean getserverCursor();
/*     */   
/*     */   int getcacheState();
/*     */   
/*     */   int getstatementType();
/*     */   
/*     */   SqlKind getSqlKind() throws SQLException;
/*     */   
/*     */   long getChecksum() throws SQLException;
/*     */   
/*     */   void setSnapshotSCN(long paramLong) throws SQLException;
/*     */   
/*     */   public enum SqlKind
/*     */   {
/* 137 */     SELECT(false, false, true, false),
/* 138 */     DELETE(false, true, false, false),
/* 139 */     INSERT(false, true, false, false),
/* 140 */     MERGE(false, true, false, false),
/* 141 */     UPDATE(false, true, false, false),
/* 142 */     PLSQL_BLOCK(true, false, false, false),
/* 143 */     CALL_BLOCK(true, false, false, false),
/* 144 */     SELECT_FOR_UPDATE(false, false, true, false),
/* 145 */     ALTER_SESSION(false, false, false, true),
/* 146 */     OTHER(false, false, false, true),
/* 147 */     UNINITIALIZED(false, false, false, false);
/*     */     
/*     */     private final boolean dml;
/*     */     
/*     */     private final boolean plsqlOrCall;
/*     */     
/*     */     private final boolean select;
/*     */     
/*     */     private final boolean other;
/*     */ 
/*     */     
/*     */     SqlKind(boolean param1Boolean1, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
/* 159 */       this.dml = param1Boolean2;
/* 160 */       this.plsqlOrCall = param1Boolean1;
/* 161 */       this.select = param1Boolean3;
/* 162 */       this.other = param1Boolean4;
/*     */     }
/*     */     
/* 165 */     public boolean isPlsqlOrCall() { return this.plsqlOrCall; }
/* 166 */     public boolean isDML() { return this.dml; }
/* 167 */     public boolean isSELECT() { return this.select; } public boolean isOTHER() {
/* 168 */       return this.other;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\internal\OracleStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */