package oracle.jdbc;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Date;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import oracle.sql.ARRAY;
import oracle.sql.BFILE;
import oracle.sql.BINARY_DOUBLE;
import oracle.sql.BINARY_FLOAT;
import oracle.sql.BLOB;
import oracle.sql.CHAR;
import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.DATE;
import oracle.sql.Datum;
import oracle.sql.INTERVALDS;
import oracle.sql.INTERVALYM;
import oracle.sql.NUMBER;
import oracle.sql.OPAQUE;
import oracle.sql.ORAData;
import oracle.sql.ORADataFactory;
import oracle.sql.RAW;
import oracle.sql.REF;
import oracle.sql.ROWID;
import oracle.sql.STRUCT;
import oracle.sql.StructDescriptor;
import oracle.sql.TIMESTAMP;
import oracle.sql.TIMESTAMPLTZ;
import oracle.sql.TIMESTAMPTZ;

public interface OracleCallableStatement extends CallableStatement, OraclePreparedStatement {
  ARRAY getARRAY(int paramInt) throws SQLException;
  
  InputStream getAsciiStream(int paramInt) throws SQLException;
  
  BFILE getBFILE(int paramInt) throws SQLException;
  
  BFILE getBfile(int paramInt) throws SQLException;
  
  InputStream getBinaryStream(int paramInt) throws SQLException;
  
  InputStream getBinaryStream(String paramString) throws SQLException;
  
  BLOB getBLOB(int paramInt) throws SQLException;
  
  CHAR getCHAR(int paramInt) throws SQLException;
  
  Reader getCharacterStream(int paramInt) throws SQLException;
  
  CLOB getCLOB(int paramInt) throws SQLException;
  
  ResultSet getCursor(int paramInt) throws SQLException;
  
  Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException;
  
  Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException;
  
  Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException;
  
  Object getAnyDataEmbeddedObject(int paramInt) throws SQLException;
  
  DATE getDATE(int paramInt) throws SQLException;
  
  NUMBER getNUMBER(int paramInt) throws SQLException;
  
  OPAQUE getOPAQUE(int paramInt) throws SQLException;
  
  Datum getOracleObject(int paramInt) throws SQLException;
  
  RAW getRAW(int paramInt) throws SQLException;
  
  REF getREF(int paramInt) throws SQLException;
  
  ROWID getROWID(int paramInt) throws SQLException;
  
  STRUCT getSTRUCT(int paramInt) throws SQLException;
  
  INTERVALYM getINTERVALYM(int paramInt) throws SQLException;
  
  INTERVALDS getINTERVALDS(int paramInt) throws SQLException;
  
  TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException;
  
  TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException;
  
  TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException;
  
  InputStream getUnicodeStream(int paramInt) throws SQLException;
  
  InputStream getUnicodeStream(String paramString) throws SQLException;
  
  void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException;
  
  void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException;
  
  void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException;
  
  int sendBatch() throws SQLException;
  
  void setExecuteBatch(int paramInt) throws SQLException;
  
  Object getPlsqlIndexTable(int paramInt) throws SQLException;
  
  Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException;
  
  Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException;
  
  void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException;
  
  void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException;
  
  void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException;
  
  void setStringForClob(String paramString1, String paramString2) throws SQLException;
  
  void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException;
  
  void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException;
  
  void setNull(String paramString1, int paramInt, String paramString2) throws SQLException;
  
  void setNull(String paramString, int paramInt) throws SQLException;
  
  void setBoolean(String paramString, boolean paramBoolean) throws SQLException;
  
  void setByte(String paramString, byte paramByte) throws SQLException;
  
  void setShort(String paramString, short paramShort) throws SQLException;
  
  void setInt(String paramString, int paramInt) throws SQLException;
  
  void setLong(String paramString, long paramLong) throws SQLException;
  
  void setFloat(String paramString, float paramFloat) throws SQLException;
  
  void setBinaryFloat(String paramString, float paramFloat) throws SQLException;
  
  void setBinaryDouble(String paramString, double paramDouble) throws SQLException;
  
  void setDouble(String paramString, double paramDouble) throws SQLException;
  
  void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException;
  
  void setString(String paramString1, String paramString2) throws SQLException;
  
  void setFixedCHAR(String paramString1, String paramString2) throws SQLException;
  
  void setCursor(String paramString, ResultSet paramResultSet) throws SQLException;
  
  void setROWID(String paramString, ROWID paramROWID) throws SQLException;
  
  void setRAW(String paramString, RAW paramRAW) throws SQLException;
  
  void setCHAR(String paramString, CHAR paramCHAR) throws SQLException;
  
  void setDATE(String paramString, DATE paramDATE) throws SQLException;
  
  void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException;
  
  void setBLOB(String paramString, BLOB paramBLOB) throws SQLException;
  
  void setBlob(String paramString, Blob paramBlob) throws SQLException;
  
  void setCLOB(String paramString, CLOB paramCLOB) throws SQLException;
  
  void setClob(String paramString, Clob paramClob) throws SQLException;
  
  void setBFILE(String paramString, BFILE paramBFILE) throws SQLException;
  
  void setBfile(String paramString, BFILE paramBFILE) throws SQLException;
  
  void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException;
  
  void setDate(String paramString, Date paramDate) throws SQLException;
  
  void setTime(String paramString, Time paramTime) throws SQLException;
  
  void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException;
  
  void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException;
  
  void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException;
  
  void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException;
  
  void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException;
  
  void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException;
  
  void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException;
  
  void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException;
  
  void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException;
  
  void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException;
  
  void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException;
  
  void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException;
  
  void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException;
  
  void setURL(String paramString, URL paramURL) throws SQLException;
  
  void setArray(String paramString, Array paramArray) throws SQLException;
  
  void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException;
  
  void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException;
  
  void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException;
  
  void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException;
  
  void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException;
  
  void setORAData(String paramString, ORAData paramORAData) throws SQLException;
  
  void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException;
  
  void setObject(String paramString, Object paramObject, int paramInt) throws SQLException;
  
  void setRefType(String paramString, REF paramREF) throws SQLException;
  
  void setRef(String paramString, Ref paramRef) throws SQLException;
  
  void setREF(String paramString, REF paramREF) throws SQLException;
  
  void setObject(String paramString, Object paramObject) throws SQLException;
  
  void setOracleObject(String paramString, Datum paramDatum) throws SQLException;
}


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\jdbc\OracleCallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */