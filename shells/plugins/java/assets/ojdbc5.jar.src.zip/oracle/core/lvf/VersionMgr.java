/*     */ package oracle.core.lvf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class VersionMgr
/*     */ {
/*     */   public static final byte ALPHA = 1;
/*     */   public static final byte BETA = 2;
/*     */   public static final byte PROD = 3;
/*     */   public static final byte NONE = 4;
/*  57 */   private final byte MAX_LEN = 64;
/*  58 */   private final byte MAX_PRODLEN = 30;
/*  59 */   private final byte MAX_VERLEN = 15;
/*  60 */   private final byte MAX_DISTLEN = 5;
/*  61 */   private final String alpha = "Alpha";
/*  62 */   private final String beta = "Beta";
/*  63 */   private final String prod = "Production";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVersion(String paramString1, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4, byte paramByte5, char paramChar, String paramString2, byte paramByte6, int paramInt) {
/*     */     String str1;
/*  88 */     char[] arrayOfChar = new char[64];
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     String str2 = "";
/*     */     
/*     */     byte b3;
/*  96 */     if ((b3 = (byte)paramString1.length()) > 30) {
/*  97 */       b3 = 30;
/*     */     }
/*     */     
/* 100 */     byte b2 = 0;
/* 101 */     for (b3 = (byte)(b3 - 1); 0 < b3; ) {
/*     */       
/* 103 */       arrayOfChar[b2] = paramString1.charAt(b2);
/* 104 */       b2 = (byte)(b2 + 1);
/*     */     } 
/*     */ 
/*     */     
/* 108 */     b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
/*     */ 
/*     */     
/* 111 */     if (paramByte1 < 0)
/* 112 */       paramByte1 = 0; 
/* 113 */     if (paramByte2 < 0)
/* 114 */       paramByte2 = 0; 
/* 115 */     if (paramByte3 < 0)
/* 116 */       paramByte3 = 0; 
/* 117 */     if (paramByte4 < 0)
/* 118 */       paramByte4 = 0; 
/* 119 */     if (paramByte5 < 0) {
/* 120 */       paramByte5 = 0;
/*     */     }
/*     */     
/* 123 */     if (paramByte1 > 99)
/* 124 */       paramByte1 = 99; 
/* 125 */     if (paramByte2 > 99)
/* 126 */       paramByte2 = 99; 
/* 127 */     if (paramByte3 > 99)
/* 128 */       paramByte3 = 99; 
/* 129 */     if (paramByte4 > 99)
/* 130 */       paramByte4 = 99; 
/* 131 */     if (paramByte5 > 99) {
/* 132 */       paramByte5 = 99;
/*     */     }
/*     */     
/* 135 */     if (paramChar != '\000') {
/* 136 */       str1 = paramByte1 + "." + paramByte2 + "." + paramByte3 + "." + paramByte4 + "." + paramByte5 + paramChar;
/*     */     } else {
/* 138 */       str1 = paramByte1 + "." + paramByte2 + "." + paramByte3 + "." + paramByte4 + "." + paramByte5;
/* 139 */     }  byte b4 = (byte)str1.length();
/*     */ 
/*     */     
/* 142 */     byte b1 = 0;
/* 143 */     for (b4 = (byte)(b4 - 1); 0 < b4; ) {
/* 144 */       b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = str1.charAt(b1);
/*     */     } 
/* 146 */     if (paramByte6 != 4) {
/*     */ 
/*     */       
/* 149 */       b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
/*     */       
/* 151 */       if (paramString2 != null) {
/*     */         
/* 153 */         byte b5 = 0;
/*     */ 
/*     */         
/* 156 */         if ((b5 = (byte)paramString2.length()) > 5) {
/* 157 */           b5 = 5;
/*     */         }
/*     */         
/* 160 */         b1 = 0;
/* 161 */         for (b5 = (byte)(b5 - 1); 0 < b5; ) {
/* 162 */           b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = paramString2.charAt(b1);
/*     */         } 
/*     */         
/* 165 */         b2 = (byte)(b2 + 1); arrayOfChar[b2] = '\t';
/*     */       } 
/*     */ 
/*     */       
/* 169 */       switch (paramByte6) {
/*     */         
/*     */         case 1:
/* 172 */           str2 = "Alpha";
/*     */           break;
/*     */         case 2:
/* 175 */           str2 = "Beta";
/*     */           break;
/*     */         case 3:
/* 178 */           str2 = "Production";
/*     */           break;
/*     */       } 
/*     */       
/* 182 */       b1 = 0;
/* 183 */       byte b = (byte)str2.length();
/*     */ 
/*     */       
/* 186 */       for (b = (byte)(b - 1); 0 < b; ) {
/* 187 */         b2 = (byte)(b2 + 1); b1 = (byte)(b1 + 1); arrayOfChar[b2] = str2.charAt(b1);
/*     */       } 
/*     */     } 
/*     */     
/* 191 */     this.version = new String(arrayOfChar, 0, b2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVersion() {
/* 200 */     return this.version;
/*     */   }
/*     */ }


/* Location:              C:\User\\user\Downloads\godzilla.jar!\shells\plugins\java\assets\ojdbc5.jar!\oracle\core\lvf\VersionMgr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */